const {
  app,
  BrowserWindow,
  ipcMain,
  dialog,
  shell,
  Tray,
  Menu,
  nativeImage,
  safeStorage,
  screen,
  desktopCapturer,
  session
} = require('electron');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');
const { exec, execFile, spawn } = require('child_process');
const { createHash } = require('crypto');
const { withRelaySignature } = require('./relay-sign');

const APP_NAME = 'Auric Code';
const APP_ID = 'com.auric.code';

const startupLogDir = process.env.AURIC_E2E === '1' && process.env.AURIC_USER_DATA ? path.join(process.env.AURIC_USER_DATA, 'logs') : path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'Auric Code', 'logs');
try {
  fs.mkdirSync(startupLogDir, { recursive: true });
} catch {}
const startupLog = path.join(startupLogDir, 'main.log');
function logMain(...parts) {
  try {
    fs.appendFileSync(
      startupLog,
      `[${new Date().toISOString()}] ${parts.map(x => (x instanceof Error ? x.stack || x.message : String(x))).join(' ')}\n`
    );
  } catch {}
}
process.on('uncaughtException', err => {
  logMain('uncaughtException', err);
  try {
    dialog?.showErrorBox?.('Auric Code', `Error inesperado al iniciar.\n\n${err?.message || err}\n\nLog: ${startupLog}`);
  } catch {}
});
process.on('unhandledRejection', err => {
  logMain('unhandledRejection', err);
});
logMain('Starting Auric Code', process.version, process.execPath, process.argv.join(' | '));

app.setName(APP_NAME);
if (process.platform === 'win32') app.setAppUserModelId(APP_ID);
// Permite aislar el perfil (pruebas E2E) sin tocar los datos reales del usuario.
if (process.env.AURIC_USER_DATA) app.setPath('userData', process.env.AURIC_USER_DATA);
// Una sola instancia: dos procesos escribiendo el mismo storage.json corrompen chats y ajustes.
const gotSingleInstanceLock = process.env.AURIC_ALLOW_MULTI ? true : app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) {
  logMain('second instance detected; exiting');
  app.exit(0);
}
app.on('second-instance', () => {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
});

let mainWindow = null;
const approvedSavePaths = new Set();
let tray = null;
let forceQuit = false;
let rendererReady = false;
let dictationProc = null;
let previewRequestedSourceId = '';
require('./auric-native').register({ app, ipcMain, BrowserWindow });

// ── Conectores (plugins reales: MCP remoto + OAuth) ───────────────────────────────────────────
const { ConnectorManager } = require('./connectors');
let connectorManager = null;
function connectors() {
  if (!connectorManager)
    connectorManager = new ConnectorManager({
      dir: app.getPath('userData'),
      safeStorage,
      logosDir: path.join(__dirname, 'resources', 'connector-logos'),
      bundledGoogle: (() => {
        try {
          return JSON.parse(fs.readFileSync(path.join(__dirname, 'resources', 'google-oauth.json'), 'utf8'));
        } catch {
          return null;
        }
      })(),
      openExternal: async url => {
        const raw = String(url || '');
        if (process.env.AURIC_E2E === '1') {
          // Pruebas: el "navegador" sigue el /authorize del servidor simulado y entrega el código al receptor loopback.
          const r = await fetch(raw, { redirect: 'manual' });
          const loc = r.headers.get('location');
          if (loc) fetch(loc).catch(() => {});
          return;
        }
        if (!/^https:\/\//i.test(raw) && !/^http:\/\/(127\.0\.0\.1|localhost)[:/]/i.test(raw))
          throw new Error('URL de autorización no permitida.');
        return shell.openExternal(raw);
      },
      log: (...a) => logMain('connectors', ...a)
    });
  return connectorManager;
}
const wrapConnector =
  fn =>
  async (_e, ...args) => {
    try {
      return { ok: true, value: await fn(...args) };
    } catch (err) {
      logMain('connector error', err?.code, err?.message);
      return { ok: false, error: String(err?.message || err), code: err?.code || '' };
    }
  };
ipcMain.handle(
  'auric:connectors-catalog',
  wrapConnector(() => connectors().catalog())
);
ipcMain.handle(
  'auric:connectors-connect',
  wrapConnector((id, input) => connectors().connect(String(id), input || {}))
);
ipcMain.handle(
  'auric:connectors-cancel',
  wrapConnector(id => connectors().cancelPending(String(id)))
);
ipcMain.handle(
  'auric:connectors-disconnect',
  wrapConnector(id => connectors().disconnect(String(id)))
);
ipcMain.handle(
  'auric:connectors-remove-custom',
  wrapConnector(id => connectors().removeCustom(String(id)))
);
ipcMain.handle(
  'auric:connectors-list-tools',
  wrapConnector(id => connectors().listTools(String(id)))
);
ipcMain.handle(
  'auric:connectors-health',
  wrapConnector(id => connectors().health(String(id)))
);
ipcMain.handle(
  'auric:connectors-call-tool',
  wrapConnector((id, name, args) => connectors().callTool(String(id), String(name), args))
);
ipcMain.handle(
  'auric:connectors-add-custom',
  wrapConnector(input => connectors().addCustom(input || {}))
);

const dataFile = () => path.join(app.getPath('userData'), 'storage.json');
const secretsFile = () => path.join(app.getPath('userData'), 'secrets.json');
const iconPng = () => path.join(__dirname, 'resources', 'icons', 'auric-code.png');
const iconIco = () => path.join(__dirname, 'resources', 'icons', 'auric-code.ico');

function readJson(file, fallback = {}) {
  const tryRead = f => JSON.parse(fs.readFileSync(f, 'utf8'));
  try {
    return tryRead(file);
  } catch (err) {
    if (err?.code === 'ENOENT') return fallback;
    // El archivo existe pero está roto: se conserva una copia para diagnóstico y se intenta el último respaldo.
    logMain('readJson failed', file, err);
    try {
      fs.copyFileSync(file, `${file}.corrupt-${Date.now()}`);
    } catch {}
    for (const candidate of [`${file}.bak`, `${file}.bak2`]) {
      try {
        const recovered = tryRead(candidate);
        logMain('recovered state from', candidate);
        return recovered;
      } catch {}
    }
    return fallback;
  }
}
// Escritura atómica: temporal + fsync + rename. Nunca deja el JSON a medias. Respaldo rotativo (máx. 1 por minuto).
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const data = JSON.stringify(value, null, 2);
  const tmp = `${file}.${process.pid}.tmp`;
  const fd = fs.openSync(tmp, 'w');
  try {
    fs.writeSync(fd, data, 0, 'utf8');
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }
  try {
    if (fs.existsSync(file)) {
      const now = Date.now(),
        stampFile = `${file}.bak.stamp`;
      let last = 0;
      try {
        last = Number(fs.readFileSync(stampFile, 'utf8')) || 0;
      } catch {}
      if (now - last > 60000) {
        try {
          if (fs.existsSync(`${file}.bak`)) fs.copyFileSync(`${file}.bak`, `${file}.bak2`);
        } catch {}
        fs.copyFileSync(file, `${file}.bak`);
        fs.writeFileSync(stampFile, String(now));
      }
    }
  } catch (err) {
    logMain('backup rotation failed', err);
  }
  fs.renameSync(tmp, file);
}
function createTray() {
  if (tray) return;
  let image = nativeImage.createFromPath(iconPng());
  if (!image.isEmpty()) image = image.resize({ width: 16, height: 16 });
  tray = new Tray(image);
  tray.setToolTip(APP_NAME);
  tray.setContextMenu(
    Menu.buildFromTemplate([
      {
        label: 'Abrir Auric Code',
        click: () => {
          mainWindow?.show();
          mainWindow?.focus();
        }
      },
      { type: 'separator' },
      {
        label: 'Salir',
        click: () => {
          forceQuit = true;
          app.quit();
        }
      }
    ])
  );
  tray.on('double-click', () => {
    mainWindow?.show();
    mainWindow?.focus();
  });
}
function showFatalPage(title, details) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const safe = String(details || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const html = `<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#080a0f;color:#e8edf5;font:14px Segoe UI,Arial;padding:42px}main{max-width:760px;margin:auto;background:#10141c;border:1px solid #293244;border-radius:18px;padding:28px}h1{font-size:24px;margin:0 0 10px;color:#e9bd4b}pre{white-space:pre-wrap;background:#080b11;border:1px solid #222a39;padding:14px;border-radius:10px;color:#aeb8c9}button{background:#d6aa38;color:#0b0c0f;border:0;padding:10px 15px;border-radius:9px;font-weight:700;cursor:pointer}</style><main><h1>${title}</h1><p>Auric Code encontró un problema al cargar la interfaz. Este error se muestra en lugar de dejar una ventana en blanco.</p><pre>${safe}</pre><div style="display:flex;gap:10px"><button onclick="location.reload()">Reintentar</button><button style="background:#20283a;color:#e8edf5" onclick="window.auricDesktop&&window.auricDesktop.openLogs()">Abrir logs</button></div></main>`;
  mainWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html)).catch(() => {});
}
function configurePreviewCapture() {
  try {
    session.defaultSession.setDisplayMediaRequestHandler(
      async (_request, callback) => {
        try {
          const id = String(previewRequestedSourceId || '');
          if (!id) return callback({});
          const sources = await desktopCapturer.getSources({
            types: ['window', 'screen'],
            thumbnailSize: { width: 1, height: 1 },
            fetchWindowIcons: false
          });
          const source = sources.find(x => x.id === id);
          if (!source) return callback({});
          callback({ video: source });
        } catch (err) {
          logMain('display media handler failed', err);
          callback({});
        }
      },
      { useSystemPicker: false }
    );
  } catch (err) {
    logMain('setDisplayMediaRequestHandler failed', err);
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1480,
    height: 930,
    minWidth: 1050,
    minHeight: 680,
    show: true,
    backgroundColor: '#080a0f',
    autoHideMenuBar: true,
    title: APP_NAME,
    icon: iconIco(),
    titleBarStyle: process.platform === 'win32' ? 'hidden' : 'default',
    titleBarOverlay: process.platform === 'win32' ? { color: '#090b10', symbolColor: '#c7cfdb', height: 40 } : undefined,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false
    }
  });
  mainWindow.setMenuBarVisibility(false);
  mainWindow.webContents.on('did-fail-load', (_e, code, desc, url, isMainFrame) => {
    if (isMainFrame) showFatalPage('No se pudo cargar Auric Code', `Código: ${code}\n${desc}\n${url}`);
    else logMain(`subframe load failed ${code} ${desc} ${url}`);
  });
  mainWindow.webContents.on('render-process-gone', (_e, details) =>
    showFatalPage('El proceso de interfaz se cerró', `${details.reason || 'unknown'} (${details.exitCode ?? ''})`)
  );
  mainWindow.webContents.on('context-menu', (_e, params) => {
    const template = [];
    if (params.isEditable) {
      template.push(
        { role: 'undo', label: 'Deshacer' },
        { role: 'redo', label: 'Rehacer' },
        { type: 'separator' },
        { role: 'cut', label: 'Cortar' },
        { role: 'copy', label: 'Copiar' },
        { role: 'paste', label: 'Pegar' },
        { role: 'selectAll', label: 'Seleccionar todo' }
      );
    } else if (params.selectionText) {
      template.push({ role: 'copy', label: 'Copiar' }, { role: 'selectAll', label: 'Seleccionar todo' });
    }
    if (template.length) Menu.buildFromTemplate(template).popup({ window: mainWindow });
  });
  mainWindow.once('ready-to-show', () => {
    logMain('ready-to-show');
    mainWindow.show();
    mainWindow.focus();
  });
  mainWindow.webContents.on('did-finish-load', () => {
    logMain('did-finish-load');
    if (!mainWindow.isVisible()) mainWindow.show();
  });
  mainWindow.webContents.on('console-message', (_e, level, message, line, sourceId) =>
    logMain('renderer', level, message, `${sourceId}:${line}`)
  );
  setTimeout(() => {
    if (mainWindow && !mainWindow.isDestroyed() && !mainWindow.isVisible()) {
      logMain('forcing window visible after startup timeout');
      mainWindow.show();
      mainWindow.focus();
    }
  }, 1800);
  mainWindow.on('close', e => {
    if (forceQuit) return;
    if (!rendererReady || mainWindow.webContents.isCrashed()) return;
    e.preventDefault();
    mainWindow.webContents.send('auric:event', { name: 'windowClose' });
    setTimeout(() => {
      if (!mainWindow || mainWindow.isDestroyed()) return;
      if (mainWindow.isVisible()) {
        forceQuit = true;
        app.quit();
      }
    }, 1800);
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^(https?:|mailto:)/i.test(String(url || ''))) shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!String(url || '').startsWith('file://')) event.preventDefault();
  });
  const entry = path.join(__dirname, 'resources', 'index.html');
  logMain('Loading renderer', entry);
  mainWindow.loadFile(entry).catch(err => {
    logMain('loadFile failed', err);
    showFatalPage('No se pudo abrir la interfaz', err.stack || err.message);
    mainWindow.show();
  });
}

const SELF_TEST = process.argv.includes('--auric-self-test');

async function runSelfTest() {
  logMain('self-test start');
  const testWindow = new BrowserWindow({
    width: 1100,
    height: 720,
    show: false,
    backgroundColor: '#080a0f',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  const entry = path.join(__dirname, 'resources', 'index.html');
  let timer;
  try {
    await Promise.race([
      testWindow.loadFile(entry),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('timeout cargando index.html')), 12000);
      })
    ]);
    clearTimeout(timer);
    await new Promise(resolve => setTimeout(resolve, 1200));
    const result = await testWindow.webContents.executeJavaScript(
      `({
      desktop: !!window.auricDesktop,
      app: !!document.getElementById('app'),
      bootDone: !document.getElementById('bootGuard'),
      bodyText: (document.body?.innerText || '').slice(0, 160)
    })`,
      true
    );
    logMain('self-test renderer', JSON.stringify(result));
    if (!result.desktop || !result.app || !result.bootDone) throw new Error('renderer incompleto: ' + JSON.stringify(result));
    testWindow.destroy();
    logMain('self-test passed');
    console.log('AURIC_SELF_TEST_OK');
    app.exit(0);
  } catch (err) {
    clearTimeout(timer);
    logMain('self-test failed', err);
    console.error('AURIC_SELF_TEST_FAILED:', err?.stack || err?.message || String(err));
    try {
      testWindow.destroy();
    } catch {}
    app.exit(21);
  }
}

if (SELF_TEST) {
  app
    .whenReady()
    .then(runSelfTest)
    .catch(err => {
      logMain('self-test ready failed', err);
      app.exit(22);
    });
} else {
  app.whenReady().then(() => {
    logMain('app ready');
    configurePreviewCapture();
    createWindow();
    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
      else {
        mainWindow?.show();
        mainWindow?.focus();
      }
    });
  });
}
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin' && forceQuit) app.quit();
});
app.on('before-quit', () => {
  forceQuit = true;
  if (dictationProc) {
    try {
      dictationProc.kill();
    } catch {}
  }
});

ipcMain.handle('auric:renderer-ready', () => {
  rendererReady = true;
  return true;
});
ipcMain.handle('auric:storage-get', (_e, key) => readJson(dataFile(), {})[key] ?? null);
ipcMain.handle('auric:storage-set', (_e, key, value) => {
  const s = readJson(dataFile(), {});
  s[key] = value;
  writeJson(dataFile(), s);
  return true;
});
ipcMain.handle('auric:storage-remove', (_e, key) => {
  const s = readJson(dataFile(), {});
  delete s[key];
  writeJson(dataFile(), s);
  return true;
});
function secretSet(key, value) {
  const s = readJson(secretsFile(), {});
  if (!value) delete s[key];
  else if (safeStorage.isEncryptionAvailable()) s[key] = { encrypted: safeStorage.encryptString(String(value)).toString('base64') };
  else s[key] = { plain: String(value) };
  writeJson(secretsFile(), s);
  return true;
}
function secretGet(key) {
  const item = readJson(secretsFile(), {})[key];
  if (!item) return '';
  try {
    if (item.encrypted) return safeStorage.decryptString(Buffer.from(item.encrypted, 'base64'));
  } catch {}
  return item.plain || '';
}
// Las claves de los servicios de imágenes ('image:…') las guarda y las usa SOLO el proceso principal (image-gen.js): la pantalla
// nunca las lee de vuelta ni las escribe por aquí (solo por los canales «auric:images-*», que las validan).
const mainOnlySecret = key => /^(?:image:|benchmark:)/i.test(String(key || ''));
ipcMain.handle('auric:secret-set', (_e, key, value) => {
  if (mainOnlySecret(key)) throw new Error('Esa clave solo se guarda desde Ajustes → Imágenes.');
  return secretSet(key, value);
});
ipcMain.handle('auric:secret-get', (_e, key) => (mainOnlySecret(key) ? '' : secretGet(key)));

ipcMain.handle('auric:choose-folder', async (_e, title, defaultPath) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: title || 'Selecciona una carpeta',
    defaultPath: defaultPath || undefined,
    properties: ['openDirectory', 'createDirectory']
  });
  return result.canceled ? '' : result.filePaths[0] || '';
});
ipcMain.handle('auric:choose-files', async (_e, options = {}) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: options.title || 'Adjuntar archivos',
    defaultPath: options.defaultPath || undefined,
    properties: ['openFile', 'multiSelections'],
    filters: options.filters || [{ name: 'Todos los archivos', extensions: ['*'] }]
  });
  return result.canceled ? [] : result.filePaths;
});
ipcMain.handle('auric:preview-window-list', async () => {
  const sources = await desktopCapturer.getSources({
    types: ['window'],
    thumbnailSize: { width: 360, height: 220 },
    fetchWindowIcons: true
  });
  return sources
    .filter(x => x.name && x.id)
    .map(x => ({
      id: x.id,
      name: x.name,
      thumbnail: x.thumbnail?.isEmpty() ? '' : x.thumbnail.toPNG().toString('base64'),
      icon: x.appIcon?.isEmpty() ? '' : x.appIcon.toPNG().toString('base64')
    }));
});
ipcMain.handle('auric:preview-window-capture', async (_e, id) => {
  const sources = await desktopCapturer.getSources({
    types: ['window'],
    thumbnailSize: { width: 1600, height: 1000 },
    fetchWindowIcons: false
  });
  const src = sources.find(x => x.id === String(id));
  if (!src) throw new Error('La ventana seleccionada ya no está disponible.');
  return src.thumbnail.toPNG().toString('base64');
});
ipcMain.handle('auric:preview-window-stream-select', async (_e, id) => {
  const wanted = String(id || '');
  if (!wanted) {
    previewRequestedSourceId = '';
    return true;
  }
  const sources = await desktopCapturer.getSources({
    types: ['window', 'screen'],
    thumbnailSize: { width: 1, height: 1 },
    fetchWindowIcons: false
  });
  if (!sources.some(x => x.id === wanted)) throw new Error('La ventana seleccionada ya no está disponible.');
  previewRequestedSourceId = wanted;
  return true;
});
ipcMain.handle('auric:save-dialog', async (_e, options = {}) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: options.title || 'Guardar',
    defaultPath: options.defaultPath || undefined,
    filters: options.filters || undefined
  });
  const target = result.canceled ? '' : result.filePath || '';
  if (target) approvedSavePaths.add(path.resolve(target));
  return target;
});
ipcMain.handle('auric:export-text', async (_e, target, content) => {
  const abs = path.resolve(String(target || ''));
  if (!approvedSavePaths.has(abs)) throw new Error('La ruta de exportación no fue aprobada por el usuario.');
  approvedSavePaths.delete(abs);
  await fsp.mkdir(path.dirname(abs), { recursive: true });
  await fsp.writeFile(abs, String(content ?? ''), 'utf8');
  return true;
});
ipcMain.handle('auric:export-base64', async (_e, target, content) => {
  const abs = path.resolve(String(target || ''));
  if (!approvedSavePaths.has(abs)) throw new Error('La ruta de exportación no fue aprobada por el usuario.');
  approvedSavePaths.delete(abs);
  await fsp.mkdir(path.dirname(abs), { recursive: true });
  await fsp.writeFile(abs, Buffer.from(String(content || ''), 'base64'));
  return true;
});
ipcMain.handle('auric:confirm', async (_e, options = {}) => {
  const r = await dialog.showMessageBox(mainWindow, {
    type: options.type || 'question',
    title: options.title || APP_NAME,
    message: options.message || '',
    detail: options.detail || '',
    buttons: options.buttons || ['Cancelar', 'Aceptar'],
    defaultId: options.defaultId ?? 1,
    cancelId: options.cancelId ?? 0,
    noLink: true
  });
  return r.response;
});
ipcMain.handle('auric:input-dialog', async () => null); // UI uses its own styled prompt.

ipcMain.handle('auric:open-external', async (_e, url) => {
  const raw = String(url || '');
  let u;
  try {
    u = new URL(raw);
  } catch {
    throw new Error('Enlace externo no válido.');
  }
  if (!['http:', 'https:', 'mailto:'].includes(u.protocol)) throw new Error('Auric bloqueó un protocolo externo no permitido.');
  return shell.openExternal(raw);
});
ipcMain.handle('auric:open-path', (_e, target) => shell.openPath(String(target || '')));
ipcMain.handle('auric:show-item', (_e, target) => {
  shell.showItemInFolder(String(target || ''));
  return true;
});
ipcMain.handle('auric:notification', (_e, title, body) => {
  try {
    const area = screen.getPrimaryDisplay().workArea;
    const w = 360,
      h = 112;
    const win = new BrowserWindow({
      width: w,
      height: h,
      x: area.x + area.width - w - 18,
      y: area.y + area.height - h - 18,
      frame: false,
      resizable: false,
      skipTaskbar: true,
      alwaysOnTop: true,
      show: false,
      focusable: false,
      backgroundColor: '#10141c',
      webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false }
    });
    const safeTitle = String(title || APP_NAME).replace(
      /[&<>"']/g,
      c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]
    );
    const safeBody = String(body || '').replace(
      /[&<>"']/g,
      c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]
    );
    let logo = '';
    try {
      logo = fs.readFileSync(iconPng()).toString('base64');
    } catch {}
    const html = `<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#10141c;color:#e9edf5;font:13px Segoe UI,Arial;border:1px solid #303949;border-radius:12px;overflow:hidden}.n{display:flex;gap:12px;padding:14px 15px;align-items:center}.i{width:40px;height:40px;display:grid;place-items:center;flex:0 0 auto}.i img{width:40px;height:40px;object-fit:contain;filter:drop-shadow(0 5px 9px rgba(0,0,0,.35))}.c{min-width:0}.c b{display:block;font-size:14px;margin-bottom:4px}.c span{display:block;color:#b9c1cf;line-height:1.35}</style><div class=n><div class=i>${logo ? `<img src="data:image/png;base64,${logo}">` : '<b style="color:#d8ac3e;font-size:18px">◆</b>'}</div><div class=c><b>${safeTitle}</b><span>${safeBody}</span></div></div>`;
    win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
    win.once('ready-to-show', () => win.showInactive());
    setTimeout(() => {
      try {
        if (!win.isDestroyed()) win.close();
      } catch {}
    }, 5200);
  } catch {}
  return true;
});
ipcMain.handle('auric:tray-enable', () => {
  createTray();
  return true;
});
ipcMain.handle('auric:window-hide', () => {
  mainWindow?.hide();
  return true;
});
ipcMain.handle('auric:window-show', () => {
  mainWindow?.show();
  return true;
});
ipcMain.handle('auric:window-focus', () => {
  mainWindow?.focus();
  return true;
});
ipcMain.handle('auric:exit', () => {
  forceQuit = true;
  app.quit();
  return true;
});
ipcMain.handle('auric:open-logs', () => {
  shell.openPath(app.getPath('logs'));
  return app.getPath('logs');
});
ipcMain.handle('auric:app-info', () => ({
  version: app.getVersion(),
  name: APP_NAME,
  userData: app.getPath('userData'),
  platform: process.platform
}));
ipcMain.handle('auric:update-check', () => require('./updates').checkManifest());
ipcMain.handle('auric:update-install', async (_e, spec = {}) => {
  spec = require('./updates').validateRelease(spec);
  if (process.platform !== 'win32') throw new Error('El actualizador automático está disponible en Windows.');
  const url = String(spec.url || ''),
    expected = String(spec.sha256 || '').toLowerCase();
  if (!/^https:\/\//i.test(url)) throw new Error('La actualización debe descargarse por HTTPS.');
  if (!/^[a-f0-9]{64}$/.test(expected)) throw new Error('La actualización no tiene un SHA-256 válido.');
  const ctl = new AbortController(),
    timer = setTimeout(() => ctl.abort(), 180000);
  try {
    const res = await fetch(url, { redirect: 'follow', signal: ctl.signal });
    if (!res.ok) throw new Error(`No se pudo descargar la actualización (HTTP ${res.status}).`);
    const len = Number(res.headers.get('content-length') || 0);
    if (len > 220 * 1024 * 1024) throw new Error('La actualización supera el tamaño permitido.');
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length > 220 * 1024 * 1024) throw new Error('La actualización supera el tamaño permitido.');
    const got = createHash('sha256').update(buf).digest('hex');
    if (got !== expected) throw new Error('El SHA-256 de la actualización no coincide. Auric no la ejecutará.');
    require('./updates').verifyInstaller(buf, expected);
    const safeVersion = String(spec.version || 'update').replace(/[^0-9A-Za-z._-]/g, '-'),
      target = path.join(app.getPath('temp'), `Auric-Code-Setup-${safeVersion}.exe`);
    await fsp.writeFile(target, buf);
    const child = spawn(target, [], { detached: true, stdio: 'ignore', windowsHide: false });
    child.unref();
    setTimeout(() => {
      forceQuit = true;
      app.quit();
    }, 350);
    return true;
  } finally {
    clearTimeout(timer);
  }
});

ipcMain.handle('auric:gallery-import', async (_e, sourcePath) => {
  const src = String(sourcePath || '');
  if (!src) throw new Error('Ruta de archivo vacía.');
  const st = await fsp.stat(src);
  if (!st.isFile()) throw new Error('Solo se pueden importar archivos.');
  const dir = path.join(app.getPath('userData'), 'gallery');
  await fsp.mkdir(dir, { recursive: true });
  const ext = path.extname(src);
  const base =
    path
      .basename(src, ext)
      .replace(/[^a-zA-Z0-9._-]+/g, '_')
      .slice(0, 80) || 'asset';
  const dest = path.join(dir, `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${base}${ext}`);
  await fsp.copyFile(src, dest);
  return { path: dest, name: path.basename(src), size: st.size };
});
ipcMain.handle('auric:gallery-remove-file', async (_e, target) => {
  const p = String(target || '');
  const dir = path.resolve(path.join(app.getPath('userData'), 'gallery'));
  const abs = path.resolve(p);
  if (abs !== dir && !abs.startsWith(dir + path.sep)) throw new Error('Ruta de galería inválida.');
  await fsp.rm(abs, { force: true });
  return true;
});

ipcMain.handle('auric:fs-stats', async (_e, target) => {
  const st = await fsp.stat(String(target));
  return { size: st.size, isDirectory: st.isDirectory(), isFile: st.isFile(), mtimeMs: st.mtimeMs };
});
ipcMain.handle('auric:fs-exists', async (_e, target) => {
  try {
    await fsp.access(String(target));
    return true;
  } catch {
    return false;
  }
});
ipcMain.handle('auric:fs-read-dir', async (_e, target) => {
  const list = await fsp.readdir(String(target), { withFileTypes: true });
  return list.map(d => ({ entry: d.name, type: d.isDirectory() ? 'DIRECTORY' : 'FILE' }));
});
ipcMain.handle('auric:fs-read-file', (_e, target) => fsp.readFile(String(target), 'utf8'));
ipcMain.handle('auric:fs-read-base64', async (_e, target) => (await fsp.readFile(String(target))).toString('base64'));
ipcMain.handle('auric:path-join', (_e, ...parts) => path.join(...parts.map(String)));
ipcMain.handle('auric:path-basename', (_e, target) => path.basename(String(target || '')));

// La comprobación de direcciones privadas y la conexión "fijada" viven en net-safe.js (probadas con ataques reales).
const netSafe = require('./net-safe');
const modelStream = require('./model-stream');

ipcMain.handle('auric:is-e2e', () => process.env.AURIC_E2E === '1');
// Peticiones HTTP cancelables: el renderer envía un requestId y puede abortarlas (Detener, watchdog, cambio de ruta).
const activeHttp = new Map();
ipcMain.handle('auric:http-abort', (_e, requestId) => {
  const ctl = activeHttp.get(String(requestId || ''));
  if (!ctl) return localAI ? localAI.abortChat(requestId) : false; // también cancela un chat con Mi PC (Ollama) en curso
  ctl.userAborted = true;
  ctl.abort();
  return true;
});
const E2E_HTTP_MAP = (() => {
  if (process.env.AURIC_E2E !== '1' || !process.env.AURIC_E2E_HTTP_MAP) return null;
  try {
    return JSON.parse(process.env.AURIC_E2E_HTTP_MAP);
  } catch {
    return null;
  }
})();
// Mi PC (Ollama local), descargas con permiso y Git: cada módulo registra sus propios canales IPC.
let localAI = null;
let downloadManager = null;
let gitManager = null;
let browserAgent = null;
let pluginManager = null;
let imageGen = null;
const getMainWindow = () => mainWindow;
function registerNativeModules() {
  localAI = require('./local-ai').register({ app, ipcMain, shell, getWindow: getMainWindow, hostMap: E2E_HTTP_MAP });
  downloadManager = require('./downloads').register({ app, ipcMain, shell, getWindow: getMainWindow, hostMap: E2E_HTTP_MAP });
  gitManager = require('./git-tools').register({ app, ipcMain });
  require('./task-worktrees').register({ app, ipcMain });
  require('./desktop-control').register({ app, ipcMain, desktopCapturer });
  require('./model-intelligence').register({ app, ipcMain, hostMap: E2E_HTTP_MAP, secrets: { get: secretGet, set: (key, value) => { if (value && !safeStorage.isEncryptionAvailable()) throw new Error('El cifrado de claves no está disponible. No se guardó la clave.'); return secretSet(key, value); } } });
  // Navegador de la IA: ventana propia con sesión aislada (permiso por sitio, sin contraseñas ni pagos sin confirmar).
  browserAgent = require('./browser').register({ app, ipcMain, getWindow: getMainWindow, iconPath: () => iconIco() });
  // Plugins: paquetes (skills + servidores MCP + conectores + instrucciones) con revisión de seguridad al instalar.
  pluginManager = require('./plugins').register({
    app,
    ipcMain,
    safeStorage,
    shell,
    getWindow: getMainWindow,
    hostMap: E2E_HTTP_MAP,
    connectors,
    builtinConnectorIds: () => new Set(require('./connectors').BUILTIN_CONNECTORS.map(b => b.id)),
    appVersion: app.getVersion(),
    officialDir: path.join(__dirname, 'resources', 'official-plugins'),
    stopMcpPrefix: require('./auric-native').stopMcpPrefix,
    log: (...a) => logMain('plugins', ...a)
  });
  // Imágenes con IA (Cloudflare Workers AI / NVIDIA, capa gratis): las claves nunca salen del proceso principal.
  imageGen = require('./image-gen').register({
    app,
    ipcMain,
    hostMap: E2E_HTTP_MAP,
    secrets: { get: secretGet, set: secretSet },
    registerAbort: (id, ctl) => {
      activeHttp.set(id, ctl); // «Detener» corta también la creación de la imagen (auric:http-abort)
      return () => {
        if (activeHttp.get(id) === ctl) activeHttp.delete(id);
      };
    }
  });
}
registerNativeModules();
const flattenHeaders = headers => Object.fromEntries(Object.entries(headers || {}).map(([k, v]) => [k, Array.isArray(v) ? v.join(', ') : String(v)]));
// GET público: DNS fijado a las direcciones ya validadas, cada redirección se revalida y el cuerpo tiene tope de tamaño.
async function publicGet(current, verb, options, ctl, timeoutMs) {
  if (!['GET', 'HEAD'].includes(verb)) throw new Error('Solo se permiten peticiones GET a URLs públicas.');
  const hop = await netSafe.openSafe(current, {
    method: verb,
    headers: withRelaySignature(current, verb, { 'Accept-Encoding': 'gzip, deflate, br', ...(options.headers || {}) }),
    allowHttp: true,
    hostMap: E2E_HTTP_MAP,
    signal: ctl.signal,
    timeoutMs: Math.min(timeoutMs, 60000),
    maxRedirects: 5
  });
  const res = hop.res;
  ctl.signal.addEventListener('abort', () => res.destroy(), { once: true });
  const maxBytes = Math.min(Number(options.maxBytes) || 25 * 1024 * 1024, 64 * 1024 * 1024);
  const { buffer, truncated } = await netSafe.readLimited(netSafe.decodedStream(res), maxBytes);
  if (truncated) throw new Error('La respuesta supera el tamaño permitido.');
  if (ctl.signal.aborted) throw new Error('ABORTED');
  return {
    statusCode: res.statusCode,
    body: options.responseType === 'base64' ? buffer.toString('base64') : buffer.toString('utf8'),
    headers: flattenHeaders(res.headers),
    encoding: options.responseType === 'base64' ? 'base64' : 'utf8'
  };
}
ipcMain.handle('auric:http', async (_e, url, method, options = {}) => {
  const ctl = new AbortController();
  const requestId = options.requestId ? String(options.requestId) : '';
  const timeoutMs = Math.max(1000, Number(options.timeout || 180000));
  if (requestId) activeHttp.set(requestId, ctl);
  const timeout = setTimeout(() => {
    ctl.timedOut = true;
    ctl.abort();
  }, timeoutMs);
  try {
    let current = String(url);
    const verb = String(method || 'GET').toUpperCase();
    if (options.publicOnly) return await publicGet(current, verb, options, ctl, timeoutMs);
    // Solo pruebas E2E (AURIC_E2E=1 + AURIC_E2E_HTTP_MAP): redirige hosts concretos a un servidor local simulado.
    if (E2E_HTTP_MAP) {
      try {
        const u0 = new URL(current);
        if (E2E_HTTP_MAP[u0.host]) current = E2E_HTTP_MAP[u0.host] + u0.pathname + u0.search;
      } catch {}
    }
    const res = await fetch(current, {
      method: verb,
      headers: withRelaySignature(current, verb, options.headers || {}),
      body: options.body ?? undefined,
      signal: ctl.signal,
      redirect: 'follow'
    });
    const responseBody = options.responseType === 'base64' ? Buffer.from(await res.arrayBuffer()).toString('base64') : await res.text();
    return {
      statusCode: res.status,
      body: responseBody,
      headers: Object.fromEntries(res.headers.entries()),
      encoding: options.responseType === 'base64' ? 'base64' : 'utf8'
    };
  } catch (err) {
    // Errores tipificados en el mensaje (la serialización IPC pierde propiedades personalizadas).
    if (ctl.userAborted) throw new Error('ABORTED: petición cancelada.');
    if (ctl.timedOut) throw new Error(`ETIMEDOUT: timeout — el servidor no respondió en ${Math.round(timeoutMs / 1000)} s.`);
    if (
      /^(Demasiadas redirecciones|Auric bloque|Solo se permiten|URL pública|No se pudo resolver|La dirección|El sitio|El servidor|La respuesta)/.test(
        String(err?.message || '')
      )
    )
      throw err;
    const cause = err?.cause?.code || err?.cause?.message || err?.code || '';
    throw new Error(`NETWORK: fetch failed ${cause ? `(${cause}) ` : ''}${err?.message || err}`);
  } finally {
    clearTimeout(timeout);
    if (requestId) activeHttp.delete(requestId);
  }
});

// Llamadas a modelos con la respuesta POR PARTES (streaming). Ver model-stream.js: el tiempo máximo es de silencio (no de duración),
// lo recibido se conserva si la conexión se corta y se avisa del avance a la ventana mientras llega.
// Los fallos se devuelven como { failed, message } (en vez de lanzar) para que el mensaje llegue limpio, sin el prefijo de Electron.
ipcMain.handle('auric:http-stream', async (event, url, method, options = {}) => {
  const ctl = new AbortController();
  const requestId = options.requestId ? String(options.requestId) : '';
  if (requestId) activeHttp.set(requestId, ctl);
  try {
    let current = String(url);
    const verb = String(method || 'POST').toUpperCase();
    if (!/^https?:\/\//i.test(current)) throw new Error('URL no válida.');
    if (E2E_HTTP_MAP) {
      try {
        const u0 = new URL(current);
        if (E2E_HTTP_MAP[u0.host]) current = E2E_HTTP_MAP[u0.host] + u0.pathname + u0.search;
      } catch {}
    }
    return await modelStream.streamRequest({
      url: current,
      method: verb,
      headers: withRelaySignature(current, verb, options.headers || {}),
      body: options.body ?? undefined,
      kind: String(options.kind || 'openai-chat'),
      idleMs: Math.max(1000, Number(options.idleTimeout || 180000)),
      totalMs: Math.max(60000, Number(options.totalTimeout || 45 * 60000)),
      signal: ctl.signal,
      onProgress: p => {
        try {
          if (!event.sender.isDestroyed()) event.sender.send('auric:http-stream-progress', { requestId, ...p });
        } catch {}
      }
    });
  } catch (err) {
    if (ctl.userAborted) return { failed: true, message: 'ABORTED: petición cancelada.' };
    return { failed: true, message: String(err?.message || err) };
  } finally {
    if (requestId) activeHttp.delete(requestId);
  }
});

ipcMain.handle('auric:dictate', async (_e, options = {}) => {
  if (process.platform !== 'win32') throw new Error('El dictado nativo está disponible en Windows.');
  if (dictationProc) throw new Error('Ya hay una sesión de dictado activa.');
  const seconds = Math.max(3, Math.min(45, Number(options.seconds || 20)));
  const preferred = String(options.locale || app.getLocale() || 'es-ES').replace(/'/g, "''");
  const script = `
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Speech
$installed=[System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()
if(-not $installed -or $installed.Count -eq 0){ throw 'Windows no tiene un motor de reconocimiento de voz instalado.' }
$choice=$installed | Where-Object { $_.Culture.Name -eq '${preferred}' } | Select-Object -First 1
if(-not $choice){ $choice=$installed | Where-Object { $_.Culture.TwoLetterISOLanguageName -eq 'es' } | Select-Object -First 1 }
if(-not $choice){ $choice=$installed | Select-Object -First 1 }
$rec=New-Object System.Speech.Recognition.SpeechRecognitionEngine($choice)
$rec.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))
$rec.SetInputToDefaultAudioDevice()
$r=$rec.Recognize([TimeSpan]::FromSeconds(${seconds}))
if($r){ [Console]::OutputEncoding=[Text.Encoding]::UTF8; Write-Output $r.Text }
$rec.Dispose()`;
  return new Promise((resolve, reject) => {
    const proc = spawn('powershell.exe', ['-NoProfile', '-Sta', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true });
    dictationProc = proc;
    let out = '',
      err = '';
    proc.stdout.on('data', d => (out += d.toString('utf8')));
    proc.stderr.on('data', d => (err += d.toString('utf8')));
    proc.on('error', e => {
      dictationProc = null;
      reject(e);
    });
    proc.on('close', code => {
      dictationProc = null;
      if (code && err.trim()) reject(new Error(err.trim()));
      else resolve(out.trim());
    });
  });
});
ipcMain.handle('auric:dictate-cancel', async () => {
  if (dictationProc) {
    try {
      dictationProc.kill();
    } catch {}
    dictationProc = null;
  }
  return true;
});
