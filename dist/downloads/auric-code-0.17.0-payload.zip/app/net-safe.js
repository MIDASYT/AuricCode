'use strict';
// Red segura para el proceso principal: clasificación de IPs, resolución DNS "fijada" (anti DNS-rebinding)
// y una petición HTTP(S) con validación en CADA salto de redirección.
// Se usa en descargas, imágenes y cualquier función que reciba una URL que no escribió el usuario.
const net = require('net');
const dns = require('dns');
const http = require('http');
const https = require('https');
const zlib = require('zlib');

// ── Clasificación de direcciones ──────────────────────────────────────────────────────────────
function parseIPv4(text) {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(String(text || ''));
  if (!m) return null;
  const p = m.slice(1).map(Number);
  return p.every(n => n >= 0 && n <= 255) ? p : null;
}
// Devuelve 16 bytes. Acepta compresión "::" y IPv4 incrustado (::ffff:1.2.3.4). Sin zona (%eth0).
function parseIPv6(text) {
  let s = String(text || '')
    .toLowerCase()
    .replace(/^\[|\]$/g, '');
  if (!s || s.includes('%') || net.isIP(s) !== 6) return null;
  const v4 = /(\d+\.\d+\.\d+\.\d+)$/.exec(s);
  if (v4) {
    const b = parseIPv4(v4[1]);
    if (!b) return null;
    s = s.slice(0, v4.index) + ((b[0] << 8) | b[1]).toString(16) + ':' + ((b[2] << 8) | b[3]).toString(16);
  }
  const halves = s.split('::');
  if (halves.length > 2) return null;
  const head = halves[0] ? halves[0].split(':') : [];
  const tail = halves.length === 2 && halves[1] ? halves[1].split(':') : [];
  const missing = 8 - head.length - tail.length;
  if ((halves.length === 1 && missing !== 0) || missing < 0) return null;
  const groups = [...head, ...Array(halves.length === 2 ? missing : 0).fill('0'), ...tail];
  if (groups.length !== 8) return null;
  const out = new Uint8Array(16);
  for (let i = 0; i < 8; i++) {
    if (!/^[0-9a-f]{1,4}$/.test(groups[i])) return null;
    const n = parseInt(groups[i], 16);
    out[i * 2] = n >> 8;
    out[i * 2 + 1] = n & 255;
  }
  return out;
}
function privateIPv4(p) {
  const [a, b, c] = p;
  return (
    a === 0 || // "esta red"
    a === 10 ||
    a === 127 ||
    (a === 100 && b >= 64 && b <= 127) || // CGNAT
    (a === 169 && b === 254) || // enlace local + metadatos de nube
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 0 && (c === 0 || c === 2)) || // 192.0.0.0/24 y documentación
    (a === 192 && b === 88 && c === 99) ||
    (a === 192 && b === 168) ||
    (a === 198 && (b === 18 || b === 19)) || // pruebas de rendimiento
    (a === 198 && b === 51 && c === 100) ||
    (a === 203 && b === 0 && c === 113) ||
    a >= 224 // multicast y reservadas (incluye 255.255.255.255)
  );
}
// true = NO es una dirección pública de Internet (no se debe conectar). Por defecto se bloquea todo lo que no se reconoce.
function isPrivateAddress(input = '') {
  const raw = String(input || '')
    .trim()
    .replace(/^\[|\]$/g, '');
  if (!raw) return true;
  const v = net.isIP(raw);
  if (v === 4) {
    const p = parseIPv4(raw);
    return !p || privateIPv4(p);
  }
  if (v === 6) {
    const b = parseIPv6(raw);
    if (!b) return true;
    const embeddedV4 = off => [b[off], b[off + 1], b[off + 2], b[off + 3]];
    const zeros = n => b.slice(0, n).every(x => x === 0);
    if (zeros(10) && b[10] === 0xff && b[11] === 0xff) return privateIPv4(embeddedV4(12)); // ::ffff:a.b.c.d (también en hex)
    if (zeros(12)) return true; // ::, ::1 y compatibles IPv4 obsoletas (::a.b.c.d)
    if (b[0] === 0x00 && b[1] === 0x64 && b[2] === 0xff && b[3] === 0x9b && b.slice(4, 12).every(x => x === 0))
      return privateIPv4(embeddedV4(12)); // NAT64 64:ff9b::/96
    if (b[0] === 0x00 && b[1] === 0x64 && b[2] === 0xff && b[3] === 0x9b && b[4] === 0x00 && b[5] === 0x01) return true; // 64:ff9b:1::/48 uso local
    if (b[0] === 0x20 && b[1] === 0x02) return privateIPv4(embeddedV4(2)); // 6to4
    if ((b[0] & 0xe0) !== 0x20) return true; // solo 2000::/3 es unicast global
    if (b[0] === 0x20 && b[1] === 0x01) {
      if (b[2] === 0x00 && b[3] === 0x00) return true; // Teredo 2001::/32
      if (b[2] === 0x0d && b[3] === 0xb8) return true; // documentación 2001:db8::/32
      if (b[2] === 0x00 && b[3] === 0x02 && b[4] === 0x00 && b[5] === 0x00) return true; // 2001:2::/48 pruebas
      if (b[2] === 0x00 && (b[3] & 0xf0) === 0x10) return true; // ORCHID 2001:10::/28
    }
    if (b[0] === 0x3f && b[1] === 0xff) return true; // documentación 3fff::/20
    return false;
  }
  return true; // no es una IP
}

const BLOCKED_HOST_SUFFIXES = [
  '.localhost',
  '.local',
  '.internal',
  '.lan',
  '.home',
  '.home.arpa',
  '.intranet',
  '.corp',
  '.private',
  '.localdomain'
];
function isBlockedHostname(host = '') {
  const h = String(host || '')
    .toLowerCase()
    .replace(/\.$/, '');
  if (!h) return true;
  if (h === 'localhost') return true;
  return BLOCKED_HOST_SUFFIXES.some(s => h.endsWith(s));
}

// Resuelve un host y exige que TODAS sus direcciones sean públicas. Devuelve la lista validada (para fijar la conexión).
async function resolvePublicHost(hostname, resolver) {
  const host = String(hostname || '')
    .toLowerCase()
    .replace(/^\[|\]$/g, '')
    .replace(/\.$/, '');
  if (!host) throw new Error('Auric bloqueó una dirección local o privada.');
  if (net.isIP(host)) {
    if (isPrivateAddress(host)) throw new Error('Auric bloqueó una dirección local o privada.');
    return [{ address: host, family: net.isIP(host) }];
  }
  if (isBlockedHostname(host)) throw new Error('Auric bloqueó una dirección local o privada.');
  let rows;
  try {
    rows = await (resolver || (h => dns.promises.lookup(h, { all: true, verbatim: true })))(host);
  } catch {
    throw new Error('No se pudo resolver el host público.');
  }
  rows = (rows || []).map(r => ({ address: r.address, family: r.family || net.isIP(r.address) })).filter(r => r.address);
  if (!rows.length) throw new Error('No se pudo resolver el host público.');
  if (rows.some(r => isPrivateAddress(r.address))) throw new Error('Auric bloqueó un host que resuelve a una red local o privada.');
  return rows;
}
// `lookup` para http(s).request que SOLO devuelve las direcciones ya validadas: el sistema no vuelve a resolver el nombre,
// así que un servidor DNS hostil no puede cambiar la respuesta entre la comprobación y la conexión (DNS rebinding).
function pinnedLookup(rows) {
  const list = rows.map(r => ({ address: r.address, family: r.family || net.isIP(r.address) }));
  return (_hostname, options, cb) => {
    if (typeof options === 'function') {
      cb = options;
      options = {};
    }
    const fam = Number(options?.family) || 0;
    const usable = list.filter(r => !fam || r.family === fam);
    const pick = usable.length ? usable : list;
    if (options?.all) return process.nextTick(cb, null, pick);
    process.nextTick(cb, null, pick[0].address, pick[0].family);
  };
}

// ── Petición con validación por salto ─────────────────────────────────────────────────────────
function errorWithCode(message, code) {
  const e = new Error(message);
  e.code = code;
  return e;
}
function parseUrlStrict(raw, { allowHttp = false } = {}) {
  let u;
  try {
    u = new URL(String(raw));
  } catch {
    throw errorWithCode('La dirección no es una URL válida.', 'BAD_URL');
  }
  if (u.protocol !== 'https:' && !(allowHttp && u.protocol === 'http:'))
    throw errorWithCode(allowHttp ? 'Solo se permiten direcciones http/https.' : 'Solo se permiten direcciones https.', 'BAD_PROTOCOL');
  if (u.username || u.password)
    throw errorWithCode(
      'La dirección incluye usuario/contraseña antes del dominio (truco habitual de engaño). Auric la rechaza.',
      'USERINFO'
    );
  return u;
}

/**
 * Abre una URL de forma segura y devuelve la respuesta SIN leer el cuerpo.
 * opts: { method, headers, body, allowHttp, maxRedirects, timeoutMs, signal, resolver, hostMap, onHop(info) }
 *   - body (opcional, para POST): texto o Buffer. Una petición con cuerpo (y casi siempre con claves en las cabeceras) NUNCA sigue una
 *     redirección: reenviar esos datos a otra dirección los filtraría, así que se corta con un error claro.
 *   - hostMap (solo pruebas E2E): { 'host:puerto' | 'host': 'http://127.0.0.1:PUERTO' } redirige hosts concretos a un servidor local.
 *   - onHop({ from, to, status, index }) puede lanzar para rechazar una redirección (p. ej. host no aprobado).
 * Devuelve { res, url, chain, address } — el llamador debe consumir o destruir `res`.
 */
async function openSafe(rawUrl, opts = {}) {
  const maxRedirects = opts.maxRedirects ?? 5;
  const chain = [];
  const bodyBuf = opts.body == null ? null : Buffer.isBuffer(opts.body) ? opts.body : Buffer.from(String(opts.body), 'utf8');
  let current = parseUrlStrict(rawUrl, { allowHttp: opts.allowHttp });
  for (let hop = 0; hop <= maxRedirects; hop++) {
    if (opts.signal?.aborted) throw errorWithCode('Petición cancelada.', 'ABORTED');
    let target = current,
      rows = null,
      mapped = false;
    const mapKey = opts.hostMap && (opts.hostMap[current.host] ? current.host : opts.hostMap[current.hostname] ? current.hostname : '');
    if (mapKey) {
      target = new URL(opts.hostMap[mapKey]);
      target.pathname = current.pathname;
      target.search = current.search;
      mapped = true;
    } else {
      rows = await resolvePublicHost(current.hostname, opts.resolver);
    }
    const lib = target.protocol === 'https:' ? https : http;
    const res = await new Promise((resolve, reject) => {
      let settled = false;
      const done = (fn, v) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        opts.signal?.removeEventListener?.('abort', onAbort);
        fn(v);
      };
      const req = lib.request(
        {
          protocol: target.protocol,
          hostname: target.hostname.replace(/^\[|\]$/g, ''),
          port: target.port || undefined,
          path: target.pathname + target.search,
          method: opts.method || 'GET',
          headers: { Host: current.host, ...(bodyBuf ? { 'Content-Length': bodyBuf.length } : {}), ...(opts.headers || {}) },
          lookup: rows ? pinnedLookup(rows) : undefined,
          servername: !mapped && !net.isIP(current.hostname) ? current.hostname : undefined,
          agent: false
        },
        r => done(resolve, r)
      );
      const onAbort = () => {
        req.destroy(errorWithCode('Petición cancelada.', 'ABORTED'));
      };
      const timer = setTimeout(
        () => req.destroy(errorWithCode(`El servidor no respondió en ${Math.round((opts.timeoutMs || 30000) / 1000)} s.`, 'TIMEOUT')),
        opts.timeoutMs || 30000
      );
      opts.signal?.addEventListener?.('abort', onAbort, { once: true });
      req.on('error', e => done(reject, e));
      req.end(bodyBuf || undefined);
    });
    chain.push({ url: current.href, status: res.statusCode, address: rows?.[0]?.address || '' });
    const loc = res.headers.location;
    if ([301, 302, 303, 307, 308].includes(res.statusCode) && loc) {
      res.resume();
      res.destroy();
      if (bodyBuf) throw errorWithCode('El servicio respondió con una redirección. Auric no reenvía tus datos ni tu clave a otra dirección.', 'REDIRECT_WITH_BODY');
      if (hop === maxRedirects) throw errorWithCode('Demasiadas redirecciones HTTP.', 'TOO_MANY_REDIRECTS');
      let next;
      try {
        next = new URL(loc, current);
      } catch {
        throw errorWithCode('El servidor devolvió una redirección inválida.', 'BAD_REDIRECT');
      }
      next = parseUrlStrict(next.href, { allowHttp: opts.allowHttp }); // exige https (sin degradar), sin usuario:clave
      if (current.protocol === 'https:' && next.protocol !== 'https:')
        throw errorWithCode('El sitio intentó pasar de https a http. Auric lo bloqueó.', 'DOWNGRADE');
      opts.onHop?.({ from: current.href, to: next.href, status: res.statusCode, index: hop });
      current = next;
      continue;
    }
    return { res, url: current, chain, address: rows?.[0]?.address || '', mapped };
  }
  throw errorWithCode('Demasiadas redirecciones HTTP.', 'TOO_MANY_REDIRECTS');
}

// Devuelve un flujo legible ya descomprimido según Content-Encoding (gzip, deflate, br). El límite de tamaño se aplica DESPUÉS
// de descomprimir (protege de bombas de compresión).
function decodedStream(res) {
  const enc = String(res.headers['content-encoding'] || '')
    .toLowerCase()
    .trim();
  let dec = null;
  if (enc === 'gzip' || enc === 'x-gzip') dec = zlib.createGunzip();
  else if (enc === 'deflate') dec = zlib.createInflate();
  else if (enc === 'br') dec = zlib.createBrotliDecompress();
  if (!dec) return res;
  res.on('error', e => dec.destroy(e));
  res.pipe(dec);
  dec.destroyRaw = () => res.destroy();
  return dec;
}

// Lee como máximo `maxBytes` del cuerpo (y destruye el resto).
function readLimited(res, maxBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let n = 0,
      finished = false;
    const finish = (fn, value) => {
      if (finished) return;
      finished = true;
      fn(value);
    };
    res.on('data', c => {
      if (finished) return;
      const room = maxBytes - n;
      if (c.length > room) {
        if (room > 0) chunks.push(c.subarray(0, room));
        n = maxBytes;
        finish(resolve, { buffer: Buffer.concat(chunks), truncated: true });
        res.destroyRaw?.();
        res.destroy();
        return;
      }
      n += c.length;
      chunks.push(c);
    });
    res.on('end', () => finish(resolve, { buffer: Buffer.concat(chunks), truncated: false }));
    res.on('error', e => finish(reject, e));
    res.on('close', () => finish(resolve, { buffer: Buffer.concat(chunks), truncated: false }));
  });
}

module.exports = {
  isPrivateAddress,
  isBlockedHostname,
  parseIPv4,
  parseIPv6,
  resolvePublicHost,
  pinnedLookup,
  parseUrlStrict,
  openSafe,
  decodedStream,
  readLimited
};
