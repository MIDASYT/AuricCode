'use strict';
// Firma de peticiones hacia el relay de Auric Free (ver Worker: clientAuthorized).
// RELAY_CLIENT_KEY debe coincidir con el secreto AURIC_CLIENT_SECRET configurado en Cloudflare.
// No es un secreto fuerte (vive en la app), pero evita el abuso casual de la URL pública y se puede rotar.
const crypto = require('crypto');
const RELAY_ORIGIN = 'https://auric-code-relay.renatix2010.workers.dev';
const RELAY_CLIENT_KEY = '3c723bbe67da28b51c496b9b0c11da6f6f71a8935f208d407a29d767135e021e';

function signRelayRequest({ method, pathname, install = '', now = Date.now(), key = RELAY_CLIENT_KEY }) {
  const ts = String(now);
  const mac = crypto
    .createHmac('sha256', key)
    .update(`${ts}.${String(install).slice(0, 180)}.${String(method || 'GET').toUpperCase()}.${pathname}`)
    .digest('hex');
  return { 'X-Auric-Ts': ts, 'X-Auric-Sig': mac };
}
function isRelayUrl(url) {
  try {
    return new URL(String(url)).origin === RELAY_ORIGIN;
  } catch {
    return false;
  }
}
// Añade las cabeceras de firma si la URL apunta al relay; en otro caso devuelve las cabeceras tal cual.
function withRelaySignature(url, method, headers = {}) {
  if (!isRelayUrl(url)) return headers;
  const u = new URL(String(url));
  const install = headers['X-Auric-Install'] || headers['x-auric-install'] || '';
  return { ...headers, ...signRelayRequest({ method, pathname: u.pathname, install }) };
}
module.exports = { signRelayRequest, isRelayUrl, withRelaySignature, RELAY_ORIGIN };
