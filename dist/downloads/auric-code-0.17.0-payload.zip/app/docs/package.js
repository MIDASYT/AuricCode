'use strict';
// Piezas comunes del formato OPC (el «paquete ZIP» de docx/xlsx/pptx): tipos de contenido, relaciones, propiedades y lectura de rutas.
const path = require('path');
const { readZip, writeZip } = require('../zip.js');
const { parseXml, kidsOf, at, esc, escAttr } = require('./xml.js');

const DECL = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
const REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const PKG_REL = 'http://schemas.openxmlformats.org/package/2006/relationships';
const CT = {
  rels: 'application/vnd.openxmlformats-package.relationships+xml',
  xml: 'application/xml',
  core: 'application/vnd.openxmlformats-package.core-properties+xml',
  app: 'application/vnd.openxmlformats-officedocument.extended-properties+xml',
  theme: 'application/vnd.openxmlformats-officedocument.theme+xml'
};

function contentTypes(overrides, defaults = {}) {
  const d = { rels: CT.rels, xml: CT.xml, ...defaults };
  return (
    DECL +
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
    Object.entries(d)
      .map(([ext, type]) => `<Default Extension="${escAttr(ext)}" ContentType="${escAttr(type)}"/>`)
      .join('') +
    overrides.map(([part, type]) => `<Override PartName="${escAttr(part)}" ContentType="${escAttr(type)}"/>`).join('') +
    '</Types>'
  );
}
// list: [{id, type, target, external?}] (type puede ser el nombre corto de ".../officeDocument/2006/relationships/<tipo>")
function relsXml(list) {
  return (
    DECL +
    `<Relationships xmlns="${PKG_REL}">` +
    list
      .map(r => {
        const type = /^https?:/.test(r.type) ? r.type : `${REL}/${r.type}`;
        return `<Relationship Id="${escAttr(r.id)}" Type="${escAttr(type)}" Target="${escAttr(r.target)}"${r.external ? ' TargetMode="External"' : ''}/>`;
      })
      .join('') +
    '</Relationships>'
  );
}
const isoNoMs = d => new Date(d).toISOString().replace(/\.\d{3}Z$/, 'Z');
function coreXml({ title = '', author = '', subject = '', now = new Date() } = {}) {
  return (
    DECL +
    '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
    `<dc:title>${esc(title)}</dc:title>` +
    (subject ? `<dc:subject>${esc(subject)}</dc:subject>` : '') +
    `<dc:creator>${esc(author)}</dc:creator>` +
    `<cp:lastModifiedBy>${esc(author)}</cp:lastModifiedBy>` +
    `<dcterms:created xsi:type="dcterms:W3CDTF">${isoNoMs(now)}</dcterms:created>` +
    `<dcterms:modified xsi:type="dcterms:W3CDTF">${isoNoMs(now)}</dcterms:modified>` +
    '</cp:coreProperties>'
  );
}
function appXml(application = 'Auric Code') {
  return DECL + `<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>${esc(application)}</Application></Properties>`;
}
// Raíz común: _rels/.rels con documento principal + propiedades.
function rootRels(mainPart) {
  return relsXml([
    { id: 'rId1', type: 'officeDocument', target: mainPart },
    { id: 'rId2', type: 'http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties', target: 'docProps/core.xml' },
    { id: 'rId3', type: 'extended-properties', target: 'docProps/app.xml' }
  ]);
}
// entries: [[nombre, texto|Buffer], …]. [Content_Types].xml y _rels/.rels van primero.
function buildPackage(entries, opts = {}) {
  const order = e => (e[0] === '[Content_Types].xml' ? 0 : e[0] === '_rels/.rels' ? 1 : 2);
  const sorted = entries.map((e, i) => [e, i]).sort((a, b) => order(a[0]) - order(b[0]) || a[1] - b[1]).map(x => x[0]);
  return writeZip(sorted, { deflate: true, date: opts.date || new Date() });
}

// ── Lectura ────────────────────────────────────────────────────────────────────────────────────────────────────────
// Resuelve un destino de relación (relativo a la carpeta de la parte de origen, o absoluto con «/») a un nombre de entrada del ZIP.
function resolveTarget(sourcePart, target) {
  let t = String(target || '').replace(/\\/g, '/');
  if (!t) return '';
  if (/^[a-z][a-z0-9+.-]*:/i.test(t)) return '';
  if (t.startsWith('/')) return t.replace(/^\/+/, '');
  const base = sourcePart.includes('/') ? sourcePart.slice(0, sourcePart.lastIndexOf('/')) : '';
  const joined = path.posix.normalize((base ? base + '/' : '') + t);
  return joined.startsWith('../') || joined === '..' ? '' : joined;
}
function relsPathFor(part) {
  const i = part.lastIndexOf('/');
  return (i >= 0 ? part.slice(0, i + 1) : '') + '_rels/' + part.slice(i + 1) + '.rels';
}
function readRels(zip, part) {
  const rp = part === '' ? '_rels/.rels' : relsPathFor(part);
  const out = new Map();
  if (!zip.has(rp)) return out;
  const root = parseXml(zip.readText(rp));
  for (const r of kidsOf(root, 'rel:Relationship')) {
    const id = at(r, 'Id');
    if (!id) continue;
    const type = String(at(r, 'Type') || '');
    const external = /external/i.test(at(r, 'TargetMode') || '');
    out.set(id, { id, type, short: type.slice(type.lastIndexOf('/') + 1), target: at(r, 'Target') || '', external, part: external ? '' : resolveTarget(part, at(r, 'Target')) });
  }
  return out;
}
function mainPartOf(zip, shortType = 'officeDocument') {
  for (const r of readRels(zip, '').values()) if (r.short === shortType && r.part && zip.has(r.part)) return r.part;
  return '';
}
function openOffice(buf, limits = {}) {
  return readZip(buf, { maxEntries: 8000, maxEntryBytes: 96 * 1024 * 1024, maxTotalBytes: 512 * 1024 * 1024, ...limits });
}
function coreProps(zip) {
  const out = {};
  try {
    const p = [...readRels(zip, '').values()].find(r => /core-properties$/.test(r.type));
    const part = p?.part || 'docProps/core.xml';
    if (!zip.has(part)) return out;
    const root = parseXml(zip.readText(part));
    for (const k of root.kids) {
      if (typeof k === 'string') continue;
      if (k.name === 'title') out.title = k.kids.join('');
      else if (k.name === 'creator') out.author = k.kids.join('');
      else if (k.name === 'subject') out.subject = k.kids.join('');
      else if (k.name === 'created') out.created = k.kids.join('');
      else if (k.name === 'modified') out.modified = k.kids.join('');
    }
  } catch {}
  return out;
}

module.exports = { DECL, REL, PKG_REL, CT, contentTypes, relsXml, coreXml, appXml, rootRels, buildPackage, resolveTarget, relsPathFor, readRels, mainPartOf, openOffice, coreProps };
