'use strict';
// Evaluador mínimo de fórmulas de Excel. Sirve para guardar el valor YA calculado junto a cada fórmula: así los visores que no
// recalculan (Vista protegida de Excel, vistas previas, móviles) muestran los números. Regla de oro: si no se puede calcular con
// certeza (función rara, referencia circular, TODAY/NOW…) NO se guarda valor y Excel recalcula al abrir (el libro lo pide).

class Unsupported extends Error {}
const E = {
  div0: { err: '#DIV/0!' },
  value: { err: '#VALUE!' },
  ref: { err: '#REF!' },
  name: { err: '#NAME?' },
  na: { err: '#N/A' },
  num: { err: '#NUM!' }
};
const isErr = v => v !== null && typeof v === 'object' && 'err' in v;
const isRange = v => v !== null && typeof v === 'object' && Array.isArray(v.rows);
const LIM = { formulas: 150_000, rangeCells: 3_000_000, depth: 400 };

function colIndex(letters) {
  let n = 0;
  for (const ch of letters.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

// ── Lexer ─────────────────────────────────────────────────────────────────────────────────────────────────────────
function lex(src) {
  const toks = [];
  let i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    if (c === ' ' || c === '\t') {
      i++;
      continue;
    }
    if (c === '"') {
      let j = i + 1,
        s = '';
      for (;;) {
        if (j >= n) throw new Unsupported('comillas');
        if (src[j] === '"') {
          if (src[j + 1] === '"') {
            s += '"';
            j += 2;
            continue;
          }
          break;
        }
        s += src[j++];
      }
      toks.push({ t: 'str', v: s });
      i = j + 1;
      continue;
    }
    let m;
    const rest = src.slice(i);
    // referencia con hoja: 'Mi hoja'!A1:B2  |  Hoja1!A1
    if ((m = /^(?:'((?:[^']|'')+)'|([A-Za-z_][A-Za-z0-9_.]*))!(\$?[A-Za-z]{1,3}\$?\d+(?::\$?[A-Za-z]{1,3}\$?\d+)?|\$?[A-Za-z]{1,3}:\$?[A-Za-z]{1,3})/.exec(rest))) {
      toks.push({ t: 'ref', sheet: (m[1] ?? m[2]).replace(/''/g, "'"), ref: m[3] });
      i += m[0].length;
      continue;
    }
    if ((m = /^(\$?[A-Za-z]{1,3}\$?\d+(?::\$?[A-Za-z]{1,3}\$?\d+)?|\$?[A-Za-z]{1,3}:\$?[A-Za-z]{1,3})(?![A-Za-z0-9_.(])/.exec(rest))) {
      toks.push({ t: 'ref', sheet: null, ref: m[1] });
      i += m[0].length;
      continue;
    }
    if ((m = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(rest))) {
      toks.push({ t: 'num', v: Number(m[0]) });
      i += m[0].length;
      continue;
    }
    if ((m = /^([A-Za-z_][A-Za-z0-9_.]*)\s*\(/.exec(rest))) {
      toks.push({ t: 'fn', v: m[1].toUpperCase().replace(/^_XLFN\./, '') });
      i += m[0].length;
      continue;
    }
    if ((m = /^(TRUE|FALSE)(?![A-Za-z0-9_.(])/i.exec(rest))) {
      toks.push({ t: 'bool', v: m[1].toUpperCase() === 'TRUE' });
      i += m[0].length;
      continue;
    }
    if ((m = /^(<>|<=|>=|[-+*/^&=<>%(),])/.exec(rest))) {
      toks.push({ t: 'op', v: m[1] });
      i += m[0].length;
      continue;
    }
    throw new Unsupported(`símbolo «${c}»`); // nombres definidos, #REF!, {matrices}, etc.
  }
  return toks;
}

// ── Parser (precedencia de Excel: - unario > % > ^ > * / > + - > & > comparación) ──────────────────────────────────
function parse(src) {
  const toks = lex(src);
  let p = 0;
  const peek = () => toks[p];
  const isOp = v => toks[p] && toks[p].t === 'op' && toks[p].v === v;
  function expr() {
    return cmp();
  }
  function cmp() {
    let l = concat();
    while (peek() && peek().t === 'op' && ['=', '<>', '<', '>', '<=', '>='].includes(peek().v)) {
      const op = toks[p++].v;
      l = { k: 'bin', op, l, r: concat() };
    }
    return l;
  }
  function concat() {
    let l = add();
    while (isOp('&')) {
      p++;
      l = { k: 'bin', op: '&', l, r: add() };
    }
    return l;
  }
  function add() {
    let l = mul();
    while (isOp('+') || isOp('-')) {
      const op = toks[p++].v;
      l = { k: 'bin', op, l, r: mul() };
    }
    return l;
  }
  function mul() {
    let l = pow();
    while (isOp('*') || isOp('/')) {
      const op = toks[p++].v;
      l = { k: 'bin', op, l, r: pow() };
    }
    return l;
  }
  function pow() {
    let l = unary();
    while (isOp('^')) {
      p++;
      l = { k: 'bin', op: '^', l, r: unary() };
    }
    return l;
  }
  function unary() {
    if (isOp('-') || isOp('+')) {
      const op = toks[p++].v;
      const x = unary();
      return op === '-' ? { k: 'neg', x } : x;
    }
    return pct();
  }
  function pct() {
    let x = primary();
    while (isOp('%')) {
      p++;
      x = { k: 'bin', op: '/', l: x, r: { k: 'num', v: 100 } };
    }
    return x;
  }
  function primary() {
    const t = toks[p++];
    if (!t) throw new Unsupported('fórmula incompleta');
    if (t.t === 'num') return { k: 'num', v: t.v };
    if (t.t === 'str') return { k: 'str', v: t.v };
    if (t.t === 'bool') return { k: 'bool', v: t.v };
    if (t.t === 'ref') return { k: 'ref', sheet: t.sheet, ref: t.ref };
    if (t.t === 'op' && t.v === '(') {
      const e = expr();
      if (!isOp(')')) throw new Unsupported('paréntesis');
      p++;
      return { k: 'paren', e };
    }
    if (t.t === 'fn') {
      const args = [];
      if (isOp(')')) {
        p++;
        return { k: 'fn', name: t.v, args };
      }
      for (;;) {
        if (isOp(',') || isOp(')')) args.push({ k: 'empty' });
        else args.push(expr());
        if (isOp(',')) {
          p++;
          continue;
        }
        if (isOp(')')) {
          p++;
          break;
        }
        throw new Unsupported('argumentos');
      }
      return { k: 'fn', name: t.v, args };
    }
    throw new Unsupported('expresión');
  }
  const tree = expr();
  if (p < toks.length) throw new Unsupported('sobran símbolos');
  return tree;
}

// ── Conversión de valores ─────────────────────────────────────────────────────────────────────────────────────────
function numVal(v) {
  if (isErr(v)) return v;
  if (v === null || v === undefined || v === '') return 0;
  if (typeof v === 'number') return v;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (typeof v === 'string') {
    const t = v.trim();
    if (/^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?$/i.test(t)) return Number(t);
    return E.value;
  }
  return E.value;
}
// Texto a partir de un valor. Lo que depende del idioma de Excel (decimales «1,5» o «1.5», VERDADERO/TRUE) NO se calcula: se deja que Excel lo haga al abrir.
function textVal(v) {
  if (isErr(v)) return v;
  if (v === null || v === undefined) return '';
  if (typeof v === 'boolean') throw new Unsupported('lógico a texto depende del idioma');
  if (typeof v === 'number') {
    if (!Number.isInteger(v) || Math.abs(v) >= 1e15) throw new Unsupported('número a texto depende del idioma');
    return String(v);
  }
  return String(v);
}
function boolVal(v) {
  if (isErr(v)) return v;
  if (typeof v === 'boolean') return v;
  if (v === null || v === undefined || v === '') return false;
  if (typeof v === 'number') return v !== 0;
  if (typeof v === 'string') {
    if (/^true$/i.test(v)) return true;
    if (/^false$/i.test(v)) return false;
    return E.value;
  }
  return E.value;
}
const rank = v => (typeof v === 'number' || v === null ? 0 : typeof v === 'string' ? 1 : 2);
function compare(a, b) {
  if (a === null) a = typeof b === 'string' ? '' : typeof b === 'boolean' ? false : 0;
  if (b === null) b = typeof a === 'string' ? '' : typeof a === 'boolean' ? false : 0;
  const ra = rank(a),
    rb = rank(b);
  if (ra !== rb) return ra < rb ? -1 : 1;
  if (typeof a === 'string') {
    const x = a.toLowerCase(),
      y = b.toLowerCase();
    return x < y ? -1 : x > y ? 1 : 0;
  }
  if (typeof a === 'boolean') return a === b ? 0 : a ? 1 : -1;
  return a < b ? -1 : a > b ? 1 : 0;
}
// Desplaza la coma decimal trabajando con el TEXTO del número (así 2.675 → 267.5 exacto y ROUND da 2.68 como Excel).
function shiftDecimal(ax, d) {
  const [m, e = '0'] = String(ax).split('e');
  return Number(`${m}e${Number(e) + d}`);
}
function roundHalfAway(x, digits) {
  if (!Number.isFinite(x) || Math.abs(digits) > 15) return x;
  const shifted = shiftDecimal(Math.abs(x), digits);
  if (!Number.isFinite(shifted)) return x;
  const r = shiftDecimal(Math.round(shifted), -digits);
  return Number.isFinite(r) ? Math.sign(x) * r : x;
}
function floorTo(x, digits, up) {
  if (!Number.isFinite(x) || Math.abs(digits) > 15) return x;
  const shifted = shiftDecimal(Math.abs(x), digits);
  if (!Number.isFinite(shifted)) return x;
  const r = shiftDecimal(up ? Math.ceil(shifted) : Math.floor(shifted), -digits);
  return Number.isFinite(r) ? Math.sign(x) * r : x;
}

// criterios de COUNTIF/SUMIF: >5, <=3, <>x, =abc, abc* (comodines)
function makeCriteria(c) {
  if (isErr(c)) return () => false;
  if (typeof c === 'number' || typeof c === 'boolean') return v => (typeof v === 'number' || typeof v === 'boolean') && v === c;
  let s = String(c ?? '');
  let op = '=';
  const m = /^(<>|<=|>=|=|<|>)(.*)$/s.exec(s);
  if (m) {
    op = m[1];
    s = m[2];
  }
  const asNum = /^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?$/i.test(s.trim()) ? Number(s) : null;
  const wild = /[*?]/.test(s) && asNum === null ? new RegExp('^' + s.toLowerCase().replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.') + '$', 's') : null;
  return v => {
    if (isErr(v)) return false;
    let r;
    if (asNum !== null) {
      if (typeof v !== 'number') {
        if (op === '<>') return true;
        return false;
      }
      r = v < asNum ? -1 : v > asNum ? 1 : 0;
    } else if (wild) {
      const hit = typeof v === 'string' && wild.test(v.toLowerCase());
      return op === '<>' ? !hit : hit;
    } else {
      if (op === '=' && s === '') return v === null || v === '';
      if (v === null) return op === '<>';
      if (typeof v !== 'string') return op === '<>';
      r = v.toLowerCase() < s.toLowerCase() ? -1 : v.toLowerCase() > s.toLowerCase() ? 1 : 0;
    }
    return op === '=' ? r === 0 : op === '<>' ? r !== 0 : op === '<' ? r < 0 : op === '>' ? r > 0 : op === '<=' ? r <= 0 : r >= 0;
  };
}

// ── Evaluación ────────────────────────────────────────────────────────────────────────────────────────────────────
// sheets: [{ name, grid }] donde grid[r][c] = { kind:'n'|'s'|'b'|'f'|'empty', v, f }. Devuelve cuántas fórmulas se resolvieron.
function evaluateWorkbook(sheets) {
  const byName = new Map(sheets.map(s => [s.name.toLowerCase(), s]));
  const state = new Map(); // celda → 'busy' | {value} | 'unsupported'
  let count = 0;
  const total = sheets.reduce((n, s) => n + s.grid.reduce((m, row) => m + row.filter(c => c && c.kind === 'f').length, 0), 0);
  if (!total || total > LIM.formulas) return 0;
  let rangeBudget = LIM.rangeCells;
  const trees = new Map();

  function cellValue(sheet, r, c, depth) {
    const cell = sheet.grid[r] && sheet.grid[r][c];
    if (!cell || cell.kind === 'empty') return null;
    if (cell.kind === 'n' || cell.kind === 's' || cell.kind === 'b') return cell.v;
    if (cell.kind !== 'f') return null;
    const key = cell;
    const st = state.get(key);
    if (st && st !== 'busy' && st !== 'unsupported') return st.value;
    if (st === 'busy' || st === 'unsupported') throw new Unsupported('circular o no calculable');
    if (depth > LIM.depth) throw new Unsupported('demasiado profunda');
    state.set(key, 'busy');
    try {
      let tree = trees.get(cell.f);
      if (!tree) {
        tree = parse(cell.f);
        trees.set(cell.f, tree);
      }
      let v = ev(tree, sheet, depth + 1);
      if (isRange(v)) {
        if (v.rows.length === 1 && v.rows[0].length === 1) v = v.rows[0][0];
        else throw new Unsupported('rango como resultado');
      }
      if (v === undefined) throw new Unsupported('sin valor');
      if (v === null) v = 0;
      state.set(key, { value: v });
      return v;
    } catch (e) {
      state.set(key, 'unsupported');
      throw e;
    }
  }
  function resolveRef(node, sheet) {
    let target = sheet;
    if (node.sheet) {
      target = byName.get(node.sheet.toLowerCase());
      if (!target) return null; // hoja inexistente: #REF!
    }
    const parts = node.ref.replace(/\$/g, '').split(':');
    const colOnly = /^[A-Za-z]{1,3}$/.test(parts[0]);
    if (colOnly) {
      const c1 = colIndex(parts[0]),
        c2 = colIndex(parts[1]);
      return { sheet: target, r1: 0, r2: Math.max(0, target.grid.length - 1), c1: Math.min(c1, c2), c2: Math.max(c1, c2), single: false };
    }
    const m1 = /^([A-Za-z]{1,3})(\d+)$/.exec(parts[0]);
    const m2 = parts[1] ? /^([A-Za-z]{1,3})(\d+)$/.exec(parts[1]) : m1;
    if (!m1 || !m2) throw new Unsupported('referencia');
    const a = { c: colIndex(m1[1]), r: Number(m1[2]) - 1 },
      b = { c: colIndex(m2[1]), r: Number(m2[2]) - 1 };
    return { sheet: target, r1: Math.min(a.r, b.r), r2: Math.max(a.r, b.r), c1: Math.min(a.c, b.c), c2: Math.max(a.c, b.c), single: !parts[1] };
  }
  function rangeRows(box, depth) {
    const h = box.r2 - box.r1 + 1,
      w = box.c2 - box.c1 + 1;
    rangeBudget -= h * w;
    if (rangeBudget < 0) throw new Unsupported('rango enorme');
    const rows = [];
    for (let r = box.r1; r <= box.r2; r++) {
      const row = [];
      for (let c = box.c1; c <= box.c2; c++) row.push(cellValue(box.sheet, r, c, depth));
      rows.push(row);
    }
    return rows;
  }
  const flat = vals => vals.flatMap(v => (isRange(v) ? v.rows.flat() : [v]));

  function ev(node, sheet, depth) {
    switch (node.k) {
      case 'num':
      case 'str':
      case 'bool':
        return node.v;
      case 'empty':
        return null;
      case 'paren':
        return ev(node.e, sheet, depth);
      case 'ref': {
        const box = resolveRef(node, sheet);
        if (!box) return E.ref;
        if (box.single) return cellValue(box.sheet, box.r1, box.c1, depth);
        return { rows: rangeRows(box, depth) };
      }
      case 'neg': {
        const x = scalar(ev(node.x, sheet, depth));
        const n = numVal(x);
        return isErr(n) ? n : -n;
      }
      case 'bin':
        return binary(node, sheet, depth);
      case 'fn':
        return call(node, sheet, depth);
    }
    throw new Unsupported('nodo');
  }
  function scalar(v) {
    if (isRange(v)) {
      if (v.rows.length === 1 && v.rows[0].length === 1) return v.rows[0][0];
      throw new Unsupported('rango en lugar de valor (intersección implícita)');
    }
    return v;
  }
  function binary(node, sheet, depth) {
    const a = scalar(ev(node.l, sheet, depth)),
      b = scalar(ev(node.r, sheet, depth));
    if (isErr(a)) return a;
    if (isErr(b)) return b;
    const op = node.op;
    if (op === '&') return textVal(a) + textVal(b);
    if (['=', '<>', '<', '>', '<=', '>='].includes(op)) {
      const c = compare(a, b);
      return op === '=' ? c === 0 : op === '<>' ? c !== 0 : op === '<' ? c < 0 : op === '>' ? c > 0 : op === '<=' ? c <= 0 : c >= 0;
    }
    const x = numVal(a),
      y = numVal(b);
    if (isErr(x)) return x;
    if (isErr(y)) return y;
    switch (op) {
      case '+':
        return x + y;
      case '-':
        return x - y;
      case '*':
        return x * y;
      case '/':
        return y === 0 ? E.div0 : x / y;
      case '^': {
        if (x === 0 && y === 0) return E.num;
        if (x === 0 && y < 0) return E.div0;
        const r = Math.pow(x, y);
        return Number.isFinite(r) ? r : E.num;
      }
    }
    throw new Unsupported('operador');
  }
  // números que cuentan para SUM/AVERAGE/MIN/MAX…: en rangos solo números; en argumentos directos también texto numérico y lógicos.
  function numbersOf(args, sheet, depth) {
    const out = [];
    for (const a of args) {
      const v = ev(a, sheet, depth);
      if (isRange(v)) {
        for (const x of v.rows.flat()) {
          if (isErr(x)) return { err: x };
          if (typeof x === 'number') out.push(x);
        }
      } else {
        if (a.k === 'empty') continue;
        if (isErr(v)) return { err: v };
        if (v === null) continue;
        const n = numVal(v);
        if (isErr(n)) return { err: n };
        out.push(n);
      }
    }
    return { nums: out };
  }
  const argv = (n, sheet, depth) => scalar(ev(n, sheet, depth));
  function criteriaPairs(args, from, sheet, depth) {
    const pairs = [];
    for (let i = from; i + 1 < args.length; i += 2) {
      const rg = ev(args[i], sheet, depth);
      if (!isRange(rg)) throw new Unsupported('criterio sin rango');
      pairs.push({ cells: rg.rows.flat(), test: makeCriteria(argv(args[i + 1], sheet, depth)), shape: [rg.rows.length, rg.rows[0]?.length || 0] });
    }
    return pairs;
  }
  function matches(pairs, i) {
    return pairs.every(p => p.test(p.cells[i]));
  }
  function call(node, sheet, depth) {
    const { name, args } = node;
    const A = args;
    switch (name) {
      case 'IF': {
        if (A.length < 2 || A.length > 3) throw new Unsupported('IF');
        const c = boolVal(argv(A[0], sheet, depth));
        if (isErr(c)) return c;
        if (c) return A[1].k === 'empty' ? 0 : scalar(ev(A[1], sheet, depth));
        if (A.length < 3) return false;
        return A[2].k === 'empty' ? 0 : scalar(ev(A[2], sheet, depth));
      }
      case 'IFERROR': {
        if (A.length !== 2) throw new Unsupported('IFERROR');
        let v;
        try {
          v = scalar(ev(A[0], sheet, depth));
        } catch (e) {
          if (e instanceof Unsupported) throw e;
          throw e;
        }
        return isErr(v) ? scalar(ev(A[1], sheet, depth)) : v;
      }
      case 'IFNA': {
        const v = scalar(ev(A[0], sheet, depth));
        return isErr(v) && v.err === '#N/A' ? scalar(ev(A[1], sheet, depth)) : v;
      }
      case 'AND':
      case 'OR': {
        let acc = name === 'AND',
          any = false;
        for (const a of A) {
          const v = ev(a, sheet, depth);
          for (const x of isRange(v) ? v.rows.flat() : [v]) {
            if (isErr(x)) return x;
            if (isRange(v) && (typeof x === 'string' || x === null)) continue;
            const b = boolVal(x);
            if (isErr(b)) return b;
            any = true;
            acc = name === 'AND' ? acc && b : acc || b;
          }
        }
        return any ? acc : E.value;
      }
      case 'NOT': {
        const b = boolVal(argv(A[0], sheet, depth));
        return isErr(b) ? b : !b;
      }
      case 'TRUE':
        return true;
      case 'FALSE':
        return false;
      case 'SUM':
      case 'AVERAGE':
      case 'MIN':
      case 'MAX':
      case 'PRODUCT':
      case 'MEDIAN':
      case 'COUNT': {
        if (name === 'COUNT') {
          let n = 0;
          for (const a of A) {
            const v = ev(a, sheet, depth);
            if (isRange(v)) n += v.rows.flat().filter(x => typeof x === 'number').length;
            else if (typeof v === 'number' || typeof v === 'boolean' || (typeof v === 'string' && !isErr(numVal(v)))) n++;
          }
          return n;
        }
        const r = numbersOf(A, sheet, depth);
        if (r.err) return r.err;
        const nums = r.nums;
        if (name === 'SUM') return nums.reduce((s, x) => s + x, 0);
        if (name === 'PRODUCT') return nums.length ? nums.reduce((s, x) => s * x, 1) : 0;
        if (name === 'MIN') return nums.length ? Math.min(...nums) : 0;
        if (name === 'MAX') return nums.length ? Math.max(...nums) : 0;
        if (!nums.length) return E.div0;
        if (name === 'AVERAGE') return nums.reduce((s, x) => s + x, 0) / nums.length;
        const sorted = [...nums].sort((x, y) => x - y),
          mid = sorted.length >> 1;
        return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
      }
      case 'COUNTA':
      case 'COUNTBLANK': {
        let n = 0;
        for (const a of A) {
          const v = ev(a, sheet, depth);
          for (const x of isRange(v) ? v.rows.flat() : [v]) {
            const blank = x === null || x === '';
            if (name === 'COUNTA' ? !blank : blank) n++;
          }
        }
        return n;
      }
      case 'ABS':
      case 'SQRT':
      case 'INT':
      case 'SIGN': {
        const x = numVal(argv(A[0], sheet, depth));
        if (isErr(x)) return x;
        if (name === 'ABS') return Math.abs(x);
        if (name === 'INT') return Math.floor(x);
        if (name === 'SIGN') return Math.sign(x);
        return x < 0 ? E.num : Math.sqrt(x);
      }
      case 'ROUND':
      case 'ROUNDUP':
      case 'ROUNDDOWN': {
        const x = numVal(argv(A[0], sheet, depth));
        const d = A[1] ? numVal(argv(A[1], sheet, depth)) : 0;
        if (isErr(x)) return x;
        if (isErr(d)) return d;
        const dg = Math.trunc(d);
        if (name === 'ROUND') return roundHalfAway(x, dg);
        return floorTo(x, dg, name === 'ROUNDUP');
      }
      case 'POWER':
      case 'MOD': {
        const x = numVal(argv(A[0], sheet, depth)),
          y = numVal(argv(A[1], sheet, depth));
        if (isErr(x)) return x;
        if (isErr(y)) return y;
        if (name === 'POWER') {
          const r = Math.pow(x, y);
          return Number.isFinite(r) ? r : E.num;
        }
        if (y === 0) return E.div0;
        return x - y * Math.floor(x / y);
      }
      case 'SUMIF':
      case 'COUNTIF':
      case 'AVERAGEIF': {
        const rg = ev(A[0], sheet, depth);
        if (!isRange(rg)) throw new Unsupported('SUMIF sin rango');
        const cells = rg.rows.flat();
        const test = makeCriteria(argv(A[1], sheet, depth));
        let sumCells = cells;
        if (A[2]) {
          const sr = ev(A[2], sheet, depth);
          if (!isRange(sr)) throw new Unsupported('suma sin rango');
          sumCells = sr.rows.flat();
          if (sumCells.length < cells.length) {
            while (sumCells.length < cells.length) sumCells.push(null);
          }
        }
        let n = 0,
          s = 0;
        for (let i = 0; i < cells.length; i++)
          if (test(cells[i])) {
            n++;
            if (typeof sumCells[i] === 'number') s += sumCells[i];
            else if (isErr(sumCells[i])) return sumCells[i];
          }
        if (name === 'COUNTIF') return n;
        if (name === 'SUMIF') return s;
        let cnt = 0;
        for (let i = 0; i < cells.length; i++) if (test(cells[i]) && typeof sumCells[i] === 'number') cnt++;
        return cnt ? s / cnt : E.div0;
      }
      case 'SUMIFS':
      case 'AVERAGEIFS':
      case 'COUNTIFS': {
        const from = name === 'COUNTIFS' ? 0 : 1;
        const pairs = criteriaPairs(A, from, sheet, depth);
        if (!pairs.length) throw new Unsupported('IFS');
        const size = pairs[0].cells.length;
        if (pairs.some(p => p.cells.length !== size)) return E.value;
        let sumCells = null;
        if (from) {
          const sr = ev(A[0], sheet, depth);
          if (!isRange(sr) || sr.rows.flat().length !== size) return E.value;
          sumCells = sr.rows.flat();
        }
        let n = 0,
          s = 0,
          cnt = 0;
        for (let i = 0; i < size; i++)
          if (matches(pairs, i)) {
            n++;
            if (sumCells && typeof sumCells[i] === 'number') {
              s += sumCells[i];
              cnt++;
            }
          }
        return name === 'COUNTIFS' ? n : name === 'SUMIFS' ? s : cnt ? s / cnt : E.div0;
      }
      case 'SUMPRODUCT': {
        const rgs = A.map(a => ev(a, sheet, depth));
        if (!rgs.every(isRange)) throw new Unsupported('SUMPRODUCT');
        const size = rgs[0].rows.flat().length;
        if (rgs.some(r => r.rows.flat().length !== size)) return E.value;
        const lists = rgs.map(r => r.rows.flat());
        let s = 0;
        for (let i = 0; i < size; i++) s += lists.reduce((p, l) => p * (typeof l[i] === 'number' ? l[i] : 0), 1);
        return s;
      }
      case 'CONCAT':
      case 'CONCATENATE': {
        let out = '';
        for (const a of A) {
          const v = ev(a, sheet, depth);
          if (isRange(v)) {
            if (name === 'CONCATENATE') throw new Unsupported('CONCATENATE con rango');
            for (const x of v.rows.flat()) {
              if (isErr(x)) return x;
              out += textVal(x);
            }
          } else {
            if (isErr(v)) return v;
            out += textVal(v);
          }
        }
        return out;
      }
      case 'LEFT':
      case 'RIGHT': {
        const t = textVal(argv(A[0], sheet, depth));
        if (isErr(t)) return t;
        const n = A[1] ? numVal(argv(A[1], sheet, depth)) : 1;
        if (isErr(n)) return n;
        if (n < 0) return E.value;
        const k = Math.trunc(n);
        return name === 'LEFT' ? [...t].slice(0, k).join('') : k === 0 ? '' : [...t].slice(-k).join('');
      }
      case 'MID': {
        const t = textVal(argv(A[0], sheet, depth));
        const s = numVal(argv(A[1], sheet, depth)),
          n = numVal(argv(A[2], sheet, depth));
        if (isErr(t)) return t;
        if (isErr(s)) return s;
        if (isErr(n)) return n;
        if (s < 1 || n < 0) return E.value;
        return [...t].slice(Math.trunc(s) - 1, Math.trunc(s) - 1 + Math.trunc(n)).join('');
      }
      case 'LEN':
      case 'UPPER':
      case 'LOWER':
      case 'TRIM': {
        const t = textVal(argv(A[0], sheet, depth));
        if (isErr(t)) return t;
        if (name === 'LEN') return [...t].length;
        if (name === 'UPPER') return t.toUpperCase();
        if (name === 'LOWER') return t.toLowerCase();
        return t.replace(/ +/g, ' ').replace(/^ | $/g, '');
      }
      case 'VALUE': {
        const v = argv(A[0], sheet, depth);
        if (isErr(v)) return v;
        if (typeof v === 'number') return v;
        if (typeof v === 'string' && !/^\s*[+-]?\d+(\.\d+)?\s*$/.test(v) && !/^\s*[+-]?\.\d+\s*$/.test(v) && /\d/.test(v)) throw new Unsupported('VALUE depende del idioma');
        return numVal(v);
      }
      case 'ISNUMBER':
        return typeof argv(A[0], sheet, depth) === 'number';
      case 'ISTEXT':
        return typeof argv(A[0], sheet, depth) === 'string';
      case 'ISBLANK': {
        const v = argv(A[0], sheet, depth);
        return v === null;
      }
      case 'ISERROR':
        return isErr(argv(A[0], sheet, depth));
      case 'DATE': {
        const y = numVal(argv(A[0], sheet, depth)),
          m = numVal(argv(A[1], sheet, depth)),
          d = numVal(argv(A[2], sheet, depth));
        for (const x of [y, m, d]) if (isErr(x)) return x;
        const yy = Math.trunc(y) < 1900 ? 1900 + Math.trunc(y) : Math.trunc(y);
        if (yy < 1900 || yy > 9999) return E.num;
        const ms = Date.UTC(yy, Math.trunc(m) - 1, Math.trunc(d)) - Date.UTC(1899, 11, 30);
        return ms / 86400000;
      }
      case 'YEAR':
      case 'MONTH':
      case 'DAY': {
        const n = numVal(argv(A[0], sheet, depth));
        if (isErr(n)) return n;
        if (n < 1) throw new Unsupported('fecha anterior a 1900');
        const dt = new Date(Date.UTC(1899, 11, 30) + Math.floor(n) * 86400000);
        return name === 'YEAR' ? dt.getUTCFullYear() : name === 'MONTH' ? dt.getUTCMonth() + 1 : dt.getUTCDate();
      }
      case 'MATCH': {
        const look = argv(A[0], sheet, depth);
        const rg = ev(A[1], sheet, depth);
        if (!isRange(rg)) throw new Unsupported('MATCH');
        if (isErr(look)) return look;
        const type = A[2] ? numVal(argv(A[2], sheet, depth)) : 1;
        if (isErr(type)) return type;
        const list = rg.rows.length === 1 ? rg.rows[0] : rg.rows.map(r => r[0]);
        if (type === 0) {
          const t = makeCriteria(typeof look === 'string' ? '=' + look : look);
          const i = list.findIndex(x => (typeof look === 'string' ? typeof x === 'string' && t(x) : x === look));
          return i < 0 ? E.na : i + 1;
        }
        let best = -1;
        for (let i = 0; i < list.length; i++) {
          if (list[i] === null) continue;
          const c = compare(list[i], look);
          if (type > 0 ? c <= 0 : c >= 0) best = i;
          else break;
        }
        return best < 0 ? E.na : best + 1;
      }
      case 'INDEX': {
        const rg = ev(A[0], sheet, depth);
        if (!isRange(rg)) throw new Unsupported('INDEX');
        const r = A[1] ? numVal(argv(A[1], sheet, depth)) : 1,
          c = A[2] ? numVal(argv(A[2], sheet, depth)) : 1;
        if (isErr(r)) return r;
        if (isErr(c)) return c;
        let rr = Math.trunc(r),
          cc = Math.trunc(c);
        if (rg.rows.length === 1 && A.length === 2) {
          cc = rr;
          rr = 1;
        }
        if (rr < 1 || cc < 1 || rr > rg.rows.length || cc > (rg.rows[0]?.length || 0)) return E.ref;
        const v = rg.rows[rr - 1][cc - 1];
        return v === null ? 0 : v;
      }
      case 'VLOOKUP': {
        const look = argv(A[0], sheet, depth);
        const rg = ev(A[1], sheet, depth);
        if (!isRange(rg)) throw new Unsupported('VLOOKUP');
        const col = numVal(argv(A[2], sheet, depth));
        if (isErr(look)) return look;
        if (isErr(col)) return col;
        const approx = A[3] ? boolVal(argv(A[3], sheet, depth)) : true;
        if (isErr(approx)) return approx;
        const k = Math.trunc(col);
        if (k < 1) return E.value;
        if (k > (rg.rows[0]?.length || 0)) return E.ref;
        let hit = -1;
        if (!approx) {
          hit = rg.rows.findIndex(r => r[0] !== null && compare(r[0], look) === 0 && rank(r[0]) === rank(look));
        } else {
          for (let i = 0; i < rg.rows.length; i++) {
            const v = rg.rows[i][0];
            if (v === null) continue;
            if (rank(v) !== rank(look)) continue;
            if (compare(v, look) <= 0) hit = i;
            else break;
          }
        }
        if (hit < 0) return E.na;
        const v = rg.rows[hit][k - 1];
        return v === null ? 0 : v;
      }
      default:
        throw new Unsupported(`función ${name}`);
    }
  }

  for (const sheet of sheets) {
    for (let r = 0; r < sheet.grid.length; r++) {
      const row = sheet.grid[r];
      for (let c = 0; c < (row ? row.length : 0); c++) {
        const cell = row[c];
        if (!cell || cell.kind !== 'f') continue;
        try {
          const v = cellValue(sheet, r, c, 0);
          if (typeof v === 'number' && !Number.isFinite(v)) continue;
          cell.cache = isErr(v) ? { t: 'e', v: v.err } : typeof v === 'number' ? { t: 'n', v } : typeof v === 'boolean' ? { t: 'b', v } : { t: 'str', v: String(v) };
          count++;
        } catch (e) {
          if (!(e instanceof Unsupported)) {
            // un fallo inesperado nunca debe impedir crear el archivo: simplemente no se guarda valor
          }
        }
      }
    }
  }
  return count;
}

module.exports = { evaluateWorkbook, parse, Unsupported };
