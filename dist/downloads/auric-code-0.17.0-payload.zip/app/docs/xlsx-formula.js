'use strict';
// Fórmulas de Excel: traducción de nombres en español, comprobación sintáctica ligera y prefijos _xlfn.
// Una fórmula inválida dentro del XML hace que Excel «repare» el libro; por eso se valida antes y, si no es fiable, se guarda como texto.

const ES_FN = {
  SUMA: 'SUM', PROMEDIO: 'AVERAGE', SI: 'IF', CONTAR: 'COUNT', CONTARA: 'COUNTA', 'CONTAR.SI': 'COUNTIF', 'SUMAR.SI': 'SUMIF', 'SUMAR.SI.CONJUNTO': 'SUMIFS',
  'CONTAR.SI.CONJUNTO': 'COUNTIFS', 'PROMEDIO.SI': 'AVERAGEIF', 'PROMEDIO.SI.CONJUNTO': 'AVERAGEIFS', REDONDEAR: 'ROUND', 'REDONDEAR.MAS': 'ROUNDUP', 'REDONDEAR.MENOS': 'ROUNDDOWN',
  BUSCARV: 'VLOOKUP', BUSCARH: 'HLOOKUP', BUSCARX: 'XLOOKUP', COINCIDIR: 'MATCH', INDICE: 'INDEX', Y: 'AND', O: 'OR', NO: 'NOT', 'SI.ERROR': 'IFERROR', 'SI.ND': 'IFNA',
  CONCATENAR: 'CONCATENATE', 'UNIR.CADENAS': 'TEXTJOIN', IZQUIERDA: 'LEFT', DERECHA: 'RIGHT', EXTRAE: 'MID', LARGO: 'LEN', MAYUSC: 'UPPER', MINUSC: 'LOWER', NOMPROPIO: 'PROPER',
  ESPACIOS: 'TRIM', HOY: 'TODAY', AHORA: 'NOW', 'AÑO': 'YEAR', MES: 'MONTH', DIA: 'DAY', FECHA: 'DATE', TEXTO: 'TEXT', VALOR: 'VALUE', ENTERO: 'INT', RESIDUO: 'MOD',
  POTENCIA: 'POWER', RAIZ: 'SQRT', PRODUCTO: 'PRODUCT', MEDIANA: 'MEDIAN', MODA: 'MODE', DESVEST: 'STDEV', 'K.ESIMO.MAYOR': 'LARGE', 'K.ESIMO.MENOR': 'SMALL',
  SUMAPRODUCTO: 'SUMPRODUCT', ESNUMERO: 'ISNUMBER', ESTEXTO: 'ISTEXT', ESBLANCO: 'ISBLANK', ESERROR: 'ISERROR', VERDADERO: 'TRUE', FALSO: 'FALSE', SIGNO: 'SIGN',
  ALEATORIO: 'RAND', 'ALEATORIO.ENTRE': 'RANDBETWEEN', PAGO: 'PMT', VA: 'PV', VF: 'FV', TASA: 'RATE', TIR: 'IRR', VNA: 'NPV', 'DIAS.LAB': 'NETWORKDAYS', 'FECHA.MES': 'EDATE',
  'FIN.MES': 'EOMONTH', DIASEM: 'WEEKDAY', HORA: 'HOUR', MINUTO: 'MINUTE', SEGUNDO: 'SECOND', ENCONTRAR: 'FIND', HALLAR: 'SEARCH', SUSTITUIR: 'SUBSTITUTE', REEMPLAZAR: 'REPLACE',
  REPETIR: 'REPT', CARACTER: 'CHAR', CODIGO: 'CODE', SUBTOTALES: 'SUBTOTAL', 'CONTAR.BLANCO': 'COUNTBLANK', FILAS: 'ROWS', COLUMNAS: 'COLUMNS', FILA: 'ROW', COLUMNA: 'COLUMN',
  DESREF: 'OFFSET', INDIRECTO: 'INDIRECT', ELEGIR: 'CHOOSE', 'SI.CONJUNTO': 'IFS', 'MAX.SI.CONJUNTO': 'MAXIFS', 'MIN.SI.CONJUNTO': 'MINIFS', 'REDOND.MULT': 'MROUND',
  TRUNCAR: 'TRUNC', SENO: 'SIN', CONCAT: 'CONCAT', DIAS: 'DAYS', 'MAX.A': 'MAXA', MAYOR: 'LARGE', MENOR: 'SMALL', JERARQUIA: 'RANK', 'COEF.DE.CORREL': 'CORREL', PRONOSTICO: 'FORECAST', FRECUENCIA: 'FREQUENCY'
};
// Funciones de Excel que se aceptan tal cual (lista amplia de las habituales). Las que llevan prefijo van en NEEDS_XLFN.
const KNOWN = new Set(
  `ABS ACOS ACOSH AND ASIN ASINH ATAN ATAN2 ATANH AVEDEV AVERAGE AVERAGEA AVERAGEIF AVERAGEIFS BIN2DEC CEILING CHAR CHOOSE CLEAN CODE COLUMN COLUMNS COMBIN CONCATENATE CORREL COS COSH COUNT COUNTA COUNTBLANK COUNTIF COUNTIFS COVAR DATE DATEDIF DATEVALUE DAY DAYS360 DEC2BIN DEGREES DOLLAR EDATE EOMONTH ERROR.TYPE EVEN EXACT EXP FACT FALSE FIND FIXED FLOOR FORECAST FREQUENCY FV GCD HLOOKUP HOUR IF IFERROR INDEX INDIRECT INT INTERCEPT IPMT IRR ISBLANK ISERR ISERROR ISEVEN ISLOGICAL ISNA ISNONTEXT ISNUMBER ISODD ISREF ISTEXT LARGE LCM LEFT LEN LN LOG LOG10 LOOKUP LOWER MATCH MAX MAXA MEDIAN MID MIN MINA MINUTE MIRR MOD MODE MONTH MROUND N NA NETWORKDAYS NOT NOW NPER NPV ODD OFFSET OR PERCENTILE PERCENTRANK PI PMT POWER PPMT PRODUCT PROPER PV QUARTILE QUOTIENT RADIANS RAND RANDBETWEEN RANK RATE REPLACE REPT RIGHT ROUND ROUNDDOWN ROUNDUP ROW ROWS SEARCH SECOND SIGN SIN SINH SLOPE SMALL SQRT STDEV STDEVP SUBSTITUTE SUBTOTAL SUM SUMIF SUMIFS SUMPRODUCT SUMSQ SWITCH T TAN TANH TEXT TIME TIMEVALUE TODAY TRANSPOSE TRIM TRUE TRUNC TYPE UPPER VALUE VAR VARP VLOOKUP WEEKDAY WEEKNUM WORKDAY YEAR YEARFRAC`.split(/\s+/)
);
// Funciones posteriores a Excel 2007: en el archivo van con prefijo _xlfn.
const NEEDS_XLFN = new Set(
  `IFS MAXIFS MINIFS TEXTJOIN CONCAT XLOOKUP XMATCH IFNA XOR DAYS ISOWEEKNUM STDEV.S STDEV.P VAR.S VAR.P RANK.EQ RANK.AVG MODE.SNGL PERCENTILE.INC PERCENTILE.EXC QUARTILE.INC QUARTILE.EXC CEILING.MATH FLOOR.MATH NORM.DIST NORM.S.DIST NORM.INV RRI PDURATION NUMBERVALUE SHEET SHEETS`.split(/\s+/)
);
// Dinámicas (se derraman): sin metadatos de matriz dinámica Excel las muestra con «@»; no se admiten.
const SPILL = new Set('FILTER UNIQUE SORT SORTBY SEQUENCE RANDARRAY LET LAMBDA MAP REDUCE SCAN BYROW BYCOL MAKEARRAY TAKE DROP VSTACK HSTACK TOCOL TOROW CHOOSECOLS CHOOSEROWS WRAPCOLS WRAPROWS EXPAND TEXTSPLIT TEXTBEFORE TEXTAFTER'.split(' '));

// Recorre la fórmula separando cadenas entre comillas («...»), para no tocar su contenido.
function mapOutsideStrings(f, fn) {
  let out = '',
    i = 0;
  while (i < f.length) {
    if (f[i] === '"') {
      let j = i + 1;
      while (j < f.length) {
        if (f[j] === '"') {
          if (f[j + 1] === '"') {
            j += 2;
            continue;
          }
          break;
        }
        j++;
      }
      out += f.slice(i, j + 1);
      i = j + 1;
    } else if (f[i] === "'") {
      // nombre de hoja entre comillas simples: 'Mi hoja'!A1
      let j = i + 1;
      while (j < f.length && !(f[j] === "'" && f[j + 1] !== "'")) j += f[j] === "'" ? 2 : 1;
      out += f.slice(i, j + 1);
      i = j + 1;
    } else {
      let j = i;
      while (j < f.length && f[j] !== '"' && f[j] !== "'") j++;
      out += fn(f.slice(i, j));
      i = j;
    }
  }
  return out;
}

// Devuelve { ok, formula, warning }. `formula` sin «=» y listo para <f>.
function prepareFormula(input) {
  let f = String(input ?? '').trim();
  if (f.startsWith('=')) f = f.slice(1).trim();
  if (!f) return { ok: false, warning: 'fórmula vacía' };
  if (f.length > 8000) return { ok: false, warning: 'fórmula demasiado larga' };
  if (/[\u0000-\u001f\u007f]/.test(f)) return { ok: false, warning: 'la fórmula tiene saltos de línea o caracteres de control' };
  const usesSemicolon = mapOutsideStrings(f, s => (s.includes(';') ? '\u0001' : s)).includes('\u0001');
  let spanish = false;
  // nombres de función en español → inglés; «;» → «,» cuando es separador de argumentos al estilo español
  f = mapOutsideStrings(f, seg =>
    seg.replace(/([A-Za-zÁÉÍÓÚÑáéíóúñ_][A-Za-zÁÉÍÓÚÑáéíóúñ0-9_.]*)\s*\(/g, (m, name) => {
      const up = name.toUpperCase();
      if (!KNOWN.has(up) && !NEEDS_XLFN.has(up) && ES_FN[up]) {
        spanish = true;
        return ES_FN[up] + '(';
      }
      return m.replace(name, up);
    })
  );
  if (spanish || usesSemicolon) f = mapOutsideStrings(f, seg => seg.replace(/;/g, ','));
  // constantes lógicas en español
  if (spanish) f = mapOutsideStrings(f, seg => seg.replace(/\bVERDADERO\b/gi, 'TRUE').replace(/\bFALSO\b/gi, 'FALSE'));
  // DDE («app|tema!dato»), libros externos («[libro.xlsx]Hoja!A1», «C:\\ruta\\») y nombres de tabla: Excel pediría confiar en vínculos o los ejecutaría.
  let hostile = '';
  mapOutsideStrings(f, seg => {
    const m = /[|\[\]\\]/.exec(seg);
    if (m && !hostile) hostile = m[0];
    return seg;
  });
  if (!hostile && /'[^']*[\[\]\\/:][^']*'!/.test(f.replace(/"(?:[^"]|"")*"/g, '""'))) hostile = 'libro externo';
  if (hostile) return { ok: false, warning: 'contiene vínculos externos o DDE («' + hostile + '»), que no se guardan por seguridad' };
  // paréntesis y comillas equilibrados
  let depth = 0,
    bad = false;
  mapOutsideStrings(f, seg => {
    for (const c of seg) {
      if (c === '(') depth++;
      else if (c === ')') {
        depth--;
        if (depth < 0) bad = true;
      }
    }
    return seg;
  });
  if (bad || depth !== 0) return { ok: false, warning: 'paréntesis sin equilibrar' };
  if ((f.match(/"/g) || []).length % 2) return { ok: false, warning: 'comillas sin cerrar' };
  // funciones desconocidas
  let unknown = '',
    spill = '';
  f = mapOutsideStrings(f, seg =>
    seg.replace(/(^|[^A-Za-z0-9_.!$'])([A-Za-z][A-Za-z0-9_.]*)\(/g, (m, pre, name) => {
      const up = name.toUpperCase();
      if (up.startsWith('_XLFN.')) return m;
      if (SPILL.has(up)) spill = spill || up;
      else if (NEEDS_XLFN.has(up)) return `${pre}_xlfn.${up}(`;
      else if (!KNOWN.has(up)) unknown = unknown || name;
      return m;
    })
  );
  if (spill) return { ok: false, warning: `la función ${spill} (matrices dinámicas) no se puede guardar de forma fiable en un archivo generado` };
  if (unknown) return { ok: false, warning: `función desconocida: ${unknown}` };
  return { ok: true, formula: f };
}

module.exports = { prepareFormula, mapOutsideStrings, ES_FN, KNOWN, NEEDS_XLFN };
