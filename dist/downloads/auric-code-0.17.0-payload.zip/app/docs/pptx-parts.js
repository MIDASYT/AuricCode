'use strict';
// Piezas fijas de una presentación: tema, patrón de diapositivas, diseños y patrón de notas. Los colores y tipos de letra salen de `pal`.
const P = require('./package.js');
const { esc, escAttr } = require('./xml.js');

const NS = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"';
const SLIDE_W = 12192000,
  SLIDE_H = 6858000;
const PAL = {
  dk1: '111827', lt1: 'FFFFFF', dk2: '1E293B', lt2: 'F1F5F9',
  accent1: '2563EB', accent2: 'D9AD3C', accent3: '10B981', accent4: '8B5CF6', accent5: 'EF4444', accent6: '06B6D4',
  hlink: '0563C1', folHlink: '7C3AED'
};
const FONT = 'Calibri';
const NV_GROUP = '<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>';

function themeXml(name, pal = PAL) {
  const c = k => `<a:${k}><a:srgbClr val="${pal[k]}"/></a:${k}>`;
  const sys = (k, sysName, last) => `<a:${k}><a:sysClr val="${sysName}" lastClr="${last}"/></a:${k}>`;
  return (
    P.DECL +
    `<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="${escAttr(name)}"><a:themeElements>` +
    `<a:clrScheme name="${escAttr(name)}">${c('dk1').replace(/<a:srgbClr val="[^"]*"\/>/, `<a:srgbClr val="${pal.dk1}"/>`)}${sys('lt1', 'window', 'FFFFFF')}${c('dk2')}${c('lt2')}${c('accent1')}${c('accent2')}${c('accent3')}${c('accent4')}${c('accent5')}${c('accent6')}${c('hlink')}${c('folHlink')}</a:clrScheme>` +
    `<a:fontScheme name="${escAttr(name)}"><a:majorFont><a:latin typeface="${FONT}"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="${FONT}"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>` +
    '<a:fmtScheme name="Office"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>' +
    '<a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="50000"/><a:satMod val="300000"/></a:schemeClr></a:gs><a:gs pos="35000"><a:schemeClr val="phClr"><a:tint val="37000"/><a:satMod val="300000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="15000"/><a:satMod val="350000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="16200000" scaled="1"/></a:gradFill>' +
    '<a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:shade val="51000"/><a:satMod val="130000"/></a:schemeClr></a:gs><a:gs pos="80000"><a:schemeClr val="phClr"><a:shade val="93000"/><a:satMod val="130000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="94000"/><a:satMod val="135000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="16200000" scaled="0"/></a:gradFill></a:fillStyleLst>' +
    '<a:lnStyleLst><a:ln w="9525" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"><a:shade val="95000"/><a:satMod val="105000"/></a:schemeClr></a:solidFill><a:prstDash val="solid"/></a:ln><a:ln w="25400" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln><a:ln w="38100" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln></a:lnStyleLst>' +
    '<a:effectStyleLst><a:effectStyle><a:effectLst><a:outerShdw blurRad="40000" dist="20000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="38000"/></a:srgbClr></a:outerShdw></a:effectLst></a:effectStyle><a:effectStyle><a:effectLst><a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw></a:effectLst></a:effectStyle><a:effectStyle><a:effectLst><a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw></a:effectLst></a:effectStyle></a:effectStyleLst>' +
    '<a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="40000"/><a:satMod val="350000"/></a:schemeClr></a:gs><a:gs pos="40000"><a:schemeClr val="phClr"><a:tint val="45000"/><a:shade val="99000"/><a:satMod val="350000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="20000"/><a:satMod val="255000"/></a:schemeClr></a:gs></a:gsLst><a:path path="circle"><a:fillToRect l="50000" t="-80000" r="50000" b="180000"/></a:path></a:gradFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="80000"/><a:satMod val="300000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="30000"/><a:satMod val="200000"/></a:schemeClr></a:gs></a:gsLst><a:path path="circle"><a:fillToRect l="50000" t="50000" r="50000" b="50000"/></a:path></a:gradFill></a:bgFillStyleLst></a:fmtScheme>' +
    '</a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>'
  );
}

// Geometría común (EMU)
const G = {
  titleX: 609600, titleY: 360000, titleW: 10972800, titleH: 960000,
  bodyX: 609600, bodyY: 1500000, bodyW: 10972800, bodyH: 4600000,
  footY: 6356350, footH: 365125
};

const ph = (id, name, phAttrs, xfrm, bodyPr, lst, paras) =>
  `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${escAttr(name)}"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph ${phAttrs}/></p:nvPr></p:nvSpPr><p:spPr>${xfrm ? `<a:xfrm><a:off x="${xfrm[0]}" y="${xfrm[1]}"/><a:ext cx="${xfrm[2]}" cy="${xfrm[3]}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>` : ''}</p:spPr><p:txBody>${bodyPr}<a:lstStyle>${lst || ''}</a:lstStyle>${paras}</p:txBody></p:sp>`;
const para = (text, lvl = 0) => `<a:p>${lvl ? `<a:pPr lvl="${lvl}"/>` : ''}<a:r><a:rPr lang="es-ES"/><a:t>${esc(text)}</a:t></a:r></a:p>`;
const fldNum = '<a:p><a:fld id="{B6F15528-21DE-4FAA-801E-634DDDAF4B2B}" type="slidenum"><a:rPr lang="es-ES"/><a:t>‹#›</a:t></a:fld><a:endParaRPr lang="es-ES"/></a:p>';
const footers = () =>
  ph(5, 'Marcador de fecha 4', 'type="dt" sz="half" idx="10"', [609600, G.footY, 2743200, G.footH], '<a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="ctr"/>', '<a:lvl1pPr algn="l"><a:defRPr sz="1100"><a:solidFill><a:schemeClr val="tx1"><a:tint val="75000"/></a:schemeClr></a:solidFill></a:defRPr></a:lvl1pPr>', '<a:p><a:endParaRPr lang="es-ES"/></a:p>') +
  ph(6, 'Marcador de pie de página 5', 'type="ftr" sz="quarter" idx="11"', [4038600, G.footY, 4114800, G.footH], '<a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="ctr"/>', '<a:lvl1pPr algn="ctr"><a:defRPr sz="1100"><a:solidFill><a:schemeClr val="tx1"><a:tint val="75000"/></a:schemeClr></a:solidFill></a:defRPr></a:lvl1pPr>', '<a:p><a:endParaRPr lang="es-ES"/></a:p>') +
  ph(7, 'Marcador de número de diapositiva 6', 'type="sldNum" sz="quarter" idx="12"', [8839200, G.footY, 2743200, G.footH], '<a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="ctr"/>', '<a:lvl1pPr algn="r"><a:defRPr sz="1100"><a:solidFill><a:schemeClr val="tx1"><a:tint val="75000"/></a:schemeClr></a:solidFill></a:defRPr></a:lvl1pPr>', fldNum);
const BODYPR = '<a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="t"><a:normAutofit/></a:bodyPr>';
const TITLEPR = '<a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="ctr"><a:normAutofit/></a:bodyPr>';
const accentBar = (id, x, y, cx, cy, clr = 'accent1') =>
  `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="Barra ${id}"/><p:cNvSpPr/><p:nvPr userDrawn="1"/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:schemeClr val="${clr}"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr rtlCol="0" anchor="ctr"/><a:lstStyle/><a:p><a:endParaRPr lang="es-ES"/></a:p></p:txBody></p:sp>`;

function masterXml() {
  const lvl = (n, marL, indent, sz, bu) =>
    `<a:lvl${n}pPr marL="${marL}" indent="${indent}" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="${n === 1 ? 25000 : 20000}"/></a:spcBef><a:buFont typeface="Arial"/><a:buChar char="${bu}"/><a:defRPr sz="${sz}" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl${n}pPr>`;
  const other = n =>
    `<a:lvl${n}pPr marL="${(n - 1) * 457200}" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl${n}pPr>`;
  const bullets = ['•', '–', '•', '–', '•', '–', '•', '–', '•'];
  const sizes = [2400, 2000, 1800, 1600, 1600, 1600, 1600, 1600, 1600];
  return (
    P.DECL +
    `<p:sldMaster ${NS}><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>${NV_GROUP}` +
    accentBar(8, 0, 0, SLIDE_W, 76200) +
    ph(2, 'Marcador de título 1', 'type="title"', [G.titleX, G.titleY, G.titleW, G.titleH], TITLEPR, '', para('Haga clic para modificar el título')) +
    ph(3, 'Marcador de texto 2', 'type="body" idx="1"', [G.bodyX, G.bodyY, G.bodyW, G.bodyH], BODYPR, '', para('Haga clic para modificar el texto') + para('Segundo nivel', 1) + para('Tercer nivel', 2)) +
    footers() +
    '</p:spTree></p:cSld>' +
    '<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>' +
    '<p:sldLayoutIdLst>' + [1, 2, 3, 4, 5, 6].map(i => `<p:sldLayoutId id="${2147483648 + i}" r:id="rId${i}"/>`).join('') + '</p:sldLayoutIdLst>' +
    '<p:txStyles><p:titleStyle><a:lvl1pPr algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="0"/></a:spcBef><a:buNone/><a:defRPr sz="3200" b="1" kern="1200"><a:solidFill><a:schemeClr val="tx2"/></a:solidFill><a:latin typeface="+mj-lt"/><a:ea typeface="+mj-ea"/><a:cs typeface="+mj-cs"/></a:defRPr></a:lvl1pPr></p:titleStyle>' +
    `<p:bodyStyle>${bullets.map((b, i) => lvl(i + 1, 342900 + i * 457200, -342900, sizes[i], b)).join('')}</p:bodyStyle>` +
    `<p:otherStyle><a:defPPr><a:defRPr lang="es-ES"/></a:defPPr>${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(other).join('')}</p:otherStyle></p:txStyles></p:sldMaster>`
  );
}
const masterRels = () =>
  P.relsXml([
    ...[1, 2, 3, 4, 5, 6].map(i => ({ id: `rId${i}`, type: 'slideLayout', target: `../slideLayouts/slideLayout${i}.xml` })),
    { id: 'rId7', type: 'theme', target: '../theme/theme1.xml' }
  ]);

// Diseños: 1 título · 2 título y contenido · 3 encabezado de sección · 4 solo título · 5 en blanco · 6 dos contenidos
const LAYOUTS = [
  { n: 1, name: 'Diapositiva de título', type: 'title' },
  { n: 2, name: 'Título y objetos', type: 'obj' },
  { n: 3, name: 'Encabezado de sección', type: 'secHead' },
  { n: 4, name: 'Solo el título', type: 'titleOnly' },
  { n: 5, name: 'En blanco', type: 'blank' },
  { n: 6, name: 'Dos objetos', type: 'twoObj' }
];
function layoutXml(L) {
  const dark = L.type === 'title' || L.type === 'secHead';
  const bg = dark ? '<p:bg><p:bgPr><a:solidFill><a:schemeClr val="tx2"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>' : '';
  const white = sz => `<a:lvl1pPr algn="l"><a:defRPr sz="${sz}" b="1"><a:solidFill><a:schemeClr val="bg1"/></a:solidFill></a:defRPr></a:lvl1pPr>`;
  let shapes = '';
  if (L.type === 'title') {
    shapes =
      accentBar(8, 914400, 3590000, 1371600, 54864, 'accent2') +
      ph(2, 'Título 1', 'type="ctrTitle"', [914400, 1700000, 10363200, 1800000], '<a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="b"><a:normAutofit/></a:bodyPr>', white(4400), para('Haga clic para modificar el título')) +
      ph(3, 'Subtítulo 2', 'type="subTitle" idx="1"', [914400, 3800000, 10363200, 1300000], '<a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="t"><a:normAutofit/></a:bodyPr>', '<a:lvl1pPr marL="0" indent="0" algn="l"><a:buNone/><a:defRPr sz="2200"><a:solidFill><a:schemeClr val="lt2"/></a:solidFill></a:defRPr></a:lvl1pPr>', para('Haga clic para modificar el subtítulo'));
  } else if (L.type === 'secHead') {
    shapes =
      accentBar(8, 914400, 3590000, 1371600, 54864, 'accent2') +
      ph(2, 'Título 1', 'type="title"', [914400, 1900000, 10363200, 1600000], '<a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="b"><a:normAutofit/></a:bodyPr>', white(4000), para('Haga clic para modificar el título')) +
      ph(3, 'Marcador de texto 2', 'type="body" idx="1"', [914400, 3800000, 10363200, 1200000], '<a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="t"><a:normAutofit/></a:bodyPr>', '<a:lvl1pPr marL="0" indent="0"><a:buNone/><a:defRPr sz="2200"><a:solidFill><a:schemeClr val="lt2"/></a:solidFill></a:defRPr></a:lvl1pPr>', para('Haga clic para modificar el texto'));
  } else {
    shapes = L.type === 'blank' ? '' : ph(2, 'Título 1', 'type="title"', null, TITLEPR, '', para('Haga clic para modificar el título'));
    if (L.type === 'obj') shapes += ph(3, 'Marcador de contenido 2', 'idx="1"', null, BODYPR, '', para('Haga clic para modificar el texto') + para('Segundo nivel', 1));
    if (L.type === 'twoObj')
      shapes +=
        ph(3, 'Marcador de contenido 2', 'sz="half" idx="1"', [G.bodyX, G.bodyY, 5334000, G.bodyH], BODYPR, '', para('Haga clic para modificar el texto')) +
        ph(4, 'Marcador de contenido 3', 'sz="half" idx="2"', [G.bodyX + 5638800, G.bodyY, 5334000, G.bodyH], BODYPR, '', para('Haga clic para modificar el texto'));
    shapes += footers();
  }
  return (
    P.DECL +
    `<p:sldLayout ${NS} type="${L.type}" preserve="1"><p:cSld name="${escAttr(L.name)}">${bg}<p:spTree>${NV_GROUP}${shapes}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>`
  );
}
const layoutRels = () => P.relsXml([{ id: 'rId1', type: 'slideMaster', target: '../slideMasters/slideMaster1.xml' }]);

function notesMasterXml() {
  const sp = (id, name, phAttrs, x, y, cx, cy, extra = '') =>
    `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${name}"/><p:cNvSpPr><a:spLocks noGrp="1"${extra}/></p:cNvSpPr><p:nvPr><p:ph ${phAttrs}/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>${extra ? '<a:noFill/><a:ln w="12700"><a:solidFill><a:prstClr val="black"/></a:solidFill></a:ln>' : ''}</p:spPr>`;
  return (
    P.DECL +
    `<p:notesMaster ${NS}><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>${NV_GROUP}` +
    sp(2, 'Marcador de imagen de diapositiva 1', 'type="sldImg" idx="2"', 685800, 1143000, 5486400, 3086100, ' noRot="1" noChangeAspect="1"') + '</p:sp>' +
    sp(3, 'Marcador de notas 2', 'type="body" sz="quarter" idx="3"', 685800, 4400550, 5486400, 3600450) +
    '<p:txBody><a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0"/><a:lstStyle/><a:p><a:pPr lvl="0"/><a:r><a:rPr lang="es-ES"/><a:t>Haga clic para modificar los estilos de texto del patrón</a:t></a:r></a:p></p:txBody></p:sp>' +
    '</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>' +
    '<p:notesStyle><a:lvl1pPr marL="0" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl1pPr></p:notesStyle></p:notesMaster>'
  );
}
const notesMasterRels = () => P.relsXml([{ id: 'rId1', type: 'theme', target: '../theme/theme2.xml' }]);

module.exports = { NS, NV_GROUP, SLIDE_W, SLIDE_H, PAL, G, LAYOUTS, themeXml, masterXml, masterRels, layoutXml, layoutRels, notesMasterXml, notesMasterRels };
