'use strict';
// Modelo común de contenido para Word, PDF y PowerPoint: Markdown / HTML / objetos → bloques normalizados.
//   {t:'title'|'subtitle', runs}   {t:'h', level:1..6, runs}   {t:'p', runs, align?}   {t:'li', ordered, level, num?, runs}
//   {t:'table', head:[runs[]]|null, rows:[runs[][]], align:[]}   {t:'quote', runs}   {t:'code', text, lang}   {t:'hr'}   {t:'pb'}
// Texto en línea («runs»): {text, b, i, u, s, code, href} o {br:true}. Todo lo que llega del modelo pasa por aquí:
// nunca se inserta HTML/XML sin escapar y los enlaces solo pueden ser http(s) o mailto.
const { cleanText } = require('./xml.js');

const LIMITS = { maxBlocks: 20000, maxChars: 6_000_000, maxCell: 32000, maxListLevel: 3 };

function fail(message, code = 'DOC_INPUT') {
  const e = new Error(message);
  e.code = code;
  return e;
}

// ── Texto en línea ─────────────────────────────────────────────────────────────────────────────────────────────────
const NAMED_ENTITIES = { nbsp: '\u{A0}', amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", copy: '©', reg: '®', euro: '€', hellip: '…', mdash: '—', ndash: '–', trade: '™' };
function decodeHtmlEntities(s) {
  if (s.indexOf('&') < 0) return s;
  return s.replace(/&(#x[0-9a-fA-F]{1,6}|#[0-9]{1,7}|[a-zA-Z]{2,8});/g, (m, g) => {
    if (g[0] === '#') {
      const c = g[1] === 'x' || g[1] === 'X' ? parseInt(g.slice(2), 16) : parseInt(g.slice(1), 10);
      return c > 0 && c <= 0x10ffff && !(c >= 0xd800 && c <= 0xdfff) ? String.fromCodePoint(c) : '';
    }
    return NAMED_ENTITIES[g.toLowerCase()] ?? m;
  });
}
function safeHref(url) {
  let u = String(url || '').trim();
  if (!u || u.length > 2000 || /[\s\u0000-\u001f<>"]/.test(u)) return '';
  if (/^www\./i.test(u)) u = 'https://' + u;
  return /^(https?:\/\/[^\s/]+|mailto:[^\s@]+@[^\s@]+)/i.test(u) ? u : '';
}
const FLAG_KEYS = ['b', 'i', 'u', 's', 'code', 'href'];
function mkRun(text, fmt) {
  const r = { text: cleanText(text) };
  for (const k of FLAG_KEYS) if (fmt && fmt[k]) r[k] = fmt[k];
  return r;
}
function sameFmt(a, b) {
  for (const k of FLAG_KEYS) if ((a[k] || false) !== (b[k] || false)) return false;
  return true;
}
function mergeRuns(runs) {
  const out = [];
  for (const r of runs) {
    if (r.br) {
      out.push(r);
      continue;
    }
    if (!r.text) continue;
    const last = out[out.length - 1];
    if (last && !last.br && sameFmt(last, r)) last.text += r.text;
    else out.push(r);
  }
  while (out.length && out[out.length - 1].br) out.pop();
  return out;
}
const isAlnum = ch => !!ch && /[\p{L}\p{N}]/u.test(ch);
const isWs = ch => !ch || /\s/.test(ch);

function findClosingBracket(src, i) {
  let depth = 0;
  for (let j = i; j < src.length; j++) {
    const c = src[j];
    if (c === '\\') j++;
    else if (c === '`') {
      const m = /^`+/.exec(src.slice(j));
      const end = src.indexOf(m[0], j + m[0].length);
      if (end > 0) j = end + m[0].length - 1;
    } else if (c === '[') depth++;
    else if (c === ']') {
      depth--;
      if (depth === 0) return j;
    }
  }
  return -1;
}
function matchLink(src, i, image = false) {
  const open = image ? i + 1 : i;
  const close = findClosingBracket(src, open);
  if (close < 0 || src[close + 1] !== '(') return null;
  let j = close + 2,
    depth = 1;
  const start = j;
  while (j < src.length && depth > 0) {
    const c = src[j];
    if (c === '\\') j++;
    else if (c === '(') depth++;
    else if (c === ')') depth--;
    else if (c === '\n') return null;
    j++;
  }
  if (depth !== 0) return null;
  let url = src.slice(start, j - 1).trim();
  const t = /^(<[^>]*>|\S+)(?:\s+(?:"[^"]*"|'[^']*'))?$/.exec(url);
  if (!t) return null;
  url = t[1].replace(/^<|>$/g, '');
  return { label: src.slice(open + 1, close), url, end: j };
}
function findDelimCloser(src, from, ch, k) {
  for (let j = from; j < src.length; j++) {
    const c = src[j];
    if (c === '\\') {
      j++;
      continue;
    }
    if (c === '`') {
      const m = /^`+/.exec(src.slice(j));
      const end = src.indexOf(m[0], j + m[0].length);
      if (end > 0) {
        j = end + m[0].length - 1;
        continue;
      }
      j += m[0].length - 1;
      continue;
    }
    if (c !== ch) continue;
    let e = j;
    while (src[e] === ch) e++;
    const len = e - j;
    if (len >= k && !isWs(src[j - 1]) && (ch !== '_' || !isAlnum(src[e - (len - k)]))) {
      // se usa el último tramo del grupo de delimitadores (p. ej. «***a***»: el cierre de 3 calza con k=3)
      if (len === k) return j;
      if (len > k) return j + (len - k);
    }
    j = e - 1;
  }
  return -1;
}
const TAG_FLAGS = { b: 'b', strong: 'b', i: 'i', em: 'i', u: 'u', ins: 'u', s: 's', del: 's', strike: 's' };

function parseInline(src, base = {}, ctx = {}) {
  const out = [];
  let buf = '';
  const flush = () => {
    if (buf) {
      out.push(mkRun(decodeHtmlEntities(buf), base));
      buf = '';
    }
  };
  src = String(src ?? '');
  const n = src.length;
  let i = 0;
  while (i < n) {
    const ch = src[i];
    if (ch === '\\' && i + 1 < n) {
      const nx = src[i + 1];
      if (nx === '\n') {
        flush();
        out.push({ br: true });
        i += 2;
        continue;
      }
      if (/[!-/:-@[-`{-~]/.test(nx)) {
        buf += nx;
        i += 2;
        continue;
      }
    }
    if (ch === '`') {
      let k = 1;
      while (src[i + k] === '`') k++;
      const fence = '`'.repeat(k);
      let end = -1,
        from = i + k;
      while (from < n) {
        const e = src.indexOf(fence, from);
        if (e < 0) break;
        if (src[e + k] !== '`' && src[e - 1] !== '`') {
          end = e;
          break;
        }
        from = e + 1;
      }
      if (end > 0) {
        flush();
        let inner = src.slice(i + k, end).replace(/\n/g, ' ');
        if (inner.length > 2 && inner.startsWith(' ') && inner.endsWith(' ')) inner = inner.slice(1, -1);
        out.push(mkRun(inner, { ...base, code: true }));
        i = end + k;
        continue;
      }
      buf += fence;
      i += k;
      continue;
    }
    if (ch === '\n') {
      buf = buf.replace(/ +$/, '');
      flush();
      out.push({ br: true });
      i++;
      while (src[i] === ' ') i++;
      continue;
    }
    if (ch === '!' && src[i + 1] === '[') {
      const m = matchLink(src, i, true);
      if (m) {
        buf += m.label ? `[Imagen: ${m.label}]` : '[Imagen]';
        (ctx.warnings || []).push(`Se omitió una imagen (${m.label || m.url}): los documentos todavía no incluyen imágenes.`);
        i = m.end;
        continue;
      }
    }
    if (ch === '[') {
      const m = matchLink(src, i);
      if (m) {
        flush();
        const href = safeHref(m.url);
        out.push(...parseInline(m.label, href ? { ...base, href } : base, ctx));
        if (!href && m.url) {
          const shown = String(m.url).slice(0, 80);
          if (m.label.trim() !== shown) out.push(mkRun(` (${shown})`, base));
        }
        i = m.end;
        continue;
      }
    }
    if (ch === '<') {
      const auto = /^<((?:https?:\/\/|mailto:)[^\s<>]+)>/i.exec(src.slice(i, i + 2100));
      if (auto) {
        flush();
        const href = safeHref(auto[1]);
        out.push(mkRun(auto[1], href ? { ...base, href } : base));
        i += auto[0].length;
        continue;
      }
      const tag = /^<(\/?)([a-zA-Z][a-zA-Z0-9]*)(\s[^<>]{0,500})?(\/?)>/.exec(src.slice(i, i + 600));
      if (tag) {
        const name = tag[2].toLowerCase();
        if (name === 'br') {
          flush();
          out.push({ br: true });
          i += tag[0].length;
          continue;
        }
        if (!tag[1] && TAG_FLAGS[name] && !tag[4]) {
          const closeRe = new RegExp(`</${name}\\s*>`, 'i');
          const rest = src.slice(i + tag[0].length);
          const cm = closeRe.exec(rest);
          if (cm) {
            flush();
            out.push(...parseInline(rest.slice(0, cm.index), { ...base, [TAG_FLAGS[name]]: true }, ctx));
            i += tag[0].length + cm.index + cm[0].length;
            continue;
          }
        }
        if (['span', 'font', 'small', 'big', 'mark', 'center', 'p', 'div', 'sub', 'sup', 'b', 'strong', 'i', 'em', 'u', 'a', 'code', 'ins', 'del', 's', 'strike'].includes(name)) {
          // etiquetas de formato sueltas: se descarta la etiqueta y se conserva el texto (las demás, como <script> o <T>, se muestran tal cual)
          i += tag[0].length;
          continue;
        }
      }
    }
    if (ch === '*' || ch === '_' || ch === '~') {
      let k = 1;
      while (src[i + k] === ch) k++;
      const prev = src[i - 1],
        next = src[i + k];
      const kk = Math.min(k, 3);
      const canOpen = !isWs(next) && (ch !== '_' || !isAlnum(prev)) && (ch !== '~' || k >= 2);
      if (canOpen) {
        const useK = ch === '~' ? 2 : kk;
        const startContent = i + k - (k - useK);
        const closer = findDelimCloser(src, i + k, ch, useK);
        if (closer > 0 && closer > startContent) {
          flush();
          if (k > useK) buf += ch.repeat(k - useK);
          const inner = src.slice(i + k, closer);
          const fmt = { ...base };
          if (ch === '~') fmt.s = true;
          else if (useK === 1) fmt.i = true;
          else if (useK === 2) fmt.b = true;
          else {
            fmt.b = true;
            fmt.i = true;
          }
          flush();
          out.push(...parseInline(inner, fmt, ctx));
          i = closer + useK;
          continue;
        }
      }
      buf += ch.repeat(k);
      i += k;
      continue;
    }
    if ((ch === 'h' || ch === 'H') && /^https?:\/\//i.test(src.slice(i, i + 8)) && !isAlnum(src[i - 1])) {
      const m = /^https?:\/\/[^\s<>"'`]+/i.exec(src.slice(i, i + 2100));
      if (m) {
        let url = m[0];
        while (/[.,;:!?)\]}'"»]$/.test(url) && !(url.endsWith(')') && url.includes('('))) url = url.slice(0, -1);
        const href = safeHref(url);
        if (href && !base.href) {
          flush();
          out.push(mkRun(url, { ...base, href }));
          i += url.length;
          continue;
        }
      }
    }
    buf += ch;
    i++;
  }
  flush();
  return mergeRuns(out);
}
const runsText = runs => (runs || []).map(r => (r.br ? '\n' : r.text)).join('');
const inline = (s, ctx) => parseInline(s, {}, ctx);

// ── Markdown (bloques) ─────────────────────────────────────────────────────────────────────────────────────────────
const LIST_RE = /^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$/;
const FENCE_RE = /^\s{0,3}(`{3,}|~{3,})\s*([\w+#.-]*)[^\n]*$/;
const HEADING_RE = /^\s{0,3}(#{1,6})\s+(.*?)(?:\s+#+\s*)?$/;
const HR_RE = /^\s{0,3}([-*_])(?:\s*\1){2,}\s*$/;
const PB_RE = /^\s*(?:\\(?:pagebreak|newpage)|<!--\s*page-?break\s*-->|\[\[\s*page-?break\s*\]\]|-{2,}\s*page-?break\s*-{2,}|<(?:div|p|hr)[^>]*page-break[^>]*>(?:\s*<\/(?:div|p)>)?)\s*$/i;
const DELIM_CELL_RE = /^:?-{1,}:?$/;

function splitRow(line) {
  let s = line.trim();
  if (s.startsWith('|')) s = s.slice(1);
  if (s.endsWith('|') && !s.endsWith('\\|')) s = s.slice(0, -1);
  const cells = [];
  let cur = '',
    inCode = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === '\\' && s[i + 1] === '|') {
      cur += '|';
      i++;
    } else if (c === '`') {
      inCode = !inCode;
      cur += c;
    } else if (c === '|' && !inCode) {
      cells.push(cur.trim());
      cur = '';
    } else cur += c;
  }
  cells.push(cur.trim());
  return cells;
}
const isDelimRow = line => {
  if (!line || line.indexOf('-') < 0) return false;
  const cells = splitRow(line);
  return cells.length >= 1 && cells.every(c => DELIM_CELL_RE.test(c.replace(/\s/g, '')));
};
const looksTableRow = line => !!line && line.includes('|') && !/^\s{4,}\S/.test(line);
function startsBlock(line, nextLine) {
  return (
    FENCE_RE.test(line) || HEADING_RE.test(line) || HR_RE.test(line) || /^\s{0,3}>/.test(line) || LIST_RE.test(line) || PB_RE.test(line) || (looksTableRow(line) && isDelimRow(nextLine))
  );
}

function parseMarkdown(src, ctx = {}) {
  const lines = String(src ?? '')
    .replace(/\r\n?/g, '\n')
    .replace(/[\u{2028}\u{2029}]/gu, '\n')
    .split('\n');
  const blocks = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) {
      i++;
      continue;
    }
    let m = FENCE_RE.exec(line);
    if (m) {
      const fence = m[1];
      const buf = [];
      i++;
      while (i < lines.length && !new RegExp(`^\\s{0,3}${fence[0]}{${fence.length},}\\s*$`).test(lines[i])) buf.push(lines[i++]);
      i++;
      blocks.push({ t: 'code', text: cleanText(buf.join('\n')), lang: m[2] || '' });
      continue;
    }
    if (PB_RE.test(line)) {
      blocks.push({ t: 'pb' });
      i++;
      continue;
    }
    m = HEADING_RE.exec(line);
    if (m) {
      blocks.push({ t: 'h', level: m[1].length, runs: inline(m[2], ctx) });
      i++;
      continue;
    }
    if (HR_RE.test(line) && !(LIST_RE.test(line) && /^\s*[-*+]\s/.test(line))) {
      blocks.push({ t: 'hr' });
      i++;
      continue;
    }
    if (looksTableRow(line) && isDelimRow(lines[i + 1])) {
      const head = splitRow(line);
      const delim = splitRow(lines[i + 1]).map(c => c.replace(/\s/g, ''));
      const align = delim.map(c => (c.startsWith(':') && c.endsWith(':') ? 'c' : c.endsWith(':') ? 'r' : c.startsWith(':') ? 'l' : ''));
      i += 2;
      const rows = [];
      while (i < lines.length && lines[i].trim() && looksTableRow(lines[i]) && !FENCE_RE.test(lines[i]) && !HEADING_RE.test(lines[i])) rows.push(splitRow(lines[i++]));
      const width = Math.max(head.length, ...rows.map(r => r.length));
      const fix = r => Array.from({ length: width }, (_, c) => inline(String(r[c] ?? '').slice(0, LIMITS.maxCell), ctx));
      blocks.push({ t: 'table', head: fix(head), rows: rows.map(fix), align: Array.from({ length: width }, (_, c) => align[c] || '') });
      continue;
    }
    if (/^\s{0,3}>/.test(line)) {
      const buf = [];
      while (i < lines.length && /^\s{0,3}>/.test(lines[i])) buf.push(lines[i++].replace(/^\s{0,3}>\s?/, ''));
      for (const para of buf.join('\n').split(/\n\s*\n/)) if (para.trim()) blocks.push({ t: 'quote', runs: inline(para.trim(), ctx) });
      continue;
    }
    m = LIST_RE.exec(line.replace(/\t/g, '    '));
    if (m && !HR_RE.test(line)) {
      const items = [];
      const indents = [];
      while (i < lines.length) {
        const raw = lines[i].replace(/\t/g, '    ');
        if (!raw.trim()) {
          let j = i + 1;
          while (j < lines.length && !lines[j].trim()) j++;
          if (j < lines.length && (LIST_RE.test(lines[j].replace(/\t/g, '    ')) || /^\s{2,}\S/.test(lines[j])) && !HR_RE.test(lines[j])) {
            i = j;
            continue;
          }
          break;
        }
        const lm = LIST_RE.exec(raw);
        if (lm && !HR_RE.test(raw)) {
          const indent = lm[1].length;
          while (indents.length && indents[indents.length - 1] > indent) indents.pop();
          if (!indents.length || indents[indents.length - 1] < indent) indents.push(indent);
          const ordered = /\d/.test(lm[2]);
          let text = lm[3];
          const task = /^\[([ xX])\]\s+/.exec(text);
          if (task) text = (task[1] === ' ' ? '☐ ' : '☑ ') + text.slice(task[0].length);
          items.push({ ordered, level: Math.min(indents.length - 1, LIMITS.maxListLevel), num: ordered ? parseInt(lm[2], 10) : undefined, src: text });
          i++;
          continue;
        }
        if (/^\s{2,}\S/.test(raw) && items.length && !startsBlock(raw.trim(), lines[i + 1])) {
          items[items.length - 1].src += '\n' + raw.trim();
          i++;
          continue;
        }
        break;
      }
      for (const it of items) blocks.push({ t: 'li', ordered: it.ordered, level: it.level, num: it.num, runs: inline(it.src, ctx) });
      continue;
    }
    // párrafo: se junta hasta una línea en blanco u otro bloque
    const buf = [line];
    i++;
    while (i < lines.length && lines[i].trim() && !startsBlock(lines[i], lines[i + 1])) buf.push(lines[i++]);
    blocks.push({ t: 'p', runs: inline(buf.map(x => x.replace(/^\s+/, '')).join('\n'), ctx) });
  }
  return blocks;
}

// ── HTML (conversión mínima a bloques; nunca se ejecuta ni se inserta tal cual) ───────────────────────────────────
function htmlToBlocks(html, ctx = {}) {
  const src = String(html ?? '')
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<(script|style|head|svg|noscript|iframe|object|embed)\b[\s\S]*?<\/\1\s*>/gi, ' ');
  const blocks = [];
  let runs = [];
  let flags = [];
  let listStack = [];
  let table = null;
  let cell = null;
  let kind = null; // {t:'h',level} | {t:'p'} | {t:'li'} | {t:'quote'} | {t:'code'}
  const fmt = () => {
    const f = {};
    for (const x of flags) Object.assign(f, x);
    return f;
  };
  const addText = t => {
    const text = decodeHtmlEntities(t.replace(/\s+/g, kind?.t === 'code' ? ' ' : ' '));
    if (!text) return;
    (cell ? cell.runs : runs).push(mkRun(text, fmt()));
  };
  const endBlock = () => {
    const rs = mergeRuns(runs);
    runs = [];
    if (!kind) {
      if (rs.some(r => r.br || /\S/.test(r.text))) blocks.push({ t: 'p', runs: trimRuns(rs) });
      return;
    }
    if (rs.some(r => r.br || /\S/.test(r.text))) {
      const t = trimRuns(rs);
      if (kind.t === 'h') blocks.push({ t: 'h', level: kind.level, runs: t });
      else if (kind.t === 'li') blocks.push({ t: 'li', ordered: kind.ordered, level: Math.min(kind.level, LIMITS.maxListLevel), num: kind.num, runs: t });
      else if (kind.t === 'quote') blocks.push({ t: 'quote', runs: t });
      else if (kind.t === 'code') blocks.push({ t: 'code', text: runsText(rs), lang: '' });
      else blocks.push({ t: 'p', runs: t });
    }
    kind = null;
  };
  function trimRuns(rs) {
    const out = rs.map(r => ({ ...r }));
    if (out[0] && !out[0].br) out[0].text = out[0].text.replace(/^\s+/, '');
    const l = out[out.length - 1];
    if (l && !l.br) l.text = l.text.replace(/\s+$/, '');
    return out.filter(r => r.br || r.text);
  }
  const tagRe = /<(\/?)([a-zA-Z][a-zA-Z0-9]*)((?:\s+[^<>]*?)?)\s*(\/?)>/g;
  let last = 0,
    m;
  while ((m = tagRe.exec(src))) {
    if (m.index > last) addText(src.slice(last, m.index));
    last = tagRe.lastIndex;
    const close = !!m[1],
      name = m[2].toLowerCase(),
      attrs = m[3] || '';
    if (/^h[1-6]$/.test(name)) {
      if (!close) {
        endBlock();
        kind = { t: 'h', level: +name[1] };
      } else endBlock();
    } else if (name === 'p' || name === 'div' || name === 'section' || name === 'article' || name === 'header' || name === 'footer') {
      if (!cell) endBlock();
      if (!close && !cell) kind = null;
    } else if (name === 'br') (cell ? cell.runs : runs).push({ br: true });
    else if (name === 'hr') {
      endBlock();
      blocks.push({ t: 'hr' });
    } else if (name === 'ul' || name === 'ol') {
      endBlock();
      if (!close) listStack.push({ ordered: name === 'ol', n: 0 });
      else listStack.pop();
    } else if (name === 'li') {
      if (!close) {
        endBlock();
        const top = listStack[listStack.length - 1] || { ordered: false, n: 0 };
        top.n++;
        kind = { t: 'li', ordered: top.ordered, level: Math.max(0, listStack.length - 1), num: top.ordered ? top.n : undefined };
      } else endBlock();
    } else if (name === 'blockquote') {
      endBlock();
      if (!close) kind = { t: 'quote' };
    } else if (name === 'pre') {
      endBlock();
      if (!close) kind = { t: 'code' };
    } else if (name === 'table') {
      if (!close) {
        endBlock();
        table = { head: null, rows: [], cur: null, inHead: false };
      } else if (table) {
        if (cell) cell = null;
        if (table.cur) table.rows.push(table.cur);
        const all = table.rows;
        const width = Math.max(0, ...all.map(r => r.length));
        const fix = r => Array.from({ length: width }, (_, c) => r[c] || []);
        if (all.length) {
          const head = table.head || (table.firstIsHeader ? all[0] : null);
          const body = head && !table.head ? all.slice(1) : all;
          blocks.push({ t: 'table', head: head ? fix(head) : null, rows: body.map(fix), align: Array(width).fill('') });
        }
        table = null;
      }
    } else if (table && (name === 'thead' || name === 'tbody' || name === 'tfoot')) {
      table.inHead = name === 'thead' && !close;
    } else if (table && name === 'tr') {
      if (!close) table.cur = [];
      else if (table.cur) {
        if (table.inHead && !table.head) table.head = table.cur;
        else table.rows.push(table.cur);
        table.cur = null;
      }
    } else if (table && (name === 'td' || name === 'th')) {
      if (!close) {
        cell = { runs: [] };
        if (name === 'th' && table.rows.length === 0 && !table.head) table.firstIsHeader = true;
      } else if (cell) {
        const t = trimRuns(mergeRuns(cell.runs));
        if (table.cur) table.cur.push(t);
        cell = null;
      }
    } else if (TAG_FLAGS[name] || name === 'code' || name === 'a' || name === 'kbd' || name === 'tt') {
      if (!close) {
        let f = {};
        if (TAG_FLAGS[name]) f = { [TAG_FLAGS[name]]: true };
        else if (name === 'a') {
          const hm = /href\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(attrs);
          const href = safeHref(decodeHtmlEntities(hm ? hm[1] ?? hm[2] ?? hm[3] : ''));
          f = href ? { href } : {};
        } else f = { code: true };
        flags.push(f);
      } else flags.pop();
    } else if (name === 'img') (ctx.warnings || []).push('Se omitió una imagen del HTML: los documentos todavía no incluyen imágenes.');
  }
  if (last < src.length) addText(src.slice(last));
  endBlock();
  return blocks;
}

// ── Objetos del modelo → bloques ───────────────────────────────────────────────────────────────────────────────────
const clip = s => cleanText(String(s ?? '').slice(0, LIMITS.maxCell));
function cellRuns(v, ctx) {
  if (v && typeof v === 'object' && !Array.isArray(v)) v = v.text ?? v.value ?? v.v ?? '';
  if (Array.isArray(v)) v = v.join('\n');
  return inline(clip(v), ctx);
}
function listBlocks(items, ordered, level, ctx, out) {
  let n = 0;
  for (const it of Array.isArray(items) ? items : [items]) {
    if (it == null) continue;
    if (typeof it === 'string' || typeof it === 'number') {
      n++;
      out.push({ t: 'li', ordered, level: Math.min(level, LIMITS.maxListLevel), num: ordered ? n : undefined, runs: inline(clip(it), ctx) });
    } else if (Array.isArray(it)) listBlocks(it, ordered, level + 1, ctx, out);
    else if (typeof it === 'object') {
      n++;
      const text = it.text ?? it.title ?? it.content ?? it.label ?? '';
      out.push({ t: 'li', ordered, level: Math.min(Number(it.level ?? it.indent ?? level) || 0, LIMITS.maxListLevel), num: ordered ? n : undefined, runs: inline(clip(text), ctx) });
      const kids = it.children ?? it.items ?? it.subitems ?? it.sub;
      if (kids) listBlocks(kids, ordered, level + 1, ctx, out);
    }
  }
}
function alignOf(v) {
  v = String(v || '').toLowerCase();
  return v === 'center' || v === 'centre' ? 'center' : v === 'right' ? 'right' : v === 'justify' || v === 'justified' || v === 'both' ? 'justify' : '';
}
function blockFromObject(o, ctx, out) {
  let type = String(o.type ?? o.kind ?? o.block ?? '').toLowerCase().replace(/[\s-]+/g, '_');
  const style = String(o.style ?? o.styleName ?? '').toLowerCase().replace(/[\s_-]+/g, '');
  const text = o.text ?? o.content ?? o.value ?? o.title ?? o.heading ?? o.paragraph ?? '';
  let hm;
  if (!type) {
    if (o.heading !== undefined && typeof o.heading === 'string') type = 'heading';
    else if (o.table || o.rows || o.header || o.headers || o.columns) type = 'table';
    else if (o.bullets || o.items || o.list) type = o.ordered || o.numbered ? 'numbered' : 'bullets';
    else if (o.code) type = 'code';
    else if ((hm = /^heading(\d)$/.exec(style))) type = 'h' + hm[1];
    else if (style === 'title') type = 'title';
    else if (style === 'subtitle') type = 'subtitle';
    else if (/^list(bullet|paragraph)/.test(style)) type = 'bullets';
    else if (/^listnumber/.test(style)) type = 'numbered';
    else if (/quote/.test(style)) type = 'quote';
    else type = 'paragraph';
  }
  if ((hm = /^h([1-6])$/.exec(type)) || (hm = /^heading_?([1-6])$/.exec(type))) {
    out.push({ t: 'h', level: +hm[1], runs: inline(clip(text), ctx) });
    return;
  }
  const baseFmt = {};
  if (o.bold) baseFmt.b = true;
  if (o.italic) baseFmt.i = true;
  if (o.underline) baseFmt.u = true;
  switch (type) {
    case 'heading':
    case 'header':
    case 'h': {
      const lv = Math.max(1, Math.min(6, Number(o.level ?? o.size ?? 1) || 1));
      out.push({ t: 'h', level: lv, runs: inline(clip(text), ctx) });
      return;
    }
    case 'title':
      out.push({ t: 'title', runs: inline(clip(text), ctx) });
      return;
    case 'subtitle':
      out.push({ t: 'subtitle', runs: inline(clip(text), ctx) });
      return;
    case 'bullets':
    case 'bullet':
    case 'bulleted_list':
    case 'bullet_list':
    case 'ul':
    case 'unordered_list':
    case 'list_bullet':
      listBlocks(o.items ?? o.bullets ?? o.list ?? o.children ?? text, false, 0, ctx, out);
      return;
    case 'numbered':
    case 'numbered_list':
    case 'ordered':
    case 'ordered_list':
    case 'ol':
    case 'list_number':
    case 'steps':
      listBlocks(o.items ?? o.steps ?? o.list ?? o.children ?? text, true, 0, ctx, out);
      return;
    case 'list': {
      const ordered = !!(o.ordered || o.numbered || /num|ord|dec/i.test(String(o.style || o.listType || '')));
      listBlocks(o.items ?? o.list ?? o.children ?? text, ordered, 0, ctx, out);
      return;
    }
    case 'table': {
      let head = o.header ?? o.headers ?? o.head ?? o.columns ?? null;
      let rows = o.rows ?? o.data ?? o.body ?? [];
      if (Array.isArray(head) && head.length && typeof head[0] === 'object' && !Array.isArray(head[0])) head = head.map(c => c.title ?? c.label ?? c.header ?? c.key ?? '');
      if (Array.isArray(rows) && rows.length && rows.every(r => r && typeof r === 'object' && !Array.isArray(r))) {
        const keys = Array.isArray(o.columns) && o.columns.every(c => typeof c === 'string') ? o.columns : [...new Set(rows.flatMap(r => Object.keys(r)))];
        if (!head) head = keys;
        rows = rows.map(r => keys.map(k => r[k]));
      }
      if (!Array.isArray(rows)) rows = [];
      rows = rows.map(r => (Array.isArray(r) ? r : [r]));
      if (!head && o.firstRowHeader !== false && o.header !== false && rows.length > 1 && o.headerRow) {
        head = rows[0];
        rows = rows.slice(1);
      }
      const width = Math.max(Array.isArray(head) ? head.length : 0, ...rows.map(r => r.length), 1);
      const fix = r => Array.from({ length: width }, (_, c) => cellRuns(r?.[c], ctx));
      out.push({ t: 'table', head: Array.isArray(head) ? fix(head) : null, rows: rows.map(fix), align: Array(width).fill('') });
      return;
    }
    case 'quote':
    case 'blockquote':
      out.push({ t: 'quote', runs: inline(clip(text), ctx) });
      return;
    case 'code':
    case 'code_block':
    case 'codeblock':
    case 'pre':
      out.push({ t: 'code', text: clip(o.code ?? text), lang: String(o.language ?? o.lang ?? '') });
      return;
    case 'pagebreak':
    case 'page_break':
    case 'break':
    case 'newpage':
      out.push({ t: 'pb' });
      return;
    case 'hr':
    case 'rule':
    case 'divider':
    case 'line':
    case 'separator':
      out.push({ t: 'hr' });
      return;
    case 'image':
    case 'picture':
    case 'figure':
      (ctx.warnings || []).push(`Se omitió una imagen (${o.alt || o.caption || o.src || o.path || ''}): los documentos todavía no incluyen imágenes.`);
      if (o.alt || o.caption) out.push({ t: 'p', runs: inline(`[Imagen: ${o.alt || o.caption}]`, ctx) });
      return;
    case 'markdown':
    case 'md':
      out.push(...parseMarkdown(String(text), ctx));
      return;
    case 'html':
      out.push(...htmlToBlocks(String(text), ctx));
      return;
    default: {
      const t = String(text ?? '');
      if (!t.trim() && !Array.isArray(o.runs)) {
        (ctx.warnings || []).push(`Se omitió un bloque desconocido (${type || 'sin tipo'}).`);
        return;
      }
      let runs;
      if (Array.isArray(o.runs)) runs = mergeRuns(o.runs.map(r => (typeof r === 'string' ? mkRun(clip(r), baseFmt) : mkRun(clip(r.text ?? ''), { ...baseFmt, b: r.bold || r.b || baseFmt.b, i: r.italic || r.i || baseFmt.i, u: r.underline || r.u || baseFmt.u, href: safeHref(r.href ?? r.link ?? r.url) || undefined }))));
      else if (type === 'paragraph' || type === 'p' || type === 'text' || type === 'body' || type === 'normal') runs = parseInline(clip(t), baseFmt, ctx);
      else runs = parseInline(clip(t), baseFmt, ctx);
      const p = { t: 'p', runs };
      const al = alignOf(o.align ?? o.alignment);
      if (al) p.align = al;
      out.push(p);
    }
  }
}
function blocksFromValue(v, ctx = {}, out = []) {
  if (v == null || v === '') return out;
  if (typeof v === 'string') out.push(...parseMarkdown(v, ctx));
  else if (typeof v === 'number' || typeof v === 'boolean') out.push({ t: 'p', runs: [mkRun(String(v), {})] });
  else if (Array.isArray(v)) {
    for (const x of v) blocksFromValue(x, ctx, out);
  } else if (typeof v === 'object') blockFromObject(v, ctx, out);
  if (out.length > LIMITS.maxBlocks) throw fail(`El documento tiene demasiados bloques (máximo ${LIMITS.maxBlocks}).`, 'DOC_LIMIT');
  return out;
}

// Elige el contenido de texto que mandó el modelo (blocks > paragraphs > content > text > markdown > html) y avisa si sobraba otro.
function contentBlocks(args = {}, ctx = {}) {
  const warnings = (ctx.warnings = ctx.warnings || []);
  const has = v => (Array.isArray(v) ? v.length > 0 : typeof v === 'string' ? v.trim().length > 0 : v && typeof v === 'object');
  const sources = [
    ['blocks', args.blocks],
    ['paragraphs', args.paragraphs],
    ['content', args.content],
    ['text', args.text],
    ['markdown', args.markdown],
    ['html', args.html]
  ].filter(([, v]) => has(v));
  const title = String(args.title ?? '').trim();
  let blocks = [];
  if (title) blocks.push({ t: 'title', runs: inline(title.slice(0, 500), ctx) });
  const subtitle = String(args.subtitle ?? '').trim();
  if (subtitle) blocks.push({ t: 'subtitle', runs: inline(subtitle.slice(0, 500), ctx) });
  if (sources.length) {
    const [name, v] = sources[0];
    if (name === 'html') blocks.push(...htmlToBlocks(String(v), ctx));
    else blocks = blocks.concat(blocksFromValue(v, ctx));
    if (sources.length > 1) warnings.push(`Se recibió contenido en varios campos (${sources.map(s => s[0]).join(', ')}); se usó «${name}» y se ignoró el resto.`);
  }
  return blocks;
}
function totalChars(blocks) {
  let n = 0;
  for (const b of blocks) {
    if (b.runs) n += runsText(b.runs).length;
    if (b.text) n += b.text.length;
    if (b.t === 'table') for (const r of [b.head || [], ...b.rows]) for (const c of r) n += runsText(c).length;
  }
  return n;
}
function assertSize(blocks) {
  if (blocks.length > LIMITS.maxBlocks) throw fail(`El documento tiene demasiados bloques (máximo ${LIMITS.maxBlocks}).`, 'DOC_LIMIT');
  if (totalChars(blocks) > LIMITS.maxChars) throw fail('El documento es demasiado grande para crearlo de una sola vez. Divídelo en partes.', 'DOC_LIMIT');
}
// Texto plano de los bloques (para verificar lo escrito y para vistas previas).
function blocksPlain(blocks) {
  const out = [];
  for (const b of blocks) {
    if (b.t === 'table') {
      for (const r of [b.head || [], ...b.rows]) if (r.length) out.push(r.map(c => runsText(c)).join(' | '));
    } else if (b.t === 'code') out.push(b.text);
    else if (b.runs) out.push(runsText(b.runs));
  }
  return out.filter(x => x != null).join('\n');
}
const wordCount = s => (String(s).match(/[\p{L}\p{N}](?:[\p{L}\p{N}'’-]|[.,](?=\p{N}))*/gu) || []).length;


// Texto para el modelo: Markdown sencillo (títulos, listas, tablas, citas, código). `marks`: conservar **negrita**/*cursiva*.
function runsMd(runs, marks) {
  let out = '';
  for (const r of runs || []) {
    if (r.br) {
      out += '\n';
      continue;
    }
    let t = r.text;
    if (!t) continue;
    if (marks && t.trim()) {
      const lead = /^\s*/.exec(t)[0],
        trail = /\s*$/.exec(t)[0],
        core = t.slice(lead.length, t.length - trail.length);
      let x = core;
      if (r.code) x = '`' + x + '`';
      if (r.b && r.i) x = '***' + x + '***';
      else if (r.b) x = '**' + x + '**';
      else if (r.i) x = '*' + x + '*';
      if (r.s) x = '~~' + x + '~~';
      t = lead + x + trail;
    }
    out += r.href && t.trim() ? `[${t}](${r.href})` : t;
  }
  return out;
}
function blocksToMarkdown(blocks, { marks = false } = {}) {
  const out = [];
  let prev = '';
  const sep = kind => {
    if (out.length && !(kind === 'li' && prev === 'li')) out.push('');
    prev = kind;
  };
  const cellText = c => runsMd(c, marks).replace(/\n/g, ' ').replace(/\|/g, '\\|').trim();
  for (const b of blocks) {
    if (b.t === 'title') {
      sep('title');
      out.push('# ' + runsMd(b.runs, marks).replace(/\n/g, ' '));
    } else if (b.t === 'subtitle') {
      sep('subtitle');
      out.push('_' + runsMd(b.runs, false).replace(/\n/g, ' ') + '_');
    } else if (b.t === 'h') {
      sep('h');
      out.push('#'.repeat(Math.max(1, Math.min(6, b.level))) + ' ' + runsMd(b.runs, marks).replace(/\n/g, ' '));
    } else if (b.t === 'p') {
      sep('p');
      out.push(runsMd(b.runs, marks));
    } else if (b.t === 'li') {
      sep('li');
      out.push('  '.repeat(b.level || 0) + (b.ordered ? `${b.num || 1}. ` : '- ') + runsMd(b.runs, marks).replace(/\n/g, ' '));
    } else if (b.t === 'table') {
      sep('table');
      const width = Math.max(b.head ? b.head.length : 0, ...b.rows.map(r => r.length), 1);
      const row = r => '| ' + Array.from({ length: width }, (_, c) => cellText(r[c] || [])).join(' | ') + ' |';
      const head = b.head || Array.from({ length: width }, () => []);
      out.push(row(head));
      out.push('|' + Array.from({ length: width }, (_, c) => (b.align?.[c] === 'r' ? ' ---: ' : b.align?.[c] === 'c' ? ' :---: ' : ' --- ')).join('|') + '|');
      for (const r of b.rows) out.push(row(r));
    } else if (b.t === 'quote') {
      sep('quote');
      out.push(runsMd(b.runs, marks).split('\n').map(l => '> ' + l).join('\n'));
    } else if (b.t === 'code') {
      sep('code');
      out.push('```' + (b.lang || ''), b.text, '```');
    } else if (b.t === 'hr') {
      sep('hr');
      out.push('---');
    }
  }
  return out.join('\n');
}

module.exports = { runsMd, blocksToMarkdown, LIMITS, fail, parseInline, parseMarkdown, htmlToBlocks, blocksFromValue, contentBlocks, blockFromObject, assertSize, blocksPlain, runsText, wordCount, safeHref, decodeHtmlEntities, mergeRuns, mkRun, inline, cleanText };
