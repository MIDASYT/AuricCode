'use strict';
// Hilo aparte que lee un PDF con PDF.js. El proceso principal lo vigila (tiempo y memoria) y lo termina si se cuelga.
const { parentPort, workerData } = require('worker_threads');
const path = require('path');
const { pathToFileURL } = require('url');

const quiet = fn => {
  const saved = { log: console.log, warn: console.warn, error: console.error, info: console.info };
  console.log = console.warn = console.error = console.info = () => {};
  return fn().finally(() => Object.assign(console, saved));
};
function pageList(spec, total) {
  if (!spec) return Array.from({ length: total }, (_, i) => i + 1);
  const out = new Set();
  for (const part of String(spec).split(',')) {
    const m = /^\s*(\d+)\s*(?:-\s*(\d+)\s*)?$/.exec(part);
    if (!m) continue;
    const a = Math.max(1, Number(m[1])),
      b = Math.min(total, Number(m[2] || m[1]));
    for (let i = a; i <= b; i++) out.add(i);
  }
  return [...out].sort((x, y) => x - y);
}
(async () => {
  try {
    const { libDir, data, pages: spec, maxPages, maxChars } = workerData;
    const pdfjs = await quiet(() => import(pathToFileURL(path.join(libDir, 'pdf.min.mjs')).href));
    pdfjs.GlobalWorkerOptions.workerSrc = pathToFileURL(path.join(libDir, 'pdf.worker.min.mjs')).href;
    const task = pdfjs.getDocument({
      data: new Uint8Array(data),
      isEvalSupported: false,
      useSystemFonts: false,
      disableFontFace: true,
      enableXfa: false,
      verbosity: 0,
      stopAtErrors: false,
      maxImageSize: 16 * 1024 * 1024,
      cMapUrl: path.join(libDir, 'cmaps').replace(/\\/g, '/') + '/',
      cMapPacked: true,
      standardFontDataUrl: path.join(libDir, 'standard_fonts').replace(/\\/g, '/') + '/'
    });
    const doc = await quiet(() => task.promise);
    const total = doc.numPages;
    const wanted = pageList(spec, total);
    const out = [];
    let chars = 0,
      truncated = false;
    for (const n of wanted) {
      if (out.length >= maxPages || chars >= maxChars) {
        truncated = true;
        break;
      }
      const page = await quiet(() => doc.getPage(n));
      const tc = await quiet(() => page.getTextContent());
      let text = '',
        prev = null;
      for (const it of tc.items) {
        if (typeof it.str !== 'string') continue;
        if (prev && !prev.hasEOL && it.str) {
          const dy = Math.abs(it.transform[5] - prev.transform[5]);
          const fs = Math.abs(prev.transform[3]) || prev.height || 10;
          if (dy > fs * 0.6) text += '\n';
          else {
            const gap = it.transform[4] - (prev.transform[4] + (prev.width || 0));
            if (gap > fs * 0.28 && !/\s$/.test(text) && !/^\s/.test(it.str)) text += ' ';
          }
        }
        text += it.str;
        if (it.hasEOL) text += '\n';
        if (it.str) prev = it;
      }
      text = text.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
      chars += text.length;
      out.push({ n, text });
      page.cleanup();
    }
    let info = {};
    try {
      const meta = await doc.getMetadata();
      for (const k of ['Title', 'Author', 'Subject', 'Creator', 'Producer', 'CreationDate']) if (meta?.info?.[k]) info[k] = String(meta.info[k]).slice(0, 300);
    } catch {}
    await task.destroy().catch(() => {});
    parentPort.postMessage({ ok: true, pageCount: total, pages: out, info, truncated });
  } catch (e) {
    parentPort.postMessage({ ok: false, error: { name: String(e?.name || 'Error'), message: String(e?.message || e).slice(0, 400), code: e?.code } });
  }
})();
