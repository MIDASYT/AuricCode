'use strict';
// Word (.docx): creación desde bloques y lectura segura. Todo el texto pasa por esc()/escAttr(); los enlaces solo http(s)/mailto.
const { esc, escAttr, parseXml, at, kidsOf, first, textOf, findAll } = require('./xml.js');
const P = require('./package.js');
const { runsText, wordCount, blocksToMarkdown } = require('./blocks.js');

const W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"';
const WR = `${W} xmlns:r="${P.REL}"`;
const T = {
  document: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml',
  styles: 'application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml',
  numbering: 'application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml',
  settings: 'application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml',
  footer: 'application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml'
};
const PAGES = { Letter: [12240, 15840], A4: [11906, 16838], Legal: [12240, 20160] };
function pageKey(v) {
  const s = String(v || '').toLowerCase();
  return s === 'a4' ? 'A4' : s === 'legal' || s === 'oficio' ? 'Legal' : 'Letter';
}

// ── Estilos ────────────────────────────────────────────────────────────────────────────────────────────────────────
function stylesXml(lang) {
  const heading = (n, name, sz, color, extra = '') =>
    `<w:style w:type="paragraph" w:styleId="Heading${n}"><w:name w:val="heading ${n}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="9"/><w:qFormat/><w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="${n === 1 ? 360 : 280}" w:after="${n === 1 ? 140 : 100}"/><w:outlineLvl w:val="${n - 1}"/></w:pPr><w:rPr>${extra}<w:color w:val="${color}"/><w:sz w:val="${sz}"/><w:szCs w:val="${sz}"/></w:rPr></w:style>`;
  return (
    P.DECL +
    `<w:styles ${W}>` +
    `<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Calibri"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="${escAttr(lang)}" w:eastAsia="en-US" w:bidi="ar-SA"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="140" w:line="269" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>` +
    '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>' +
    '<w:style w:type="character" w:default="1" w:styleId="DefaultParagraphFont"><w:name w:val="Default Paragraph Font"/><w:uiPriority w:val="1"/><w:semiHidden/><w:unhideWhenUsed/></w:style>' +
    '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:uiPriority w:val="99"/><w:semiHidden/><w:unhideWhenUsed/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>' +
    '<w:style w:type="numbering" w:default="1" w:styleId="NoList"><w:name w:val="No List"/><w:uiPriority w:val="99"/><w:semiHidden/><w:unhideWhenUsed/></w:style>' +
    '<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="10"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="0" w:after="120" w:line="240" w:lineRule="auto"/><w:contextualSpacing/></w:pPr><w:rPr><w:b/><w:bCs/><w:color w:val="111827"/><w:sz w:val="52"/><w:szCs w:val="52"/></w:rPr></w:style>' +
    '<w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="11"/><w:qFormat/><w:pPr><w:spacing w:after="240"/></w:pPr><w:rPr><w:color w:val="4B5563"/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr></w:style>' +
    heading(1, 'heading 1', 36, '1F2937', '<w:b/><w:bCs/>') +
    heading(2, 'heading 2', 29, '1F2937', '<w:b/><w:bCs/>') +
    heading(3, 'heading 3', 25, '374151', '<w:b/><w:bCs/>') +
    heading(4, 'heading 4', 23, '374151', '<w:b/><w:bCs/>') +
    heading(5, 'heading 5', 22, '4B5563', '<w:b/><w:bCs/><w:i/><w:iCs/>') +
    heading(6, 'heading 6', 22, '6B7280', '<w:i/><w:iCs/>') +
    '<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:uiPriority w:val="34"/><w:qFormat/><w:pPr><w:spacing w:after="60"/><w:ind w:left="720"/><w:contextualSpacing/></w:pPr></w:style>' +
    '<w:style w:type="paragraph" w:styleId="Quote"><w:name w:val="Quote"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="29"/><w:qFormat/><w:pPr><w:pBdr><w:left w:val="single" w:sz="18" w:space="10" w:color="BFC5D0"/></w:pBdr><w:spacing w:before="120" w:after="160"/><w:ind w:left="540"/></w:pPr><w:rPr><w:i/><w:iCs/><w:color w:val="4B5563"/></w:rPr></w:style>' +
    '<w:style w:type="paragraph" w:styleId="Code"><w:name w:val="Code"/><w:basedOn w:val="Normal"/><w:uiPriority w:val="99"/><w:qFormat/><w:pPr><w:shd w:val="clear" w:color="auto" w:fill="F3F4F6"/><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:ind w:left="120" w:right="120"/></w:pPr><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:eastAsia="Consolas" w:cs="Consolas"/><w:sz w:val="19"/><w:szCs w:val="19"/></w:rPr></w:style>' +
    '<w:style w:type="paragraph" w:styleId="TableText"><w:name w:val="Table Text"/><w:basedOn w:val="Normal"/><w:uiPriority w:val="99"/><w:qFormat/><w:pPr><w:spacing w:before="50" w:after="50" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr><w:sz w:val="21"/><w:szCs w:val="21"/></w:rPr></w:style>' +
    '<w:style w:type="paragraph" w:styleId="Footer"><w:name w:val="footer"/><w:basedOn w:val="Normal"/><w:uiPriority w:val="99"/><w:unhideWhenUsed/><w:pPr><w:tabs><w:tab w:val="center" w:pos="4680"/><w:tab w:val="right" w:pos="9360"/></w:tabs><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr><w:color w:val="6B7280"/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>' +
    '<w:style w:type="character" w:styleId="Hyperlink"><w:name w:val="Hyperlink"/><w:basedOn w:val="DefaultParagraphFont"/><w:uiPriority w:val="99"/><w:unhideWhenUsed/><w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr></w:style>' +
    '<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:basedOn w:val="TableNormal"/><w:uiPriority w:val="39"/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="BFC5D0"/><w:left w:val="single" w:sz="4" w:space="0" w:color="BFC5D0"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="BFC5D0"/><w:right w:val="single" w:sz="4" w:space="0" w:color="BFC5D0"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="BFC5D0"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="BFC5D0"/></w:tblBorders></w:tblPr></w:style>' +
    '</w:styles>'
  );
}
function numberingXml(instances) {
  const bullets = ['•', '◦', '▪', '•', '◦', '▪', '•', '◦', '▪'];
  const fmts = ['decimal', 'lowerLetter', 'lowerRoman'];
  const lvl = (i, fmt, text) =>
    `<w:lvl w:ilvl="${i}"><w:start w:val="1"/><w:numFmt w:val="${fmt}"/><w:lvlText w:val="${escAttr(text)}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${720 * (i + 1)}" w:hanging="360"/></w:pPr></w:lvl>`;
  let a0 = '<w:abstractNum w:abstractNumId="0"><w:nsid w:val="1A2B3C4D"/><w:multiLevelType w:val="hybridMultilevel"/><w:tmpl w:val="5E6F7A8B"/>';
  let a1 = '<w:abstractNum w:abstractNumId="1"><w:nsid w:val="2B3C4D5E"/><w:multiLevelType w:val="hybridMultilevel"/><w:tmpl w:val="6F7A8B9C"/>';
  for (let i = 0; i < 9; i++) {
    a0 += lvl(i, 'bullet', bullets[i]);
    a1 += lvl(i, fmts[i % 3], `%${i + 1}.`);
  }
  a0 += '</w:abstractNum>';
  a1 += '</w:abstractNum>';
  let nums = '<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>';
  for (const n of instances)
    nums += `<w:num w:numId="${n.numId}"><w:abstractNumId w:val="1"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="${n.start}"/></w:lvlOverride></w:num>`;
  return P.DECL + `<w:numbering ${W}>${a0}${a1}${nums}</w:numbering>`;
}
function settingsXml(lang) {
  return P.DECL + `<w:settings ${W}><w:zoom w:percent="100"/><w:defaultTabStop w:val="720"/><w:characterSpacingControl w:val="doNotCompress"/><w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat><w:themeFontLang w:val="${escAttr(lang)}"/></w:settings>`;
}
function footerXml(es) {
  const fld = code => `<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> ${code} </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r>`;
  const t = s => `<w:r><w:t xml:space="preserve">${esc(s)}</w:t></w:r>`;
  return P.DECL + `<w:ftr ${W}><w:p><w:pPr><w:pStyle w:val="Footer"/><w:jc w:val="center"/></w:pPr>${t(es ? 'Página ' : 'Page ')}${fld('PAGE')}${t(es ? ' de ' : ' of ')}${fld('NUMPAGES')}</w:p></w:ftr>`;
}

// ── Cuerpo ─────────────────────────────────────────────────────────────────────────────────────────────────────────
function textRuns(text, rpr) {
  // separa tabuladores y saltos de línea en elementos propios
  const parts = String(text).split(/(\t|\r\n|\r|\n)/);
  let out = '';
  for (const part of parts) {
    if (part === '') continue;
    if (part === '\t') out += `<w:r>${rpr}<w:tab/></w:r>`;
    else if (part === '\n' || part === '\r' || part === '\r\n') out += `<w:r>${rpr}<w:br/></w:r>`;
    else out += `<w:r>${rpr}<w:t xml:space="preserve">${esc(part)}</w:t></w:r>`;
  }
  return out;
}
function runsXml(runs, st, base = {}) {
  let out = '';
  for (const r of runs || []) {
    if (r.br) {
      out += '<w:r><w:br/></w:r>';
      continue;
    }
    if (!r.text) continue;
    const b = r.b || base.b,
      i = r.i || base.i;
    const rpr =
      (r.href ? '<w:rStyle w:val="Hyperlink"/>' : '') +
      (r.code ? '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:eastAsia="Consolas" w:cs="Consolas"/>' : '') +
      (b ? '<w:b/><w:bCs/>' : '') +
      (i ? '<w:i/><w:iCs/>' : '') +
      (r.s ? '<w:strike/>' : '') +
      (base.color ? `<w:color w:val="${base.color}"/>` : '') +
      (r.code ? '<w:sz w:val="20"/><w:szCs w:val="20"/>' : '') +
      (r.u && !r.href ? '<w:u w:val="single"/>' : '') +
      (r.code ? '<w:shd w:val="clear" w:color="auto" w:fill="F3F4F6"/>' : '');
    const inner = textRuns(r.text, rpr ? `<w:rPr>${rpr}</w:rPr>` : '');
    if (r.href) {
      let id = st.links.get(r.href);
      if (!id) {
        id = `rId${st.nextRel++}`;
        st.links.set(r.href, id);
      }
      out += `<w:hyperlink r:id="${id}" w:history="1">${inner}</w:hyperlink>`;
    } else out += inner;
  }
  return out;
}
const para = (style, inner, o = {}) => {
  const ppr =
    (style ? `<w:pStyle w:val="${style}"/>` : '') +
    (o.keepNext ? '<w:keepNext/>' : '') +
    (o.numPr ? `<w:numPr><w:ilvl w:val="${o.numPr[0]}"/><w:numId w:val="${o.numPr[1]}"/></w:numPr>` : '') +
    (o.border ? o.border : '') +
    (o.spacing ? o.spacing : '') +
    (o.jc ? `<w:jc w:val="${o.jc}"/>` : '');
  return `<w:p>${ppr ? `<w:pPr>${ppr}</w:pPr>` : ''}${inner}</w:p>`;
};
const JC = { center: 'center', right: 'right', justify: 'both', c: 'center', r: 'right' };

function tableXml(b, st, textW) {
  const cols = Math.max(b.head ? b.head.length : 0, ...b.rows.map(r => r.length), 1);
  const lens = Array(cols).fill(6);
  for (const r of [b.head || [], ...b.rows]) for (let c = 0; c < cols; c++) lens[c] = Math.max(lens[c], Math.min(48, runsText(r[c] || []).length + 2));
  const sum = lens.reduce((a, x) => a + x, 0);
  let widths = lens.map(l => Math.max(700, Math.round((l / sum) * textW)));
  const diff = textW - widths.reduce((a, x) => a + x, 0);
  widths[widths.indexOf(Math.max(...widths))] += diff;
  const cell = (runs, c, header) => {
    const jc = JC[b.align?.[c]] || '';
    const inner = runsXml(runs, st, header ? { b: true } : {});
    return `<w:tc><w:tcPr><w:tcW w:w="${widths[c]}" w:type="dxa"/>${header ? '<w:shd w:val="clear" w:color="auto" w:fill="E7EAF0"/>' : ''}<w:vAlign w:val="top"/></w:tcPr>${para('TableText', inner, { jc })}</w:tc>`;
  };
  const row = (r, header) =>
    `<w:tr><w:trPr><w:cantSplit/>${header ? '<w:tblHeader/>' : ''}</w:trPr>${Array.from({ length: cols }, (_, c) => cell(r[c] || [], c, header)).join('')}</w:tr>`;
  return (
    `<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="${textW}" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>` +
    `<w:tblGrid>${widths.map(w => `<w:gridCol w:w="${w}"/>`).join('')}</w:tblGrid>` +
    (b.head ? row(b.head, true) : '') +
    b.rows.map(r => row(r, false)).join('') +
    '</w:tbl>' +
    '<w:p><w:pPr><w:spacing w:before="0" w:after="60" w:line="120" w:lineRule="exact"/></w:pPr></w:p>'
  );
}
function bodyXml(blocks, st, textW) {
  let out = '';
  let ordNum = null;
  for (const b of blocks) {
    if (b.t !== 'li') ordNum = null;
    switch (b.t) {
      case 'title':
        out += para('Title', runsXml(b.runs, st));
        break;
      case 'subtitle':
        out += para('Subtitle', runsXml(b.runs, st));
        break;
      case 'h':
        out += para(`Heading${Math.max(1, Math.min(6, b.level))}`, runsXml(b.runs, st));
        break;
      case 'p':
        out += para('', runsXml(b.runs, st), { jc: JC[b.align] || '' });
        break;
      case 'li': {
        let numId = 1;
        if (!b.ordered) {
          if ((b.level || 0) === 0) ordNum = null;
        } else {
          if (ordNum === null) {
            ordNum = st.nextNum++;
            st.numInstances.push({ numId: ordNum, start: Math.max(1, Math.min(9999, b.num || 1)) });
          }
          numId = ordNum;
        }
        out += para('ListParagraph', runsXml(b.runs, st), { numPr: [Math.min(8, b.level || 0), numId] });
        break;
      }
      case 'table':
        out += tableXml(b, st, textW);
        break;
      case 'quote':
        out += para('Quote', runsXml(b.runs, st));
        break;
      case 'code': {
        const lines = String(b.text || '').split('\n');
        lines.forEach((ln, idx) => {
          const sp = idx === 0 ? '<w:spacing w:before="80" w:after="0"/>' : idx === lines.length - 1 ? '<w:spacing w:before="0" w:after="160"/>' : '';
          out += para('Code', textRuns(ln.replace(/\r$/, ''), ''), { spacing: sp });
        });
        break;
      }
      case 'hr':
        out += para('', '', { border: '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="BFC5D0"/></w:pBdr>', spacing: '<w:spacing w:before="120" w:after="120"/>' });
        break;
      case 'pb':
        out += '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
        break;
    }
  }
  return out;
}

function buildDocx(blocks, opts = {}) {
  const lang = opts.lang || 'es-ES';
  const es = /^es/i.test(lang);
  const key = pageKey(opts.pageSize);
  const [pw, ph] = PAGES[key];
  const margin = 1440;
  const textW = pw - 2 * margin;
  const st = { links: new Map(), nextRel: 10, numInstances: [], nextNum: 2 };
  const body = bodyXml(blocks, st, textW);
  const chars = blocks.reduce((n, b) => n + (b.runs ? runsText(b.runs).length : b.text ? b.text.length : 0), 0);
  const pageNumbers = opts.pageNumbers ?? (blocks.length > 30 || chars > 3500);
  const firstHeading = blocks.find(b => b.t === 'title' || b.t === 'h');
  const title = opts.title || (firstHeading ? runsText(firstHeading.runs) : '');
  const sect = `<w:sectPr>${pageNumbers ? '<w:footerReference w:type="default" r:id="rId4"/>' : ''}<w:pgSz w:w="${pw}" w:h="${ph}"/><w:pgMar w:top="${margin}" w:right="${margin}" w:bottom="${margin}" w:left="${margin}" w:header="720" w:footer="720" w:gutter="0"/><w:cols w:space="720"/></w:sectPr>`;
  const doc = P.DECL + `<w:document ${WR}><w:body>${body || para('', '')}${sect}</w:body></w:document>`;
  const rels = [
    { id: 'rId1', type: 'styles', target: 'styles.xml' },
    { id: 'rId2', type: 'numbering', target: 'numbering.xml' },
    { id: 'rId3', type: 'settings', target: 'settings.xml' }
  ];
  if (pageNumbers) rels.push({ id: 'rId4', type: 'footer', target: 'footer1.xml' });
  for (const [url, id] of st.links) rels.push({ id, type: 'hyperlink', target: url, external: true });
  const overrides = [
    ['/word/document.xml', T.document],
    ['/word/styles.xml', T.styles],
    ['/word/numbering.xml', T.numbering],
    ['/word/settings.xml', T.settings],
    ['/docProps/core.xml', P.CT.core],
    ['/docProps/app.xml', P.CT.app]
  ];
  if (pageNumbers) overrides.push(['/word/footer1.xml', T.footer]);
  const entries = [
    ['[Content_Types].xml', P.contentTypes(overrides)],
    ['_rels/.rels', P.rootRels('word/document.xml')],
    ['docProps/core.xml', P.coreXml({ title, author: opts.author || '', now: opts.now || new Date() })],
    ['docProps/app.xml', P.appXml()],
    ['word/document.xml', doc],
    ['word/_rels/document.xml.rels', P.relsXml(rels)],
    ['word/styles.xml', stylesXml(lang)],
    ['word/numbering.xml', numberingXml(st.numInstances)],
    ['word/settings.xml', settingsXml(lang)]
  ];
  if (pageNumbers) entries.push(['word/footer1.xml', footerXml(es)]);
  return P.buildPackage(entries, { date: opts.now });
}

// ── Lectura ────────────────────────────────────────────────────────────────────────────────────────────────────────
const flagOn = n => {
  if (!n) return false;
  const v = at(n, 'val', 'w');
  return v === undefined || !/^(0|false|off|none)$/i.test(v);
};
function readStyles(zip, part) {
  const map = new Map();
  if (!part || !zip.has(part)) return map;
  const root = parseXml(zip.readText(part));
  for (const s of kidsOf(root, 'w:style')) {
    const id = at(s, 'styleId', 'w');
    if (!id) continue;
    const pPr = first(s, 'w:pPr');
    const numPr = first(pPr, 'w:numPr');
    map.set(id, {
      name: at(first(s, 'w:name'), 'val', 'w') || id,
      basedOn: at(first(s, 'w:basedOn'), 'val', 'w') || '',
      outline: first(pPr, 'w:outlineLvl') ? Number(at(first(pPr, 'w:outlineLvl'), 'val', 'w')) : undefined,
      numId: numPr && first(numPr, 'w:numId') ? Number(at(first(numPr, 'w:numId'), 'val', 'w')) : undefined,
      ilvl: numPr && first(numPr, 'w:ilvl') ? Number(at(first(numPr, 'w:ilvl'), 'val', 'w')) : undefined
    });
  }
  return map;
}
function styleChain(styles, id) {
  const out = [];
  const seen = new Set();
  while (id && styles.has(id) && !seen.has(id) && out.length < 12) {
    seen.add(id);
    const s = styles.get(id);
    out.push(s);
    id = s.basedOn;
  }
  return out;
}
function readNumbering(zip, part) {
  const abs = new Map(),
    nums = new Map();
  if (!part || !zip.has(part)) return { abs, nums };
  const root = parseXml(zip.readText(part));
  for (const a of kidsOf(root, 'w:abstractNum')) {
    const lv = new Map();
    for (const l of kidsOf(a, 'w:lvl'))
      lv.set(Number(at(l, 'ilvl', 'w') || 0), { fmt: at(first(l, 'w:numFmt'), 'val', 'w') || 'decimal', start: Number(at(first(l, 'w:start'), 'val', 'w') || 1) });
    abs.set(at(a, 'abstractNumId', 'w'), lv);
  }
  for (const n of kidsOf(root, 'w:num')) {
    const o = new Map();
    for (const ov of kidsOf(n, 'w:lvlOverride')) {
      const so = first(ov, 'w:startOverride');
      if (so) o.set(Number(at(ov, 'ilvl', 'w') || 0), Number(at(so, 'val', 'w') || 1));
    }
    nums.set(Number(at(n, 'numId', 'w')), { abs: at(first(n, 'w:abstractNumId'), 'val', 'w'), overrides: o });
  }
  return { abs, nums };
}

// Texto en línea de un párrafo (o de una celda): runs {text,b,i,u,s,href}
function inlineOf(node, st, fmt, out) {
  for (const k of node.kids) {
    if (typeof k === 'string') continue;
    switch (k.tag) {
      case 'w:r':
        runOf(k, st, fmt, out);
        break;
      case 'w:hyperlink': {
        const rid = at(k, 'id', 'r');
        const rel = rid ? st.rels.get(rid) : null;
        const href = rel?.external ? rel.target : at(k, 'anchor', 'w') ? `#${at(k, 'anchor', 'w')}` : '';
        inlineOf(k, st, href ? { ...fmt, href } : fmt, out);
        break;
      }
      case 'w:ins':
      case 'w:moveTo':
      case 'w:smartTag':
      case 'w:sdt':
      case 'w:sdtContent':
      case 'w:fldSimple':
      case 'w:customXml':
      case 'w:dir':
      case 'w:bdo':
        if (k.tag === 'w:ins' || k.tag === 'w:moveTo') st.changes++;
        inlineOf(k, st, fmt, out);
        break;
      case 'w:del':
      case 'w:moveFrom':
        st.changes++;
        break;
    }
  }
}
function pushText(out, text, fmt) {
  if (!text) return;
  const last = out[out.length - 1];
  const same = last && !last.br && !!last.b === !!fmt.b && !!last.i === !!fmt.i && !!last.u === !!fmt.u && !!last.s === !!fmt.s && last.href === fmt.href;
  if (same) last.text += text;
  else {
    const r = { text };
    if (fmt.b) r.b = true;
    if (fmt.i) r.i = true;
    if (fmt.u) r.u = true;
    if (fmt.s) r.s = true;
    if (fmt.href) r.href = fmt.href;
    out.push(r);
  }
}
function runOf(r, st, base, out) {
  const rPr = first(r, 'w:rPr');
  const fmt = { ...base };
  if (rPr) {
    if (flagOn(first(rPr, 'w:b'))) fmt.b = true;
    if (flagOn(first(rPr, 'w:i'))) fmt.i = true;
    if (flagOn(first(rPr, 'w:strike'))) fmt.s = true;
    const u = first(rPr, 'w:u');
    if (u && flagOn(u)) fmt.u = true;
  }
  const kids = [];
  const expand = n => {
    for (const k of n.kids) {
      if (typeof k === 'string') continue;
      if (k.tag === '_:AlternateContent' || k.tag === 'mc:AlternateContent') {
        const choice = k.kids.find(x => typeof x !== 'string' && /Choice$/.test(x.tag)) || k.kids.find(x => typeof x !== 'string' && /Fallback$/.test(x.tag));
        if (choice) expand(choice);
      } else kids.push(k);
    }
  };
  expand(r);
  for (const k of kids) {
    switch (k.tag) {
      case 'w:t':
        pushText(out, textOf(k), fmt);
        break;
      case 'w:tab':
      case 'w:ptab':
        pushText(out, '\t', fmt);
        break;
      case 'w:br':
      case 'w:cr':
        if (at(k, 'type', 'w') !== 'page') out.push({ br: true });
        break;
      case 'w:noBreakHyphen':
        pushText(out, '-', fmt);
        break;
      case 'w:footnoteReference':
        st.footRefs.add(at(k, 'id', 'w'));
        pushText(out, `[^${at(k, 'id', 'w')}]`, fmt);
        break;
      case 'w:endnoteReference':
        pushText(out, `[^e${at(k, 'id', 'w')}]`, fmt);
        break;
      case 'w:drawing':
      case 'w:pict':
      case 'w:object': {
        const dp = findAll(k, 'wp:docPr')[0];
        const alt = (dp && (at(dp, 'descr') || at(dp, 'title') || '')) || '';
        const boxes = findAll(k, 'w:txbxContent');
        if (boxes.length) {
          for (const bx of boxes.slice(0, 1)) {
            const sub = [];
            for (const p of kidsOf(bx, 'w:p')) {
              const o2 = [];
              inlineOf(p, st, {}, o2);
              if (o2.length) sub.push(o2.map(x => (x.br ? '\n' : x.text)).join(''));
            }
            if (sub.length) pushText(out, `[cuadro de texto: ${sub.join(' / ')}]`, fmt);
          }
        } else {
          st.images++;
          pushText(out, alt ? `[imagen: ${alt}]` : '[imagen]', fmt);
        }
        break;
      }
    }
  }
}
const trimRuns = runs => {
  const o = runs.map(r => ({ ...r }));
  while (o.length && o[o.length - 1].br) o.pop();
  while (o.length && o[0].br) o.shift();
  return o;
};

function readDocx(buf, opts = {}) {
  const maxChars = opts.maxChars ?? 600_000;
  const zip = P.openOffice(buf, opts.zipLimits);
  const mainPart = P.mainPartOf(zip);
  if (!mainPart) throw Object.assign(new Error('No parece un documento de Word (.docx): falta la parte principal.'), { code: 'DOC_INVALID' });
  const mainRels = P.readRels(zip, mainPart);
  const relOf = short => [...mainRels.values()].find(r => r.short === short && r.part && zip.has(r.part))?.part || '';
  const styles = readStyles(zip, relOf('styles'));
  const numbering = readNumbering(zip, relOf('numbering'));
  const st = { rels: mainRels, images: 0, changes: 0, footRefs: new Set() };
  const root = parseXml(zip.readText(mainPart));
  const body = first(root, 'w:body');
  const blocks = [];
  const counters = new Map();
  let chars = 0,
    truncated = false;
  const stats = { paragraphs: 0, tables: 0, headings: 0, listItems: 0, images: 0, words: 0 };
  const push = b => {
    blocks.push(b);
    if (b.runs) chars += runsText(b.runs).length;
    else if (b.text) chars += b.text.length;
    else if (b.t === 'table') for (const r of [b.head || [], ...b.rows]) for (const c of r) chars += runsText(c).length;
    if (chars > maxChars) truncated = true;
  };

  function paragraphBlock(p) {
    const pPr = first(p, 'w:pPr');
    const sid = at(first(pPr, 'w:pStyle'), 'val', 'w') || '';
    const chain = styleChain(styles, sid);
    const sname = (chain[0]?.name || sid || '').toLowerCase();
    let level = 0,
      kind = 'p';
    for (const s of chain) {
      const m = /^(?:heading|t[ií]tulo|überschrift|titre)\s*([1-9])$/i.exec(s.name);
      if (m) {
        level = Number(m[1]);
        break;
      }
    }
    const ol = first(pPr, 'w:outlineLvl');
    if (!level && ol) {
      const v = Number(at(ol, 'val', 'w'));
      if (v >= 0 && v < 9) level = v + 1;
    }
    if (!level) for (const s of chain) if (s.outline !== undefined && s.outline < 9) { level = s.outline + 1; break; }
    if (!level && /^title$|^t[ií]tulo$/.test(sname)) kind = 'title';
    else if (!level && /^subtitle$|^subt[ií]tulo$/.test(sname)) kind = 'subtitle';
    else if (!level && /^(quote|intense quote|cita)/.test(sname)) kind = 'quote';
    else if (!level && /^(code|source code|html preformatted|plain text|preformatted)/.test(sname)) kind = 'code';
    // listas
    let numId, ilvl;
    const numPr = first(pPr, 'w:numPr');
    if (numPr) {
      numId = first(numPr, 'w:numId') ? Number(at(first(numPr, 'w:numId'), 'val', 'w')) : undefined;
      ilvl = first(numPr, 'w:ilvl') ? Number(at(first(numPr, 'w:ilvl'), 'val', 'w')) : undefined;
    }
    if (numId === undefined) for (const s of chain) if (s.numId !== undefined) { numId = s.numId; ilvl = ilvl ?? s.ilvl; break; }
    const runs = [];
    inlineOf(p, st, {}, runs);
    const clean = trimRuns(runs);
    const text = clean.map(r => (r.br ? '\n' : r.text)).join('');
    if (numId && numId > 0 && text.trim()) {
      const lvl = Math.max(0, Math.min(8, ilvl || 0));
      const num = numbering.nums.get(numId);
      const def = num ? numbering.abs.get(num.abs)?.get(lvl) : null;
      const ordered = !!def && !/^(bullet|none)$/i.test(def.fmt);
      let n;
      if (ordered) {
        for (const key of [...counters.keys()]) {
          const [kn, kl] = key.split(':').map(Number);
          if (kn === numId && kl > lvl) counters.delete(key);
        }
        const ck = `${numId}:${lvl}`;
        n = counters.has(ck) ? counters.get(ck) + 1 : num?.overrides.get(lvl) ?? def.start ?? 1;
        counters.set(ck, n);
      }
      return { t: 'li', ordered, level: lvl, num: n, runs: clean };
    }
    if (!text.trim()) return null;
    if (level) return { t: 'h', level: Math.min(6, level), runs: clean };
    if (kind === 'code') return { t: 'code', text, lang: '' };
    return { t: kind, runs: clean };
  }
  function tableBlock(tbl) {
    const rows = [];
    let head = null;
    for (const tr of kidsOf(tbl, 'w:tr')) {
      const cells = [];
      for (const tc of kidsOf(tr, 'w:tc')) {
        const parts = [];
        const walkCell = n => {
          for (const k of n.kids) {
            if (typeof k === 'string') continue;
            if (k.tag === 'w:p') {
              const rs = [];
              inlineOf(k, st, {}, rs);
              const t = trimRuns(rs);
              if (t.length) parts.push(t);
            } else if (k.tag === 'w:tbl') {
              for (const r2 of kidsOf(k, 'w:tr')) for (const c2 of kidsOf(r2, 'w:tc')) walkCell(c2);
            } else if (k.tag === 'w:sdt' || k.tag === 'w:sdtContent') walkCell(k);
          }
        };
        walkCell(tc);
        const merged = [];
        parts.forEach((p, idx) => {
          if (idx) merged.push({ br: true });
          merged.push(...p);
        });
        cells.push(merged);
      }
      const isHeader = !!first(first(tr, 'w:trPr'), 'w:tblHeader');
      if (isHeader && !rows.length && !head) head = cells;
      else rows.push(cells);
    }
    const width = Math.max(head ? head.length : 0, ...rows.map(r => r.length), 0);
    if (!width) return null;
    const fix = r => Array.from({ length: width }, (_, c) => r[c] || []);
    return { t: 'table', head: head ? fix(head) : null, rows: rows.map(fix), align: Array(width).fill('') };
  }
  function walkBody(node) {
    for (const k of node.kids) {
      if (truncated) return;
      if (typeof k === 'string') continue;
      if (k.tag === 'w:p') {
        const b = paragraphBlock(k);
        if (b) {
          // los párrafos de código consecutivos forman un solo bloque
          const prev = blocks[blocks.length - 1];
          if (b.t === 'code' && prev && prev.t === 'code') prev.text += '\n' + b.text;
          else push(b);
        }
      } else if (k.tag === 'w:tbl') {
        const t = tableBlock(k);
        if (t) push(t);
      } else if (k.tag === 'w:sdt') {
        const c = first(k, 'w:sdtContent');
        if (c) walkBody(c);
      } else if (k.tag === 'w:ins' || k.tag === 'w:moveTo' || k.tag === 'w:customXml') walkBody(k);
      else if (k.tag === 'w:del' || k.tag === 'w:moveFrom') st.changes++;
    }
  }
  if (body) walkBody(body);

  // comentarios, notas al pie, encabezados y pies
  const comments = [];
  const cpart = relOf('comments');
  if (cpart) {
    try {
      for (const c of kidsOf(parseXml(zip.readText(cpart)), 'w:comment').slice(0, 200)) {
        const t = findAll(c, 'w:t').map(textOf).join('').trim();
        if (t) comments.push({ author: at(c, 'author', 'w') || '', text: t.slice(0, 2000) });
      }
    } catch {}
  }
  const footnotes = [];
  const fpart = relOf('footnotes');
  if (fpart && st.footRefs.size) {
    try {
      for (const f of kidsOf(parseXml(zip.readText(fpart)), 'w:footnote')) {
        const id = at(f, 'id', 'w');
        if (!st.footRefs.has(id)) continue;
        const t = findAll(f, 'w:t').map(textOf).join('').trim();
        if (t) footnotes.push({ id, text: t.slice(0, 2000) });
      }
    } catch {}
  }
  const headers = [],
    footers = [];
  for (const r of mainRels.values()) {
    if ((r.short === 'header' || r.short === 'footer') && r.part && zip.has(r.part)) {
      try {
        const t = findAll(parseXml(zip.readText(r.part)), 'w:p')
          .map(p => findAll(p, 'w:t').map(textOf).join(''))
          .join(' ')
          .replace(/\s+/g, ' ')
          .trim();
        if (t && !(r.short === 'header' ? headers : footers).includes(t)) (r.short === 'header' ? headers : footers).push(t.slice(0, 400));
      } catch {}
    }
  }
  for (const b of blocks) {
    if (b.t === 'h' || b.t === 'title') stats.headings++;
    else if (b.t === 'li') stats.listItems++;
    else if (b.t === 'table') stats.tables++;
    else if (b.t === 'p' || b.t === 'quote' || b.t === 'code' || b.t === 'subtitle') stats.paragraphs++;
  }
  stats.images = st.images;
  const plain = blocks
    .map(b => (b.t === 'table' ? [b.head || [], ...b.rows].map(r => r.map(c => runsText(c)).join(' ')).join('\n') : b.runs ? runsText(b.runs) : b.text || ''))
    .join('\n');
  stats.words = wordCount(plain);
  stats.comments = comments.length;
  stats.trackedChanges = st.changes;
  return { kind: 'docx', blocks, comments, footnotes, headers, footers, stats, truncated, properties: P.coreProps(zip) };
}

// Texto para el modelo.
function docxToText(doc, { marks = false } = {}) {
  let t = blocksToMarkdown(doc.blocks, { marks });
  if (doc.footnotes?.length) t += '\n\nNotas al pie:\n' + doc.footnotes.map(f => `[^${f.id}]: ${f.text}`).join('\n');
  if (doc.comments?.length) t += '\n\nComentarios del documento:\n' + doc.comments.map(c => `- ${c.author ? c.author + ': ' : ''}${c.text}`).join('\n');
  if (doc.headers?.length) t += '\n\n(Encabezado: ' + doc.headers.join(' | ') + ')';
  if (doc.footers?.length) t += '\n(Pie de página: ' + doc.footers.join(' | ') + ')';
  return t;
}

module.exports = { buildDocx, readDocx, docxToText, PAGES, pageKey };
