'use strict';
// Bloques → HTML para imprimir a PDF. TODO el texto se escapa; los enlaces solo pueden ser http(s) o mailto. No lleva scripts ni recursos externos.
const { runsText, safeHref } = require('./blocks.js');

const escHtml = s =>
  String(s ?? '')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

const CSP = "default-src 'none'; style-src 'unsafe-inline'; img-src data:; font-src data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'";
const CSS = `
html,body{margin:0;padding:0;background:#fff}
body{font-family:"Segoe UI",Calibri,"Helvetica Neue",Arial,"Liberation Sans",sans-serif;font-size:11pt;line-height:1.5;color:#111827;-webkit-print-color-adjust:exact;print-color-adjust:exact}
h1,h2,h3,h4,h5,h6{color:#1F2937;font-weight:700;line-height:1.25;page-break-after:avoid;break-after:avoid}
h1{font-size:20pt;margin:20pt 0 8pt}h2{font-size:15.5pt;margin:16pt 0 6pt}h3{font-size:13pt;margin:13pt 0 5pt;color:#374151}
h4{font-size:11.5pt;margin:11pt 0 4pt;color:#374151}h5{font-size:11pt;font-style:italic;margin:10pt 0 4pt}h6{font-size:11pt;font-weight:400;font-style:italic;color:#6B7280;margin:10pt 0 4pt}
p{margin:0 0 8pt;orphans:3;widows:3}
.title{font-size:27pt;font-weight:700;margin:0 0 4pt;color:#111827;line-height:1.15}
.subtitle{font-size:14pt;color:#4B5563;margin:0 0 18pt}
ul,ol{margin:2pt 0 8pt;padding-left:22pt}ul ul,ol ol,ul ol,ol ul{margin:2pt 0}li{margin:2pt 0}
a{color:#0563C1;text-decoration:underline}
table{border-collapse:collapse;width:100%;margin:8pt 0 12pt;font-size:10.5pt}
th,td{border:1px solid #BFC5D0;padding:4.5pt 7pt;vertical-align:top;text-align:left}
th{background:#E7EAF0;font-weight:700}
tr{page-break-inside:avoid;break-inside:avoid}thead{display:table-header-group}
td.r,th.r{text-align:right}td.c,th.c{text-align:center}
pre{background:#F3F4F6;padding:8pt 10pt;border-radius:4pt;white-space:pre-wrap;word-wrap:break-word;font:9.5pt/1.4 Consolas,"Courier New","Liberation Mono",monospace;margin:6pt 0 10pt;page-break-inside:avoid;break-inside:avoid}
code{font-family:Consolas,"Courier New","Liberation Mono",monospace;background:#F3F4F6;padding:0 3pt;border-radius:3pt;font-size:.92em}
pre code{background:none;padding:0}
blockquote{border-left:3px solid #BFC5D0;margin:8pt 0 10pt;padding:2pt 0 2pt 12pt;color:#4B5563;font-style:italic}
hr{border:0;border-top:1px solid #BFC5D0;margin:12pt 0}
.pb{page-break-after:always;break-after:page;height:0;margin:0}
`;

function runsHtml(runs) {
  let out = '';
  for (const r of runs || []) {
    if (r.br) {
      out += '<br>';
      continue;
    }
    if (!r.text) continue;
    let t = escHtml(r.text);
    if (r.code) t = `<code>${t}</code>`;
    if (r.b) t = `<strong>${t}</strong>`;
    if (r.i) t = `<em>${t}</em>`;
    if (r.u && !r.href) t = `<u>${t}</u>`;
    if (r.s) t = `<s>${t}</s>`;
    const href = r.href ? safeHref(r.href) : '';
    if (href) t = `<a href="${escHtml(href)}">${t}</a>`;
    out += t;
  }
  return out;
}
function listsHtml(items) {
  let html = '';
  const stack = [];
  const open = it => {
    const tag = it.ordered ? 'ol' : 'ul';
    stack.push(tag);
    html += it.ordered && it.num && it.num > 1 ? `<ol start="${Math.min(9999, it.num)}">` : `<${tag}>`;
  };
  for (const it of items) {
    const lvl = Math.min(3, Math.max(0, it.level || 0));
    while (stack.length > lvl + 1) html += `</li></${stack.pop()}>`;
    if (stack.length === lvl + 1) {
      if ((stack[lvl] === 'ol') !== !!it.ordered) {
        html += `</li></${stack.pop()}>`;
        open(it);
      } else html += '</li>';
    }
    while (stack.length < lvl + 1) open(it);
    html += `<li>${runsHtml(it.runs)}`;
  }
  while (stack.length) html += `</li></${stack.pop()}>`;
  return html;
}
function blocksToHtml(blocks, { title = '', lang = 'es' } = {}) {
  let body = '';
  for (let i = 0; i < blocks.length; i++) {
    const b = blocks[i];
    switch (b.t) {
      case 'title':
        body += `<h1 class="title">${runsHtml(b.runs)}</h1>`;
        break;
      case 'subtitle':
        body += `<p class="subtitle">${runsHtml(b.runs)}</p>`;
        break;
      case 'h':
        body += `<h${Math.max(1, Math.min(6, b.level))}>${runsHtml(b.runs)}</h${Math.max(1, Math.min(6, b.level))}>`;
        break;
      case 'p':
        body += `<p${b.align ? ` style="text-align:${b.align === 'justify' ? 'justify' : b.align}"` : ''}>${runsHtml(b.runs)}</p>`;
        break;
      case 'li': {
        const group = [];
        while (i < blocks.length && blocks[i].t === 'li') group.push(blocks[i++]);
        i--;
        body += listsHtml(group);
        break;
      }
      case 'table': {
        const cols = Math.max(b.head ? b.head.length : 0, ...b.rows.map(r => r.length), 1);
        const cell = (tag, runs, c) => `<${tag}${b.align?.[c] === 'r' ? ' class="r"' : b.align?.[c] === 'c' ? ' class="c"' : ''}>${runsHtml(runs)}</${tag}>`;
        const row = (r, tag) => `<tr>${Array.from({ length: cols }, (_, c) => cell(tag, r[c] || [], c)).join('')}</tr>`;
        body += `<table>${b.head ? `<thead>${row(b.head, 'th')}</thead>` : ''}<tbody>${b.rows.map(r => row(r, 'td')).join('')}</tbody></table>`;
        break;
      }
      case 'quote':
        body += `<blockquote>${runsHtml(b.runs)}</blockquote>`;
        break;
      case 'code':
        body += `<pre><code>${escHtml(b.text)}</code></pre>`;
        break;
      case 'hr':
        body += '<hr>';
        break;
      case 'pb':
        body += '<div class="pb"></div>';
        break;
    }
  }
  return `<!doctype html><html lang="${escHtml(lang)}"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${CSP}"><title>${escHtml(title)}</title><style>${CSS}</style></head><body>${body}</body></html>`;
}
// HTML recibido tal cual del modelo: se le antepone una CSP estricta y se quitan etiquetas activas. (Aun así la ventana de impresión
// no ejecuta JavaScript y bloquea toda la red: esto es una segunda barrera.)
function sanitizeRawHtml(html) {
  let h = String(html ?? '');
  h = h.replace(/<!--[\s\S]*?-->/g, '').replace(/<(script|iframe|object|embed|link|base|meta|form|frame|frameset|applet|noscript)\b[\s\S]*?(?:<\/\1\s*>|$)/gi, '');
  h = h.replace(/<(?:script|iframe|object|embed|link|base|meta|form|frame|frameset|applet)\b[^>]*>/gi, '');
  h = h.replace(/\s(on[a-z]+)\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');
  h = h.replace(/(href|src|action|formaction|xlink:href|poster|background)\s*=\s*("\s*(?:javascript|vbscript|file|ftp):[^"]*"|'\s*(?:javascript|vbscript|file|ftp):[^']*')/gi, '$1="#"');
  h = h.replace(/\ssrc\s*=\s*("(?!data:image\/)[^"]*"|'(?!data:image\/)[^']*')/gi, ' data-blocked-src=$1');
  const bodyMatch = /<body[^>]*>([\s\S]*)<\/body>/i.exec(h);
  const styleBlocks = (h.match(/<style[\s\S]*?<\/style>/gi) || []).join('');
  const inner = bodyMatch ? bodyMatch[1] : h.replace(/<\/?(?:html|head|body)[^>]*>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '');
  const titleMatch = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(h);
  return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${CSP}"><title>${escHtml(titleMatch ? titleMatch[1].replace(/<[^>]*>/g, '') : '')}</title><style>${CSS}</style>${styleBlocks.replace(/@import[^;]*;/gi, '').replace(/url\(\s*(?!["']?data:)[^)]*\)/gi, 'none')}</head><body>${inner}</body></html>`;
}

module.exports = { escHtml, CSP, CSS, blocksToHtml, runsHtml, sanitizeRawHtml, runsText };
