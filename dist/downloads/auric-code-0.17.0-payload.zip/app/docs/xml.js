'use strict';
// Lector y escritor XML SEGURO para documentos de Office (docx / xlsx / pptx). Sin DOM ni librerías externas.
// Defensas: rechaza <!DOCTYPE> y <!ENTITY> (evita XXE y "billion laughs": nunca se expande nada que no sea una de las 5
// entidades predefinidas o una referencia numérica), límites de tamaño / profundidad / nodos / atributos, análisis lineal
// (sin expresiones regulares con retroceso sobre texto del documento) y etiquetas mal cerradas = error claro.

const XML_LIMITS = {
  maxChars: 96 * 1024 * 1024,
  maxNodes: 4_000_000,
  maxDepth: 200,
  maxAttrs: 200,
  maxNameLen: 256
};

function xmlError(message, code = 'XML_INVALID') {
  const e = new Error(message);
  e.code = code;
  return e;
}

// ── Espacios de nombres: se identifica por «tipo» (w, a, p, s, r…) y no por el prefijo que use cada archivo ─────────
const KIND_PATTERNS = [
  ['w', /\/wordprocessingml\/(?:2006\/)?main$/],
  ['a', /\/drawingml\/(?:2006\/)?main$/],
  ['p', /\/presentationml\/(?:2006\/)?main$/],
  ['s', /\/spreadsheetml\/(?:2006\/)?main$/],
  ['r', /\/officeDocument\/(?:2006\/)?relationships$/],
  ['rel', /\/package\/2006\/relationships$/],
  ['ct', /\/package\/2006\/content-types$/],
  ['cp', /\/package\/2006\/metadata\/core-properties$/],
  ['dc', /purl\.org\/dc\/elements\/1\.1\/?$/],
  ['dcterms', /purl\.org\/dc\/terms\/?$/],
  ['xml', /\/XML\/1998\/namespace$/],
  ['mc', /\/markup-compatibility\/2006$/],
  ['wp', /\/wordprocessingDrawing$/],
  ['pic', /\/drawingml\/(?:2006\/)?picture$/],
  ['v', /^urn:schemas-microsoft-com:vml$/]
];
const kindCache = new Map();
function kindOf(uri) {
  if (!uri) return '';
  let k = kindCache.get(uri);
  if (k === undefined) {
    k = '?';
    for (const [name, re] of KIND_PATTERNS)
      if (re.test(uri)) {
        k = name;
        break;
      }
    if (kindCache.size < 500) kindCache.set(uri, k);
  }
  return k;
}
const XML_NS = 'http://www.w3.org/XML/1998/namespace';

// ── Texto ──────────────────────────────────────────────────────────────────────────────────────────────────────────
function validCodePoint(c) {
  return c === 0x9 || c === 0xa || c === 0xd || (c >= 0x20 && c <= 0xd7ff) || (c >= 0xe000 && c <= 0xfffd) || (c >= 0x10000 && c <= 0x10ffff);
}
function decodeEntities(s) {
  if (s.indexOf('&') < 0) return s;
  return s.replace(/&(#x[0-9a-fA-F]{1,6}|#[0-9]{1,7}|amp|lt|gt|quot|apos);/g, (m, g) => {
    switch (g) {
      case 'amp':
        return '&';
      case 'lt':
        return '<';
      case 'gt':
        return '>';
      case 'quot':
        return '"';
      case 'apos':
        return "'";
    }
    const c = g[1] === 'x' ? parseInt(g.slice(2), 16) : parseInt(g.slice(1), 10);
    return validCodePoint(c) ? String.fromCodePoint(c) : '\u{FFFD}';
  });
}
// Quita lo que XML 1.0 no admite (controles, U+FFFE/FFFF, sustitutos sueltos).
const BAD_XML_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u{FFFE}\u{FFFF}]/gu;
function cleanText(s) {
  s = String(s ?? '');
  s = s.replace(BAD_XML_CHARS, '');
  return typeof s.toWellFormed === 'function' ? s.toWellFormed() : s;
}
function esc(s) {
  return cleanText(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function escAttr(s) {
  return cleanText(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;')
    .replace(/\t/g, '&#9;')
    .replace(/\n/g, '&#10;')
    .replace(/\r/g, '&#13;');
}

// ── Análisis (SAX) ─────────────────────────────────────────────────────────────────────────────────────────────────
const isSpace = c => c === 32 || c === 9 || c === 10 || c === 13;
const STOP = Symbol('xml-stop');

// Manejadores: open(el) / close(el) / text(str). `el` = { tag:'w:p', name:'p', k:'w', attrs:[{local,k,value}], selfClose }.
// Devolver STOP desde cualquiera corta el análisis sin error (útil para leer solo las primeras filas de una hoja enorme).
function saxParse(src, h, userLimits = {}) {
  const L = { ...XML_LIMITS, ...userLimits };
  let s = typeof src === 'string' ? src : Buffer.isBuffer(src) ? src.toString('utf8') : String(src ?? '');
  if (s.length > L.maxChars) throw xmlError('El XML es demasiado grande.', 'XML_LIMIT');
  if (s.charCodeAt(0) === 0xfeff) s = s.slice(1);
  const n = s.length;
  const stack = []; // { qname, el, nsMap }
  let nsMap = new Map([['xml', XML_NS]]);
  let nodes = 0,
    i = 0,
    rootSeen = false,
    rootClosed = false;
  const emitText = (t, raw) => {
    if (!t) return;
    if (!stack.length) {
      // fuera del elemento raíz solo se admiten espacios
      if (/\S/.test(t)) throw xmlError('Hay texto fuera del elemento raíz del XML.');
      return;
    }
    if (h.text && h.text(raw ? t : decodeEntities(t)) === STOP) throw STOP;
  };
  try {
    while (i < n) {
      const lt = s.indexOf('<', i);
      if (lt < 0) {
        emitText(s.slice(i));
        break;
      }
      if (lt > i) emitText(s.slice(i, lt));
      const c1 = s.charCodeAt(lt + 1);
      if (c1 === 33) {
        // <!
        if (s.startsWith('<!--', lt)) {
          const end = s.indexOf('-->', lt + 4);
          if (end < 0) throw xmlError('Comentario XML sin cerrar.');
          i = end + 3;
          continue;
        }
        if (s.startsWith('<![CDATA[', lt)) {
          const end = s.indexOf(']]>', lt + 9);
          if (end < 0) throw xmlError('Sección CDATA sin cerrar.');
          emitText(s.slice(lt + 9, end), true);
          i = end + 3;
          continue;
        }
        throw xmlError('El XML contiene una declaración DOCTYPE o ENTITY. Se rechaza por seguridad (podría leer archivos o agotar la memoria).', 'XML_UNSAFE');
      }
      if (c1 === 63) {
        // <? ... ?>
        const end = s.indexOf('?>', lt + 2);
        if (end < 0) throw xmlError('Instrucción XML sin cerrar.');
        i = end + 2;
        continue;
      }
      if (c1 === 47) {
        // </nombre>
        const end = s.indexOf('>', lt + 2);
        if (end < 0) throw xmlError('Etiqueta de cierre sin terminar.');
        const qn = s.slice(lt + 2, end).trim();
        const top = stack.pop();
        if (!top || top.qname !== qn) throw xmlError(`XML mal formado: se esperaba </${top ? top.qname : '?'}> y llegó </${qn}>.`);
        nsMap = top.parentNs;
        if (stack.length === 0) rootClosed = true;
        if (h.close && h.close(top.el) === STOP) throw STOP;
        i = end + 1;
        continue;
      }
      // etiqueta de apertura
      if (rootClosed) throw xmlError('El XML tiene más de un elemento raíz.');
      let j = lt + 1;
      while (j < n) {
        const c = s.charCodeAt(j);
        if (isSpace(c) || c === 47 || c === 62 || c === 61 || c === 60 || c === 34 || c === 39) break;
        j++;
      }
      const qname = s.slice(lt + 1, j);
      if (!qname || qname.length > L.maxNameLen) throw xmlError('Nombre de etiqueta XML no válido.');
      const attrsRaw = [];
      let selfClose = false,
        closed = false;
      while (j < n) {
        while (j < n && isSpace(s.charCodeAt(j))) j++;
        const c = s.charCodeAt(j);
        if (c === 62) {
          j++;
          closed = true;
          break;
        }
        if (c === 47) {
          if (s.charCodeAt(j + 1) !== 62) throw xmlError('Etiqueta XML mal formada.');
          j += 2;
          selfClose = true;
          closed = true;
          break;
        }
        const a0 = j;
        while (j < n) {
          const cc = s.charCodeAt(j);
          if (isSpace(cc) || cc === 61 || cc === 62 || cc === 47 || cc === 60 || cc === 34 || cc === 39) break;
          j++;
        }
        const an = s.slice(a0, j);
        if (!an || an.length > L.maxNameLen) throw xmlError('Atributo XML no válido.');
        while (j < n && isSpace(s.charCodeAt(j))) j++;
        if (s.charCodeAt(j) !== 61) throw xmlError(`Atributo sin valor en <${qname}>.`);
        j++;
        while (j < n && isSpace(s.charCodeAt(j))) j++;
        const q = s.charCodeAt(j);
        if (q !== 34 && q !== 39) throw xmlError(`Valor de atributo sin comillas en <${qname}>.`);
        const vend = s.indexOf(q === 34 ? '"' : "'", j + 1);
        if (vend < 0) throw xmlError('Valor de atributo sin cerrar.');
        if (attrsRaw.length >= L.maxAttrs) throw xmlError('Demasiados atributos en una etiqueta.', 'XML_LIMIT');
        attrsRaw.push([an, decodeEntities(s.slice(j + 1, vend))]);
        j = vend + 1;
      }
      if (!closed) throw xmlError('Etiqueta XML sin terminar.');
      // declaraciones de espacios de nombres
      let localNs = nsMap;
      let copied = false;
      const plain = [];
      for (const [an, av] of attrsRaw) {
        if (an === 'xmlns' || an.startsWith('xmlns:')) {
          if (!copied) {
            localNs = new Map(nsMap);
            copied = true;
          }
          localNs.set(an === 'xmlns' ? '' : an.slice(6), av);
        } else plain.push([an, av]);
      }
      const colon = qname.indexOf(':');
      const prefix = colon > 0 ? qname.slice(0, colon) : '';
      const name = colon > 0 ? qname.slice(colon + 1) : qname;
      const k = kindOf(localNs.get(prefix));
      const attrs = plain.map(([an, av]) => {
        const c2 = an.indexOf(':');
        if (c2 <= 0) return { local: an, k: '', value: av };
        return { local: an.slice(c2 + 1), k: kindOf(localNs.get(an.slice(0, c2))), value: av };
      });
      if (++nodes > L.maxNodes) throw xmlError('El XML tiene demasiados elementos.', 'XML_LIMIT');
      if (stack.length >= L.maxDepth) throw xmlError('El XML está anidado demasiado profundo.', 'XML_LIMIT');
      const el = { tag: `${k || '_'}:${name}`, name, k, attrs, selfClose };
      rootSeen = true;
      if (h.open && h.open(el) === STOP) throw STOP;
      if (selfClose) {
        if (stack.length === 0) rootClosed = true;
        if (h.close && h.close(el) === STOP) throw STOP;
      } else {
        stack.push({ qname, el, parentNs: nsMap });
        nsMap = localNs;
      }
      i = j;
    }
    if (stack.length) throw xmlError(`XML mal formado: falta cerrar <${stack[stack.length - 1].qname}>.`);
    if (!rootSeen) throw xmlError('El XML está vacío.');
  } catch (e) {
    if (e === STOP) return { stopped: true };
    throw e;
  }
  return { stopped: false };
}

// Árbol completo en memoria (para partes pequeñas/medianas). Las hojas de cálculo grandes se leen con saxParse.
function parseXml(src, limits = {}) {
  let root = null,
    cur = null;
  saxParse(
    src,
    {
      open(el) {
        const node = { tag: el.tag, name: el.name, k: el.k, attrs: el.attrs, kids: [], parent: cur };
        if (cur) cur.kids.push(node);
        else root = node;
        cur = node;
      },
      close() {
        cur = cur.parent;
      },
      text(t) {
        const last = cur.kids[cur.kids.length - 1];
        if (typeof last === 'string') cur.kids[cur.kids.length - 1] = last + t;
        else cur.kids.push(t);
      }
    },
    limits
  );
  return root;
}

// ── Utilidades de árbol ────────────────────────────────────────────────────────────────────────────────────────────
// Atributo por nombre local (y tipo de espacio de nombres si se indica; sin tipo se prefiere el atributo sin prefijo).
function at(node, local, kind) {
  if (!node) return undefined;
  const list = node.attrs;
  if (kind !== undefined) {
    for (const a of list) if (a.local === local && a.k === kind) return a.value;
    return undefined;
  }
  let any;
  for (const a of list) {
    if (a.local !== local) continue;
    if (a.k === '') return a.value;
    if (any === undefined) any = a.value;
  }
  return any;
}
const elems = node => (node ? node.kids.filter(k => typeof k !== 'string') : []);
const kidsOf = (node, tag) => elems(node).filter(k => k.tag === tag);
const first = (node, tag) => {
  if (!node) return null;
  for (const k of node.kids) if (typeof k !== 'string' && k.tag === tag) return k;
  return null;
};
function textOf(node) {
  if (!node) return '';
  if (typeof node === 'string') return node;
  let out = '';
  for (const k of node.kids) out += typeof k === 'string' ? k : textOf(k);
  return out;
}
function walk(node, fn) {
  if (!node || typeof node === 'string') return;
  if (fn(node) === false) return;
  for (const k of node.kids) walk(k, fn);
}
function findAll(node, tag, out = []) {
  walk(node, n => {
    if (n.tag === tag) out.push(n);
  });
  return out;
}

module.exports = { XML_LIMITS, STOP, xmlError, kindOf, saxParse, parseXml, decodeEntities, cleanText, esc, escAttr, at, elems, kidsOf, first, textOf, walk, findAll };
