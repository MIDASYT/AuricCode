'use strict';
// Motor de documentos de Auric Code: crea Word / Excel / PowerPoint / PDF, los VERIFICA releyéndolos antes de entregarlos
// y lee los que ya existen (para el modelo y para la vista previa). Sin dependencias externas de npm.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const B = require('./blocks');
const { buildDocx, readDocx, docxToText } = require('./docx');
const { buildXlsx, readXlsx, xlsxToText, sheetsFromArgs } = require('./xlsx');
const { buildPptx, readPptx, pptxToText, slidesFromArgs } = require('./pptx');
const { blocksToHtml, sanitizeRawHtml } = require('./pdf-html');
const { printHtmlToPdf, pageSizeOf } = require('./pdf-gen');
const { extractPdf, pdfToText } = require('./pdf-read');

const FORMAT_ALIASES = {
  docx: 'docx', word: 'docx', doc: 'docx',
  xlsx: 'xlsx', excel: 'xlsx', xls: 'xlsx', hoja: 'xlsx', spreadsheet: 'xlsx',
  pptx: 'pptx', powerpoint: 'pptx', ppt: 'pptx', presentacion: 'pptx', presentación: 'pptx', slides: 'pptx',
  pdf: 'pdf'
};
const MIME = {
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  pdf: 'application/pdf'
};
const MAX_READ_BYTES = 200 * 1024 * 1024;
const LETTER_REGIONS = new Set(['US', 'CA', 'MX', 'CL', 'CO', 'VE', 'PH', 'PR', 'GT', 'CR', 'PA', 'DO', 'SV', 'HN', 'NI', 'BO', 'EC', 'PE', 'CU']);
const pageSizeForRegion = region => (LETTER_REGIONS.has(String(region || '').toUpperCase()) ? 'Letter' : 'A4');

const fail = (message, code) => Object.assign(new Error(message), { code });

function normalizeFormat(f) {
  const k = String(f || '').trim().toLowerCase().replace(/^\./, '');
  const out = FORMAT_ALIASES[k];
  if (!out) {
    if (['md', 'txt', 'csv', 'html', 'json', 'markdown', 'text', 'rtf', 'odt', 'ods', 'odp'].includes(k))
      throw fail(`generate_document crea solo Word (docx), Excel (xlsx), PowerPoint (pptx) y PDF. Para «${k}» usa write_file.`, 'DOC_FORMAT');
    throw fail(`Formato de documento no compatible: «${f || ''}». Usa docx, xlsx, pptx o pdf.`, 'DOC_FORMAT');
  }
  return out;
}
function formatOfPath(p) {
  const e = path.extname(String(p || '')).toLowerCase().replace('.', '');
  return ['docx', 'xlsx', 'pptx', 'pdf'].includes(e) ? e : '';
}
const LEGACY = { doc: 'Word antiguo (.doc)', xls: 'Excel antiguo (.xls)', ppt: 'PowerPoint antiguo (.ppt)', odt: 'OpenDocument (.odt)', ods: 'OpenDocument (.ods)', odp: 'OpenDocument (.odp)', rtf: 'RTF' };
function legacyKind(p) {
  const e = path.extname(String(p || '')).toLowerCase().replace('.', '');
  return LEGACY[e] || '';
}

// ── Creación ──────────────────────────────────────────────────────────────────────────────────────────────────────
function rowsToTableBlocks(args, ctx) {
  const rows = args.rows;
  if (!Array.isArray(rows) || !rows.length) return [];
  return B.blocksFromValue({ type: 'table', rows, header: args.columns ?? args.headers }, ctx);
}
const has = v => (Array.isArray(v) ? v.length > 0 : typeof v === 'string' ? v.trim().length > 0 : !!(v && typeof v === 'object'));
const textSources = a => ['blocks', 'paragraphs', 'content', 'text', 'markdown', 'html'].filter(k => has(a[k]));

function docBlocks(args, ctx) {
  let blocks = B.contentBlocks(args, ctx);
  if (!textSources(args).length && has(args.rows)) blocks = blocks.concat(rowsToTableBlocks(args, ctx));
  B.assertSize(blocks);
  const withContent = blocks.some(b => b.t !== 'title' && b.t !== 'subtitle');
  if (!blocks.length || (!withContent && !String(args.title || '').trim()))
    throw fail('No hay contenido para el documento. Envía title y el texto en text/markdown, paragraphs o blocks.', 'DOC_INPUT');
  return blocks;
}
function expectOf(blocks) {
  const plain = B.blocksPlain(blocks);
  return {
    words: B.wordCount(plain),
    tables: blocks.filter(b => b.t === 'table').length,
    headings: blocks.filter(b => b.t === 'h' || b.t === 'title').length,
    plain
  };
}

async function buildOne(format, args, deps, warnings) {
  const now = deps.now || new Date();
  const lang = String(args.lang || deps.lang || 'es-ES');
  const ctx = { warnings, lang };
  const author = String(args.author ?? '').trim().slice(0, 120);
  const title = String(args.title ?? '').trim().slice(0, 300);
  const pageSize = args.pageSize || deps.pageSize || 'Letter';
  if (format === 'docx') {
    const blocks = docBlocks(args, ctx);
    const buffer = buildDocx(blocks, { lang, pageSize, author, title, pageNumbers: args.pageNumbers, now });
    return { buffer, expect: expectOf(blocks), blocks };
  }
  if (format === 'xlsx') {
    const sheets = sheetsFromArgs(args, ctx);
    if (!sheets.length) throw fail('No hay datos para la hoja de cálculo. Envía rows (filas), sheets o csv.', 'DOC_INPUT');
    const buffer = buildXlsx(sheets, { title, author, warnings, now });
    return { buffer, expect: { sheets: sheets.length } };
  }
  if (format === 'pptx') {
    const slides = slidesFromArgs(args, ctx);
    if (!slides.length) throw fail('No hay contenido para la presentación. Envía slides, markdown o text.', 'DOC_INPUT');
    const built = buildPptx(slides, { title, author, lang, slideNumbers: args.slideNumbers, now });
    return { buffer: built.buffer, expect: { slides: built.slides } };
  }
  // PDF
  if (!deps.BrowserWindow) throw fail('Crear PDF no está disponible en este entorno.', 'DOC_ENV');
  let html, blocks = null;
  const sources = textSources(args);
  if (has(args.html)) {
    if (sources.length > 1) warnings.push(`Se recibió contenido en varios campos (${sources.join(', ')}); para el PDF se usó «html» y se ignoró el resto.`);
    html = sanitizeRawHtml(String(args.html));
    if (title && !/<title[\s>]/i.test(html)) html = html.replace(/<head[^>]*>/i, m => `${m}<title>${B.runsText([{ text: title }]).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' })[c])}</title>`);
  } else {
    blocks = docBlocks(args, ctx);
    html = blocksToHtml(blocks, { title: title || '', lang: lang.slice(0, 2) });
  }
  const printed = await printHtmlToPdf(html, { BrowserWindow: deps.BrowserWindow, tmpDir: deps.tmpDir }, { pageSize, landscape: args.orientation === 'landscape' || args.landscape === true, pageNumbers: args.pageNumbers });
  if (printed.blocked?.length) warnings.push(`Se bloquearon ${printed.blocked.length} recurso(s) externo(s) del contenido HTML (el PDF no accede a internet ni a archivos).`);
  return { buffer: printed.buffer, expect: blocks ? { ...expectOf(blocks), pages: printed.pages } : { pages: printed.pages, html: true }, blocks };
}

// Relee lo creado y lo compara con lo pedido. Si algo no cuadra se lanza un error y NO se entrega el archivo.
async function verifyBuilt(format, built) {
  const buf = built.buffer;
  const e = built.expect || {};
  if (format === 'docx') {
    const r = readDocx(buf);
    if (e.words && r.stats.words < Math.floor(e.words * 0.95)) throw fail(`Verificación fallida: el Word tiene ${r.stats.words} palabras y se esperaban ${e.words}.`, 'DOC_VERIFY');
    if (e.tables !== undefined && r.stats.tables !== e.tables) throw fail(`Verificación fallida: el Word tiene ${r.stats.tables} tablas y se esperaban ${e.tables}.`, 'DOC_VERIFY');
    return { words: r.stats.words, paragraphs: r.stats.paragraphs, headings: r.stats.headings, tables: r.stats.tables, listItems: r.stats.listItems };
  }
  if (format === 'xlsx') {
    const r = readXlsx(buf, { maxRows: 50 });
    if (r.sheets.length !== e.sheets) throw fail(`Verificación fallida: el Excel tiene ${r.sheets.length} hojas y se esperaban ${e.sheets}.`, 'DOC_VERIFY');
    const cells = r.sheets.reduce((n, s) => n + (s.cellCount || s.rows.reduce((m, row) => m + row.cells.filter(c => c !== '').length, 0)), 0);
    if (!cells) throw fail('Verificación fallida: el Excel quedó sin datos.', 'DOC_VERIFY');
    return { sheets: r.sheets.map(s => ({ name: s.name, rows: s.rowCount, cols: s.colCount, formulas: s.formulas.length })), cells };
  }
  if (format === 'pptx') {
    const r = readPptx(buf);
    if (r.stats.slides !== e.slides) throw fail(`Verificación fallida: la presentación tiene ${r.stats.slides} diapositivas y se esperaban ${e.slides}.`, 'DOC_VERIFY');
    if (!r.stats.words) throw fail('Verificación fallida: la presentación quedó sin texto.', 'DOC_VERIFY');
    return { slides: r.stats.slides, words: r.stats.words, notes: r.stats.notes, tables: r.stats.tables };
  }
  const r = await extractPdf(buf, { maxPages: 500 });
  if (e.pages && r.pageCount !== e.pages) throw fail(`Verificación fallida: el PDF tiene ${r.pageCount} páginas y se esperaban ${e.pages}.`, 'DOC_VERIFY');
  const words = r.pages.reduce((n, p) => n + B.wordCount(p.text), 0);
  if (!words) throw fail('Verificación fallida: el PDF no tiene texto legible.', 'DOC_VERIFY');
  return { pages: r.pageCount, words };
}

// ── Escritura segura ──────────────────────────────────────────────────────────────────────────────────────────────
function withSuffix(target, i) {
  const ext = path.extname(target);
  return path.join(path.dirname(target), `${path.basename(target, ext)} (${i})${ext}`);
}
async function linkOrCopyExcl(tmp, dest) {
  try {
    await fsp.link(tmp, dest);
  } catch (e) {
    if (e.code === 'EEXIST') throw e;
    await fsp.copyFile(tmp, dest, fs.constants.COPYFILE_EXCL);
  }
}
const busyMessage = target => `No se pudo escribir «${path.basename(target)}»: parece estar abierto en otro programa (Word, Excel, PowerPoint o un visor de PDF). Ciérralo e inténtalo de nuevo.`;
// mode 'new': NUNCA pisa un archivo existente (agrega « (2)», « (3)»…). mode 'replace': reemplaza de forma atómica.
async function placeFile(buffer, target, mode) {
  await fsp.mkdir(path.dirname(target), { recursive: true });
  const tmp = path.join(path.dirname(target), `.${path.basename(target)}.${crypto.randomBytes(5).toString('hex')}.auric-tmp`);
  try {
    await fsp.writeFile(tmp, buffer, { mode: 0o666, flag: 'wx' });
    if (mode === 'replace') {
      try {
        await fsp.rename(tmp, target);
      } catch (e) {
        if (['EPERM', 'EBUSY', 'EACCES'].includes(e.code)) throw fail(busyMessage(target), 'DOC_BUSY');
        throw e;
      }
      return { path: target, renamed: false };
    }
    for (let i = 1; i <= 500; i++) {
      const dest = i === 1 ? target : withSuffix(target, i);
      try {
        await linkOrCopyExcl(tmp, dest);
        return { path: dest, renamed: i > 1 };
      } catch (e) {
        if (e.code === 'EEXIST') continue;
        if (['EPERM', 'EBUSY', 'EACCES'].includes(e.code)) throw fail(busyMessage(dest), 'DOC_BUSY');
        throw e;
      }
    }
    throw fail('Ya existen demasiados archivos con ese nombre en la carpeta.', 'DOC_EXISTS');
  } finally {
    fsp.rm(tmp, { force: true }).catch(() => {});
  }
}

function describe(format, v) {
  if (format === 'docx') return `${v.words} palabras, ${v.headings} títulos, ${v.tables} tabla${v.tables === 1 ? '' : 's'}, ${v.listItems} elementos de lista`;
  if (format === 'xlsx') return v.sheets.map(s => `hoja «${s.name}»: ${s.rows} filas × ${s.cols} columnas${s.formulas ? `, ${s.formulas} fórmulas` : ''}`).join('; ');
  if (format === 'pptx') return `${v.slides} diapositiva${v.slides === 1 ? '' : 's'}, ${v.words} palabras${v.notes ? `, ${v.notes} con notas del orador` : ''}${v.tables ? `, ${v.tables} tabla${v.tables === 1 ? '' : 's'}` : ''}`;
  return `${v.pages} página${v.pages === 1 ? '' : 's'}, ${v.words} palabras`;
}

async function generateDocument({ format, target, args = {}, deps = {}, mode = 'new' }) {
  const fmt = normalizeFormat(format);
  if (!target) throw fail('Falta la ruta del documento.', 'DOC_INPUT');
  const want = '.' + fmt;
  let final = String(target);
  if (path.extname(final).toLowerCase() !== want) final += want;
  const warnings = [];
  const built = await buildOne(fmt, args || {}, deps, warnings);
  const verified = await verifyBuilt(fmt, built);
  const placed = await placeFile(built.buffer, final, mode === 'replace' ? 'replace' : 'new');
  const size = built.buffer.length;
  const detail = describe(fmt, verified);
  return { path: placed.path, requested: final, renamed: placed.renamed, size, type: fmt, mime: MIME[fmt], verified, detail, warnings };
}

// ── Lectura ───────────────────────────────────────────────────────────────────────────────────────────────────────
async function readBytes(file) {
  const st = await fsp.stat(file);
  if (!st.isFile()) throw fail('Eso no es un archivo.', 'DOC_INPUT');
  if (st.size > MAX_READ_BYTES) throw fail(`El archivo es demasiado grande para leerlo (${Math.round(st.size / 1048576)} MB; máximo 200 MB).`, 'DOC_LIMIT');
  if (!st.size) throw fail('El archivo está vacío.', 'DOC_INVALID');
  return { buf: await fsp.readFile(file), size: st.size, mtime: st.mtimeMs };
}
function sniff(buf, file) {
  if (buf.subarray(0, 1024).indexOf('%PDF-') >= 0) return 'pdf';
  if (buf[0] === 0x50 && buf[1] === 0x4b) {
    const f = formatOfPath(file);
    return f && f !== 'pdf' ? f : '';
  }
  if (buf[0] === 0xd0 && buf[1] === 0xcf && buf[2] === 0x11 && buf[3] === 0xe0) return 'ole';
  return '';
}
function parseSlideSpec(spec, total) {
  if (!spec) return null;
  const out = new Set();
  for (const part of String(spec).split(',')) {
    const m = /^\s*(\d+)\s*(?:-\s*(\d+)\s*)?$/.exec(part);
    if (!m) continue;
    for (let i = Math.max(1, +m[1]); i <= Math.min(total, +(m[2] || m[1])); i++) out.add(i);
  }
  return out.size ? out : null;
}
function sliceText(text, offset, max) {
  offset = Math.max(0, Number(offset) || 0);
  if (!offset && text.length <= max) return { text, truncated: false, next: 0 };
  const part = text.slice(offset, offset + max);
  const end = offset + part.length;
  return { text: (offset ? `(continúa desde el carácter ${offset})\n` : '') + part + (end < text.length ? `\n… (hay más: ${text.length - end} caracteres; pídelos con offset=${end})` : ''), truncated: end < text.length, next: end < text.length ? end : 0 };
}

// Texto para el modelo (o para adjuntos). opts: pages (PDF/PPTX), sheet y range (XLSX), offset, maxChars.
async function readDocument(file, opts = {}) {
  const legacy = legacyKind(file);
  if (legacy) throw fail(`${legacy} no se puede leer directamente. Ábrelo y guárdalo como ${/xls|ods/i.test(legacy) ? '.xlsx' : /ppt|odp/i.test(legacy) ? '.pptx' : '.docx'} (o PDF) y vuelve a intentarlo.`, 'DOC_FORMAT');
  const { buf, size } = await readBytes(file);
  return readDocumentBytes(buf, file, opts, size);
}
async function readDocumentBytes(buf, file, opts = {}, size = buf.length) {
  const kind = sniff(buf, file);
  if (kind === 'ole') throw fail('Es un formato antiguo de Office (.doc/.xls/.ppt). Guárdalo como .docx/.xlsx/.pptx (o PDF) y vuelve a intentarlo.', 'DOC_FORMAT');
  if (!kind) throw fail('No parece un documento Word, Excel, PowerPoint ni PDF válido.', 'DOC_INVALID');
  const maxChars = Math.max(2000, Math.min(400000, Number(opts.maxChars) || 60000));
  const name = path.basename(String(file || ''));
  if (kind === 'docx') {
    const d = readDocx(buf);
    const full = docxToText(d, { marks: opts.marks !== false });
    const s = sliceText(full, opts.offset, maxChars);
    return { kind, name, size, text: s.text, truncated: s.truncated || d.truncated, next: s.next, stats: d.stats, properties: d.properties, warnings: warnDocx(d) };
  }
  if (kind === 'xlsx') {
    const d = readXlsx(buf, { sheet: opts.sheet, range: opts.range, maxRows: opts.maxRows });
    const full = xlsxToText(d, { maxChars: 2_000_000 });
    const s = sliceText(full, opts.offset, maxChars);
    return { kind, name, size, text: s.text, truncated: s.truncated || d.sheets.some(x => x.truncated), next: s.next, stats: { sheets: d.sheets.map(x => ({ name: x.name, rows: x.rowCount, cols: x.colCount, state: x.state })) }, properties: d.properties, warnings: [] };
  }
  if (kind === 'pptx') {
    const d = readPptx(buf);
    const want = parseSlideSpec(opts.pages, d.slides.length);
    const part = want ? { ...d, slides: d.slides.filter(s => want.has(s.n)) } : d;
    const full = pptxToText(part);
    const s = sliceText(full, opts.offset, maxChars);
    return { kind, name, size, text: s.text, truncated: s.truncated, next: s.next, stats: d.stats, properties: d.properties, warnings: d.stats.images ? [`La presentación tiene ${d.stats.images} imagen(es) que no se pueden leer como texto.`] : [] };
  }
  const p = await extractPdf(buf, { pages: opts.pages, maxPages: opts.maxPages });
  const warnings = [];
  const words = p.pages.reduce((n, x) => n + B.wordCount(x.text), 0);
  if (!words) warnings.push('El PDF no tiene texto seleccionable (probablemente son imágenes escaneadas). Auric no hace OCR: no se puede leer su contenido.');
  const full = pdfToText(p, { maxChars: 2_000_000 });
  const s = sliceText(full, opts.offset, maxChars);
  return { kind, name, size, text: s.text, truncated: s.truncated || p.truncated, next: s.next, stats: { pages: p.pageCount, words }, properties: p.info, warnings };
}
function warnDocx(d) {
  const w = [];
  if (d.stats.images) w.push(`El documento tiene ${d.stats.images} imagen(es) que no se pueden leer como texto.`);
  if (d.stats.trackedChanges) w.push(`Tiene ${d.stats.trackedChanges} cambio(s) con control de cambios; se muestra el texto con los cambios aceptados.`);
  if (d.stats.comments) w.push(`Tiene ${d.stats.comments} comentario(s) (incluidos al final del texto).`);
  return w;
}

// ── Vista previa (JSON pequeño y seguro; el panel lo pinta con textContent) ───────────────────────────────────────────
const PREVIEW = { blocks: 700, tableRows: 80, tableCols: 14, rows: 300, cols: 40, text: 4000, slides: 200 };
const clip = (s, n = PREVIEW.text) => (String(s ?? '').length > n ? String(s).slice(0, n) + '…' : String(s ?? ''));
function compactRuns(runs) {
  return (runs || []).map(r => (r.br ? { br: 1 } : { text: clip(r.text, 2000), ...(r.b ? { b: 1 } : {}), ...(r.i ? { i: 1 } : {}), ...(r.u ? { u: 1 } : {}), ...(r.s ? { s: 1 } : {}), ...(r.code ? { code: 1 } : {}), ...(r.href && B.safeHref(r.href) ? { href: r.href } : {}) }));
}
function compactBlock(b) {
  if (b.t === 'table') {
    const cut = rows => rows.slice(0, PREVIEW.tableRows).map(r => r.slice(0, PREVIEW.tableCols).map(compactRuns));
    return { t: 'table', head: b.head ? b.head.slice(0, PREVIEW.tableCols).map(compactRuns) : null, rows: cut(b.rows), moreRows: Math.max(0, b.rows.length - PREVIEW.tableRows), moreCols: Math.max(0, Math.max(0, ...b.rows.map(r => r.length)) - PREVIEW.tableCols), align: b.align };
  }
  if (b.t === 'code') return { t: 'code', text: clip(b.text) };
  return { t: b.t, level: b.level, ordered: b.ordered, num: b.num, runs: compactRuns(b.runs) };
}
async function previewDocument(file, opts = {}) {
  const legacy = legacyKind(file);
  if (legacy) throw fail(`${legacy} no tiene vista previa en Auric. Ábrelo con su programa.`, 'DOC_FORMAT');
  const { buf, size, mtime } = await readBytes(file);
  const kind = sniff(buf, file);
  const name = path.basename(String(file));
  if (kind === 'ole') throw fail('Es un formato antiguo de Office: sin vista previa en Auric. Ábrelo con su programa.', 'DOC_FORMAT');
  if (!kind) throw fail('No parece un documento Word, Excel, PowerPoint ni PDF válido.', 'DOC_INVALID');
  if (kind === 'pdf') {
    if (size > 60 * 1024 * 1024) throw fail('El PDF es muy grande (más de 60 MB) para la vista previa. Ábrelo con tu visor de PDF.', 'DOC_LIMIT');
    return { kind, name, size, mtime, bytes: new Uint8Array(buf) };
  }
  if (kind === 'docx') {
    const d = readDocx(buf, { maxChars: 400000 });
    return { kind, name, size, mtime, blocks: d.blocks.slice(0, PREVIEW.blocks).map(compactBlock), moreBlocks: Math.max(0, d.blocks.length - PREVIEW.blocks), stats: d.stats, headers: d.headers?.slice?.(0, 3), footers: d.footers?.slice?.(0, 3), truncated: d.truncated, properties: d.properties };
  }
  if (kind === 'xlsx') {
    const d = readXlsx(buf, { maxRows: PREVIEW.rows, maxCols: PREVIEW.cols });
    return {
      kind, name, size, mtime,
      sheets: d.sheets.map(s => ({ name: s.name, state: s.state, rowCount: s.rowCount, colCount: s.colCount, truncated: s.truncated, error: s.error || '', rows: (s.rows || []).slice(0, PREVIEW.rows).map(r => ({ n: r.n, cells: r.cells.slice(0, PREVIEW.cols).map(c => clip(c, 500)) })), formulas: (s.formulas || []).slice(0, 200).map(f => ({ ref: f.ref, f: clip(f.f, 300), value: clip(f.value, 100) })) })),
      properties: d.properties
    };
  }
  const d = readPptx(buf);
  return { kind, name, size, mtime, slides: d.slides.slice(0, PREVIEW.slides).map(s => ({ n: s.n, title: clip(s.title, 500), subtitle: clip(s.subtitle, 500), items: (s.items || []).slice(0, 80).map(it => ({ text: clip(B.runsText(it.runs), 800), level: it.level || 0, bullet: it.bullet !== false })), tables: (s.tables || []).slice(0, 4).map(t => t.slice(0, PREVIEW.tableRows).map(r => r.slice(0, PREVIEW.tableCols).map(c => clip(c, 300)))), notes: clip(s.notes, 2000), hidden: !!s.hidden, images: s.images || 0, charts: s.charts || 0 })), stats: d.stats, properties: d.properties };
}

module.exports = { generateDocument, readDocument, readDocumentBytes, previewDocument, normalizeFormat, formatOfPath, legacyKind, pageSizeForRegion, pageSizeOf, placeFile, withSuffix, MIME, buildOne, verifyBuilt };
