'use strict';
// Excel (.xlsx): creación (varias hojas, fórmulas, formatos, anchos, filtros, inmovilizar encabezado) y lectura segura.
const { esc, escAttr, cleanText, parseXml, saxParse, STOP, at, kidsOf, first, textOf, findAll } = require('./xml.js');
const P = require('./package.js');
const B = require('./blocks.js');
const { prepareFormula } = require('./xlsx-formula.js');
const { evaluateWorkbook } = require('./xlsx-eval.js');

const MAIN = 'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"';
const T = {
  workbook: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml',
  sheet: 'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml',
  styles: 'application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml',
  sst: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml'
};
const LIM = { maxRows: 1_048_576, maxCols: 16_384, maxCells: 1_000_000, maxStr: 32_767 };

function colName(n) {
  let s = '';
  n++;
  while (n) {
    const r = (n - 1) % 26;
    s = String.fromCharCode(65 + r) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}
function colIndex(letters) {
  let n = 0;
  for (const ch of letters.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}
function parseRef(ref) {
  const m = /^\$?([A-Za-z]{1,3})\$?(\d{1,7})$/.exec(String(ref || '').trim());
  return m ? { c: colIndex(m[1]), r: Number(m[2]) - 1 } : null;
}
function parseRange(range) {
  const parts = String(range || '').split(':');
  const a = parseRef(parts[0]),
    b = parseRef(parts[1] ?? parts[0]);
  if (!a || !b) return null;
  return { c1: Math.min(a.c, b.c), r1: Math.min(a.r, b.r), c2: Math.max(a.c, b.c), r2: Math.max(a.r, b.r) };
}

// ── Valores ────────────────────────────────────────────────────────────────────────────────────────────────────────
const NUMFMT = {
  general: 'General', entero: '0', integer: '0', numero: '#,##0', number: '#,##0', decimal: '#,##0.00', porcentaje: '0.0%', percent: '0.0%', percentage: '0.0%',
  fecha: 'dd/mm/yyyy', date: 'dd/mm/yyyy', fechahora: 'dd/mm/yyyy hh:mm', datetime: 'dd/mm/yyyy hh:mm', hora: 'hh:mm', time: 'hh:mm',
  moneda: '"$"#,##0.00', currency: '"$"#,##0.00', clp: '"$"#,##0', usd: '"US$"#,##0.00', eur: '#,##0.00" €"', texto: '@', text: '@'
};
const BUILTIN_FMT = { General: 0, '0': 1, '0.00': 2, '#,##0': 3, '#,##0.00': 4, '0%': 9, '0.00%': 10, '@': 49 };
function serialOf(y, mo, d, h = 0, mi = 0, s = 0) {
  const ms = Date.UTC(y, mo - 1, d, h, mi, s) - Date.UTC(1899, 11, 30);
  return ms / 86400000;
}
function isoDateToSerial(str) {
  let m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str);
  if (m) {
    const [y, mo, d] = [+m[1], +m[2], +m[3]];
    const dt = new Date(Date.UTC(y, mo - 1, d));
    if (y >= 1900 && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d) return { serial: serialOf(y, mo, d), time: false };
    return null;
  }
  m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?(?:Z)?$/.exec(str);
  if (m) {
    const [y, mo, d, h, mi, s] = [+m[1], +m[2], +m[3], +m[4], +m[5], +(m[6] || 0)];
    const dt = new Date(Date.UTC(y, mo - 1, d));
    if (y >= 1900 && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d && h < 24 && mi < 60 && s < 60) return { serial: serialOf(y, mo, d, h, mi, s), time: true };
  }
  return null;
}
// Normaliza una celda cualquiera que llegue del modelo → {kind, v, f?, style}
function normCell(v, warnings, where) {
  let style = null;
  let raw = v;
  if (raw && typeof raw === 'object' && !(raw instanceof Date) && !Array.isArray(raw)) {
    const o = raw;
    style = {};
    if (o.bold ?? o.b) style.bold = true;
    if (o.italic ?? o.i) style.italic = true;
    if (o.underline ?? o.u) style.underline = true;
    const color = hex(o.color ?? o.fontColor ?? o.font_color ?? o.fg);
    if (color) style.color = color;
    const fill = hex(o.fill ?? o.bg ?? o.background ?? o.backgroundColor ?? o.bgColor);
    if (fill) style.fill = fill;
    const fmt = o.numFmt ?? o.numberFormat ?? o.format ?? o.fmt ?? o.number_format;
    if (fmt) style.fmt = NUMFMT[String(fmt).toLowerCase()] ?? String(fmt).slice(0, 120);
    const al = String(o.align ?? o.horizontal ?? '').toLowerCase();
    if (['left', 'center', 'right', 'justify'].includes(al)) style.align = al;
    const va = String(o.valign ?? o.vertical ?? '').toLowerCase();
    if (['top', 'center', 'bottom'].includes(va)) style.valign = va;
    if (o.wrap ?? o.wrapText) style.wrap = true;
    if (o.border) style.border = true;
    if (o.size ?? o.fontSize) style.size = Math.max(6, Math.min(72, Number(o.size ?? o.fontSize) || 11));
    raw = o.formula !== undefined && o.formula !== null ? (String(o.formula).startsWith('=') ? o.formula : '=' + o.formula) : o.f ? (String(o.f).startsWith('=') ? o.f : '=' + o.f) : (o.value ?? o.v ?? o.text ?? '');
    if (Object.keys(style).length === 0) style = null;
  }
  if (raw === null || raw === undefined || raw === '') return { kind: 'empty', style };
  if (raw instanceof Date && !isNaN(raw)) {
    return { kind: 'n', v: serialOf(raw.getUTCFullYear(), raw.getUTCMonth() + 1, raw.getUTCDate(), raw.getUTCHours(), raw.getUTCMinutes(), raw.getUTCSeconds()), style: { ...(style || {}), fmt: style?.fmt || 'dd/mm/yyyy hh:mm' } };
  }
  if (typeof raw === 'boolean') return { kind: 'b', v: raw, style };
  if (typeof raw === 'number') {
    if (!Number.isFinite(raw)) {
      warnings.push(`${where}: valor numérico no válido (${raw}); se dejó vacío.`);
      return { kind: 'empty', style };
    }
    return { kind: 'n', v: raw, style };
  }
  if (Array.isArray(raw)) raw = raw.join(', ');
  const s = cleanText(String(raw));
  if (s.startsWith('=') && s.length > 1 && !s.includes('\n')) {
    const pf = prepareFormula(s);
    if (pf.ok) return { kind: 'f', f: pf.formula, style };
    warnings.push(`${where}: la fórmula «${s.slice(0, 60)}» no se guardó como fórmula (${pf.warning}); quedó como texto.`);
    return { kind: 's', v: s, style: { ...(style || {}), quote: true } };
  }
  const d = isoDateToSerial(s.trim());
  if (d) return { kind: 'n', v: d.serial, style: { ...(style || {}), fmt: style?.fmt || (d.time ? 'dd/mm/yyyy hh:mm' : 'dd/mm/yyyy') } };
  let t = s;
  if (t.length > LIM.maxStr) {
    warnings.push(`${where}: texto demasiado largo para una celda (${t.length} caracteres); se recortó a ${LIM.maxStr}.`);
    t = t.slice(0, LIM.maxStr);
  }
  return { kind: 's', v: t, style: t.includes('\n') ? { ...(style || {}), wrap: true } : style };
}
function hex(c) {
  if (!c) return '';
  const s = String(c).trim().replace(/^#/, '');
  return /^[0-9a-fA-F]{6}$/.test(s) ? s.toUpperCase() : /^[0-9a-fA-F]{3}$/.test(s) ? s.split('').map(x => x + x).join('').toUpperCase() : '';
}

// ── Texto / Markdown / CSV → hojas ─────────────────────────────────────────────────────────────────────────────────
function numberFromText(s, delim) {
  const t = s.trim();
  if (!t) return null;
  if (/^-?0\d/.test(t) || /^[+]/.test(t)) return null; // ceros a la izquierda / teléfonos: texto
  let m;
  if (/^-?\d+$/.test(t)) return t.length > 15 ? null : { n: Number(t) };
  if (/^-?\d+\.\d+$/.test(t)) return { n: Number(t) };
  if (delim !== ',' && /^-?\d+,\d+$/.test(t)) return { n: Number(t.replace(',', '.')) };
  if (/^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(t) && delim !== ',') return { n: Number(t.replace(/,/g, '')) };
  if (/^-?\d{1,3}(\.\d{3}){2,}(,\d+)?$/.test(t)) return { n: Number(t.replace(/\./g, '').replace(',', '.')) };
  if ((m = /^(-?\d+(?:[.,]\d+)?)\s?%$/.exec(t)) && !(delim === ',' && m[1].includes(','))) return { n: Number(m[1].replace(',', '.')) / 100, fmt: '0.0%' };
  return null;
}
function parseCsv(text) {
  const src = String(text).replace(/\r\n?/g, '\n');
  const lines = src.split('\n').filter(l => l.trim());
  const head = lines.slice(0, 5).join('\n');
  const counts = { '\t': (head.match(/\t/g) || []).length, ';': (head.match(/;/g) || []).length, ',': (head.match(/,/g) || []).length, '|': (head.match(/\|/g) || []).length };
  const delim = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
  const d = delim[1] > 0 ? delim[0] : ',';
  const rows = [];
  let row = [],
    cur = '',
    q = false,
    wasQuoted = false;
  const endCell = () => {
    row.push({ s: cur, quoted: wasQuoted });
    cur = '';
    wasQuoted = false;
  };
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (q) {
      if (c === '"') {
        if (src[i + 1] === '"') {
          cur += '"';
          i++;
        } else q = false;
      } else cur += c;
    } else if (c === '"' && cur === '') {
      q = true;
      wasQuoted = true;
    } else if (c === d) endCell();
    else if (c === '\n') {
      endCell();
      if (row.some(x => x.s.trim() || x.quoted)) rows.push(row);
      row = [];
    } else cur += c;
  }
  if (cur || row.length) {
    endCell();
    if (row.some(x => x.s.trim() || x.quoted)) rows.push(row);
  }
  return { rows, delim: d };
}
function cellFromText(s, quoted, delim) {
  if (quoted) return s;
  const n = numberFromText(s, delim);
  if (n) return n.fmt ? { v: n.n, fmt: n.fmt } : n.n;
  return s.trim();
}
function sheetsFromText(text, ctx) {
  const src = String(text ?? '');
  const out = [];
  // tablas Markdown
  const blocks = B.parseMarkdown(src, ctx);
  const tables = blocks.filter(b => b.t === 'table');
  if (tables.length) {
    let lastHeading = '';
    for (const b of blocks) {
      if (b.t === 'h' || b.t === 'title') lastHeading = B.runsText(b.runs);
      else if (b.t === 'table') {
        const conv = c => {
          const t = B.runsText(c);
          const n = numberFromText(t, '|');
          return n ? (n.fmt ? { v: n.n, fmt: n.fmt } : n.n) : t;
        };
        const rows = [];
        if (b.head) rows.push(b.head.map(c => B.runsText(c)));
        for (const r of b.rows) rows.push(r.map(conv));
        out.push({ name: lastHeading || `Tabla ${out.length + 1}`, rows, header: !!b.head });
        lastHeading = '';
      }
    }
    return out;
  }
  const { rows, delim } = parseCsv(src);
  if (rows.length) out.push({ name: '', rows: rows.map(r => r.map(c => cellFromText(c.s, c.quoted, delim))) });
  return out;
}

// ── Argumentos → hojas normalizadas ────────────────────────────────────────────────────────────────────────────────
function sheetFromObject(o, idx, defaultName, ctx) {
  let rows = o.rows ?? o.data ?? o.values ?? o.records ?? o.cells ?? [];
  let header = o.header;
  let columns = o.columns ?? o.headers;
  if (typeof rows === 'string') {
    const parsed = sheetsFromText(rows, ctx)[0];
    rows = parsed ? parsed.rows : [];
    if (header === undefined && parsed?.header !== undefined) header = parsed.header;
  }
  if (!Array.isArray(rows)) rows = [];
  if (rows.length && rows.every(r => r && typeof r === 'object' && !Array.isArray(r) && !(r instanceof Date) && !('v' in r || 'value' in r || 'f' in r || 'formula' in r))) {
    const keys = Array.isArray(columns) && columns.every(c => typeof c === 'string') ? columns : [...new Set(rows.flatMap(r => Object.keys(r)))];
    rows = [keys, ...rows.map(r => keys.map(k => r[k]))];
    header = header ?? true;
    columns = undefined;
  }
  rows = rows.map(r => (Array.isArray(r) ? r : [r]));
  if (Array.isArray(columns) && columns.length) {
    const names = columns.map(c => (c && typeof c === 'object' ? c.header ?? c.title ?? c.name ?? c.key ?? '' : c));
    const same = rows[0] && rows[0].length === names.length && rows[0].every((x, i) => String(x ?? '') === String(names[i] ?? ''));
    if (!same) rows = [names, ...rows];
    header = header ?? true;
  }
  return {
    name: String(o.name ?? o.title ?? o.sheet ?? o.sheetName ?? defaultName(idx)),
    rows,
    header,
    widths: Array.isArray(o.widths) ? o.widths : Array.isArray(o.columnWidths) ? o.columnWidths : Array.isArray(o.columns) ? o.columns.map(c => (c && typeof c === 'object' ? c.width : undefined)) : undefined,
    freeze: o.freeze ?? o.freezeHeader ?? o.freezePanes,
    filter: o.filter ?? o.autoFilter ?? o.autofilter,
    merges: Array.isArray(o.merges) ? o.merges : Array.isArray(o.mergeCells) ? o.mergeCells : undefined,
    landscape: o.landscape
  };
}
function sheetsFromArgs(args = {}, ctx = {}) {
  const warnings = (ctx.warnings = ctx.warnings || []);
  const es = /^es/i.test(ctx.lang || 'es');
  const defName = i => (es ? `Hoja${i + 1}` : `Sheet${i + 1}`);
  const has = v => (Array.isArray(v) ? v.length > 0 : typeof v === 'string' ? v.trim().length > 0 : v && typeof v === 'object' && Object.keys(v).length > 0);
  const order = [['sheets', args.sheets], ['rows', args.rows], ['data', args.data], ['records', args.records], ['csv', args.csv], ['text', args.text], ['markdown', args.markdown], ['content', args.content], ['blocks', args.blocks], ['paragraphs', args.paragraphs]].filter(([, v]) => has(v));
  if (!order.length) return [];
  const [name, v] = order[0];
  if (order.length > 1) warnings.push(`Se recibió contenido en varios campos (${order.map(o => o[0]).join(', ')}); se usó «${name}» y se ignoró el resto.`);
  let sheets = [];
  if (name === 'sheets') {
    if (Array.isArray(v)) sheets = v.map((s, i) => (Array.isArray(s) ? { name: defName(i), rows: s } : sheetFromObject(s || {}, i, defName, ctx)));
    else sheets = Object.entries(v).map(([k, rows], i) => (Array.isArray(rows) ? { name: k, rows } : sheetFromObject({ name: k, ...rows }, i, defName, ctx)));
  } else if (name === 'rows' || name === 'data' || name === 'records') {
    if (typeof v === 'string') sheets = sheetsFromText(v, ctx);
    else sheets = [sheetFromObject({ rows: v, name: args.sheetName ?? args.sheet ?? args.name, columns: args.columns ?? args.headers, header: args.header, widths: args.widths, freeze: args.freeze, filter: args.filter, merges: args.merges }, 0, defName, ctx)];
  } else if (name === 'blocks' || name === 'paragraphs' || name === 'content') {
    const bl = B.contentBlocks({ [name]: v }, ctx).filter(b => b.t === 'table');
    sheets = bl.map((b, i) => ({ name: defName(i), rows: [b.head ? b.head.map(c => B.runsText(c)) : null, ...b.rows.map(r => r.map(c => B.runsText(c)))].filter(Boolean), header: !!b.head }));
  } else sheets = sheetsFromText(String(v), ctx);
  sheets = sheets.map((s, i) => ({ ...s, name: s.name || args.sheetName || args.sheet || defName(i) }));
  return sheets;
}

// ── Estilos ────────────────────────────────────────────────────────────────────────────────────────────────────────
class StyleBook {
  constructor() {
    this.fonts = ['<font><sz val="11"/><color rgb="FF000000"/><name val="Calibri"/><family val="2"/></font>'];
    this.fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>'];
    this.borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>'];
    this.numFmts = new Map(); // código → id
    this.xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'];
    this.cache = new Map();
  }
  idx(list, xml) {
    const i = list.indexOf(xml);
    if (i >= 0) return i;
    list.push(xml);
    return list.length - 1;
  }
  xf(st) {
    if (!st) return 0;
    const key = JSON.stringify(st);
    if (this.cache.has(key)) return this.cache.get(key);
    const font = `<font>${st.bold ? '<b/>' : ''}${st.italic ? '<i/>' : ''}${st.underline ? '<u/>' : ''}<sz val="${st.size || 11}"/><color rgb="FF${st.color || '000000'}"/><name val="Calibri"/><family val="2"/></font>`;
    const fontId = this.idx(this.fonts, font);
    const fillId = st.fill ? this.idx(this.fills, `<fill><patternFill patternType="solid"><fgColor rgb="FF${st.fill}"/><bgColor indexed="64"/></patternFill></fill>`) : 0;
    const bc = '<color rgb="FFBFC5D0"/>';
    const borderId = st.border === 'header' ? this.idx(this.borders, `<border><left/><right/><top/><bottom style="thin">${bc}</bottom><diagonal/></border>`) : st.border ? this.idx(this.borders, `<border><left style="thin">${bc}</left><right style="thin">${bc}</right><top style="thin">${bc}</top><bottom style="thin">${bc}</bottom><diagonal/></border>`) : 0;
    let numFmtId = 0;
    if (st.fmt && st.fmt !== 'General') {
      if (BUILTIN_FMT[st.fmt] !== undefined) numFmtId = BUILTIN_FMT[st.fmt];
      else {
        if (!this.numFmts.has(st.fmt)) this.numFmts.set(st.fmt, 164 + this.numFmts.size);
        numFmtId = this.numFmts.get(st.fmt);
      }
    }
    const al = st.align || st.valign || st.wrap ? `<alignment${st.align ? ` horizontal="${st.align}"` : ''}${st.valign ? ` vertical="${st.valign}"` : ''}${st.wrap ? ' wrapText="1"' : ''}/>` : '';
    const xml = `<xf numFmtId="${numFmtId}" fontId="${fontId}" fillId="${fillId}" borderId="${borderId}" xfId="0"${st.quote ? ' quotePrefix="1"' : ''}${numFmtId ? ' applyNumberFormat="1"' : ''}${fontId ? ' applyFont="1"' : ''}${fillId ? ' applyFill="1"' : ''}${borderId ? ' applyBorder="1"' : ''}${al ? ' applyAlignment="1">' + al + '</xf>' : '/>'}`;
    this.xfs.push(xml);
    const id = this.xfs.length - 1;
    this.cache.set(key, id);
    return id;
  }
  xml() {
    const nf = [...this.numFmts].map(([code, id]) => `<numFmt numFmtId="${id}" formatCode="${escAttr(code)}"/>`).join('');
    return (
      P.DECL +
      `<styleSheet ${MAIN}>` +
      (nf ? `<numFmts count="${this.numFmts.size}">${nf}</numFmts>` : '') +
      `<fonts count="${this.fonts.length}">${this.fonts.join('')}</fonts>` +
      `<fills count="${this.fills.length}">${this.fills.join('')}</fills>` +
      `<borders count="${this.borders.length}">${this.borders.join('')}</borders>` +
      '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
      `<cellXfs count="${this.xfs.length}">${this.xfs.join('')}</cellXfs>` +
      '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
      '<dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium9" defaultPivotStyle="PivotStyleLight16"/>' +
      '</styleSheet>'
    );
  }
}

function safeSheetName(name, used, fallback) {
  let n = String(name ?? '')
    .replace(/[\\/?*[\]:]/g, ' ')
    .replace(/^'+|'+$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!n) n = fallback;
  n = n.slice(0, 31).trim() || fallback;
  if (/^history$/i.test(n)) n = n + ' 1';
  let cand = n,
    k = 2;
  while (used.has(cand.toLowerCase())) {
    const suf = ` (${k++})`;
    cand = n.slice(0, 31 - suf.length) + suf;
  }
  used.add(cand.toLowerCase());
  return cand;
}

// ── Creación ───────────────────────────────────────────────────────────────────────────────────────────────────────
function buildXlsx(sheetsIn, opts = {}) {
  const warnings = opts.warnings || [];
  const styles = new StyleBook();
  const sst = [];
  const sstIdx = new Map();
  const used = new Set();
  const sheets = [];
  const prep = [];
  let totalCells = 0;
  const headerStyle = { bold: true, fill: 'E7EAF0', border: 'header', valign: 'center' };
  sheetsIn.forEach((s, si) => {
    const name = safeSheetName(s.name, used, `Hoja${si + 1}`);
    const rowsIn = (s.rows || []).slice(0, LIM.maxRows);
    if ((s.rows || []).length > LIM.maxRows) warnings.push(`${name}: se recortó a ${LIM.maxRows} filas.`);
    const grid = [];
    let maxC = 0;
    const lens = [];
    rowsIn.forEach((row, r) => {
      const cells = [];
      (row || []).slice(0, LIM.maxCols).forEach((v, c) => {
        const where = `${name}!${colName(c)}${r + 1}`;
        const cell = normCell(v, warnings, where);
        cells[c] = cell;
        if (cell.kind !== 'empty') {
          totalCells++;
          const len = cell.kind === 's' ? Math.max(...String(cell.v).split('\n').map(x => x.length)) : cell.kind === 'f' ? Math.min(14, cell.f.length) : cell.kind === 'n' ? (cell.style?.fmt && /d|m|y/.test(cell.style.fmt) ? 16 : String(cell.v).length + 2) : 6;
          lens[c] = Math.max(lens[c] || 0, len);
        }
      });
      maxC = Math.max(maxC, cells.length);
      grid.push(cells);
    });
    if (totalCells > LIM.maxCells) throw Object.assign(new Error(`La hoja de cálculo es demasiado grande (más de ${LIM.maxCells} celdas). Divídela en varios archivos.`), { code: 'DOC_LIMIT' });
    const firstRow = grid[0] || [];
    const autoHeader = grid.length > 1 && firstRow.length > 0 && firstRow.every(c => !c || c.kind === 's') && firstRow.some(c => c && c.kind === 's');
    const header = s.header === undefined || s.header === null ? autoHeader : !!s.header;
    if (header && grid.length) for (let c = 0; c < maxC; c++) if (firstRow[c]) firstRow[c].style = { ...headerStyle, ...(firstRow[c].style || {}) };
    const freeze = s.freeze === undefined || s.freeze === null ? header : !!s.freeze;
    const filter = s.filter === undefined || s.filter === null ? header && grid.length > 1 : !!s.filter;
    prep.push({ s, si, name, grid, maxC, lens, header, freeze, filter });
  });
  // Valor ya calculado junto a cada fórmula (los visores que no recalculan, como la Vista protegida de Excel, muestran números).
  evaluateWorkbook(prep.map(x => ({ name: x.name, grid: x.grid })));
  for (const x of prep)
    x.grid.forEach(row =>
      row.forEach((cell, c) => {
        if (cell && cell.kind === 'f' && cell.cache) x.lens[c] = Math.max(x.lens[c] || 0, cell.cache.t === 'n' ? Math.min(14, String(Number(Number(cell.cache.v).toPrecision(10))).length + 2) : Math.min(40, String(cell.cache.v).length));
      })
    );
  prep.forEach(({ s, si, name, grid, maxC, lens, header, freeze, filter }) => {
    // XML de filas
    let rowsXml = '';
    grid.forEach((cells, r) => {
      let cx = '';
      for (let c = 0; c < cells.length; c++) {
        const cell = cells[c];
        if (!cell || (cell.kind === 'empty' && !cell.style)) continue;
        const ref = `${colName(c)}${r + 1}`;
        let st = cell.style ? { ...cell.style } : null;
        if (st && st.border === true && header && r === 0) st.border = 'header';
        const sId = st ? styles.xf(st) : 0;
        const sAttr = sId ? ` s="${sId}"` : '';
        if (cell.kind === 'empty') cx += `<c r="${ref}"${sAttr}/>`;
        else if (cell.kind === 'n') cx += `<c r="${ref}"${sAttr}><v>${cell.v}</v></c>`;
        else if (cell.kind === 'b') cx += `<c r="${ref}"${sAttr} t="b"><v>${cell.v ? 1 : 0}</v></c>`;
        else if (cell.kind === 'f') {
          const k = cell.cache;
          if (!k) cx += `<c r="${ref}"${sAttr}><f>${esc(cell.f)}</f></c>`;
          else cx += `<c r="${ref}"${sAttr}${k.t === 'n' ? '' : ` t="${k.t}"`}><f>${esc(cell.f)}</f><v>${k.t === 'b' ? (k.v ? 1 : 0) : k.t === 'n' ? k.v : esc(k.v)}</v></c>`;
        }
        else {
          let i = sstIdx.get(cell.v);
          if (i === undefined) {
            i = sst.length;
            sst.push(cell.v);
            sstIdx.set(cell.v, i);
          }
          cx += `<c r="${ref}"${sAttr} t="s"><v>${i}</v></c>`;
        }
      }
      rowsXml += `<row r="${r + 1}"${header && r === 0 ? ' ht="20" customHeight="1"' : ''}>${cx}</row>`;
    });
    // anchos
    const widths = [];
    for (let c = 0; c < maxC; c++) {
      const w = s.widths && Number(s.widths[c]) > 0 ? Number(s.widths[c]) : Math.max(8, Math.min(60, Math.ceil((lens[c] || 6) * 1.15 + 2)));
      widths.push(Math.min(255, w));
    }
    const lastRef = `${colName(Math.max(0, maxC - 1))}${Math.max(1, grid.length)}`;
    // combinadas (sin solapes)
    const merges = [];
    for (const m of s.merges || []) {
      const rg = parseRange(m);
      if (!rg || (rg.c1 === rg.c2 && rg.r1 === rg.r2)) continue;
      if (merges.some(x => !(rg.c2 < x.c1 || rg.c1 > x.c2 || rg.r2 < x.r1 || rg.r1 > x.r2))) {
        warnings.push(`${name}: la combinación de celdas ${m} se solapa con otra y se omitió.`);
        continue;
      }
      merges.push({ ...rg, ref: `${colName(rg.c1)}${rg.r1 + 1}:${colName(rg.c2)}${rg.r2 + 1}` });
    }
    const view = `<sheetViews><sheetView workbookViewId="0"${si === 0 ? ' tabSelected="1"' : ''}>${freeze && grid.length > 1 ? '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/>' : ''}</sheetView></sheetViews>`;
    const xml =
      P.DECL +
      `<worksheet ${MAIN} xmlns:r="${P.REL}">` +
      `<dimension ref="${grid.length ? `A1:${lastRef}` : 'A1'}"/>` +
      view +
      '<sheetFormatPr defaultRowHeight="15"/>' +
      (widths.length ? `<cols>${widths.map((w, c) => `<col min="${c + 1}" max="${c + 1}" width="${w}" customWidth="1"/>`).join('')}</cols>` : '') +
      `<sheetData>${rowsXml}</sheetData>` +
      (filter && grid.length > 1 && maxC ? `<autoFilter ref="A1:${lastRef}"/>` : '') +
      (merges.length ? `<mergeCells count="${merges.length}">${merges.map(m => `<mergeCell ref="${m.ref}"/>`).join('')}</mergeCells>` : '') +
      '<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>' +
      (s.landscape ? '<pageSetup orientation="landscape"/>' : '') +
      '</worksheet>';
    sheets.push({ name, xml, filterRef: filter && grid.length > 1 && maxC ? `A1:${lastRef}` : '', cells: grid.reduce((n, r) => n + r.filter(c => c && c.kind !== 'empty').length, 0) });
  });
  if (!sheets.length) throw Object.assign(new Error('No hay hojas que crear.'), { code: 'DOC_INPUT' });
  const q = n => "'" + n.replace(/'/g, "''") + "'";
  const defined = sheets
    .map((s, i) => (s.filterRef ? `<definedName name="_xlnm._FilterDatabase" localSheetId="${i}" hidden="1">${esc(q(s.name))}!${s.filterRef.replace(/([A-Z]+)(\d+)/g, '$$$1$$$2')}</definedName>` : ''))
    .join('');
  const workbook =
    P.DECL +
    `<workbook ${MAIN} xmlns:r="${P.REL}">` +
    '<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="28800" windowHeight="15000"/></bookViews>' +
    `<sheets>${sheets.map((s, i) => `<sheet name="${escAttr(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets>` +
    (defined ? `<definedNames>${defined}</definedNames>` : '') +
    '<calcPr calcId="191029" fullCalcOnLoad="1"/>' +
    '</workbook>';
  const n = sheets.length;
  const wbRels = [...sheets.map((_, i) => ({ id: `rId${i + 1}`, type: 'worksheet', target: `worksheets/sheet${i + 1}.xml` })), { id: `rId${n + 1}`, type: 'styles', target: 'styles.xml' }, { id: `rId${n + 2}`, type: 'sharedStrings', target: 'sharedStrings.xml' }];
  const sstXml = P.DECL + `<sst ${MAIN} count="${sst.length}" uniqueCount="${sst.length}">${sst.map(t => `<si><t xml:space="preserve">${esc(t)}</t></si>`).join('')}</sst>`;
  const entries = [
    ['[Content_Types].xml', P.contentTypes([['/xl/workbook.xml', T.workbook], ...sheets.map((_, i) => [`/xl/worksheets/sheet${i + 1}.xml`, T.sheet]), ['/xl/styles.xml', T.styles], ['/xl/sharedStrings.xml', T.sst], ['/docProps/core.xml', P.CT.core], ['/docProps/app.xml', P.CT.app]])],
    ['_rels/.rels', P.rootRels('xl/workbook.xml')],
    ['docProps/core.xml', P.coreXml({ title: opts.title || '', author: opts.author || '', now: opts.now || new Date() })],
    ['docProps/app.xml', P.appXml()],
    ['xl/workbook.xml', workbook],
    ['xl/_rels/workbook.xml.rels', P.relsXml(wbRels)],
    ['xl/styles.xml', styles.xml()],
    ['xl/sharedStrings.xml', sstXml],
    ...sheets.map((s, i) => [`xl/worksheets/sheet${i + 1}.xml`, s.xml])
  ];
  return P.buildPackage(entries, { date: opts.now });
}

// ── Lectura ────────────────────────────────────────────────────────────────────────────────────────────────────────
const DATE_BUILTIN = new Set([14, 15, 16, 17, 18, 19, 20, 21, 22, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 45, 46, 47, 50, 51, 52, 53, 54, 55, 56, 57, 58]);
function isDateFormat(id, code) {
  if (DATE_BUILTIN.has(id)) return true;
  if (!code) return false;
  const c = code.replace(/"[^"]*"/g, '').replace(/\[[^\]]*\]/g, '').replace(/\\./g, '');
  return /[dmyhs]/i.test(c) && !/^[#0?.,%\s$€E+\-()_*@]*$/i.test(c);
}
function serialToText(n, dateSystem1904) {
  const base = dateSystem1904 ? Date.UTC(1904, 0, 1) : Date.UTC(1899, 11, 30);
  const ms = Math.round(n * 86400000);
  const d = new Date(base + ms);
  if (isNaN(d)) return String(n);
  const p = x => String(x).padStart(2, '0');
  const date = `${d.getUTCFullYear()}-${p(d.getUTCMonth() + 1)}-${p(d.getUTCDate())}`;
  const time = `${p(d.getUTCHours())}:${p(d.getUTCMinutes())}${d.getUTCSeconds() ? ':' + p(d.getUTCSeconds()) : ''}`;
  if (n > 0 && n < 1) return time;
  return Math.abs(n % 1) < 1e-9 ? date : `${date} ${time}`;
}
function tidyNumber(s) {
  const n = Number(s);
  if (!Number.isFinite(n)) return s;
  const t = String(Number(n.toPrecision(15)));
  return t.includes('e') ? t : t;
}
function readSharedStrings(zip, part) {
  const out = [];
  if (!part || !zip.has(part)) return out;
  let cur = null,
    inT = false,
    inPh = 0;
  saxParse(zip.readText(part), {
    open(el) {
      if (el.tag === 's:si') cur = '';
      else if (el.tag === 's:rPh') inPh++;
      else if (el.tag === 's:t' && !inPh) inT = true;
    },
    close(el) {
      if (el.tag === 's:si') {
        out.push(cur ?? '');
        cur = null;
      } else if (el.tag === 's:rPh') inPh--;
      else if (el.tag === 's:t') inT = false;
    },
    text(t) {
      if (inT && cur !== null) cur += t;
    }
  });
  return out;
}
function readStyleInfo(zip, part) {
  const info = { xfDate: [], xfPercent: [] };
  if (!part || !zip.has(part)) return info;
  const root = parseXml(zip.readText(part));
  const codes = new Map();
  for (const nf of kidsOf(first(root, 's:numFmts'), 's:numFmt')) codes.set(Number(at(nf, 'numFmtId')), at(nf, 'formatCode') || '');
  for (const xf of kidsOf(first(root, 's:cellXfs'), 's:xf')) {
    const id = Number(at(xf, 'numFmtId') || 0);
    const code = codes.get(id) || '';
    info.xfDate.push(isDateFormat(id, code));
    info.xfPercent.push(id === 9 || id === 10 || /%/.test(code));
  }
  return info;
}
function readXlsx(buf, opts = {}) {
  const maxRows = opts.maxRows ?? 2000,
    maxCols = opts.maxCols ?? 200,
    maxCells = opts.maxCells ?? 250_000;
  const zip = P.openOffice(buf, opts.zipLimits);
  const mainPart = P.mainPartOf(zip);
  if (!mainPart) throw Object.assign(new Error('No parece un libro de Excel (.xlsx): falta la parte principal.'), { code: 'DOC_INVALID' });
  const rels = P.readRels(zip, mainPart);
  const relPart = short => [...rels.values()].find(r => r.short === short && r.part && zip.has(r.part))?.part || '';
  const wb = parseXml(zip.readText(mainPart));
  const date1904 = flag(first(first(wb, 's:workbookPr'), '')) || /1|true/i.test(at(first(wb, 's:workbookPr'), 'date1904') || '');
  const shared = readSharedStrings(zip, relPart('sharedStrings'));
  const styleInfo = readStyleInfo(zip, relPart('styles'));
  const sheetEls = kidsOf(first(wb, 's:sheets'), 's:sheet');
  const want = opts.sheet !== undefined && opts.sheet !== null && opts.sheet !== '' ? String(opts.sheet) : null;
  const sheets = [];
  let totalCells = 0;
  for (let si = 0; si < sheetEls.length; si++) {
    const el = sheetEls[si];
    const name = at(el, 'name') || `Hoja${si + 1}`;
    const state = at(el, 'state') || 'visible';
    const rel = rels.get(at(el, 'id', 'r'));
    const part = rel?.part;
    const meta = { name, state, index: si + 1, rows: [], rowCount: 0, colCount: 0, truncated: false, formulas: [], skipped: false };
    if (want && !(want.toLowerCase() === name.toLowerCase() || want === String(si + 1))) {
      meta.skipped = true;
      sheets.push(meta);
      continue;
    }
    if (!part || !zip.has(part)) {
      meta.error = 'hoja ilegible';
      sheets.push(meta);
      continue;
    }
    const range = opts.range ? parseRange(opts.range) : null;
    const rowsMap = new Map();
    let maxRow = -1,
      maxCol = -1;
    let cell = null,
      inV = false,
      inF = false,
      inT = false,
      inIs = false,
      rowCount = 0;
    saxParse(zip.readText(part), {
      open(el) {
        switch (el.tag) {
          case 's:c': {
            const ref = parseRef(at(el, 'r'));
            cell = { ref, t: at(el, 't') || 'n', s: Number(at(el, 's') || 0), v: '', f: '', is: '' };
            break;
          }
          case 's:v':
            inV = true;
            break;
          case 's:f':
            inF = true;
            break;
          case 's:is':
            inIs = true;
            break;
          case 's:t':
            if (inIs) inT = true;
            break;
          case 's:row':
            rowCount++;
            break;
        }
      },
      close(el) {
        switch (el.tag) {
          case 's:v':
            inV = false;
            break;
          case 's:f':
            inF = false;
            break;
          case 's:t':
            inT = false;
            break;
          case 's:is':
            inIs = false;
            break;
          case 's:c': {
            const c = cell;
            cell = null;
            if (!c || !c.ref) break;
            const { r, c: col } = c.ref;
            maxRow = Math.max(maxRow, r);
            maxCol = Math.max(maxCol, col);
            if (range && (r < range.r1 || r > range.r2 || col < range.c1 || col > range.c2)) break;
            let text = '';
            if (c.t === 's') text = shared[Number(c.v)] ?? '';
            else if (c.t === 'inlineStr') text = c.is;
            else if (c.t === 'str') text = c.v;
            else if (c.t === 'b') text = c.v === '1' ? 'TRUE' : 'FALSE';
            else if (c.t === 'e') text = c.v;
            else if (c.t === 'd') text = c.v;
            else if (c.v !== '') {
              const num = Number(c.v);
              if (Number.isFinite(num) && styleInfo.xfDate[c.s]) text = serialToText(num, date1904);
              else if (Number.isFinite(num) && styleInfo.xfPercent[c.s]) text = tidyNumber(String(num * 100)) + '%';
              else text = tidyNumber(c.v);
            }
            if (c.f && meta.formulas.length < 400) meta.formulas.push({ ref: `${colName(col)}${r + 1}`, f: c.f.startsWith('=') ? c.f : '=' + c.f, value: text });
            if (text === '' && !c.f) break;
            if (col >= maxCols) {
              meta.truncated = true;
              break;
            }
            if (r >= maxRows + (range ? range.r1 : 0) || totalCells >= maxCells) {
              meta.truncated = true;
              return STOP;
            }
            let row = rowsMap.get(r);
            if (!row) rowsMap.set(r, (row = []));
            row[col] = text;
            totalCells++;
            break;
          }
        }
      },
      text(t) {
        if (!cell) return;
        if (inV) cell.v += t;
        else if (inF) cell.f += t;
        else if (inT) cell.is += t;
      }
    });
    meta.rowCount = maxRow + 1;
    meta.colCount = maxCol + 1;
    const rowIdx = [...rowsMap.keys()].sort((a, b) => a - b);
    // filas en orden; las vacías intermedias se conservan para que los números de fila sean los reales
    meta.firstRow = rowIdx.length ? rowIdx[0] + 1 : 1;
    const out = [];
    let prev = rowIdx.length ? rowIdx[0] - 1 : -1;
    for (const r of rowIdx) {
      for (let g = prev + 1; g < r && out.length < maxRows * 2; g++) out.push({ n: g + 1, cells: [] });
      const cells = rowsMap.get(r);
      const w = Math.min(cells.length, maxCols);
      out.push({ n: r + 1, cells: Array.from({ length: w }, (_, i) => cells[i] ?? '') });
      prev = r;
    }
    meta.rows = out;
    sheets.push(meta);
  }
  const stats = { sheets: sheets.length, cells: totalCells, formulas: sheets.reduce((n, s) => n + s.formulas.length, 0) };
  return { kind: 'xlsx', sheets, stats, truncated: sheets.some(s => s.truncated), properties: P.coreProps(zip) };
}
function flag() {
  return false;
}
function xlsxToText(doc, { maxChars = 60000 } = {}) {
  const out = [];
  for (const s of doc.sheets) {
    if (s.skipped) {
      out.push(`## Hoja «${s.name}»${s.state !== 'visible' ? ` (${s.state})` : ''} — no leída (pídela con el parámetro sheet)`);
      continue;
    }
    const nonEmpty = s.rows.filter(r => r.cells.some(x => x !== ''));
    out.push(`## Hoja «${s.name}»${s.state !== 'visible' ? ` (${s.state})` : ''} — ${s.rowCount} fila${s.rowCount === 1 ? '' : 's'} × ${s.colCount} columna${s.colCount === 1 ? '' : 's'}${s.truncated ? ' (se muestra solo una parte)' : ''}`);
    if (s.error) {
      out.push(`(${s.error})`);
      continue;
    }
    if (!nonEmpty.length) {
      out.push('(vacía)');
      continue;
    }
    const width = Math.max(...nonEmpty.map(r => r.cells.length));
    const row = r => '| ' + Array.from({ length: width }, (_, c) => String(r.cells[c] ?? '').replace(/\n/g, ' ⏎ ').replace(/\|/g, '\\|')).join(' | ') + ' |';
    out.push(`(fila ${nonEmpty[0].n} = primera fila con datos; columnas A–${colName(width - 1)})`);
    out.push(row(nonEmpty[0]));
    out.push('|' + ' --- |'.repeat(width));
    for (const r of nonEmpty.slice(1)) out.push(row(r) + (nonEmpty.length > 12 ? '' : ''));
    if (s.formulas.length) out.push('Fórmulas: ' + s.formulas.slice(0, 60).map(f => `${f.ref} ${f.f}${f.value !== '' ? ` → ${f.value}` : ''}`).join(' · ') + (s.formulas.length > 60 ? ` · … (+${s.formulas.length - 60})` : ''));
    out.push('');
  }
  let text = out.join('\n');
  if (text.length > maxChars) text = text.slice(0, maxChars) + '\n… (recortado)';
  return text;
}

module.exports = { buildXlsx, readXlsx, xlsxToText, sheetsFromArgs, sheetsFromText, parseCsv, colName, colIndex, parseRef, parseRange, normCell, StyleBook, serialToText, isDateFormat };
