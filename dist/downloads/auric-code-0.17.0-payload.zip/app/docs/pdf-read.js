'use strict';
// Lectura de texto de PDF (PDF.js en un hilo aparte, con límites de tiempo y memoria).
const path = require('path');
const { Worker } = require('worker_threads');

const LIB_DIR = path.join(__dirname, '..', 'resources', 'vendor', 'pdfjs');
const MAX_PDF_BYTES = 120 * 1024 * 1024;

function friendly(err) {
  const n = err?.name || '';
  const m = err?.message || '';
  if (n === 'PasswordException') return Object.assign(new Error('El PDF está protegido con contraseña: no se puede leer.'), { code: 'PDF_PASSWORD' });
  if (n === 'InvalidPDFException' || /Invalid PDF|not a PDF/i.test(m)) return Object.assign(new Error('El archivo no es un PDF válido o está dañado.'), { code: 'PDF_INVALID' });
  if (n === 'MissingPDFException') return Object.assign(new Error('No se encontró el PDF.'), { code: 'PDF_MISSING' });
  return Object.assign(new Error(`No se pudo leer el PDF: ${m || n}`), { code: 'PDF_ERROR' });
}
function extractPdf(buffer, opts = {}) {
  if (!Buffer.isBuffer(buffer)) buffer = Buffer.from(buffer);
  if (buffer.length > MAX_PDF_BYTES) return Promise.reject(Object.assign(new Error('El PDF es demasiado grande para leerlo (más de 120 MB).'), { code: 'PDF_LIMIT' }));
  if (buffer.subarray(0, 1024).indexOf('%PDF-') < 0) return Promise.reject(Object.assign(new Error('El archivo no es un PDF válido.'), { code: 'PDF_INVALID' }));
  return new Promise((resolve, reject) => {
    let done = false;
    const w = new Worker(path.join(__dirname, 'pdf-worker.js'), {
      workerData: { libDir: LIB_DIR, data: buffer, pages: opts.pages || '', maxPages: opts.maxPages ?? 400, maxChars: opts.maxChars ?? 900000 },
      resourceLimits: { maxOldGenerationSizeMb: 1024, maxYoungGenerationSizeMb: 128, stackSizeMb: 8 }
    });
    const finish = (fn, v) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      w.terminate().catch(() => {});
      fn(v);
    };
    const timer = setTimeout(() => finish(reject, Object.assign(new Error('El PDF tardó demasiado en leerse y se canceló (puede ser muy grande o estar dañado).'), { code: 'PDF_TIMEOUT' })), opts.timeoutMs || 60000);
    timer.unref?.();
    w.once('message', m => (m.ok ? finish(resolve, { kind: 'pdf', pageCount: m.pageCount, pages: m.pages, info: m.info, truncated: m.truncated }) : finish(reject, friendly(m.error))));
    w.once('error', e => finish(reject, /out of memory|ERR_WORKER_OUT_OF_MEMORY/i.test(String(e?.code || e?.message)) ? Object.assign(new Error('El PDF necesita demasiada memoria para leerse.'), { code: 'PDF_LIMIT' }) : friendly(e)));
    w.once('exit', code => {
      if (!done) finish(reject, Object.assign(new Error(`La lectura del PDF terminó de forma inesperada (código ${code}).`), { code: 'PDF_ERROR' }));
    });
  });
}
function pdfToText(doc, { maxChars = 120000 } = {}) {
  const out = [];
  const t = doc.info?.Title;
  out.push(`PDF de ${doc.pageCount} página${doc.pageCount === 1 ? '' : 's'}${t ? ` — «${t}»` : ''}`);
  let used = out[0].length;
  for (const p of doc.pages) {
    const block = `\n--- Página ${p.n} ---\n${p.text || '(sin texto)'}`;
    if (used + block.length > maxChars) {
      out.push(`\n… (recortado: faltan las páginas desde la ${p.n}; pídelas con el parámetro pages)`);
      return out.join('');
    }
    out.push(block);
    used += block.length;
  }
  if (doc.truncated) out.push('\n… (hay más páginas: pídelas con el parámetro pages)');
  return out.join('');
}

module.exports = { extractPdf, pdfToText, LIB_DIR };
