'use strict';
// Crea PDF imprimiendo HTML propio en una ventana oculta y AISLADA: sin JavaScript, sin red, sin permisos, sin navegación,
// con su propia sesión en memoria y con una política CSP que solo permite estilos incrustados. Nada de lo que traiga el HTML
// puede ejecutarse, consultar internet ni leer archivos.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const { pathToFileURL } = require('url');

function countPdfPages(buf) {
  const m = Buffer.from(buf).toString('latin1').match(/\/Type\s*\/Page(?![A-Za-z])/g);
  return m ? m.length : 0;
}
const PAGE_SIZES = { a4: 'A4', letter: 'Letter', carta: 'Letter', legal: 'Legal', oficio: 'Legal', a3: 'A3', a5: 'A5', tabloid: 'Tabloid' };
function pageSizeOf(v) {
  return PAGE_SIZES[String(v || '').toLowerCase()] || 'Letter';
}
const FOOTER = '<div style="font-size:8px;color:#6B7280;width:100%;text-align:center;font-family:Arial,sans-serif;"><span class="pageNumber"></span> / <span class="totalPages"></span></div>';

// deps: { BrowserWindow, tmpDir }. html ya incluye su CSP. Devuelve { buffer, pages, blocked:[urls], footer }
async function printHtmlToPdf(html, deps, opts = {}) {
  const { BrowserWindow, tmpDir } = deps;
  if (!BrowserWindow) throw new Error('No hay motor de impresión disponible.');
  const dir = tmpDir || require('os').tmpdir();
  await fsp.mkdir(dir, { recursive: true });
  const file = path.join(dir, `auric-pdf-${crypto.randomUUID()}.html`);
  await fsp.writeFile(file, html, { encoding: 'utf8', mode: 0o600 });
  const expected = path.basename(file).toLowerCase();
  const partition = `auric-pdf-${crypto.randomUUID()}`; // sin «persist:» = en memoria
  let win;
  const blocked = [];
  try {
    win = new BrowserWindow({
      show: false,
      width: 900,
      height: 1200,
      webPreferences: {
        partition,
        sandbox: true,
        contextIsolation: true,
        nodeIntegration: false,
        javascript: false,
        webSecurity: true,
        allowRunningInsecureContent: false,
        plugins: false,
        webgl: false,
        spellcheck: false,
        enableWebSQL: false,
        navigateOnDragDrop: false,
        backgroundThrottling: false
      }
    });
    const wc = win.webContents;
    const ses = wc.session;
    ses.webRequest.onBeforeRequest({ urls: ['<all_urls>'] }, (d, cb) => {
      let ok = false;
      try {
        ok = d.resourceType === 'mainFrame' ? d.url.startsWith('file:') && decodeURIComponent(d.url).toLowerCase().endsWith(expected) : d.url.startsWith('data:');
      } catch {}
      if (!ok) blocked.push(String(d.url).slice(0, 300));
      cb({ cancel: !ok });
    });
    ses.setPermissionRequestHandler((_w, _p, cb) => cb(false));
    ses.setPermissionCheckHandler(() => false);
    try {
      ses.setDevicePermissionHandler(() => false);
    } catch {}
    wc.setWindowOpenHandler(() => ({ action: 'deny' }));
    wc.on('will-navigate', e => e.preventDefault());
    wc.on('will-redirect', e => e.preventDefault());
    wc.on('will-attach-webview', e => e.preventDefault());
    const timeout = ms =>
      new Promise((_, rej) => {
        const t = setTimeout(() => rej(Object.assign(new Error('La creación del PDF tardó demasiado y se canceló.'), { code: 'PDF_TIMEOUT' })), ms);
        t.unref?.();
      });
    await Promise.race([
      new Promise((resolve, reject) => {
        wc.once('did-finish-load', resolve);
        // Solo cuenta el fallo de la página principal: lo que se bloquee dentro (imágenes, marcos…) ya está cancelado y no impide imprimir.
        wc.on('did-fail-load', (_e, code, desc, _url, isMainFrame) => {
          if (isMainFrame) reject(new Error(`No se pudo preparar el PDF (${desc || code}).`));
        });
        win.loadFile(file).catch(reject);
      }),
      timeout(opts.timeoutMs || 60000)
    ]);
    const base = { printBackground: true, pageSize: pageSizeOf(opts.pageSize), landscape: !!opts.landscape, margins: { top: 0.8, bottom: 0.8, left: 0.85, right: 0.85 }, generateTaggedPDF: true, generateDocumentOutline: true, preferCSSPageSize: false };
    let buffer = await Promise.race([wc.printToPDF({ ...base, displayHeaderFooter: false }), timeout(opts.timeoutMs || 60000)]);
    let pages = countPdfPages(buffer);
    let footer = false;
    if (pages > 1 && opts.pageNumbers !== false) {
      buffer = await Promise.race([wc.printToPDF({ ...base, displayHeaderFooter: true, headerTemplate: '<span></span>', footerTemplate: FOOTER }), timeout(opts.timeoutMs || 60000)]);
      pages = countPdfPages(buffer) || pages;
      footer = true;
    }
    return { buffer: Buffer.from(buffer), pages, blocked, footer };
  } finally {
    try {
      if (win && !win.isDestroyed()) win.destroy();
    } catch {}
    fsp.rm(file, { force: true }).catch(() => {});
  }
}

module.exports = { printHtmlToPdf, countPdfPages, pageSizeOf };
