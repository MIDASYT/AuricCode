'use strict';
// PowerPoint (.pptx): creación a partir de diapositivas / Markdown y lectura segura (texto, tablas, notas del orador).
const { esc, escAttr, parseXml, at, kidsOf, first, textOf, findAll, elems } = require('./xml.js');
const P = require('./package.js');
const B = require('./blocks.js');
const X = require('./pptx-parts.js');
const { blocksToMarkdown, runsText, wordCount } = B;

const T = {
  presentation: 'application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml',
  master: 'application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml',
  layout: 'application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml',
  slide: 'application/vnd.openxmlformats-officedocument.presentationml.slide+xml',
  notesMaster: 'application/vnd.openxmlformats-officedocument.presentationml.notesMaster+xml',
  notesSlide: 'application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml',
  presProps: 'application/vnd.openxmlformats-officedocument.presentationml.presProps+xml',
  viewProps: 'application/vnd.openxmlformats-officedocument.presentationml.viewProps+xml',
  tableStyles: 'application/vnd.openxmlformats-officedocument.presentationml.tableStyles+xml'
};
const LAYOUT = { title: 1, content: 2, section: 3, titleOnly: 4, blank: 5, two: 6 };
const MAX_SLIDES = 300;

// ── Entrada → diapositivas canónicas ───────────────────────────────────────────────────────────────────────────────
// slide = { layout, title: runs, subtitle: runs|null, items:[{level,bullet,runs,bold?}], left:[], right:[], table:{head,rows,align}|null, notes:'' }
const runsOf = (s, ctx) => B.inline(String(s ?? '').slice(0, 2000), ctx);
function itemsFromBlocks(blocks, slide, ctx) {
  for (const b of blocks) {
    if (b.t === 'p') slide.items.push({ level: 0, bullet: false, runs: b.runs });
    else if (b.t === 'li') slide.items.push({ level: Math.min(b.level || 0, 3), bullet: true, runs: b.runs });
    else if (b.t === 'h' || b.t === 'title' || b.t === 'subtitle') slide.items.push({ level: 0, bullet: false, runs: b.runs.map(r => ({ ...r, b: true })) });
    else if (b.t === 'quote') slide.items.push({ level: 0, bullet: false, runs: b.runs.map(r => ({ ...r, i: true })) });
    else if (b.t === 'code') for (const ln of String(b.text).split('\n')) slide.items.push({ level: 0, bullet: false, runs: [{ text: ln || ' ', code: true }] });
    else if (b.t === 'table') {
      if (!slide.table) slide.table = { head: b.head, rows: b.rows, align: b.align };
      else ctx.warnings.push('Una diapositiva traía más de una tabla; solo se usó la primera.');
    }
  }
}
function notesFromItems(slide) {
  // «Notas: …» al final de una diapositiva escrita en Markdown
  const keep = [];
  for (const it of slide.items) {
    const t = runsText(it.runs);
    const m = /^(?:notas?(?: del orador)?|notes?|speaker notes?)\s*:\s*([\s\S]*)$/i.exec(t.trim());
    if (m && !it.bullet) slide.notes += (slide.notes ? '\n' : '') + m[1];
    else keep.push(it);
  }
  slide.items = keep;
}
function slideFromObject(o, ctx) {
  const s = { layout: '', title: [], subtitle: null, items: [], left: [], right: [], table: null, notes: '' };
  const title = o.title ?? o.heading ?? o.header ?? o.name ?? '';
  s.title = runsOf(title, ctx);
  const sub = o.subtitle ?? o.subheading ?? o.tagline;
  if (sub) s.subtitle = runsOf(sub, ctx);
  const hint = String(o.layout ?? o.type ?? o.kind ?? '').toLowerCase().replace(/[\s-]+/g, '_');
  const listOf = (v, target) => {
    const tmp = [];
    B.blocksFromValue(
      Array.isArray(v)
        ? v.map(x => (typeof x === 'string' ? '- ' + x.replace(/^\s*[-*•]\s+/, '') : x && typeof x === 'object' && !x.type ? { type: 'bullets', items: [x] } : x))
        : v,
      ctx,
      tmp
    );
    itemsFromBlocks(tmp, { items: target, table: null }, ctx);
  };
  const bullets = o.bullets ?? o.points ?? o.items ?? o.list ?? o.bullet_points ?? (Array.isArray(o.content) ? o.content : undefined);
  if (bullets !== undefined && bullets !== null && bullets !== '') {
    const arr = Array.isArray(bullets) ? bullets : [bullets];
    const tmp = [];
    for (const x of arr) {
      if (typeof x === 'string') tmp.push({ t: 'li', ordered: false, level: 0, runs: B.inline(x.replace(/^\s*[-*•]\s+/, ''), ctx) });
      else if (x && typeof x === 'object') B.blocksFromValue(x.type ? x : { type: 'bullets', items: [x] }, ctx, tmp);
    }
    itemsFromBlocks(tmp, s, ctx);
  }
  const body = o.body ?? o.text ?? o.paragraph ?? o.description ?? (typeof o.content === 'string' ? o.content : undefined);
  if (body !== undefined && body !== null && body !== '') {
    const tmp = [];
    B.blocksFromValue(typeof body === 'string' || Array.isArray(body) ? body : String(body), ctx, tmp);
    itemsFromBlocks(tmp, s, ctx);
  }
  const cols = o.columns ?? o.two_columns;
  if (o.left !== undefined || o.right !== undefined) {
    if (o.left) listOf(o.left, s.left);
    if (o.right) listOf(o.right, s.right);
  } else if (Array.isArray(cols) && cols.length >= 2 && !cols.every(c => typeof c === 'string') && cols.slice(0, 2).every(c => c !== null && c !== undefined)) {
    listOf(cols[0]?.items ?? cols[0]?.bullets ?? cols[0], s.left);
    listOf(cols[1]?.items ?? cols[1]?.bullets ?? cols[1], s.right);
  }
  const tb = o.table ?? (o.rows ? { rows: o.rows, header: o.header ?? o.headers ?? o.columns } : null);
  if (tb) {
    const tmp = [];
    B.blockFromObject({ type: 'table', ...(Array.isArray(tb) ? { rows: tb } : tb) }, ctx, tmp);
    if (tmp[0]) s.table = { head: tmp[0].head, rows: tmp[0].rows, align: tmp[0].align };
  }
  s.notes = String(o.notes ?? o.speakerNotes ?? o.speaker_notes ?? o.note ?? o.script ?? '').slice(0, 20000);
  s.layout =
    hint === 'title' || hint === 'cover' || hint === 'portada' ? 'title' :
    hint === 'section' || hint === 'divider' || hint === 'section_header' || o.section === true ? 'section' :
    hint === 'blank' ? 'blank' :
    s.left.length || s.right.length ? 'two' : s.table ? 'table' : '';
  return s;
}
function slidesFromMarkdown(src, ctx) {
  const blocks = B.parseMarkdown(src, ctx);
  const hs = blocks.filter(b => b.t === 'h');
  const levels = [...new Set(hs.map(h => h.level))].sort();
  const h1s = hs.filter(h => h.level === 1).length;
  const hasHr = blocks.some(b => b.t === 'hr');
  let deckTitle = null;
  let list = blocks;
  let slideLevel = levels[0] || 1;
  if (h1s === 1 && levels.includes(2)) {
    // # Título del mazo + ## una por diapositiva
    const i = blocks.findIndex(b => b.t === 'h' && b.level === 1);
    deckTitle = { h: blocks[i], extra: [] };
    let j = i + 1;
    while (j < blocks.length && !(blocks[j].t === 'h' || blocks[j].t === 'hr')) deckTitle.extra.push(blocks[j++]);
    list = [...blocks.slice(0, i), ...blocks.slice(j)];
    slideLevel = 2;
  }
  const groups = [];
  let cur = null;
  const flush = () => {
    if (cur && (cur.title || cur.blocks.length)) groups.push(cur);
    cur = null;
  };
  for (const b of list) {
    if (b.t === 'hr' && hasHr) {
      flush();
      continue;
    }
    if (b.t === 'pb') {
      flush();
      continue;
    }
    if (b.t === 'h' && b.level <= slideLevel) {
      // Sin «---» cada título abre una diapositiva. Con «---» ellos separan, pero un segundo título del mismo nivel también abre una nueva.
      const startsNew = !hasHr ? true : !!(cur && cur.title && b.level <= cur.titleLevel);
      if (startsNew) flush();
      if (!cur) cur = { title: null, blocks: [] };
      if (!cur.title) {
        cur.title = b.runs;
        cur.titleLevel = b.level;
      } else cur.blocks.push(b);
      continue;
    }
    if (!cur) cur = { title: null, blocks: [] };
    if (!cur.title && b.t === 'h') cur.title = b.runs;
    else cur.blocks.push(b);
  }
  flush();
  const out = [];
  if (deckTitle) {
    const s = { layout: 'title', title: deckTitle.h.runs, subtitle: null, items: [], left: [], right: [], table: null, notes: '' };
    const sub = deckTitle.extra.find(b => b.t === 'p');
    if (sub) s.subtitle = sub.runs;
    out.push(s);
  }
  for (const g of groups) {
    const s = { layout: '', title: g.title || [], subtitle: null, items: [], left: [], right: [], table: null, notes: '' };
    itemsFromBlocks(g.blocks, s, ctx);
    notesFromItems(s);
    if (!deckTitle && out.length === 0 && s.title.length && !s.items.length && !s.table) {
      // primera diapositiva con solo título (+ quizá una línea): portada
      s.layout = 'title';
    }
    if (!s.title.length && !s.items.length && !s.table) continue;
    out.push(s);
  }
  return out;
}
function slidesFromArgs(args = {}, ctx = {}) {
  ctx.warnings = ctx.warnings || [];
  const has = v => (Array.isArray(v) ? v.length > 0 : typeof v === 'string' ? v.trim().length > 0 : false);
  const sources = [['slides', args.slides], ['text', args.text], ['markdown', args.markdown], ['content', args.content], ['paragraphs', args.paragraphs], ['blocks', args.blocks]].filter(([, v]) => has(v));
  if (!sources.length) return [];
  const [name, v] = sources[0];
  if (sources.length > 1) ctx.warnings.push(`Se recibió contenido en varios campos (${sources.map(s => s[0]).join(', ')}); se usó «${name}» y se ignoró el resto.`);
  let slides;
  if (name === 'slides') {
    const arr = Array.isArray(v) ? v : [v];
    slides = arr.filter(x => x !== null && x !== undefined && x !== '').map(x => (typeof x === 'string' ? slidesFromMarkdown(x, ctx)[0] || slideFromObject({ title: x }, ctx) : slideFromObject(x, ctx)));
  } else if (typeof v === 'string') slides = slidesFromMarkdown(v, ctx);
  else slides = slidesFromMarkdown(blocksFlat(v, ctx), ctx);
  // portada con el título del mazo
  const deckTitle = String(args.title ?? '').trim();
  if (deckTitle && !(slides[0] && slides[0].layout === 'title')) {
    const s = { layout: 'title', title: runsOf(deckTitle, ctx), subtitle: args.subtitle ? runsOf(args.subtitle, ctx) : null, items: [], left: [], right: [], table: null, notes: '' };
    slides.unshift(s);
  } else if (slides[0]?.layout === 'title' && !slides[0].subtitle && args.subtitle) slides[0].subtitle = runsOf(args.subtitle, ctx);
  // clasificación automática
  slides.forEach((s, i) => {
    if (!s.layout) {
      if (i === 0 && s.title.length && !s.items.length && !s.table) s.layout = 'title';
      else if (i === 0 && s.title.length && s.subtitle && !s.table) s.layout = 'title';
      else if (s.table) s.layout = 'table';
      else if (!s.title.length && !s.items.length) s.layout = 'blank';
      else s.layout = s.items.length || s.title.length ? 'content' : 'titleOnly';
    }
    if (s.layout === 'title' && s.items.length && !s.subtitle) {
      s.subtitle = s.items[0].runs;
      s.items = s.items.slice(1);
    }
  });
  if (slides.length > MAX_SLIDES) throw B.fail(`La presentación tiene demasiadas diapositivas (máximo ${MAX_SLIDES}).`, 'DOC_LIMIT');
  return slides;
}
function blocksFlat(v, ctx) {
  // paragraphs/blocks/content en forma de arreglo → texto Markdown
  return blocksToMarkdown(B.blocksFromValue(v, ctx), { marks: true });
}

// ── Medidas y ajuste de texto (aproximado) ────────────────────────────────────────────────────────────────────────
const PT = 12700;
const BOX = { w: X.G.bodyW / PT - 14.4, h: X.G.bodyH / PT - 7.2 };
const CHAR_W = 0.52;
function indentPt(level, bullet) {
  return bullet ? 27 + level * 36 : 0;
}
function itemLines(it, sizePt, widthPt) {
  const avail = Math.max(60, widthPt - indentPt(it.level, it.bullet));
  const cpl = Math.max(8, Math.floor(avail / (sizePt * CHAR_W)));
  const text = runsText(it.runs);
  let lines = 0;
  for (const part of text.split('\n')) lines += Math.max(1, Math.ceil(part.length / cpl));
  return lines;
}
function itemSize(it, base) {
  return Math.max(12, base - it.level * 2);
}
function heightOf(items, base, widthPt) {
  let h = 0;
  for (const it of items) {
    const sz = itemSize(it, base);
    h += itemLines(it, sz, widthPt) * sz * 1.2 + sz * (it.level ? 0.2 : 0.25);
  }
  return h;
}
function fitSize(items, widthPt, heightPt, start = 24, min = 14) {
  for (let sz = start; sz >= min; sz -= 2) if (heightOf(items, sz, widthPt) <= heightPt) return sz;
  return 0;
}
function chunkItems(items, widthPt, heightPt, size = 18) {
  const chunks = [];
  let cur = [];
  for (const it of items) {
    if (cur.length && heightOf([...cur, it], size, widthPt) > heightPt) {
      chunks.push(cur);
      cur = [];
    }
    cur.push(it);
  }
  if (cur.length) chunks.push(cur);
  return chunks;
}
const cont = lang => (/^es/i.test(lang) ? ' (cont.)' : ' (cont.)');

// Tabla: anchos proporcionales, tamaño de letra y filas por diapositiva
function tableLayout(tb, widthEmu, heightPt) {
  const cols = Math.max(tb.head ? tb.head.length : 0, ...tb.rows.map(r => r.length), 1);
  const lens = Array(cols).fill(4);
  for (const r of [tb.head || [], ...tb.rows]) for (let c = 0; c < cols; c++) lens[c] = Math.max(lens[c], Math.min(40, runsText(r[c] || []).length + 2));
  const sum = lens.reduce((a, x) => a + x, 0);
  const minW = Math.round(widthEmu * 0.08);
  let widths = lens.map(l => Math.max(minW, Math.round((l / sum) * widthEmu)));
  const diff = widthEmu - widths.reduce((a, x) => a + x, 0);
  widths[widths.indexOf(Math.max(...widths))] += diff;
  const rowH = (r, sz, isHead) => {
    let lines = 1;
    for (let c = 0; c < cols; c++) {
      const cpl = Math.max(4, Math.floor((widths[c] / PT - 14.4) / (sz * (isHead ? 0.56 : CHAR_W))));
      const t = runsText(r[c] || []);
      lines = Math.max(lines, t.split('\n').reduce((n, part) => n + Math.max(1, Math.ceil(part.length / cpl)), 0));
    }
    return lines * sz * 1.2 + 10.8;
  };
  for (const sz of [16, 14, 12, 11]) {
    const hs = tb.head ? rowH(tb.head, sz, true) : 0;
    const rows = tb.rows.map(r => rowH(r, sz, false));
    const total = hs + rows.reduce((a, x) => a + x, 0);
    if (total <= heightPt || sz === 11) {
      // reparto en diapositivas si aún no cabe
      const pages = [];
      let cur = [],
        h = hs;
      rows.forEach((rh, i) => {
        if (cur.length && h + rh > heightPt) {
          pages.push(cur);
          cur = [];
          h = hs;
        }
        cur.push(i);
        h += rh;
      });
      if (cur.length || !pages.length) pages.push(cur);
      return { cols, widths, sz, pages, headH: hs, rowHs: rows };
    }
  }
}

// ── XML de diapositivas ────────────────────────────────────────────────────────────────────────────────────────────
class SlideCtx {
  constructor() {
    this.shapeId = 1;
    this.links = new Map();
    this.nextRel = 2;
  }
  id() {
    return ++this.shapeId;
  }
  link(url) {
    let id = this.links.get(url);
    if (!id) {
      id = `rId${this.nextRel++}`;
      this.links.set(url, id);
    }
    return id;
  }
}
function runXml(r, sc, o = {}) {
  if (r.br) return `<a:br><a:rPr lang="es-ES"${o.sz ? ` sz="${o.sz}"` : ''}/></a:br>`;
  if (!r.text) return '';
  const bold = r.b || o.b;
  const attrs = ` lang="es-ES"${o.sz ? ` sz="${o.sz}"` : ''}${bold ? ' b="1"' : ''}${r.i || o.i ? ' i="1"' : ''}${r.u && !r.href ? ' u="sng"' : ''}${r.s ? ' strike="sngStrike"' : ''} dirty="0"`;
  let kids = '';
  if (o.color && !r.href) kids += `<a:solidFill><a:srgbClr val="${o.color}"/></a:solidFill>`;
  if (r.code) kids += '<a:latin typeface="Consolas"/><a:cs typeface="Consolas"/>';
  else if (o.themeFont) kids += '<a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/>';
  if (r.href) kids += `<a:hlinkClick r:id="${sc.link(r.href)}"/>`;
  return `<a:r><a:rPr${attrs}>${kids}</a:rPr><a:t>${esc(r.text)}</a:t></a:r>`;
}
function paraXml(it, sc, base, { placeholder = true, color } = {}) {
  const sz = itemSize(it, base) * 100;
  let ppr = '';
  if (placeholder) {
    if (it.bullet) ppr = it.level ? `<a:pPr lvl="${Math.min(it.level, 4)}"/>` : '';
    else ppr = '<a:pPr marL="0" indent="0"><a:buNone/></a:pPr>';
  } else if (it.bullet) {
    const marL = 285750 + it.level * 457200;
    ppr = `<a:pPr marL="${marL}" indent="-285750"><a:spcBef><a:spcPts val="600"/></a:spcBef><a:buFont typeface="Arial"/><a:buChar char="${it.level ? '–' : '•'}"/></a:pPr>`;
  } else ppr = '<a:pPr marL="0" indent="0"><a:spcBef><a:spcPts val="600"/></a:spcBef><a:buNone/></a:pPr>';
  const runs = it.runs.map(r => runXml(r, sc, { sz, color, themeFont: !placeholder })).join('') || `<a:r><a:rPr lang="es-ES" sz="${sz}"/><a:t> </a:t></a:r>`;
  return `<a:p>${ppr}${runs}</a:p>`;
}
const phShape = (sc, name, phAttrs, xfrm, bodyPr, paras) =>
  `<p:sp><p:nvSpPr><p:cNvPr id="${sc.id()}" name="${escAttr(name)}"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph ${phAttrs}/></p:nvPr></p:nvSpPr><p:spPr>${xfrm ? `<a:xfrm><a:off x="${xfrm[0]}" y="${xfrm[1]}"/><a:ext cx="${xfrm[2]}" cy="${xfrm[3]}"/></a:xfrm>` : ''}</p:spPr><p:txBody>${bodyPr}<a:lstStyle/>${paras}</p:txBody></p:sp>`;
const NORM = '<a:bodyPr><a:normAutofit/></a:bodyPr>';
function titleSize(runs, large = false) {
  const n = runsText(runs).length;
  if (large) return n > 70 ? 3200 : n > 45 ? 3600 : 4400;
  return n > 130 ? 2000 : n > 90 ? 2400 : n > 55 ? 2800 : 0;
}
function titleShape(sc, runs, type = 'title', large = false, xfrm = null) {
  const sz = titleSize(runs, large);
  const paras = `<a:p>${runs.length ? runs.map(r => runXml(r, sc, { sz: sz || undefined, b: false })).join('') : '<a:endParaRPr lang="es-ES"/>'}</a:p>`;
  return phShape(sc, 'Título', `type="${type}"`, xfrm, NORM, paras);
}
function textBox(sc, name, x, y, cx, cy, parasXml, anchor = 't') {
  return `<p:sp><p:nvSpPr><p:cNvPr id="${sc.id()}" name="${escAttr(name)}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr><p:txBody><a:bodyPr wrap="square" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="${anchor}"><a:normAutofit/></a:bodyPr><a:lstStyle/>${parasXml}</p:txBody></p:sp>`;
}
function tableXml(sc, tb, lay, pageRows, x, y) {
  const cell = (runs, c, head, rowIdx) => {
    const al = tb.align?.[c] === 'r' ? 'r' : tb.align?.[c] === 'c' ? 'ctr' : 'l';
    const fill = head ? '1E293B' : rowIdx % 2 ? 'F1F5F9' : 'FFFFFF';
    const color = head ? 'FFFFFF' : '111827';
    const sz = lay.sz * 100;
    const body = runs.length ? runs.map(r => runXml(r, sc, { sz, b: head, color, themeFont: true })).join('') : `<a:endParaRPr lang="es-ES" sz="${sz}"/>`;
    const ln = side => `<a:${side} w="6350" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:srgbClr val="CBD5E1"/></a:solidFill><a:prstDash val="solid"/></a:${side}>`;
    return `<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr algn="${al}"/>${body}</a:p></a:txBody><a:tcPr marL="91440" marR="91440" marT="45720" marB="45720" anchor="ctr">${ln('lnL')}${ln('lnR')}${ln('lnT')}${ln('lnB')}<a:solidFill><a:srgbClr val="${fill}"/></a:solidFill></a:tcPr></a:tc>`;
  };
  const rowXml = (r, head, h, i) => `<a:tr h="${Math.round(h * PT)}">${Array.from({ length: lay.cols }, (_, c) => cell(r[c] || [], c, head, i)).join('')}</a:tr>`;
  let rows = '';
  let total = 0;
  if (tb.head) {
    rows += rowXml(tb.head, true, lay.headH, 0);
    total += lay.headH;
  }
  pageRows.forEach((ri, i) => {
    rows += rowXml(tb.rows[ri], false, lay.rowHs[ri], i);
    total += lay.rowHs[ri];
  });
  const cx = lay.widths.reduce((a, w) => a + w, 0);
  return `<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="${sc.id()}" name="Tabla"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr><p:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${Math.round(total * PT)}"/></p:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl><a:tblPr firstRow="${tb.head ? 1 : 0}" bandRow="1"/><a:tblGrid>${lay.widths.map(w => `<a:gridCol w="${w}"/>`).join('')}</a:tblGrid>${rows}</a:tbl></a:graphicData></a:graphic></p:graphicFrame>`;
}
const sldNum = sc =>
  `<p:sp><p:nvSpPr><p:cNvPr id="${sc.id()}" name="Número de diapositiva"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldNum" sz="quarter" idx="12"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:fld id="{B6F15528-21DE-4FAA-801E-634DDDAF4B2B}" type="slidenum"><a:rPr lang="es-ES" dirty="0"/><a:t>‹#›</a:t></a:fld><a:endParaRPr lang="es-ES" dirty="0"/></a:p></p:txBody></p:sp>`;

// Una diapositiva canónica → una o varias diapositivas finales ({layoutN, xml, links, notes})
function renderSlide(s, opts) {
  const out = [];
  const lang = opts.lang || 'es-ES';
  const mk = (layout, build, notes) => {
    const sc = new SlideCtx();
    const shapes = build(sc);
    out.push({ layout, shapes, sc, notes: notes || '' });
  };
  const withNum = (sc, shapes) => (opts.slideNumbers === false ? shapes : shapes + sldNum(sc));
  if (s.layout === 'title') {
    mk(LAYOUT.title, sc => {
      let x = titleShape(sc, s.title, 'ctrTitle', true);
      x += phShape(sc, 'Subtítulo', 'type="subTitle" idx="1"', null, NORM, `<a:p>${s.subtitle?.length ? s.subtitle.map(r => runXml(r, sc, {})).join('') : '<a:endParaRPr lang="es-ES"/>'}</a:p>`);
      return x;
    }, s.notes);
    return out;
  }
  if (s.layout === 'section') {
    mk(LAYOUT.section, sc => {
      let x = titleShape(sc, s.title, 'title', true);
      const lines = s.subtitle?.length ? [{ level: 0, bullet: false, runs: s.subtitle }] : s.items;
      x += phShape(sc, 'Texto', 'type="body" idx="1"', null, NORM, lines.length ? lines.map(it => paraXml(it, sc, 22, { placeholder: true })).join('') : '<a:p><a:endParaRPr lang="es-ES"/></a:p>');
      return x;
    }, s.notes);
    return out;
  }
  if (s.layout === 'blank') {
    mk(LAYOUT.blank, sc => '', s.notes);
    return out;
  }
  if (s.layout === 'two') {
    const colW = (X.G.bodyW - 304800) / 2 / PT - 14.4;
    const all = [...s.left, ...s.right];
    let size = Math.min(fitSize(s.left, colW, BOX.h, 22) || 0, fitSize(s.right, colW, BOX.h, 22) || 0) || 0;
    if (!size) {
      // no cabe: se reparte en varias diapositivas, cada una con su par de columnas
      const L = chunkItems(s.left, colW, BOX.h, 16),
        R = chunkItems(s.right, colW, BOX.h, 16);
      const n = Math.max(L.length, R.length, 1);
      for (let i = 0; i < n; i++) out.push(...renderSlide({ ...s, title: i ? [...s.title, { text: cont(lang) }] : s.title, left: L[i] || [], right: R[i] || [], notes: i ? '' : s.notes }, opts));
      return out;
    }
    mk(LAYOUT.two, sc => {
      let x = titleShape(sc, s.title);
      const col = (name, idx, items) => phShape(sc, name, `sz="half" idx="${idx}"`, null, NORM, items.length ? items.map(it => paraXml(it, sc, size, { placeholder: true })).join('') : '<a:p><a:endParaRPr lang="es-ES"/></a:p>');
      x += col('Contenido izquierdo', 1, s.left) + col('Contenido derecho', 2, s.right);
      return withNum(sc, x);
    }, s.notes);
    void all;
    return out;
  }
  if (s.layout === 'table' && s.table) {
    const intro = s.items;
    const introH = intro.length ? Math.min(heightOf(intro, 16, BOX.w) + 12, 150) : 0;
    const availH = BOX.h - (introH ? introH + 10 : 0);
    const lay = tableLayout(s.table, X.G.bodyW, availH);
    lay.pages.forEach((pageRows, pi) => {
      mk(LAYOUT.titleOnly, sc => {
        let x = titleShape(sc, pi ? [...s.title, { text: cont(lang) }] : s.title);
        let y = X.G.bodyY;
        if (pi === 0 && introH) {
          x += textBox(sc, 'Texto', X.G.bodyX, y, X.G.bodyW, Math.round(introH * PT), intro.map(it => paraXml(it, sc, 16, { placeholder: false })).join(''));
          y += Math.round((introH + 10) * PT);
        }
        x += tableXml(sc, s.table, lay, pageRows, X.G.bodyX, y);
        return withNum(sc, x);
      }, pi ? '' : s.notes);
    });
    return out;
  }
  // contenido normal
  const items = s.items;
  let size = items.length ? fitSize(items, BOX.w, BOX.h, 24) : 24;
  if (!size) {
    const chunks = chunkItems(items, BOX.w, BOX.h, 18);
    chunks.forEach((c, i) => out.push(...renderSlide({ ...s, title: i ? [...s.title, { text: cont(lang) }] : s.title, items: c, notes: i ? '' : s.notes }, opts)));
    return out;
  }
  mk(items.length ? LAYOUT.content : LAYOUT.titleOnly, sc => {
    let x = titleShape(sc, s.title);
    if (items.length) x += phShape(sc, 'Contenido', 'idx="1"', null, NORM, items.map(it => paraXml(it, sc, size, { placeholder: true })).join(''));
    return withNum(sc, x);
  }, s.notes);
  return out;
}

function slidePlain(s) {
  const parts = [runsText(s.title)];
  if (s.subtitle) parts.push(runsText(s.subtitle));
  for (const it of [...s.items, ...(s.left || []), ...(s.right || [])]) parts.push(runsText(it.runs));
  if (s.table) for (const r of [s.table.head || [], ...s.table.rows]) parts.push(r.map(c => runsText(c)).join(' '));
  return parts.filter(Boolean).join('\n');
}

function buildPptx(slidesIn, opts = {}) {
  if (!slidesIn.length) throw B.fail('No hay diapositivas que crear.', 'DOC_INPUT');
  const rendered = [];
  for (const s of slidesIn) rendered.push(...renderSlide(s, opts));
  if (rendered.length > MAX_SLIDES) throw B.fail(`La presentación resultante tiene demasiadas diapositivas (máximo ${MAX_SLIDES}).`, 'DOC_LIMIT');
  const n = rendered.length;
  const hasNotes = rendered.some(r => r.notes.trim());
  const now = opts.now || new Date();
  const entries = [];
  const overrides = [
    ['/ppt/presentation.xml', T.presentation],
    ['/ppt/slideMasters/slideMaster1.xml', T.master],
    ...X.LAYOUTS.map(L => [`/ppt/slideLayouts/slideLayout${L.n}.xml`, T.layout]),
    ['/ppt/theme/theme1.xml', P.CT.theme],
    ['/ppt/presProps.xml', T.presProps],
    ['/ppt/viewProps.xml', T.viewProps],
    ['/ppt/tableStyles.xml', T.tableStyles],
    ['/docProps/core.xml', P.CT.core],
    ['/docProps/app.xml', P.CT.app]
  ];
  if (hasNotes) overrides.push(['/ppt/notesMasters/notesMaster1.xml', T.notesMaster], ['/ppt/theme/theme2.xml', P.CT.theme]);
  rendered.forEach((_, i) => overrides.push([`/ppt/slides/slide${i + 1}.xml`, T.slide]));
  let noteNo = 0;
  rendered.forEach((r, i) => {
    r.noteIdx = r.notes.trim() ? ++noteNo : 0;
    if (r.noteIdx) overrides.push([`/ppt/notesSlides/notesSlide${r.noteIdx}.xml`, T.notesSlide]);
  });
  entries.push(['[Content_Types].xml', P.contentTypes(overrides)]);
  entries.push(['_rels/.rels', P.rootRels('ppt/presentation.xml')]);
  const first = slidesIn.find(s => s.title && s.title.length);
  entries.push(['docProps/core.xml', P.coreXml({ title: opts.title || (first ? runsText(first.title) : ''), author: opts.author || '', now })]);
  entries.push(['docProps/app.xml', P.appXml()]);
  const preRels = [{ id: 'rId1', type: 'slideMaster', target: 'slideMasters/slideMaster1.xml' }];
  rendered.forEach((_, i) => preRels.push({ id: `rId${i + 2}`, type: 'slide', target: `slides/slide${i + 1}.xml` }));
  preRels.push({ id: `rId${n + 2}`, type: 'presProps', target: 'presProps.xml' }, { id: `rId${n + 3}`, type: 'viewProps', target: 'viewProps.xml' }, { id: `rId${n + 4}`, type: 'theme', target: 'theme/theme1.xml' }, { id: `rId${n + 5}`, type: 'tableStyles', target: 'tableStyles.xml' });
  if (hasNotes) preRels.push({ id: `rId${n + 6}`, type: 'notesMaster', target: 'notesMasters/notesMaster1.xml' });
  entries.push(['ppt/_rels/presentation.xml.rels', P.relsXml(preRels)]);
  entries.push([
    'ppt/presentation.xml',
    P.DECL +
      `<p:presentation ${X.NS} saveSubsetFonts="1"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>` +
      (hasNotes ? `<p:notesMasterIdLst><p:notesMasterId r:id="rId${n + 6}"/></p:notesMasterIdLst>` : '') +
      `<p:sldIdLst>${rendered.map((_, i) => `<p:sldId id="${256 + i}" r:id="rId${i + 2}"/>`).join('')}</p:sldIdLst>` +
      `<p:sldSz cx="${X.SLIDE_W}" cy="${X.SLIDE_H}"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>`
  ]);
  entries.push(['ppt/presProps.xml', P.DECL + `<p:presentationPr ${X.NS}/>`]);
  entries.push(['ppt/viewProps.xml', P.DECL + `<p:viewPr ${X.NS}><p:gridSpacing cx="72008" cy="72008"/></p:viewPr>`]);
  entries.push(['ppt/tableStyles.xml', P.DECL + '<a:tblStyleLst xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" def="{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"/>']);
  entries.push(['ppt/theme/theme1.xml', X.themeXml('Auric')]);
  if (hasNotes) {
    entries.push(['ppt/theme/theme2.xml', X.themeXml('Notas')]);
    entries.push(['ppt/notesMasters/notesMaster1.xml', X.notesMasterXml()]);
    entries.push(['ppt/notesMasters/_rels/notesMaster1.xml.rels', X.notesMasterRels()]);
  }
  entries.push(['ppt/slideMasters/slideMaster1.xml', X.masterXml()]);
  entries.push(['ppt/slideMasters/_rels/slideMaster1.xml.rels', X.masterRels()]);
  for (const L of X.LAYOUTS) {
    entries.push([`ppt/slideLayouts/slideLayout${L.n}.xml`, X.layoutXml(L)]);
    entries.push([`ppt/slideLayouts/_rels/slideLayout${L.n}.xml.rels`, X.layoutRels()]);
  }
  rendered.forEach((r, i) => {
    entries.push([`ppt/slides/slide${i + 1}.xml`, P.DECL + `<p:sld ${X.NS}><p:cSld><p:spTree>${X.NV_GROUP}${r.shapes}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`]);
    const rels = [{ id: 'rId1', type: 'slideLayout', target: `../slideLayouts/slideLayout${r.layout}.xml` }];
    for (const [url, id] of r.sc.links) rels.push({ id, type: 'hyperlink', target: url, external: true });
    if (r.noteIdx) rels.push({ id: `rId${r.sc.nextRel + 1}`, type: 'notesSlide', target: `../notesSlides/notesSlide${r.noteIdx}.xml` });
    entries.push([`ppt/slides/_rels/slide${i + 1}.xml.rels`, P.relsXml(rels)]);
    if (r.noteIdx) {
      const paras = r.notes
        .split(/\r?\n/)
        .map(l => `<a:p><a:r><a:rPr lang="es-ES" dirty="0"/><a:t>${esc(l)}</a:t></a:r></a:p>`)
        .join('');
      entries.push([
        `ppt/notesSlides/notesSlide${r.noteIdx}.xml`,
        P.DECL +
          `<p:notes ${X.NS}><p:cSld><p:spTree>${X.NV_GROUP}<p:sp><p:nvSpPr><p:cNvPr id="2" name="Imagen de diapositiva 1"/><p:cNvSpPr><a:spLocks noGrp="1" noRot="1" noChangeAspect="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldImg"/></p:nvPr></p:nvSpPr><p:spPr/></p:sp><p:sp><p:nvSpPr><p:cNvPr id="3" name="Notas 2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>${paras}</p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>`
      ]);
      entries.push([`ppt/notesSlides/_rels/notesSlide${r.noteIdx}.xml.rels`, P.relsXml([{ id: 'rId1', type: 'notesMaster', target: '../notesMasters/notesMaster1.xml' }, { id: 'rId2', type: 'slide', target: `../slides/slide${i + 1}.xml` }])]);
    }
  });
  return { buffer: P.buildPackage(entries, { date: now }), slides: n };
}

// ── Lectura ────────────────────────────────────────────────────────────────────────────────────────────────────────
function paragraphsOf(txBody, st) {
  const out = [];
  for (const p of kidsOf(txBody, 'a:p')) {
    const pPr = first(p, 'a:pPr');
    const lvl = Number(at(pPr, 'lvl') || 0);
    const noBullet = !!first(pPr, 'a:buNone');
    const hasBullet = !!(first(pPr, 'a:buChar') || first(pPr, 'a:buAutoNum'));
    const runs = [];
    const push = (text, rPr, href) => {
      if (!text) return;
      const r = { text };
      if (rPr && /^(1|true)$/.test(at(rPr, 'b') || '')) r.b = true;
      if (rPr && /^(1|true)$/.test(at(rPr, 'i') || '')) r.i = true;
      if (href) r.href = href;
      const last = runs[runs.length - 1];
      if (last && !last.br && !!last.b === !!r.b && !!last.i === !!r.i && last.href === r.href) last.text += text;
      else runs.push(r);
    };
    for (const k of elems(p)) {
      if (k.tag === 'a:r' || k.tag === 'a:fld') {
        if (k.tag === 'a:fld' && /slidenum|datetime/i.test(at(k, 'type') || '')) continue;
        const rPr = first(k, 'a:rPr');
        const hl = first(rPr, 'a:hlinkClick');
        const rid = hl ? at(hl, 'id', 'r') : '';
        const rel = rid ? st.rels.get(rid) : null;
        push(textOf(first(k, 'a:t')), rPr, rel?.external ? rel.target : '');
      } else if (k.tag === 'a:br') runs.push({ br: true });
    }
    while (runs.length && runs[runs.length - 1].br) runs.pop();
    if (!runs.length) continue;
    out.push({ level: Math.max(0, Math.min(4, lvl)), explicitBullet: hasBullet, noBullet, runs });
  }
  return out;
}
function shapesOf(tree, st, slide) {
  for (const k of elems(tree)) {
    switch (k.tag) {
      case 'p:sp': {
        const ph = first(first(first(k, 'p:nvSpPr'), 'p:nvPr'), 'p:ph');
        const type = ph ? at(ph, 'type') || 'body' : '';
        const tx = first(k, 'p:txBody');
        if (!tx) break;
        if (['sldNum', 'dt', 'ftr', 'hdr'].includes(type)) break;
        const paras = paragraphsOf(tx, st);
        if (!paras.length) break;
        if (type === 'title' || type === 'ctrTitle') {
          const t = paras.map(p => runsText(p.runs)).join(' ');
          slide.title = slide.title ? slide.title + ' ' + t : t;
        } else if (type === 'subTitle') slide.subtitle = paras.map(p => runsText(p.runs)).join('\n');
        else {
          const placeholderBody = !!ph;
          for (const p of paras) slide.items.push({ level: p.level, bullet: p.explicitBullet || (placeholderBody && !p.noBullet && type !== 'subTitle' && (type === 'body' || type === 'obj' || type === '')), runs: p.runs });
        }
        break;
      }
      case 'p:graphicFrame': {
        const tbl = findAll(k, 'a:tbl')[0];
        if (tbl) {
          const rows = kidsOf(tbl, 'a:tr').map(tr => kidsOf(tr, 'a:tc').map(tc => paragraphsOf(first(tc, 'a:txBody'), st).map(p => runsText(p.runs)).join('\n')));
          if (rows.length) slide.tables.push(rows);
        } else if (findAll(k, 'c:chart').length || /chart/i.test(JSON.stringify(k.attrs))) slide.charts++;
        else if (findAll(k, 'a:graphicData').some(g => /chart/i.test(at(g, 'uri') || ''))) slide.charts++;
        break;
      }
      case 'p:grpSp':
        shapesOf(k, st, slide);
        break;
      case 'p:pic': {
        slide.images++;
        const c = first(first(k, 'p:nvPicPr'), 'p:cNvPr');
        const alt = c ? at(c, 'descr') || at(c, 'title') || '' : '';
        if (alt) slide.imageAlts.push(alt);
        break;
      }
    }
  }
}
function readPptx(buf, opts = {}) {
  const zip = P.openOffice(buf, opts.zipLimits);
  const mainPart = P.mainPartOf(zip);
  if (!mainPart) throw Object.assign(new Error('No parece una presentación de PowerPoint (.pptx): falta la parte principal.'), { code: 'DOC_INVALID' });
  const pres = parseXml(zip.readText(mainPart));
  const rels = P.readRels(zip, mainPart);
  const ids = kidsOf(first(pres, 'p:sldIdLst'), 'p:sldId');
  const slides = [];
  let words = 0;
  for (let i = 0; i < ids.length && i < MAX_SLIDES * 2; i++) {
    const rel = rels.get(at(ids[i], 'id', 'r'));
    const part = rel?.part;
    const slide = { n: i + 1, title: '', subtitle: '', items: [], tables: [], notes: '', hidden: false, images: 0, imageAlts: [], charts: 0 };
    if (!part || !zip.has(part)) {
      slide.error = 'diapositiva ilegible';
      slides.push(slide);
      continue;
    }
    const root = parseXml(zip.readText(part));
    slide.hidden = at(root, 'show') === '0';
    const srels = P.readRels(zip, part);
    const st = { rels: srels };
    shapesOf(first(first(root, 'p:cSld'), 'p:spTree'), st, slide);
    const nrel = [...srels.values()].find(r => r.short === 'notesSlide' && r.part && zip.has(r.part));
    if (nrel) {
      const nroot = parseXml(zip.readText(nrel.part));
      const parts = [];
      for (const sp of findAll(first(nroot, 'p:cSld'), 'p:sp')) {
        const ph = first(first(first(sp, 'p:nvSpPr'), 'p:nvPr'), 'p:ph');
        if (ph && at(ph, 'type') === 'body') parts.push(paragraphsOf(first(sp, 'p:txBody'), { rels: new Map() }).map(p => runsText(p.runs)).join('\n'));
      }
      slide.notes = parts.join('\n').trim();
    }
    const text = [slide.title, slide.subtitle, ...slide.items.map(x => runsText(x.runs)), ...slide.tables.flat(2), slide.notes].join(' ');
    words += wordCount(text);
    slides.push(slide);
  }
  return { kind: 'pptx', slides, stats: { slides: slides.length, words, notes: slides.filter(s => s.notes).length, tables: slides.reduce((n, s) => n + s.tables.length, 0), images: slides.reduce((n, s) => n + s.images, 0) }, properties: P.coreProps(zip) };
}
function pptxToText(doc, { maxChars = 80000 } = {}) {
  const out = [];
  for (const s of doc.slides) {
    out.push(`## Diapositiva ${s.n}${s.title ? ': ' + s.title : ''}${s.hidden ? ' (oculta)' : ''}`);
    if (s.error) {
      out.push(`(${s.error})`);
      continue;
    }
    if (s.subtitle) out.push(s.subtitle);
    for (const it of s.items) out.push('  '.repeat(it.level) + (it.bullet ? '- ' : '') + runsText(it.runs).replace(/\n/g, ' '));
    for (const t of s.tables) {
      const w = Math.max(...t.map(r => r.length));
      out.push('| ' + Array.from({ length: w }, (_, c) => (t[0][c] ?? '').replace(/\n/g, ' ')).join(' | ') + ' |');
      out.push('|' + ' --- |'.repeat(w));
      for (const r of t.slice(1)) out.push('| ' + Array.from({ length: w }, (_, c) => (r[c] ?? '').replace(/\n/g, ' ')).join(' | ') + ' |');
    }
    if (s.images) out.push(`[${s.images} imagen${s.images === 1 ? '' : 'es'}${s.imageAlts.length ? ': ' + s.imageAlts.join('; ') : ''}]`);
    if (s.charts) out.push(`[${s.charts} gráfico${s.charts === 1 ? '' : 's'}]`);
    if (s.notes) out.push(`Notas del orador: ${s.notes.replace(/\n/g, ' ')}`);
    out.push('');
  }
  let text = out.join('\n');
  if (text.length > maxChars) text = text.slice(0, maxChars) + '\n… (recortado)';
  return text;
}

module.exports = { buildPptx, readPptx, pptxToText, slidesFromArgs, slidesFromMarkdown, slidePlain, renderSlide, fitSize, heightOf, tableLayout, LAYOUT };
