'use strict';
// Imágenes con IA (herramienta image_generate). Proceso principal.
//
// Servicios con capa GRATIS (comprobados el día que indica resources/image-providers.json): Cloudflare Workers AI y NVIDIA.
// Aquí se arman las peticiones, se valida lo que vuelve (solo se guardan imágenes reales, con tope de tamaño), se guarda el archivo
// y se lleva la cuenta diaria para avisar de los límites. Las claves viven cifradas (safeStorage) y NUNCA viajan al renderer.
//
// Seguridad:
//  · Solo se habla con el servidor fijo de cada servicio (https), con DNS fijado a una dirección pública (net-safe.js).
//  · Una petición con clave NUNCA sigue una redirección (no se reenvía la clave ni el texto a otra dirección).
//  · Ningún mensaje de error incluye la clave: se tacha si el servicio la repite.
//  · La descripción de la imagen se envía como texto dentro del cuerpo JSON; nunca forma parte de la dirección.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const netSafe = require('./net-safe');

const CATALOG_FILE = path.join(__dirname, 'resources', 'image-providers.json');
const MAX_PROMPT = 1500;
const MAX_IMAGE_BYTES = 20 * 1024 * 1024;
const MAX_RESPONSE_BYTES = 40 * 1024 * 1024; // JSON con la imagen en base64
const MAX_PER_CALL = 4;
const TIMEOUT_MS = 90000;

class ImageError extends Error {
  constructor(message, code = 'IMAGE_ERROR', extra = {}) {
    super(message);
    this.code = code;
    Object.assign(this, extra);
  }
}

// ── Tamaños ─────────────────────────────────────────────────────────────────────────────────────
const ASPECTS = ['1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3'];
const RATIO = { '1:1': 1, '16:9': 16 / 9, '9:16': 9 / 16, '4:3': 4 / 3, '3:4': 3 / 4, '3:2': 3 / 2, '2:3': 2 / 3 };
const NVIDIA_SIZES = { '1:1': [1024, 1024], '16:9': [1344, 768], '9:16': [768, 1344], '4:3': [1152, 896], '3:4': [896, 1152], '3:2': [1216, 832], '2:3': [832, 1216] };

// Acepta «16:9», «horizontal», «cuadrada», «vertical»… y lo lleva al tamaño disponible más cercano.
function normalizeAspect(value) {
  const s = String(value ?? '')
    .trim()
    .toLowerCase();
  if (!s) return '1:1';
  if (ASPECTS.includes(s)) return s;
  const m = /^(\d{1,3}(?:\.\d+)?)\s*[:x/]\s*(\d{1,3}(?:\.\d+)?)$/.exec(s);
  if (m && Number(m[1]) > 0 && Number(m[2]) > 0) {
    const r = Number(m[1]) / Number(m[2]);
    return ASPECTS.reduce((best, k) => (Math.abs(Math.log(RATIO[k] / r)) < Math.abs(Math.log(RATIO[best] / r)) ? k : best), '1:1');
  }
  if (/cuadrad|square/.test(s)) return '1:1';
  if (/horizontal|landscape|apaisad|panor[aá]mic|wide|ancha/.test(s)) return '16:9';
  if (/vertical|portrait|retrato|story|historia/.test(s)) return '9:16';
  return '1:1';
}

function cleanPrompt(value) {
  const s = String(value ?? '')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!s) throw new ImageError('Falta la descripción de la imagen.', 'BAD_PROMPT');
  return s.length > MAX_PROMPT ? { text: s.slice(0, MAX_PROMPT), truncated: true } : { text: s, truncated: false };
}

// ── Imágenes de verdad ──────────────────────────────────────────────────────────────────────────
function sniffImage(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 12) return null;
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { mime: 'image/png', ext: 'png' };
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: 'image/jpeg', ext: 'jpg' };
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return { mime: 'image/webp', ext: 'webp' };
  return null;
}
function decodeBase64Image(value) {
  let s = String(value ?? '').trim();
  const m = /^data:image\/[a-z0-9.+-]+;base64,/i.exec(s);
  if (m) s = s.slice(m[0].length);
  s = s.replace(/\s+/g, '');
  if (!s || s.length > MAX_RESPONSE_BYTES || !/^[A-Za-z0-9+/_-]+={0,2}$/.test(s)) return null;
  const buf = Buffer.from(s, 'base64');
  return buf.length ? buf : null;
}
function parseJson(buf) {
  try {
    const v = JSON.parse(Buffer.from(buf).toString('utf8'));
    return v && typeof v === 'object' ? v : null;
  } catch {
    return null;
  }
}
function firstString(...values) {
  return values.find(v => typeof v === 'string' && v.length > 0) || '';
}

// ── Servicios ───────────────────────────────────────────────────────────────────────────────────
// Cada servicio sabe armar su petición y leer su respuesta. Lo demás (claves, cuenta, límites, archivos) es común.
const ADAPTERS = {
  cloudflare: {
    id: 'cloudflare',
    fields: [
      { name: 'accountId', secret: false, label: 'ID de cuenta', test: v => /^[0-9a-f]{32}$/i.test(v), problem: 'El ID de cuenta de Cloudflare tiene 32 letras y números (a–f y 0–9).' },
      { name: 'apiToken', secret: true, label: 'Token de API', test: v => /^[A-Za-z0-9_.~-]{20,200}$/.test(v), problem: 'El token de Cloudflare no parece válido: debe tener entre 20 y 200 letras, números o guiones, sin espacios.' }
    ],
    secretNames: { accountId: 'image:cloudflare:account', apiToken: 'image:cloudflare:token' },
    perDay: 170, // 10.000 neuronas por día ÷ ~58 por imagen de 1024×1024 con 4 pasos (4 teselas × 4,8 + 4 pasos × 9,6)
    square: true,
    buildRequest({ prompt, creds }) {
      return {
        url: `https://api.cloudflare.com/client/v4/accounts/${creds.accountId.toLowerCase()}/ai/run/@cf/black-forest-labs/flux-1-schnell`,
        headers: { Authorization: `Bearer ${creds.apiToken}`, 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ prompt, steps: 4 }),
        size: null
      };
    },
    // Respuesta documentada: { image: "<base64>" } (la API REST la envuelve en { result: {...}, success, errors }).
    readImage(res) {
      if (/^image\//i.test(res.contentType)) return res.buf;
      const j = parseJson(res.buf);
      if (!j) return null;
      if (j.success === false) throw new ImageError(describeCloudflareError(j) || 'Cloudflare no pudo crear la imagen.', 'SERVICE');
      return decodeBase64Image(firstString(j.result?.image, j.image, j.result?.images?.[0]));
    },
    errorDetail(j) {
      const e = Array.isArray(j?.errors) ? j.errors[0] : null;
      return { code: e?.code, text: String(e?.message || j?.message || '') };
    }
  },
  nvidia: {
    id: 'nvidia',
    fields: [{ name: 'apiToken', secret: true, label: 'Clave de NVIDIA', test: v => /^[\x21-\x7e]{16,300}$/.test(v), problem: 'La clave de NVIDIA no parece válida: suele empezar por «nvapi-» y no lleva espacios.' }],
    secretNames: { apiToken: 'image:nvidia:key' },
    chatKeyNames: ['provider-pool:nvidia', 'provider:nvidia'], // la clave que ya tengas para el chat con NVIDIA
    perMinute: 40,
    square: false,
    buildRequest({ prompt, aspect, creds, forceSquare }) {
      const [width, height] = NVIDIA_SIZES[forceSquare ? '1:1' : aspect] || NVIDIA_SIZES['1:1'];
      return {
        url: 'https://ai.api.nvidia.com/v1/genai/black-forest-labs/flux.1-schnell',
        headers: { Authorization: `Bearer ${creds.apiToken}`, 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ prompt, width, height, seed: 0, steps: 4 }),
        size: { width, height }
      };
    },
    // La página de NVIDIA no documenta la respuesta: se aceptan las formas habituales de sus servicios de imágenes.
    readImage(res) {
      if (/^image\//i.test(res.contentType)) return res.buf;
      const j = parseJson(res.buf);
      if (!j) return null;
      const art = Array.isArray(j.artifacts) ? j.artifacts[0] : null;
      const reason = String(art?.finishReason || art?.finish_reason || '').toUpperCase();
      if (reason && reason !== 'SUCCESS') {
        if (/FILTER/.test(reason)) throw new ImageError('NVIDIA bloqueó la imagen con su filtro de contenido. Prueba describiéndola con otras palabras.', 'BAD_PROMPT');
        throw new ImageError(`NVIDIA no pudo terminar la imagen (${reason.slice(0, 40)}).`, 'SERVICE');
      }
      return decodeBase64Image(firstString(art?.base64, art?.b64_json, j.image, j.images?.[0], j.data?.[0]?.b64_json, j.b64_json));
    },
    errorDetail(j) {
      return { code: j?.status ?? j?.code, text: String(j?.detail?.[0]?.msg || j?.detail || j?.error?.message || j?.message || j?.title || '') };
    }
  }
};
function describeCloudflareError(j) {
  const e = Array.isArray(j?.errors) ? j.errors[0] : null;
  return e ? String(e.message || '') : '';
}

const redact = (text, secrets) => {
  let out = String(text || '');
  for (const s of secrets) if (s && s.length >= 8) out = out.split(s).join('•••');
  return out;
};
const plainText = (v, max = 220) =>
  String(v || '')
    .replace(/[\u0000-\u001f\u007f]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);

// Traduce el fallo del servicio a un mensaje que una persona entienda y a un «código» con el que la app decide qué hacer.
function explainHttpError({ provider, name, status, buf, secrets, resetsAt }) {
  const j = parseJson(buf) || {};
  const detail = redact(plainText(ADAPTERS[provider]?.errorDetail?.(j)?.text), secrets);
  const extra = detail ? ` Detalle del servicio: «${detail}».` : '';
  const quota = /neuron|allocation|quota|exceed|limit|too many|rate/i.test(detail);
  // Cloudflare avisa del cupo diario agotado («you have used up your daily free allocation of 10,000 neurons») aunque el código HTTP varíe.
  const dailyCloudflare = provider === 'cloudflare' && /allocation|neurons|used up/i.test(detail);
  if (status === 401 || status === 403)
    return new ImageError(
      `${name} no aceptó tu clave. Revisa que esté bien copiada${provider === 'cloudflare' ? ', que el ID de cuenta sea el de la misma cuenta y que el token tenga permiso de «Workers AI»' : ' y que siga activa'}.${extra}`,
      'AUTH'
    );
  if (status === 402) return new ImageError(`${name} pide pasar a un plan de pago para seguir creando imágenes.${extra}`, 'LIMIT', { resetsAt: null });
  if (status === 429 || dailyCloudflare || (status >= 400 && status < 500 && quota && status !== 400 && status !== 422))
    return new ImageError(
      provider === 'cloudflare'
        ? `Llegaste al límite gratis de Cloudflare por hoy (o estás pidiendo demasiado rápido). Se renueva a las 00:00 UTC.${extra}`
        : `Llegaste al límite de NVIDIA por ahora (unas 40 peticiones por minuto). Espera un momento e inténtalo de nuevo.${extra}`,
      'LIMIT',
      { resetsAt: provider === 'cloudflare' ? resetsAt : null }
    );
  if (status === 400 || status === 422)
    return new ImageError(`${name} no aceptó la descripción (puede que su filtro la bloqueara o que sea muy larga). Prueba con otras palabras.${extra}`, 'BAD_PROMPT');
  if (status === 404) return new ImageError(`${name} no encontró el servicio de imágenes (puede haber cambiado).${extra}`, 'SERVICE');
  if (status >= 500) return new ImageError(`${name} está fallando en este momento (error ${status}). Inténtalo de nuevo en unos minutos.${extra}`, 'SERVICE');
  return new ImageError(`${name} respondió con un error inesperado (${status}).${extra}`, 'SERVICE');
}

// ── Servicio principal ──────────────────────────────────────────────────────────────────────────
const utcDay = ms => new Date(ms).toISOString().slice(0, 10);
const nextUtcMidnight = ms => {
  const d = new Date(ms);
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1)).toISOString();
};
function loadCatalog(file = CATALOG_FILE) {
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  const providers = (Array.isArray(raw.providers) ? raw.providers : []).filter(p => p && ADAPTERS[p.id]);
  return { reviewed: String(raw.reviewed || ''), note: String(raw.note || ''), notAvailable: Array.isArray(raw.notAvailable) ? raw.notAvailable.map(String) : [], providers };
}

/**
 * deps: { dir (carpeta de datos de la app), outDir (dónde se guardan las imágenes), secrets: { get(name), set(name, value) },
 *         hostMap (solo pruebas E2E), openSafe, now, catalogFile, registerAbort(requestId, controller) -> unregister() }
 */
function createService(deps = {}) {
  const { dir, outDir, secrets } = deps;
  if (!dir || !outDir || !secrets) throw new Error('image-gen: faltan dir, outDir o secrets.');
  const now = deps.now || Date.now;
  const openSafe = deps.openSafe || netSafe.openSafe;
  const catalog = loadCatalog(deps.catalogFile || CATALOG_FILE);
  const settingsFile = path.join(dir, 'image-gen.json');
  let queue = Promise.resolve();

  const readSettings = () => {
    try {
      const j = JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
      return { default: String(j.default || ''), usage: j.usage && typeof j.usage === 'object' ? j.usage : {} };
    } catch {
      return { default: '', usage: {} };
    }
  };
  const writeSettings = s => {
    fs.mkdirSync(dir, { recursive: true });
    const tmp = `${settingsFile}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(s, null, 2));
    fs.renameSync(tmp, settingsFile);
  };
  const adapterOf = id => {
    const a = ADAPTERS[id];
    if (!a || !catalog.providers.some(p => p.id === id)) throw new ImageError('Ese servicio de imágenes no existe.', 'BAD_PROVIDER');
    return a;
  };
  const nameOf = id => {
    const p = catalog.providers.find(x => x.id === id);
    return p ? p.name : id;
  };

  // Credenciales: las propias del servicio y, para NVIDIA, la clave del chat si no hay una propia.
  async function readCreds(id) {
    const a = adapterOf(id);
    const creds = {};
    let source = '';
    for (const f of a.fields) {
      const v = String((await secrets.get(a.secretNames[f.name])) || '').trim();
      if (v && f.test(v)) creds[f.name] = v; // lo que no cumple el formato no se usa (el ID de cuenta forma parte de la dirección)
    }
    if (a.fields.every(f => creds[f.name])) source = 'own';
    else if (a.chatKeyNames && !creds.apiToken) {
      for (const name of a.chatKeyNames) {
        let v = String((await secrets.get(name)) || '').trim();
        if (name.startsWith('provider-pool:')) {
          try {
            v = String(JSON.parse(v || '[]')[0] || '').trim();
          } catch {
            v = '';
          }
        }
        if (v && a.fields[0].test(v)) {
          creds.apiToken = v;
          source = 'chat';
          break;
        }
      }
    }
    return { creds, source, complete: a.fields.every(f => creds[f.name]) };
  }

  function usageOf(id, settings = readSettings()) {
    const a = adapterOf(id);
    const day = utcDay(now());
    const row = settings.usage[id];
    const used = row && row.day === day ? Math.max(0, Number(row.count) || 0) : 0;
    return { used, perDay: a.perDay || null, perMinute: a.perMinute || null, resetsAt: a.perDay ? nextUtcMidnight(now()) : null };
  }
  function bump(id, count) {
    const s = readSettings();
    const day = utcDay(now());
    const row = s.usage[id] && s.usage[id].day === day ? s.usage[id] : { day, count: 0 };
    s.usage[id] = { day, count: (Number(row.count) || 0) + count };
    writeSettings(s);
    return usageOf(id, s);
  }

  async function status() {
    const settings = readSettings();
    const providers = [];
    for (const p of catalog.providers) {
      const a = ADAPTERS[p.id];
      const { complete, source, creds } = await readCreds(p.id);
      providers.push({
        ...p,
        configured: complete,
        source, // 'own' | 'chat' | ''
        // Qué campos ya tienen valor (sin revelar secretos); el ID de cuenta no es secreto y se muestra.
        stored: Object.fromEntries(a.fields.map(f => [f.name, !!creds[f.name]])),
        accountId: p.id === 'cloudflare' && creds.accountId ? creds.accountId : '',
        usage: usageOf(p.id, settings)
      });
    }
    const configured = providers.filter(p => p.configured).map(p => p.id);
    const def = configured.includes(settings.default) ? settings.default : configured[0] || '';
    return { reviewed: catalog.reviewed, note: catalog.note, notAvailable: catalog.notAvailable, providers, default: def, anyConfigured: configured.length > 0, maxPerCall: MAX_PER_CALL };
  }

  async function saveCredentials(id, fields = {}) {
    const a = adapterOf(id);
    // Primero se valida TODO y solo después se guarda: si un campo viene mal, no se guarda ninguno (nada a medias).
    const toStore = [];
    for (const f of a.fields) {
      const raw = fields[f.name];
      if (raw == null || String(raw).trim() === '') continue; // vacío = dejar lo que ya hay
      const v = String(raw).trim();
      if (!f.test(v)) throw new ImageError(f.problem, 'BAD_CREDENTIALS');
      toStore.push([a.secretNames[f.name], v]);
    }
    for (const [name, v] of toStore) await secrets.set(name, v);
    const s = readSettings();
    const st = await status();
    if (!s.default && st.providers.find(p => p.id === id)?.configured) {
      s.default = id;
      writeSettings(s);
    }
    return status();
  }
  async function clearCredentials(id) {
    const a = adapterOf(id);
    for (const f of a.fields) await secrets.set(a.secretNames[f.name], '');
    const s = readSettings();
    if (s.default === id) {
      s.default = '';
      writeSettings(s);
    }
    return status();
  }
  async function setDefault(id) {
    adapterOf(id);
    const s = readSettings();
    s.default = id;
    writeSettings(s);
    return status();
  }

  async function callOnce(id, { prompt, aspect, creds, signal, forceSquare }) {
    const a = adapterOf(id);
    const name = nameOf(id);
    const req = a.buildRequest({ prompt, aspect, creds, forceSquare });
    const secretValues = Object.values(creds);
    let hop;
    try {
      hop = await openSafe(req.url, {
        method: 'POST',
        headers: { ...req.headers, 'Accept-Encoding': 'gzip, deflate, br' },
        body: req.body,
        hostMap: deps.hostMap || null,
        signal,
        timeoutMs: TIMEOUT_MS,
        maxRedirects: 0
      });
    } catch (e) {
      if (e?.code === 'ABORTED' || signal?.aborted) throw new ImageError('Creación de imagen cancelada.', 'ABORTED');
      if (e?.code === 'TIMEOUT') throw new ImageError(`${name} no respondió a tiempo. Inténtalo de nuevo.`, 'NETWORK');
      if (e?.code === 'REDIRECT_WITH_BODY') throw new ImageError(`${name} respondió con una redirección inesperada. Auric no envió tu clave a otra dirección.`, 'SERVICE');
      throw new ImageError(`No se pudo conectar con ${name}: ${redact(plainText(e?.message, 160), secretValues)}`, 'NETWORK');
    }
    const res = hop.res;
    const onAbort = () => res.destroy();
    signal?.addEventListener?.('abort', onAbort, { once: true });
    const bodyTimer = setTimeout(() => res.destroy(), TIMEOUT_MS); // si el servicio deja de enviar datos, no se espera para siempre
    let body;
    try {
      body = await netSafe.readLimited(netSafe.decodedStream(res), MAX_RESPONSE_BYTES);
    } catch (e) {
      if (signal?.aborted) throw new ImageError('Creación de imagen cancelada.', 'ABORTED');
      throw new ImageError(`Se cortó la conexión con ${name}. Inténtalo de nuevo.`, 'NETWORK');
    } finally {
      clearTimeout(bodyTimer);
      signal?.removeEventListener?.('abort', onAbort);
    }
    if (signal?.aborted) throw new ImageError('Creación de imagen cancelada.', 'ABORTED');
    if (body.truncated) throw new ImageError(`La respuesta de ${name} es demasiado grande y se descartó.`, 'BAD_RESPONSE');
    if (res.statusCode < 200 || res.statusCode >= 300)
      throw explainHttpError({ provider: id, name, status: res.statusCode, buf: body.buffer, secrets: secretValues, resetsAt: a.perDay ? nextUtcMidnight(now()) : null });
    const contentType = String(res.headers['content-type'] || '');
    let image;
    try {
      image = a.readImage({ contentType, buf: body.buffer });
    } catch (e) {
      if (e instanceof ImageError) throw e;
      throw new ImageError(`${name} devolvió una respuesta que Auric no entiende.`, 'BAD_RESPONSE');
    }
    const kind = image && sniffImage(image);
    if (!image || !kind || image.length > MAX_IMAGE_BYTES) throw new ImageError(`${name} no devolvió una imagen válida (puede que haya cambiado su formato de respuesta).`, 'BAD_RESPONSE');
    return { buf: image, kind, size: req.size };
  }

  function pickProvider(requested, st) {
    const configured = st.providers.filter(p => p.configured).map(p => p.id);
    if (requested) {
      const id = String(requested).toLowerCase();
      if (!catalog.providers.some(p => p.id === id)) throw new ImageError(`El servicio «${plainText(requested, 40)}» no existe. Los disponibles son: ${catalog.providers.map(p => p.id).join(', ')}.`, 'BAD_PROVIDER');
      if (!configured.includes(id)) throw new ImageError(`${nameOf(id)} todavía no está configurado (Ajustes → Imágenes).`, 'NO_CREDENTIALS');
      return { id, explicit: true, others: [] };
    }
    if (!configured.length) throw new ImageError('Todavía no hay un servicio de imágenes configurado. Hay que ponerlo en Ajustes → Imágenes (es gratis).', 'NO_CREDENTIALS');
    const id = configured.includes(st.default) ? st.default : configured[0];
    return { id, explicit: false, others: configured.filter(x => x !== id) };
  }

  async function generateInner(req = {}) {
    const st = await status();
    const picked = pickProvider(req.provider, st);
    const p = cleanPrompt(req.prompt);
    const n = Math.max(1, Math.min(MAX_PER_CALL, Math.floor(Number(req.n) || 1)));
    const aspect = normalizeAspect(req.aspect);
    const warnings = [];
    if (p.truncated) warnings.push(`La descripción era muy larga y se recortó a ${MAX_PROMPT} caracteres.`);
    const controller = new AbortController();
    const unregister = req.requestId && deps.registerAbort ? deps.registerAbort(String(req.requestId), controller) : null;
    const images = [];
    let active = picked.id;
    let queueOthers = [...picked.others];
    let usedProviderNames = new Set();
    try {
      await fsp.mkdir(outDir, { recursive: true });
      for (let i = 0; i < n; i++) {
        let result = null;
        for (;;) {
          const { creds } = await readCreds(active);
          let forceSquare = ADAPTERS[active].square === true && aspect !== '1:1';
          if (forceSquare && !warnings.some(w => w.startsWith(`${nameOf(active)} solo`))) warnings.push(`${nameOf(active)} solo crea imágenes cuadradas: se hizo cuadrada.`);
          try {
            try {
              result = await callOnce(active, { prompt: p.text, aspect, creds, signal: controller.signal, forceSquare });
            } catch (e) {
              // NVIDIA puede no aceptar tamaños que no sean cuadrados: se reintenta una vez en cuadrado, avisando.
              if (e.code === 'BAD_PROMPT' && !forceSquare && aspect !== '1:1' && active === 'nvidia' && /tamaño|size|width|height|resolution/i.test(String(e.message))) {
                warnings.push('NVIDIA no aceptó ese tamaño: se hizo cuadrada.');
                forceSquare = true;
                result = await callOnce(active, { prompt: p.text, aspect, creds, signal: controller.signal, forceSquare });
              } else throw e;
            }
            break;
          } catch (e) {
            if (e.code === 'ABORTED') throw e;
            // Si se acabó el cupo de uno y hay otro configurado (y no se pidió uno concreto), se sigue con el otro.
            if (e.code === 'LIMIT' && !picked.explicit && queueOthers.length) {
              warnings.push(`${nameOf(active)} llegó a su límite: se usó ${nameOf(queueOthers[0])}.`);
              active = queueOthers.shift();
              continue;
            }
            if (images.length) {
              warnings.push(`Se crearon ${images.length} de ${n} imágenes: ${e.message}`);
              result = null;
              break;
            }
            throw e;
          }
        }
        if (!result) break;
        const file = `imagen-${now()}-${i + 1}.${result.kind.ext}`;
        const abs = path.join(outDir, file);
        await fsp.writeFile(abs, result.buf, { mode: 0o600 });
        usedProviderNames.add(nameOf(active));
        bump(active, 1);
        images.push({ path: abs, name: file, size: result.buf.length, mime: result.kind.mime, width: result.size?.width || null, height: result.size?.height || null, provider: active });
      }
    } finally {
      unregister?.();
    }
    const usage = usageOf(active);
    if (usage.perDay) {
      if (usage.used >= usage.perDay) warnings.push(`Hoy llevas ${usage.used} imágenes con ${nameOf(active)}: probablemente ya llegaste a su límite gratis (unas ${usage.perDay} por día). Las próximas pueden ser rechazadas hasta mañana.`);
      else if (usage.used >= Math.floor(usage.perDay * 0.8)) warnings.push(`Hoy llevas ${usage.used} de unas ${usage.perDay} imágenes gratis con ${nameOf(active)}. Quedan pocas.`);
    }
    return { provider: { id: active, name: nameOf(active) }, providers: [...usedProviderNames], images, usage: { ...usage, provider: active }, warnings, aspect };
  }

  // De una en una: así nunca se pasan del límite por minuto del servicio por pedir varias a la vez.
  function generate(req) {
    const run = queue.then(() => generateInner(req));
    queue = run.catch(() => {});
    return run;
  }

  // Borra imágenes de prueba (solo dentro de la carpeta de imágenes generadas).
  async function discard(paths = []) {
    const base = path.resolve(outDir);
    let n = 0;
    for (const p of Array.isArray(paths) ? paths.slice(0, 10) : []) {
      const abs = path.resolve(String(p || ''));
      if (!abs.startsWith(base + path.sep) || !/^imagen-\d+-\d+\.(png|jpg|webp)$/.test(path.basename(abs))) continue;
      try {
        await fsp.rm(abs, { force: true });
        n++;
      } catch {}
    }
    return n;
  }

  return { status, saveCredentials, clearCredentials, setDefault, generate, discard, catalog };
}

// ── IPC ─────────────────────────────────────────────────────────────────────────────────────────
function register({ app, ipcMain, hostMap = null, secrets, registerAbort = null }) {
  const service = createService({
    dir: app.getPath('userData'),
    outDir: path.join(app.getPath('userData'), 'generated'),
    secrets,
    hostMap,
    registerAbort
  });
  const wrap = fn => async (_e, ...args) => {
    try {
      return { ok: true, value: await fn(...args) };
    } catch (e) {
      if (e instanceof ImageError) return { ok: false, error: e.message, code: e.code, resetsAt: e.resetsAt ?? null };
      return { ok: false, error: `No se pudo completar: ${plainText(e?.message || e, 200)}`, code: 'IMAGE_ERROR' };
    }
  };
  ipcMain.handle('auric:images-status', wrap(() => service.status()));
  ipcMain.handle('auric:images-save', wrap((id, fields) => service.saveCredentials(String(id || ''), fields && typeof fields === 'object' ? fields : {})));
  ipcMain.handle('auric:images-clear', wrap(id => service.clearCredentials(String(id || ''))));
  ipcMain.handle('auric:images-default', wrap(id => service.setDefault(String(id || ''))));
  ipcMain.handle(
    'auric:images-generate',
    wrap(req => service.generate(req && typeof req === 'object' ? { provider: req.provider, prompt: req.prompt, aspect: req.aspect, n: req.n, requestId: req.requestId } : {}))
  );
  ipcMain.handle('auric:images-discard', wrap(paths => service.discard(paths)));
  return service;
}

module.exports = { register, createService, ImageError, normalizeAspect, cleanPrompt, sniffImage, decodeBase64Image, explainHttpError, ADAPTERS, ASPECTS, NVIDIA_SIZES, MAX_PROMPT, MAX_PER_CALL, loadCatalog };
