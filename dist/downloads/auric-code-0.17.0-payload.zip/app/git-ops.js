'use strict';
// Las operaciones de Git que Auric sabe hacer. Cada una tiene dos partes:
//   plan(c)   → valida lo que pidió la IA, mira el estado del repositorio y devuelve QUÉ comandos exactos se ejecutarán
//               y qué enseñar a la persona (archivos, commits, avisos). No cambia nada.
//   finish(c) → convierte lo que devolvió Git en un texto claro para la IA y para la persona.
// c = { h, a, ctx }: h = repositorio ya abierto (git-tools.js), a = argumentos de la IA, ctx = permisos y petición explícita.
const fsp = require('fs').promises;
const path = require('path');
const core = require('./git-core');
const { fail } = core;

const LOG_FORMAT = '--format=%H%x00%h%x00%an%x00%ae%x00%ct%x00%s%x00%D%x1e';
const MB = 1024 * 1024;
const LARGE_FILE = 25 * MB;

const take = (arr, n) => ({ items: arr.slice(0, n), more: Math.max(0, arr.length - n) });
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const bool = v => v === true || v === 'true' || v === 1 || v === '1';
const short = sha => String(sha || '').slice(0, 7);
const cut = (text, n) => {
  const s = String(text || '');
  return s.length > n
    ? {
        text: `${s.slice(0, n)}\n… (recortado: había ${s.length - n} caracteres más; pide un archivo concreto con "paths" para ver el resto)`,
        truncated: true
      }
    : { text: s, truncated: false };
};
const fileLine = f => `${statusLetter(f.status)}  ${f.from ? `${f.from} → ` : ''}${f.path}`;
const statusLetter = s => (s === 'U' ? 'U' : s);
const dateOf = iso => (iso ? iso.slice(0, 10) : '');

async function stagedDetails(h) {
  const [raw, num] = await Promise.all([
    h.must(['diff', '--cached', '--raw', '-z', '--no-abbrev', '--find-renames'], { readOnly: true }),
    h.must(['diff', '--cached', '--numstat', '-z', '--find-renames'], { readOnly: true })
  ]);
  const stats = new Map(core.parseNumstat(num.stdout).map(r => [r.path, r]));
  return core.parseRawDiff(raw.stdout).map(r => {
    const s = stats.get(r.path) || {};
    return {
      path: r.path,
      from: r.from,
      status: r.status,
      added: s.added || 0,
      deleted: s.deleted || 0,
      binary: !!s.binary,
      newId: r.newId,
      newMode: r.newMode
    };
  });
}
async function fileSizes(h, files, limit = 200) {
  const out = [];
  for (const f of files.slice(0, limit)) {
    if (f.status === 'D') continue;
    try {
      const st = await fsp.stat(path.join(h.toplevel, ...f.path.split('/')));
      if (st.isFile()) out.push({ path: f.path, size: st.size });
    } catch {}
  }
  return out;
}
function sensitiveWarnings(sensitive, secrets, large) {
  const w = [];
  for (const s of sensitive) w.push({ level: 'danger', text: `«${s.path}» parece un ${s.reason}.` });
  for (const s of secrets) w.push({ level: s.level === 'danger' ? 'danger' : 'warn', text: `En «${s.file}» hay ${s.what}.` });
  for (const l of large)
    w.push({
      level: 'warn',
      text: `«${l.path}» pesa ${(l.size / MB).toFixed(1).replace('.', ',')} MB: los archivos muy grandes no suelen ir en Git.`
    });
  return w;
}

// ── Lecturas ─────────────────────────────────────────────────────────────────────────────────────
function formatStatus(snap, st) {
  const lines = [];
  const b = st.branch;
  const where = b.head ? `Rama: ${b.head}` : `HEAD desacoplado en ${short(b.oid) || '(sin commits)'}`;
  let track = '';
  if (b.upstream) track = b.hasAB ? ` (sigue a ${b.upstream}: ${b.ahead} por subir, ${b.behind} por bajar)` : ` (sigue a ${b.upstream})`;
  else if (b.head) track = ' (sin rama remota asociada)';
  lines.push(where + track);
  if (!b.oid) lines.push('Todavía no hay ningún commit en este repositorio.');
  if (snap.operation) lines.push(`⚠ Hay ${core.OPERATION_TEXT[snap.operation] || snap.operation}.`);
  const sect = (title, rows, fmt) => {
    if (!rows.length) return;
    const t = take(rows, 200);
    lines.push(`${title} (${rows.length}):`);
    for (const r of t.items) lines.push(`  ${fmt(r)}`);
    if (t.more) lines.push(`  … y ${t.more} más`);
  };
  sect('En conflicto', st.conflicts, r => `U  ${r.path}`);
  sect('Preparados para guardar', st.staged, r => fileLine(r));
  sect('Modificados sin preparar', st.unstaged, r => fileLine(r));
  sect('Sin seguimiento', st.untracked, r => `?  ${r}`);
  if (!st.conflicts.length && !st.staged.length && !st.unstaged.length && !st.untracked.length)
    lines.push('No hay cambios: todo está guardado.');
  return lines.join('\n');
}

const OPS = {};

OPS.status = {
  family: 'status',
  async plan() {
    return {
      kind: 'read',
      title: 'Ver el estado',
      summary: 'Mirar qué archivos cambiaron y en qué rama estás.',
      steps: [{ args: ['status', '--porcelain=v2', '--branch', '-z', '--untracked-files=normal'], readOnly: true }]
    };
  },
  async finish({ h }, [r]) {
    const st = core.parseStatusV2(r.stdout);
    const snap = { operation: await h.operationInProgress() };
    return {
      text: formatStatus(snap, st),
      data: {
        branch: st.branch.head,
        upstream: st.branch.upstream,
        ahead: st.branch.ahead,
        behind: st.branch.behind,
        staged: st.staged.length,
        unstaged: st.unstaged.length,
        untracked: st.untracked.length,
        conflicts: st.conflicts.length,
        operation: snap.operation || ''
      }
    };
  }
};

OPS.diff = {
  family: 'diff',
  async plan({ h, a }) {
    const paths = h.paths(a.paths);
    const args = ['diff', '--no-ext-diff', '--no-textconv', '--no-color', '--find-renames'];
    if (bool(a.staged)) args.push('--cached');
    if (bool(a.stat)) args.push('--stat=120');
    if (a.revision) args.push(core.validateRange(a.revision));
    args.push('--', ...h.specs(paths));
    return {
      kind: 'read',
      title: 'Ver los cambios',
      summary: 'Leer las diferencias entre versiones.',
      steps: [{ args, readOnly: true, maxBytes: 8 * MB }]
    };
  },
  async finish(_c, [r]) {
    const { text, truncated } = cut(r.stdout, 60000);
    return {
      text: text.trim() ? text : 'No hay diferencias (los archivos nuevos sin seguimiento no aparecen en el diff: usa status).',
      data: { truncated }
    };
  }
};

OPS.log = {
  family: 'log',
  async plan({ h, a }) {
    const limit = Math.max(1, Math.min(200, Number(a.limit) || 20));
    const args = ['log', `--max-count=${limit}`, '--no-color', '--no-show-signature', LOG_FORMAT];
    if (a.revision) args.push(core.validateRange(a.revision));
    args.push('--', ...h.specs(h.paths(a.paths)));
    return { kind: 'read', title: 'Ver el historial', summary: 'Leer los últimos commits.', steps: [{ args, readOnly: true }] };
  },
  async finish(_c, [r]) {
    const rows = core.parseLog(r.stdout);
    if (!rows.length) return { text: 'No hay commits que mostrar.', data: { commits: [] } };
    return {
      text: rows.map(c => `${c.short} · ${dateOf(c.date)} · ${c.author} · ${c.subject}${c.refs ? ` (${c.refs})` : ''}`).join('\n'),
      data: { commits: rows.map(c => ({ hash: c.hash, short: c.short, author: c.author, date: c.date, subject: c.subject })) }
    };
  }
};

OPS.show = {
  family: 'show',
  async plan({ h, a }) {
    const rev = core.validateRevision(a.revision || 'HEAD');
    const args = [
      'show',
      '--no-ext-diff',
      '--no-textconv',
      '--no-color',
      '--no-show-signature',
      '--format=commit %H%nAutor: %an <%ae>%nFecha: %cI%n%n%B'
    ];
    args.push(bool(a.patch) ? '--patch' : '--stat=120');
    args.push(rev, '--', ...h.specs(h.paths(a.paths)));
    return { kind: 'read', title: 'Ver un commit', summary: `Leer el commit ${rev}.`, steps: [{ args, readOnly: true, maxBytes: 8 * MB }] };
  },
  async finish(_c, [r]) {
    const { text, truncated } = cut(r.stdout, 60000);
    return { text: text.trim() || 'Sin contenido.', data: { truncated } };
  }
};

OPS.branch_list = {
  family: 'branch',
  async plan({ a }) {
    const refs = ['refs/heads'];
    if (bool(a.all)) refs.push('refs/remotes');
    return {
      kind: 'read',
      title: 'Ver las ramas',
      summary: 'Listar las ramas.',
      steps: [
        {
          args: [
            'for-each-ref',
            '--format=%(HEAD)%00%(refname)%00%(refname:short)%00%(objectname:short)%00%(upstream:short)%00%(contents:subject)',
            ...refs
          ],
          readOnly: true
        }
      ]
    };
  },
  async finish(_c, [r]) {
    const rows = r.stdout
      .split('\n')
      .filter(Boolean)
      .map(l => l.split('\0'))
      .filter(f => !/\/HEAD$/.test(f[1] || ''))
      .map(f => ({
        current: f[0] === '*',
        ref: f[1],
        name: f[2],
        sha: f[3],
        upstream: f[4] || '',
        subject: f[5] || '',
        remote: (f[1] || '').startsWith('refs/remotes/')
      }));
    if (!rows.length) return { text: 'No hay ramas todavía (el repositorio no tiene commits).', data: { branches: [] } };
    return {
      text: rows
        .map(
          b =>
            `${b.current ? '*' : ' '} ${b.name}${b.remote ? ' (remota)' : ''}  ${b.sha}${b.upstream ? `  → ${b.upstream}` : ''}  ${b.subject}`
        )
        .join('\n'),
      data: { branches: rows.map(({ current, name, sha, upstream, remote }) => ({ current, name, sha, upstream, remote })) }
    };
  }
};

OPS.remote_list = {
  family: 'remote',
  async plan() {
    return { kind: 'read', title: 'Ver los servidores remotos', summary: 'Listar dónde se sube y baja el código.', steps: [] };
  },
  async finish({ h }) {
    const list = await h.remotes();
    if (!list.length) return { text: 'No hay ningún servidor remoto configurado.', data: { remotes: [] } };
    const lines = list.map(r => {
      const same = r.fetchInfo.display === r.pushInfos[0]?.display && r.pushInfos.length === 1;
      return same
        ? `${r.name}  ${r.fetchInfo.display}`
        : `${r.name}  bajar: ${r.fetchInfo.display}  subir: ${r.pushInfos.map(p => p.display).join(', ')}`;
    });
    return {
      text: lines.join('\n'),
      data: { remotes: list.map(r => ({ name: r.name, fetch: r.fetchInfo.display, push: r.pushInfos.map(p => p.display) })) }
    };
  }
};

// ── Preparar y guardar ───────────────────────────────────────────────────────────────────────────
OPS.init = {
  family: 'init',
  async plan({ h, a }) {
    const branch = a.branch ? core.validateBranchName(a.branch) : '';
    const cfg = branch ? null : await h.git(['config', '--get', 'init.defaultBranch'], { readOnly: true });
    const initial = branch || (cfg && cfg.stdout.trim() ? '' : 'main');
    const args = ['init', '--quiet'];
    if (initial) args.push(`--initial-branch=${initial}`);
    return {
      kind: 'tree',
      title: 'Empezar un repositorio de Git',
      summary: 'Crear la carpeta interna .git en tu proyecto para llevar el historial de cambios.',
      steps: [{ args }],
      effects: ['Se crea una carpeta oculta llamada .git dentro de tu proyecto. No se cambia ni se borra ningún archivo tuyo.'],
      digest: { top: h.toplevel }
    };
  },
  async finish({ h }) {
    return {
      text: `Repositorio de Git creado en ${h.toplevel}. Aún no hay commits: prepara archivos con add y guarda con commit.`,
      data: {}
    };
  }
};

OPS.add = {
  family: 'add',
  async plan({ h, a }) {
    const all = bool(a.all);
    const paths = h.paths(a.paths);
    if (!all && !paths.length)
      throw fail('BAD_ARG', 'Indica qué archivos preparar con "paths", o usa all:true para preparar todos los cambios.');
    const target = all ? ['.'] : paths;
    const dry = await h.git(['add', '--dry-run', '--all', '--', ...h.specs(target)], { readOnly: true });
    const planned = dry.stdout
      .split('\n')
      .map(l => /^(add|remove) '(.*)'$/.exec(l))
      .filter(Boolean)
      .map(m => ({ path: m[2].replace(/'\\''/g, "'"), action: m[1] }));
    if (dry.code !== 0 && !planned.length) throw h.errorFrom(dry);
    if (!planned.length)
      throw fail(
        'NOTHING_TO_ADD',
        'No hay cambios que preparar en esas rutas (ya estaban preparados, no existen o están ignorados por .gitignore).'
      );
    const sensitive = core.detectSensitiveFiles(planned.map(p => p.path));
    const sizes = await fileSizes(
      h,
      planned.filter(p => p.action === 'add').map(p => ({ path: p.path, status: 'A' }))
    );
    const large = sizes.filter(s => s.size > LARGE_FILE);
    // El estado de cada archivo (nuevo / modificado / borrado) sale del estado real del proyecto, no de la simulación.
    const snapNow = await h.snapshot();
    const known = new Map([...snapNow.st.unstaged.map(x => [x.path, x.status]), ...snapNow.st.conflicts.map(x => [x.path, 'U'])]);
    const rowsToShow = planned.map(p => ({ path: p.path, status: p.action === 'remove' ? 'D' : known.get(p.path) || '?' }));
    const shown = take(rowsToShow, 50);
    return {
      kind: 'stage',
      title: 'Preparar archivos para guardar',
      summary: all
        ? 'Preparar todos los cambios nuevos y modificados.'
        : `Preparar ${plural(paths.length, 'ruta', 'rutas')} para el próximo commit.`,
      steps: [{ args: ['add', '--all', '--', ...h.specs(target)] }],
      data: { files: shown.items, more: shown.more, total: planned.length },
      warnings: sensitiveWarnings(sensitive, [], large),
      escalate: sensitive.length > 0 || large.length > 0,
      digest: { paths: target, planned: planned.map(p => p.path) }
    };
  },
  async finish({ h }) {
    const st = core.parseStatusV2(
      (await h.git(['status', '--porcelain=v2', '--branch', '-z', '--untracked-files=no'], { readOnly: true })).stdout
    );
    return { text: `Preparados para guardar: ${st.staged.length} archivo(s).`, data: { staged: st.staged.length } };
  }
};

OPS.unstage = {
  family: 'add',
  async plan({ h, a }) {
    const paths = h.paths(a.paths);
    const snap = await h.snapshot();
    const target = paths.length ? paths : ['.'];
    if (!snap.st.staged.length) throw fail('NOTHING_STAGED', 'No hay nada preparado que quitar.');
    const args = snap.head
      ? ['restore', '--staged', '--', ...h.specs(target)]
      : ['rm', '--cached', '-r', '-q', '-f', '--', ...h.specs(target)];
    return {
      kind: 'stage',
      title: 'Quitar archivos de «preparados»',
      summary: 'Los archivos siguen igual en tu carpeta; solo dejan de estar preparados para el próximo commit.',
      steps: [{ args }],
      data: { files: take(snap.st.staged, 50).items },
      digest: { head: snap.head, paths: target }
    };
  },
  async finish({ h }) {
    const st = core.parseStatusV2(
      (await h.git(['status', '--porcelain=v2', '--branch', '-z', '--untracked-files=no'], { readOnly: true })).stdout
    );
    return { text: `Ahora hay ${st.staged.length} archivo(s) preparado(s).`, data: { staged: st.staged.length } };
  }
};

OPS.commit = {
  family: 'commit',
  needsIdentity: true,
  async plan({ h, a }) {
    const snap = await h.snapshot();
    if (snap.st.conflicts.length)
      throw fail(
        'CONFLICTS',
        `Hay ${plural(snap.st.conflicts.length, 'archivo', 'archivos')} en conflicto sin resolver: ${snap.st.conflicts
          .slice(0, 5)
          .map(c => c.path)
          .join(', ')}. Resuélvelos y prepáralos con add antes de guardar.`
      );
    const merging = snap.operation === 'merge';
    if (snap.operation && !merging)
      throw fail('BUSY', `Hay ${core.OPERATION_TEXT[snap.operation] || snap.operation}. Termínala o cancélala antes de guardar un commit.`);
    if (!snap.st.staged.length && !merging)
      throw fail('NOTHING_STAGED', 'No hay nada preparado para guardar. Prepara los archivos primero con la acción "add".');
    // Un commit de Auric se lee como trabajo de la persona: se quitan las firmas de IA que el modelo haya añadido al mensaje.
    const message = core.validateMessage(core.stripAiAttribution(a.message), { label: 'El mensaje del commit' });
    const files = await stagedDetails(h);
    const diff = await h.git(['diff', '--cached', '--no-ext-diff', '--no-textconv', '--no-color', '-U0'], {
      readOnly: true,
      maxBytes: 6 * MB
    });
    const secrets = core.scanDiffForSecrets(diff.stdout);
    const sensitive = core.detectSensitiveFiles(files.filter(f => f.status !== 'D').map(f => f.path));
    const large = (await fileSizes(h, files)).filter(s => s.size > LARGE_FILE);
    const warnings = sensitiveWarnings(sensitive, secrets, large);
    if (!snap.branch)
      warnings.push({
        level: 'warn',
        text: 'No estás en ninguna rama (HEAD desacoplado): este commit podría perderse si cambias de rama sin crear una nueva.'
      });
    if (merging) warnings.push({ level: 'info', text: 'Esto termina la fusión de ramas que estaba en curso.' });
    const totals = files.reduce((t, f) => ({ added: t.added + f.added, deleted: t.deleted + f.deleted }), { added: 0, deleted: 0 });
    const flagged = new Set(sensitive.map(s => s.path));
    for (const s of secrets) flagged.add(s.file);
    const notStaged = take(
      [...snap.st.unstaged.map(x => ({ path: x.path, status: x.status })), ...snap.st.untracked.map(p => ({ path: p, status: '?' }))],
      30
    );
    return {
      kind: 'commit',
      dialog: 'commit',
      title: 'Guardar los cambios (commit)',
      summary: `Guardar ${plural(files.length, 'archivo', 'archivos')} en la rama ${snap.branch || '(sin rama)'}.`,
      steps: [{ args: ['commit', '-F', '-', '--cleanup=whitespace'], input: `${message}\n` }],
      data: {
        branch: snap.branch,
        message,
        files: take(
          files.map(f => ({
            path: f.path,
            from: f.from,
            status: f.status,
            added: f.added,
            deleted: f.deleted,
            binary: f.binary,
            flagged: flagged.has(f.path)
          })),
          300
        ).items,
        totalFiles: files.length,
        added: totals.added,
        deleted: totals.deleted,
        notStaged: notStaged.items,
        notStagedMore: notStaged.more,
        merging
      },
      warnings,
      needsAck: warnings.some(w => w.level === 'danger')
        ? 'Entiendo los avisos en rojo y quiero guardar estos archivos de todos modos'
        : '',
      escalate: warnings.some(w => w.level === 'danger'),
      digest: { head: snap.head, branch: snap.branch, merging, staged: files.map(f => [f.status, f.path, f.from, f.newId, f.newMode]) }
    };
  },
  applyDecision(plan, decision) {
    if (decision?.message != null) {
      // El mensaje que la persona deja en la ventana también sale sin firmas de IA; si había alguna se avisa al terminar (nunca en silencio).
      const typed = core.validateMessage(decision.message, { label: 'El mensaje del commit' });
      const message = core.validateMessage(core.stripAiAttribution(typed), { label: 'El mensaje del commit' });
      plan.steps[0].input = `${message}\n`;
      plan.data.message = message;
      if (message !== typed.replace(/\n{3,}/g, '\n\n')) plan.data.signatureRemoved = true;
    }
  },
  async finish({ h }, [r], plan) {
    const head = (await h.git(['rev-parse', 'HEAD'], { readOnly: true })).stdout.trim();
    const line = /^\[([^\]]+?) ([0-9a-f]{4,})\]\s*(.*)$/m.exec(r.stdout);
    const stat = /(\d+ files? changed[^\n]*)/.exec(r.stdout);
    return {
      text: `Commit creado: ${short(head)}${line ? ` en ${line[1].replace(/ \(root-commit\)/, '')} — ${line[3]}` : ''}${stat ? `\n${stat[1]}` : ''}${plan?.data?.signatureRemoved ? '\nSe quitó del mensaje una firma de IA: Auric no deja firmas de IA en los commits.' : ''}`,
      data: { commit: head, short: short(head) }
    };
  }
};

// ── Ramas ────────────────────────────────────────────────────────────────────────────────────────
OPS.branch_create = {
  family: 'branch',
  async plan({ h, a }) {
    const name = core.validateBranchName(a.name || a.branch);
    const start = a.from || a.start ? core.validateRevision(a.from || a.start) : '';
    if (await h.refExists(`refs/heads/${name}`)) throw fail('EXISTS', `Ya existe una rama llamada «${name}».`);
    const snap = await h.snapshot();
    if (!snap.head && !start) throw fail('NO_COMMITS', 'No se puede crear una rama todavía: el repositorio no tiene ningún commit.');
    if (start) await h.revSha(start);
    return {
      kind: 'branch',
      title: 'Crear una rama',
      summary: `Crear la rama «${name}»${start ? ` a partir de ${start}` : ' a partir de donde estás'}. No cambia de rama.`,
      steps: [{ args: ['branch', name, ...(start ? [start] : [])] }],
      digest: { head: snap.head, name, start }
    };
  },
  async finish({ a }) {
    return { text: `Rama «${core.validateBranchName(a.name || a.branch)}» creada. Para trabajar en ella usa la acción switch.`, data: {} };
  }
};

OPS.branch_delete = {
  family: 'branch',
  async plan({ h, a }) {
    const name = core.validateBranchName(a.name || a.branch);
    const snap = await h.snapshot();
    if (snap.branch === name) throw fail('CURRENT', 'No se puede borrar la rama en la que estás. Cambia a otra rama primero.');
    if (!(await h.refExists(`refs/heads/${name}`))) throw fail('NO_BRANCH', `La rama «${name}» no existe.`);
    const sha = await h.revSha(`refs/heads/${name}`);
    const force = bool(a.force);
    let unique = [];
    if (snap.head) {
      const u = await h.git(['log', '--max-count=20', '--no-color', LOG_FORMAT, `refs/heads/${name}`, '--not', 'HEAD'], { readOnly: true });
      unique = core.parseLog(u.stdout);
    }
    const warnings = [];
    if (unique.length)
      warnings.push({
        level: force ? 'danger' : 'warn',
        text: `Esta rama tiene ${plural(unique.length, 'commit', 'commits')} que no están en la rama actual${force ? ': se perderían (queda una copia de seguridad)' : ': Git se negará a borrarla si no están fusionados'}.`
      });
    return {
      kind: 'destructive',
      dialog: 'destructive',
      title: force ? 'Borrar una rama (aunque no esté fusionada)' : 'Borrar una rama',
      summary: `Borrar la rama «${name}» (apuntaba a ${short(sha)}).`,
      steps: [{ args: ['branch', force ? '-D' : '-d', name] }],
      data: { name, sha: short(sha), commits: unique.map(c => ({ short: c.short, subject: c.subject })), force },
      warnings,
      backups: [{ kind: 'branch', name, sha }],
      effects: ['Auric guarda una copia de seguridad de dónde apuntaba la rama, para poder recuperarla.'],
      digest: { name, sha, head: snap.head, force }
    };
  },
  async finish({ a }, [r]) {
    return { text: `Rama «${core.validateBranchName(a.name || a.branch)}» borrada. ${r.stdout.trim()}`.trim(), data: {} };
  }
};

OPS.switch = {
  family: 'switch',
  async plan({ h, a }) {
    const name = core.validateBranchName(a.name || a.branch);
    const create = bool(a.create);
    const start = create && (a.from || a.start) ? core.validateRevision(a.from || a.start) : '';
    const snap = await h.snapshot();
    if (!create && snap.branch === name) throw fail('SAME', `Ya estás en la rama «${name}».`);
    const exists = await h.refExists(`refs/heads/${name}`);
    const warnings = [];
    const effects = [];
    let args;
    if (create) {
      if (exists) throw fail('EXISTS', `Ya existe una rama llamada «${name}». Para cambiarte a ella usa switch sin create.`);
      if (!snap.head && !start) throw fail('NO_COMMITS', 'No se puede crear una rama todavía: el repositorio no tiene ningún commit.');
      if (start) await h.revSha(start);
      args = ['switch', '--create', name, ...(start ? [start] : [])];
      effects.push(`Se crea la rama «${name}» y te cambias a ella.`);
    } else {
      let remoteCandidates = [];
      if (!exists) {
        const r = await h.git(['for-each-ref', '--format=%(refname:short)', `refs/remotes/*/${name}`], { readOnly: true });
        remoteCandidates = r.stdout.split('\n').filter(Boolean);
        if (remoteCandidates.length !== 1)
          throw fail(
            'NO_BRANCH',
            remoteCandidates.length
              ? `La rama «${name}» existe en varios servidores: ${remoteCandidates.join(', ')}. Indica cuál usar.`
              : `No existe la rama «${name}». Para crearla usa create:true.`
          );
        effects.push(`Se crea la rama local «${name}» que sigue a ${remoteCandidates[0]}.`);
      }
      args = ['switch', name];
    }
    const dirty = [...snap.st.staged, ...snap.st.unstaged];
    if (dirty.length) {
      const names = [...new Set(dirty.map(d => d.path))];
      warnings.push({
        level: 'info',
        text: `Tienes ${plural(names.length, 'archivo con cambios', 'archivos con cambios')} sin guardar. Si no chocan con la otra rama, viajan contigo; si chocan, Git se detiene sin tocar nada.`
      });
    }
    effects.push('Los archivos de tu carpeta cambian para mostrar la versión de esa rama.');
    return {
      kind: 'tree',
      title: create ? 'Crear una rama y cambiar a ella' : 'Cambiar de rama',
      summary: `Pasar de «${snap.branch || '(sin rama)'}» a «${name}».`,
      steps: [{ args }],
      data: { from: snap.branch, to: name, create, dirty: take([...new Set(dirty.map(d => d.path))], 20).items },
      warnings,
      effects,
      digest: { head: snap.head, branch: snap.branch, name, create, tracked: dirty.map(d => [d.status, d.path]) }
    };
  },
  async finish({ h }) {
    const snap = await h.snapshot(true);
    return {
      text: snap.branch ? `Ahora estás en la rama «${snap.branch}».` : `Ahora estás en ${short(snap.head)} (sin rama).`,
      data: { branch: snap.branch }
    };
  }
};

// ── Guardado temporal (stash) ────────────────────────────────────────────────────────────────────
OPS.stash_list = {
  family: 'stash',
  async plan() {
    return {
      kind: 'read',
      title: 'Ver lo guardado temporalmente',
      summary: 'Listar los guardados temporales.',
      steps: [{ args: ['stash', 'list', '--format=%gd%x00%H%x00%ct%x00%gs'], readOnly: true }]
    };
  },
  async finish(_c, [r]) {
    const rows = r.stdout
      .split('\n')
      .filter(Boolean)
      .map(l => l.split('\0'))
      .map(f => ({ ref: f[0], sha: f[1], date: f[2] ? new Date(Number(f[2]) * 1000).toISOString() : '', subject: f[3] || '' }));
    return {
      text: rows.length ? rows.map(s => `${s.ref}  ${dateOf(s.date)}  ${s.subject}`).join('\n') : 'No hay nada guardado temporalmente.',
      data: { stashes: rows }
    };
  }
};
OPS.stash_show = {
  family: 'stash',
  async plan({ a }) {
    const ref = core.validateStashRef(a.ref);
    return {
      kind: 'read',
      title: 'Ver un guardado temporal',
      summary: `Leer ${ref}.`,
      steps: [{ args: ['stash', 'show', '--patch', '--no-ext-diff', '--no-textconv', '--no-color', ref], readOnly: true, maxBytes: 8 * MB }]
    };
  },
  async finish(_c, [r]) {
    const { text, truncated } = cut(r.stdout, 60000);
    return { text: text.trim() || 'Sin diferencias.', data: { truncated } };
  }
};
OPS.stash_push = {
  family: 'stash',
  needsIdentity: true,
  async plan({ h, a }) {
    const snap = await h.snapshot();
    const untracked = bool(a.includeUntracked ?? a.include_untracked);
    const tracked = [...snap.st.staged, ...snap.st.unstaged];
    if (!snap.head) throw fail('NO_COMMITS', 'No se puede guardar temporalmente todavía: el repositorio no tiene ningún commit.');
    if (!tracked.length && !(untracked && snap.st.untracked.length)) throw fail('NOTHING', 'No hay cambios que guardar temporalmente.');
    const message = a.message
      ? core.validateMessage(String(a.message).split('\n')[0].slice(0, 200), { label: 'El nombre del guardado' })
      : '';
    const seenPaths = new Set();
    const trackedRows = tracked.filter(t => !seenPaths.has(t.path) && seenPaths.add(t.path)).map(t => ({ path: t.path, status: t.status }));
    const untrackedRows = untracked ? snap.st.untracked.map(p => ({ path: p, status: '?' })) : [];
    const shownFiles = take([...trackedRows, ...untrackedRows], 50);
    const args = ['stash', 'push', ...(untracked ? ['--include-untracked'] : []), ...(message ? ['-m', message] : [])];
    return {
      kind: 'tree',
      title: 'Guardar los cambios temporalmente (stash)',
      summary: 'Apartar tus cambios sin hacer commit; la carpeta vuelve a la última versión guardada.',
      steps: [{ args }],
      data: {
        files: shownFiles.items,
        more: shownFiles.more,
        total: trackedRows.length + untrackedRows.length,
        untracked: untracked ? take(snap.st.untracked, 30).items : [],
        message
      },
      effects: [
        'Los archivos modificados vuelven a su última versión guardada; tus cambios quedan apartados y se pueden recuperar con stash apply o pop.',
        ...(untracked
          ? ['También se apartan los archivos nuevos sin seguimiento (desaparecen de la carpeta hasta que los recuperes).']
          : [])
      ],
      digest: { head: snap.head, tracked: tracked.map(t => [t.status, t.path]), untracked: untracked ? snap.st.untracked : null }
    };
  },
  async finish(_c, [r]) {
    return {
      text: /No local changes to save/i.test(r.stdout)
        ? 'No había nada que guardar.'
        : `Cambios guardados temporalmente. ${r.stdout.trim()}`,
      data: {}
    };
  }
};
for (const mode of ['apply', 'pop']) {
  OPS[`stash_${mode}`] = {
    family: 'stash',
    async plan({ h, a }) {
      const ref = core.validateStashRef(a.ref);
      const sha = await h.revSha(ref, 'No existe ese guardado temporal. Mira la lista con stash list.');
      const stat = await h.git(['stash', 'show', '--stat=120', '--no-color', ref], { readOnly: true });
      const snap = await h.snapshot();
      return {
        kind: 'tree',
        title: mode === 'pop' ? 'Recuperar un guardado temporal y borrarlo de la lista' : 'Recuperar un guardado temporal',
        summary: `Volver a poner en tu carpeta los cambios de ${ref}.`,
        steps: [{ args: ['stash', mode, '--quiet', ref] }],
        data: { ref, stat: stat.stdout.trim().slice(0, 4000) },
        effects: ['Los archivos de tu carpeta cambian. Si algo choca, Git deja marcas de conflicto y no borra el guardado.'],
        digest: { ref, sha, head: snap.head, tracked: [...snap.st.staged, ...snap.st.unstaged].map(t => [t.status, t.path]) }
      };
    },
    failureIsResult: r => /CONFLICT|conflict/i.test(`${r.stdout}\n${r.stderr}`),
    async finish({ h }, [r]) {
      const st = core.parseStatusV2(
        (await h.git(['status', '--porcelain=v2', '--branch', '-z', '--untracked-files=no'], { readOnly: true })).stdout
      );
      if (st.conflicts.length)
        return {
          text: `El guardado se aplicó con conflictos en ${st.conflicts.map(c => c.path).join(', ')}. Resuélvelos a mano.`,
          data: { conflicts: st.conflicts.map(c => c.path) }
        };
      return {
        text: `Guardado temporal ${mode === 'pop' ? 'recuperado y quitado de la lista' : 'recuperado (sigue en la lista)'}.`,
        data: {}
      };
    }
  };
}
OPS.stash_drop = {
  family: 'stash',
  async plan({ h, a }) {
    const ref = core.validateStashRef(a.ref);
    const sha = await h.revSha(ref, 'No existe ese guardado temporal. Mira la lista con stash list.');
    const stat = await h.git(['stash', 'show', '--stat=120', '--no-color', ref], { readOnly: true });
    return {
      kind: 'destructive',
      dialog: 'destructive',
      title: 'Borrar un guardado temporal',
      summary: `Borrar ${ref} de la lista de guardados temporales.`,
      steps: [{ args: ['stash', 'drop', '--quiet', ref] }],
      data: { ref, stat: stat.stdout.trim().slice(0, 4000) },
      backups: [{ kind: 'stash', sha }],
      effects: ['Auric guarda una copia de seguridad antes de borrarlo.'],
      digest: { ref, sha }
    };
  },
  async finish() {
    return { text: 'Guardado temporal borrado (queda una copia de seguridad recuperable).', data: {} };
  }
};

// ── Servidor remoto ──────────────────────────────────────────────────────────────────────────────
function remoteWarnings(remote, which = 'push') {
  const infos = which === 'push' ? remote.pushInfos : [remote.fetchInfo];
  const w = [];
  for (const i of infos) {
    if (i.helper)
      throw fail(
        'BLOCKED_REMOTE',
        `El servidor «${remote.name}» usa un protocolo especial (${i.scheme}::) que ejecuta programas. Auric no lo permite.`
      );
    if (i.scheme === 'http' || i.scheme === 'git')
      w.push({
        level: 'warn',
        text: `La dirección ${i.display} no está cifrada (${i.scheme}://): cualquiera en la red podría leer lo que envías.`
      });
    if (i.hadCredentials)
      w.push({
        level: 'warn',
        text: 'La dirección del servidor guarda un usuario o una clave escrita dentro. Auric no la muestra completa.'
      });
    if (i.local) w.push({ level: 'info', text: `El destino es una carpeta de este mismo equipo (${i.display}).` });
  }
  return w;
}

OPS.fetch = {
  family: 'fetch',
  network: true,
  async plan({ h, a }) {
    const snap = await h.snapshot();
    const remote = await h.pickRemote(a.remote, { branch: snap.branch });
    return {
      kind: 'fetch',
      title: 'Traer información del servidor',
      summary: `Mirar qué hay de nuevo en «${remote.name}» (${remote.fetchInfo.display}). No cambia tus archivos ni tus ramas.`,
      steps: [{ args: ['fetch', '--no-recurse-submodules', remote.name], timeoutMs: 300000 }],
      data: { remote: remote.name, url: remote.fetchInfo.display },
      warnings: remoteWarnings(remote, 'fetch'),
      network: true,
      digest: { remote: remote.name, url: remote.fetchUrl }
    };
  },
  async finish({ a }, [r]) {
    const out = core.maskUrls(`${r.stdout}\n${r.stderr}`).trim();
    return { text: out ? `Listo. ${out}` : 'Listo: no había nada nuevo.', data: {} };
  }
};

OPS.pull = {
  family: 'pull',
  network: true,
  needsIdentity: false,
  async plan({ h, a }) {
    const snap = await h.snapshot();
    if (!snap.branch) throw fail('DETACHED', 'No estás en ninguna rama (HEAD desacoplado): no hay a dónde traer los cambios.');
    if (snap.operation)
      throw fail('BUSY', `Hay ${core.OPERATION_TEXT[snap.operation] || snap.operation}. Termínala antes de traer cambios.`);
    const remote = await h.pickRemote(a.remote, { branch: snap.branch });
    let remoteBranch = a.branch ? core.validateBranchName(a.branch) : '';
    if (!remoteBranch) {
      const up = await h.git(['config', '--get', `branch.${snap.branch}.merge`], { readOnly: true });
      remoteBranch = up.stdout.trim().replace(/^refs\/heads\//, '');
      if (!remoteBranch)
        throw fail(
          'NO_UPSTREAM',
          `La rama «${snap.branch}» no tiene una rama remota asociada. Indica "branch" (y "remote") o haz push con setUpstream.`
        );
    }
    const dirty = [...snap.st.staged, ...snap.st.unstaged];
    const warnings = remoteWarnings(remote, 'fetch');
    if (dirty.length)
      warnings.push({
        level: 'info',
        text: `Tienes ${plural(new Set(dirty.map(d => d.path)).size, 'archivo', 'archivos')} con cambios sin guardar. Si los cambios que llegan los tocan, Git se detiene sin tocar nada.`
      });
    return {
      kind: 'tree',
      title: 'Traer los cambios del servidor',
      summary: `Bajar de «${remote.name}/${remoteBranch}» y avanzar tu rama «${snap.branch}» solo si se puede sin mezclar (sin commits de fusión).`,
      steps: [
        {
          args: ['pull', '--ff-only', '--no-rebase', '--no-edit', '--no-recurse-submodules', remote.name, `refs/heads/${remoteBranch}`],
          timeoutMs: 300000
        }
      ],
      data: { remote: remote.name, url: remote.fetchInfo.display, branch: snap.branch, remoteBranch },
      warnings,
      effects: ['Si llegan cambios, los archivos de tu carpeta se actualizan.'],
      network: true,
      digest: {
        head: snap.head,
        branch: snap.branch,
        remote: remote.name,
        url: remote.fetchUrl,
        remoteBranch,
        tracked: dirty.map(d => [d.status, d.path])
      },
      before: snap.head
    };
  },
  async finish({ h }, [r], plan) {
    const after = (await h.git(['rev-parse', 'HEAD'], { readOnly: true })).stdout.trim();
    if (after === plan.before) return { text: 'Ya estabas al día: no llegó nada nuevo.', data: { changed: false } };
    const list = await h.git(['log', '--max-count=20', '--no-color', LOG_FORMAT, `${plan.before}..${after}`], { readOnly: true });
    const commits = core.parseLog(list.stdout);
    return {
      text: `Se trajeron ${plural(commits.length, 'commit', 'commits')}:\n${commits.map(c => `${c.short} ${c.subject}`).join('\n')}`,
      data: { changed: true, commits: commits.map(c => ({ short: c.short, subject: c.subject })) }
    };
  }
};

OPS.merge = {
  family: 'merge',
  needsIdentity: true,
  async plan({ h, a }) {
    const rev = core.validateRevision(a.branch || a.revision || a.name || a.from);
    const snap = await h.snapshot();
    if (!snap.branch) throw fail('DETACHED', 'No estás en ninguna rama: cambia a la rama que quieres actualizar antes de fusionar.');
    if (snap.operation)
      throw fail('BUSY', `Hay ${core.OPERATION_TEXT[snap.operation] || snap.operation}. Termínala antes de fusionar otra rama.`);
    const target = await h.revSha(rev, `No existe «${rev}».`);
    const isAncestor = async (x, y) => (await h.git(['merge-base', '--is-ancestor', x, y], { readOnly: true })).code === 0;
    if (await isAncestor(target, 'HEAD'))
      throw fail('UP_TO_DATE', `«${rev}» ya está incluida en «${snap.branch}»: no hay nada que fusionar.`);
    const noFf = bool(a.noFf ?? a.no_ff);
    const ff = !noFf && (await isAncestor('HEAD', target));
    const counts = (await h.git(['rev-list', '--left-right', '--count', `HEAD...${target}`], { readOnly: true })).stdout
      .trim()
      .split(/\s+/)
      .map(Number);
    const incoming = core.parseLog(
      (await h.git(['log', '--max-count=20', '--no-color', LOG_FORMAT, `HEAD..${target}`], { readOnly: true })).stdout
    );
    const warnings = [];
    let conflicts = null;
    if (!ff) {
      const mt = await h.git(['merge-tree', '--write-tree', '--name-only', '--no-messages', 'HEAD', target], { readOnly: true });
      if (mt.code === 1) {
        const lines = mt.stdout.split('\n').slice(1);
        const end = lines.findIndex(l => l === '');
        conflicts = lines.slice(0, end < 0 ? lines.length : end).filter(Boolean);
        warnings.push({
          level: 'warn',
          text: `Se espera ${plural(conflicts.length, 'conflicto', 'conflictos')} (${take(conflicts, 4).items.join(', ')}${conflicts.length > 4 ? '…' : ''}): tendrás que resolverlos a mano.`
        });
      }
    }
    const dirty = [...snap.st.staged, ...snap.st.unstaged];
    if (dirty.length)
      warnings.push({ level: 'info', text: 'Tienes cambios sin guardar; si la fusión los toca, Git se detiene sin hacer nada.' });
    return {
      kind: 'tree',
      title: 'Fusionar ramas',
      summary: `Traer a «${snap.branch}» los cambios de «${rev}»${ff ? ' (avanza sin crear un commit de fusión)' : ' (crea un commit de fusión)'}.`,
      steps: [{ args: ['merge', '--no-edit', ff ? '--ff' : '--no-ff', target] }],
      data: {
        into: snap.branch,
        from: rev,
        fastForward: ff,
        ahead: counts[0] || 0,
        behind: counts[1] || 0,
        commits: incoming.map(c => ({ short: c.short, subject: c.subject })),
        expectedConflicts: conflicts
      },
      warnings,
      effects: ['Los archivos de tu carpeta cambian para incluir lo de la otra rama.'],
      needsIdentity: !ff,
      digest: { head: snap.head, branch: snap.branch, target, noFf, tracked: dirty.map(d => [d.status, d.path]) },
      before: snap.head
    };
  },
  async finish({ h }, [r], plan) {
    const op = await h.operationInProgress();
    if (r.code !== 0 || op === 'merge') {
      const st = core.parseStatusV2(
        (await h.git(['status', '--porcelain=v2', '--branch', '-z', '--untracked-files=no'], { readOnly: true })).stdout
      );
      const files = st.conflicts.map(c => c.path);
      return {
        text: `La fusión quedó a medias por ${plural(files.length, 'conflicto', 'conflictos')}: ${files.join(', ')}.\nEdita esos archivos, quita las marcas <<<<<<< ======= >>>>>>>, prepáralos con add y termina con commit. Para cancelar todo usa merge con mode:"abort".`,
        data: { conflicts: files, state: 'conflict' }
      };
    }
    const after = (await h.git(['rev-parse', 'HEAD'], { readOnly: true })).stdout.trim();
    return {
      text: `Fusión completada${plan.data.fastForward ? ' (avanzó sin commit de fusión)' : ''}. HEAD ahora es ${short(after)}.`,
      data: { state: 'merged' }
    };
  },
  failureIsResult: (r, text) => /CONFLICT|Automatic merge failed/i.test(`${r.stdout}\n${r.stderr}`)
};
OPS.merge_abort = {
  family: 'merge',
  async plan({ h }) {
    const snap = await h.snapshot();
    if (snap.operation !== 'merge') throw fail('NO_MERGE', 'No hay ninguna fusión en curso que cancelar.');
    return {
      kind: 'destructive',
      dialog: 'destructive',
      title: 'Cancelar la fusión en curso',
      summary: 'Volver al estado de antes de empezar la fusión.',
      steps: [{ args: ['merge', '--abort'] }],
      data: {
        files: take([...snap.st.conflicts.map(c => ({ path: c.path, status: 'U' })), ...snap.st.staged, ...snap.st.unstaged], 50).items
      },
      warnings: [{ level: 'danger', text: 'Se pierden los conflictos que ya hayas resuelto a mano durante esta fusión.' }],
      effects: [
        'Auric no puede hacer una copia de seguridad durante una fusión a medias: si ya resolviste conflictos, guarda una copia de esos archivos antes.'
      ],
      digest: { head: snap.head, conflicts: snap.st.conflicts.map(c => c.path) }
    };
  },
  async finish() {
    return { text: 'Fusión cancelada: la rama volvió al estado de antes.', data: {} };
  }
};

// ── Subir ────────────────────────────────────────────────────────────────────────────────────────
OPS.push = {
  family: 'push',
  network: true,
  async plan({ h, a, ctx }) {
    const snap = await h.snapshot();
    const branch = a.branch ? core.validateBranchName(a.branch) : snap.branch;
    if (!branch) throw fail('DETACHED', 'No estás en ninguna rama (HEAD desacoplado). Cambia a una rama o indica cuál subir con "branch".');
    if (!(await h.refExists(`refs/heads/${branch}`))) throw fail('NO_BRANCH', `La rama «${branch}» no existe en tu copia local.`);
    const remote = await h.pickRemote(a.remote, { branch });
    const warnings = remoteWarnings(remote, 'push');
    const trackRef = `refs/remotes/${remote.name}/${branch}`;
    const hasTrack = await h.refExists(trackRef);
    const tipSha = await h.revSha(`refs/heads/${branch}`);
    let commits;
    if (hasTrack)
      commits = core.parseLog(
        (await h.git(['log', '--max-count=30', '--no-color', LOG_FORMAT, `${trackRef}..refs/heads/${branch}`], { readOnly: true })).stdout
      );
    else
      commits = core.parseLog(
        (
          await h.git(['log', '--max-count=30', '--no-color', LOG_FORMAT, `refs/heads/${branch}`, '--not', `--remotes=${remote.name}`], {
            readOnly: true
          })
        ).stdout
      );
    let total = commits.length;
    if (hasTrack)
      total =
        Number((await h.git(['rev-list', '--count', `${trackRef}..refs/heads/${branch}`], { readOnly: true })).stdout.trim()) ||
        commits.length;
    const behind = hasTrack
      ? Number((await h.git(['rev-list', '--count', `refs/heads/${branch}..${trackRef}`], { readOnly: true })).stdout.trim()) || 0
      : 0;
    const force = bool(a.force);
    const args = ['push'];
    let needsAck = '';
    if (force) {
      if (!ctx?.explicit?.force)
        throw fail(
          'NOT_EXPLICIT',
          'No puedo forzar la subida porque no lo pediste de forma explícita. Pregúntale a la persona si de verdad quiere forzarla y reintenta solo si lo confirma.'
        );
      if (!hasTrack)
        throw fail('NO_LEASE', 'Para forzar con seguridad hace falta saber cómo está la rama en el servidor: haz primero un fetch.');
      const lease = await h.revSha(trackRef);
      args.push(`--force-with-lease=refs/heads/${branch}:${lease}`);
      warnings.push({
        level: 'danger',
        text: `Es una subida FORZADA: reemplaza lo que hay en «${remote.name}/${branch}» y puede borrar el trabajo de otras personas. Solo funciona si nadie subió nada nuevo desde tu último fetch.`
      });
      needsAck = 'Entiendo que esto reemplaza la historia del servidor y puede borrar trabajo de otras personas';
    } else if (behind > 0) {
      warnings.push({
        level: 'warn',
        text: `El servidor tiene ${plural(behind, 'commit', 'commits')} que tú no tienes: lo normal es que Git rechace esta subida. Primero trae los cambios (pull).`
      });
    }
    const setUpstream =
      a.setUpstream === undefined && a.set_upstream === undefined
        ? !snap.upstream && branch === snap.branch
        : bool(a.setUpstream ?? a.set_upstream);
    if (setUpstream) args.push('--set-upstream');
    args.push(remote.name, `refs/heads/${branch}:refs/heads/${branch}`);
    if (!total && hasTrack)
      warnings.push({
        level: 'info',
        text: 'No hay commits nuevos desde lo último que Auric sabe del servidor (puede estar desactualizado).'
      });
    if (!hasTrack)
      warnings.push({
        level: 'info',
        text: `La rama «${branch}» no existe todavía en «${remote.name}» (según lo último que Auric sabe): se creará allí.`
      });
    const gh = githubSlug(remote.pushInfos[0]);
    return {
      kind: 'push',
      dialog: 'push',
      title: force ? 'Subir a la fuerza (puede borrar trabajo)' : 'Subir los cambios al servidor',
      summary: `Enviar «${branch}» a «${remote.name}» (${remote.pushInfos.map(p => p.display).join(', ')}).`,
      steps: [{ args, timeoutMs: 300000 }],
      data: {
        remote: remote.name,
        urls: remote.pushInfos.map(p => p.display),
        host: remote.pushInfos[0]?.host || '',
        branch,
        force,
        newBranch: !hasTrack,
        commits: commits.map(c => ({ short: c.short, subject: c.subject, author: c.author, date: c.date })),
        totalCommits: total,
        behind,
        setUpstream,
        github: gh
      },
      warnings,
      needsAck,
      effects: ['Esto envía tu trabajo fuera de este equipo. Una vez subido, otras personas pueden verlo.'],
      network: true,
      digest: {
        tip: tipSha,
        branch,
        remote: remote.name,
        urls: remote.pushUrls,
        track: hasTrack ? await h.revSha(trackRef) : '',
        force,
        setUpstream
      }
    };
  },
  async finish({ a }, [r], plan) {
    const out = core.maskUrls(`${r.stdout}\n${r.stderr}`);
    const pr = /(https?:\/\/\S+\/pull\/new\/\S+|https?:\/\/\S+\/-\/merge_requests\/new\S*)/.exec(out);
    const gh = plan.data.github;
    const hint = pr ? pr[1] : gh ? `https://github.com/${gh.owner}/${gh.repo}/pull/new/${plan.data.branch}` : '';
    return {
      text: `Subida completada: «${plan.data.branch}» → «${plan.data.remote}»${plan.data.totalCommits ? ` (${plural(plan.data.totalCommits, 'commit', 'commits')})` : ''}.${hint ? `\nPara abrir una solicitud de cambios (Pull Request): ${hint}` : ''}`,
      data: { pushed: true, prUrl: hint }
    };
  }
};
function githubSlug(info) {
  if (!info || info.host !== 'github.com') return null;
  const m = /^([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+?)(?:\.git)?\/?$/.exec(info.path || '');
  return m ? { owner: m[1], repo: m[2] } : null;
}

// ── Destructivo (con copia de seguridad) ─────────────────────────────────────────────────────────
OPS.discard = {
  family: 'discard',
  async plan({ h, a }) {
    const paths = h.paths(a.paths);
    if (!paths.length) throw fail('BAD_ARG', 'Indica qué archivos descartar con "paths" (por ejemplo ["src/app.js"]).');
    const num = await h.must(['diff', '--numstat', '-z', '--', ...h.specs(paths)], { readOnly: true });
    const rows = core.parseNumstat(num.stdout);
    if (!rows.length) throw fail('NOTHING', 'Esos archivos no tienen cambios sin preparar que descartar.');
    const snap = await h.snapshot();
    const lost = rows.reduce((t, r) => ({ added: t.added + r.added, deleted: t.deleted + r.deleted }), { added: 0, deleted: 0 });
    const raw = await h.must(['diff', '--raw', '-z', '--no-abbrev', '--', ...h.specs(paths)], { readOnly: true });
    const rawRows = core.parseRawDiff(raw.stdout);
    const statusOf = new Map(rawRows.map(r => [r.path, r.status]));
    const shownRows = take(
      rows.map(r => ({ path: r.path, status: statusOf.get(r.path) || 'M', added: r.added, deleted: r.deleted, binary: r.binary })),
      100
    );
    return {
      kind: 'destructive',
      dialog: 'destructive',
      title: 'Descartar cambios de archivos',
      summary: `Los archivos vuelven a su última versión guardada: se pierden ${plural(rows.length, 'archivo modificado', 'archivos modificados')} sin guardar.`,
      steps: [{ args: ['restore', '--worktree', '--', ...h.specs(paths)] }],
      data: { files: shownRows.items, more: shownRows.more, total: rows.length, added: lost.added, deleted: lost.deleted },
      warnings: [{ level: 'danger', text: 'Los cambios que hiciste en estos archivos desaparecerán de tu carpeta.' }],
      backups: [{ kind: 'changes' }],
      effects: [
        'Auric guarda una copia de seguridad de tus cambios (dentro de .git) antes de descartarlos.',
        'Los archivos nuevos sin seguimiento no se tocan.'
      ],
      digest: { head: snap.head, paths, raw: rawRows.map(r => [r.path, r.status, r.newId]) }
    };
  },
  async finish() {
    return { text: 'Cambios descartados. Queda una copia de seguridad recuperable con backups restore.', data: {} };
  }
};

OPS.reset = {
  family: 'reset',
  async plan({ h, a, ctx }) {
    const mode = String(a.mode || a.resetMode || a.reset_mode || 'mixed').toLowerCase();
    if (!['soft', 'mixed', 'hard'].includes(mode)) throw fail('BAD_ARG', 'El modo de reset debe ser soft, mixed o hard.');
    const snap = await h.snapshot();
    if (!snap.head) throw fail('NO_COMMITS', 'Todavía no hay commits a los que volver.');
    const rev = core.validateRevision(a.revision || (mode === 'hard' ? 'HEAD' : 'HEAD~1'));
    const target = await h.revSha(rev, `No existe «${rev}».`);
    const hard = mode === 'hard';
    if (hard && !ctx?.explicit?.hard)
      throw fail(
        'NOT_EXPLICIT',
        'No puedo borrar cambios con un reset duro porque no lo pediste de forma explícita. Pregúntale a la persona y reintenta solo si lo confirma.'
      );
    if (snap.operation && hard)
      throw fail('BUSY', `Hay ${core.OPERATION_TEXT[snap.operation] || snap.operation}; cancélala antes de un reset duro.`);
    const dropped = core.parseLog(
      (await h.git(['log', '--max-count=20', '--no-color', LOG_FORMAT, `${target}..HEAD`], { readOnly: true })).stdout
    );
    const droppedTotal = Number((await h.git(['rev-list', '--count', `${target}..HEAD`], { readOnly: true })).stdout.trim()) || 0;
    const warnings = [];
    if (droppedTotal) {
      if (snap.upstream) {
        const pushed = Number((await h.git(['rev-list', '--count', `${target}..${snap.upstream}`], { readOnly: true })).stdout.trim()) || 0;
        if (pushed)
          warnings.push({
            level: 'warn',
            text: `${plural(Math.min(pushed, droppedTotal), 'de esos commits ya está', 'de esos commits ya están')} en el servidor: para que el servidor lo refleje habría que forzar la subida.`
          });
      }
    }
    const lostFiles = hard ? [...snap.st.staged, ...snap.st.unstaged] : [];
    if (hard && lostFiles.length)
      warnings.push({
        level: 'danger',
        text: `Se perderán los cambios sin guardar de ${plural(new Set(lostFiles.map(f => f.path)).size, 'archivo', 'archivos')}.`
      });
    if (hard && droppedTotal)
      warnings.push({
        level: 'danger',
        text: `La rama «${snap.branch || 'actual'}» perderá ${plural(droppedTotal, 'commit', 'commits')} (quedan en una copia de seguridad).`
      });
    const effects = {
      soft: ['La rama retrocede, pero tus archivos y lo que tenías preparado se quedan exactamente igual.'],
      mixed: ['La rama retrocede y lo preparado vuelve a «sin preparar»; tus archivos se quedan igual.'],
      hard: ['La rama retrocede y TUS ARCHIVOS vuelven a esa versión: los cambios sin guardar se pierden.']
    }[mode];
    return {
      kind: hard ? 'destructive' : 'tree',
      dialog: hard ? 'destructive' : 'generic',
      title: hard
        ? 'Volver atrás y descartar cambios (reset duro)'
        : mode === 'soft'
          ? 'Deshacer commits (conservando todo)'
          : 'Deshacer commits (conservando los archivos)',
      summary: `Mover «${snap.branch || 'HEAD'}» de ${short(snap.head)} a ${short(target)} (${rev}).`,
      steps: [{ args: ['reset', `--${mode}`, '--quiet', target] }],
      data: {
        mode,
        from: short(snap.head),
        to: short(target),
        rev,
        dropped: dropped.map(c => ({ short: c.short, subject: c.subject })),
        droppedTotal,
        files: take(
          lostFiles.map(f => ({ path: f.path, status: f.status })),
          50
        ).items
      },
      warnings,
      effects: [...effects, ...(hard ? ['Auric guarda una copia de seguridad de los commits y de los cambios antes de hacerlo.'] : [])],
      backups: hard ? [{ kind: 'head', sha: snap.head }, { kind: 'changes' }] : [],
      digest: { head: snap.head, target, mode, tracked: [...snap.st.staged, ...snap.st.unstaged].map(t => [t.status, t.path]) }
    };
  },
  async finish({ h }) {
    const snap = await h.snapshot(true);
    return { text: `Listo: la rama está ahora en ${short(snap.head)}.`, data: { head: snap.head } };
  }
};

// ── Copias de seguridad hechas por Auric ─────────────────────────────────────────────────────────
async function listBackups(h) {
  const r = await h.git(['for-each-ref', '--format=%(refname)%00%(objectname)%00%(creatordate:unix)', 'refs/auric/backup'], {
    readOnly: true
  });
  return r.stdout
    .split('\n')
    .filter(Boolean)
    .map(l => l.split('\0'))
    .map(([ref, sha, ct]) => {
      const m = /^refs\/auric\/backup\/([^/]+)\/(changes|head|branch|stash)(?:\/(.+))?$/.exec(ref || '');
      return m ? { ref, sha, id: m[1], kind: m[2], name: m[3] || '', date: ct ? new Date(Number(ct) * 1000).toISOString() : '' } : null;
    })
    .filter(Boolean)
    .sort((a, b) => (a.id < b.id ? 1 : -1));
}
OPS.backups_list = {
  family: 'backup',
  async plan() {
    return {
      kind: 'read',
      title: 'Ver las copias de seguridad',
      summary: 'Listar las copias de seguridad que Auric guardó antes de acciones destructivas.',
      steps: []
    };
  },
  async finish({ h }) {
    const list = await listBackups(h);
    const KIND = { changes: 'cambios sin guardar', head: 'commits de la rama', branch: 'rama borrada', stash: 'guardado temporal borrado' };
    return {
      text: list.length
        ? list.map(b => `${b.id} · ${KIND[b.kind]}${b.name ? ` «${b.name}»` : ''} · ${short(b.sha)}`).join('\n')
        : 'No hay copias de seguridad.',
      data: { backups: list.map(b => ({ id: b.id, kind: b.kind, name: b.name, sha: short(b.sha), date: b.date })) }
    };
  }
};
OPS.backups_restore = {
  family: 'backup',
  async plan({ h, a }) {
    const id = String(a.id || a.backup || '').trim();
    const kind = String(a.kind || '').trim();
    if (!/^[0-9A-Za-z-]{6,40}$/.test(id)) throw fail('BAD_ARG', 'Indica el "id" de la copia (mira la lista con backups list).');
    const all = (await listBackups(h)).filter(b => b.id === id && (!kind || b.kind === kind));
    if (!all.length) throw fail('NO_BACKUP', `No existe una copia con id ${id}.`);
    if (all.length > 1) throw fail('AMBIGUOUS', `Esa copia tiene varias partes (${all.map(b => b.kind).join(', ')}). Indica "kind".`);
    const b = all[0];
    const snap = await h.snapshot();
    let args, summary, effects;
    if (b.kind === 'changes' || b.kind === 'stash') {
      args = ['stash', 'apply', '--quiet', b.sha];
      summary = 'Volver a poner en tu carpeta los cambios que Auric guardó.';
      effects = ['Los archivos de tu carpeta cambian. Si algo choca, Git deja marcas de conflicto.'];
    } else if (b.kind === 'branch') {
      const name = core.validateBranchName(b.name);
      if (await h.refExists(`refs/heads/${name}`)) throw fail('EXISTS', `Ya existe una rama «${name}»; no se puede recrear encima.`);
      args = ['branch', name, b.sha];
      summary = `Volver a crear la rama «${name}» tal como estaba.`;
      effects = [];
    } else {
      const name = `auric-rescate-${b.id}`.slice(0, 80);
      args = ['branch', name, b.sha];
      summary = `Crear la rama «${name}» con los commits que había antes del reset.`;
      effects = [];
    }
    return {
      kind: 'tree',
      title: 'Restaurar una copia de seguridad',
      summary,
      steps: [{ args }],
      data: { id: b.id, kind: b.kind, name: b.name, sha: short(b.sha) },
      effects,
      digest: {
        id: b.id,
        kind: b.kind,
        sha: b.sha,
        head: snap.head,
        tracked: [...snap.st.staged, ...snap.st.unstaged].map(t => [t.status, t.path])
      }
    };
  },
  async finish() {
    return { text: 'Copia restaurada.', data: {} };
  }
};

// ── Nombre de la acción → operación ──────────────────────────────────────────────────────────────
const SUBMODES = {
  branch: { list: 'branch_list', create: 'branch_create', delete: 'branch_delete', default: 'branch_list' },
  stash: {
    push: 'stash_push',
    save: 'stash_push',
    list: 'stash_list',
    show: 'stash_show',
    apply: 'stash_apply',
    pop: 'stash_pop',
    drop: 'stash_drop',
    default: 'stash_push'
  },
  merge: { merge: 'merge', abort: 'merge_abort', default: 'merge' },
  backups: { list: 'backups_list', restore: 'backups_restore', default: 'backups_list' },
  remote: { list: 'remote_list', default: 'remote_list' }
};
function resolveOperation(spec = {}) {
  let action = String(spec.action || '')
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, '_');
  if (action === 'checkout') action = 'switch';
  if (action === 'backup') action = 'backups';
  if (action === 'remotes') action = 'remote';
  const mode = String(spec.mode || '')
    .trim()
    .toLowerCase();
  const table = SUBMODES[action];
  // Las acciones con varios modos (branch, stash, merge…) se resuelven por su "mode"; «merge» también es una operación en sí misma.
  if (table) {
    const op = table[mode || 'default'];
    if (!op)
      throw fail(
        'BAD_ARG',
        `Para «${action}» el "mode" debe ser uno de: ${Object.keys(table)
          .filter(k => k !== 'default')
          .join(', ')}.`
      );
    return op;
  }
  if (OPS[action]) return action;
  throw fail(
    'BAD_ARG',
    `Acción de Git desconocida: «${String(spec.action || '').slice(0, 40)}». Las disponibles: status, diff, log, show, branch, switch, add, unstage, discard, commit, stash, fetch, pull, merge, push, remote, reset, init, backups.`
  );
}

const READ_OPS = new Set(['status', 'diff', 'log', 'show', 'branch_list', 'remote_list', 'stash_list', 'stash_show', 'backups_list']);

module.exports = { OPS, READ_OPS, resolveOperation, listBackups, LOG_FORMAT, githubSlug, formatStatus };
