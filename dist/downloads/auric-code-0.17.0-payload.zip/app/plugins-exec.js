'use strict';
// Cómo se lanza el servidor MCP de un plugin. Parte PURA (sin lanzar nada) para poder probarla en cualquier sistema.
//  · Entorno mínimo: el programa NO hereda todas las variables de tu PC (claves de otros programas, etc.). Solo las básicas para
//    funcionar más las que el plugin declaró y tú aceptaste.
//  · En Windows, los programas .cmd/.bat (npx.cmd, por ejemplo) solo se pueden lanzar a través de cmd.exe: aquí se citan los
//    argumentos de forma segura y se RECHAZAN los que traen símbolos de consola, para que un argumento no pueda ejecutar otra cosa.
const core = require('./plugins-core');

const RESERVED = new Set(['PLUGIN_DIR', 'PLUGIN_DATA', 'WORKSPACE', 'AURIC_NODE']);
const BASE_WIN = ['APPDATA', 'COMSPEC', 'HOMEDRIVE', 'HOMEPATH', 'LOCALAPPDATA', 'NUMBER_OF_PROCESSORS', 'OS', 'PATH', 'PATHEXT', 'PROCESSOR_ARCHITECTURE', 'PROGRAMDATA', 'PROGRAMFILES', 'PROGRAMFILES(X86)', 'PROGRAMW6432', 'PUBLIC', 'SYSTEMDRIVE', 'SYSTEMROOT', 'TEMP', 'TMP', 'USERNAME', 'USERPROFILE', 'WINDIR', 'ALLUSERSPROFILE', 'LANG'];
const BASE_POSIX = ['PATH', 'HOME', 'LOGNAME', 'USER', 'SHELL', 'TERM', 'TMPDIR', 'LANG', 'LC_ALL', 'LC_CTYPE', 'TZ'];
const PROXY = ['HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'ALL_PROXY', 'NODE_EXTRA_CA_CERTS', 'SSL_CERT_FILE'];
// Variables que nunca se entregan, ni aunque el plugin las pida.
const NEVER = /^(AURIC_|ELECTRON_|NODE_OPTIONS$|NODE_PATH$|LD_PRELOAD$|LD_LIBRARY_PATH$|DYLD_|PYTHONSTARTUP$|PYTHONPATH$|PYTHONHOME$|RUBYOPT$|PERL5OPT$|JAVA_TOOL_OPTIONS$|_JAVA_OPTIONS$|BASH_ENV$|ENV$)/i;

function baseEnv(src, platform = process.platform) {
  const win = platform === 'win32';
  const allow = new Set((win ? BASE_WIN : BASE_POSIX).concat(win ? [] : ['LC_MESSAGES']));
  const out = {};
  for (const [k, v] of Object.entries(src || {})) {
    if (typeof v !== 'string') continue;
    const key = win ? k.toUpperCase() : k;
    const isProxy = PROXY.some(p => p.toLowerCase() === k.toLowerCase());
    if (isProxy) {
      // Las direcciones de proxy con usuario:clave no se entregan.
      if (/@/.test(v)) continue;
      out[k] = v;
    } else if (allow.has(key) || (!win && /^LC_/.test(k))) out[k] = v;
  }
  return out;
}

// Reemplaza ${NOMBRE} por el valor guardado o de tu entorno, SOLO si el plugin lo declaró. Lo demás queda vacío.
function expandRefs(text, { declared = new Set(), lookup = () => undefined } = {}) {
  const used = [];
  const out = String(text).replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g, (all, name) => {
    if (RESERVED.has(name)) return all;
    if (NEVER.test(name) || !declared.has(name)) return '';
    const v = lookup(name);
    if (typeof v === 'string' && !/[\u0000\r\n]/.test(v)) {
      used.push(name);
      return v;
    }
    return '';
  });
  return { text: out, used };
}

const CMD_FORBIDDEN = /["%^!&|<>\r\n\u0000]/;
const quoteCmd = s => (s === '' || /[\s()]/.test(s) ? `"${s}"` : s);

/**
 * Plan de ejecución. `command` ya viene resuelto (ruta completa o nombre). Devuelve { file, args, verbatim } para child_process.spawn.
 * En Windows, un .cmd/.bat se ejecuta con cmd.exe /d /s /c "…" y verbatim; si algún argumento trae símbolos de consola se rechaza.
 */
function planSpawn({ command, args = [], platform = process.platform, comspec = 'cmd.exe' }) {
  const cmd = String(command || '');
  if (!cmd) throw new core.PluginError('El servidor no tiene comando.', 'PLUGIN_BAD_COMMAND');
  if (platform !== 'win32' || !/\.(cmd|bat)$/i.test(cmd)) return { file: cmd, args: args.map(String), verbatim: false };
  const all = [cmd, ...args.map(String)];
  const bad = all.find(a => CMD_FORBIDDEN.test(a));
  if (bad !== undefined)
    throw new core.PluginError(
      `Auric no ejecuta este servidor: «${String(bad).slice(0, 60)}» contiene símbolos de consola de Windows (" % ^ ! & | < >) y se lanzaría a través de cmd.exe, donde podrían ejecutar otra cosa.`,
      'PLUGIN_UNSAFE_ARG'
    );
  return { file: comspec, args: ['/d', '/s', '/c', `"${all.map(quoteCmd).join(' ')}"`], verbatim: true };
}

// `where npx` en Windows devuelve varias líneas (a veces la primera es el archivo sin extensión, que no se puede ejecutar).
function pickWindowsCommand(lines) {
  const list = (Array.isArray(lines) ? lines : String(lines || '').split(/\r?\n/)).map(l => l.trim()).filter(Boolean);
  const rank = ext => ['.exe', '.com', '.cmd', '.bat'].indexOf(ext);
  let best = '';
  let bestRank = 99;
  for (const l of list) {
    const m = /\.(exe|com|cmd|bat)$/i.exec(l);
    if (!m) continue;
    const r = rank(`.${m[1].toLowerCase()}`);
    if (r < bestRank) {
      best = l;
      bestRank = r;
    }
  }
  return best;
}

module.exports = { RESERVED, NEVER, baseEnv, expandRefs, planSpawn, pickWindowsCommand, quoteCmd, CMD_FORBIDDEN };
