﻿param([Parameter(Mandatory=$true)][string]$Payload)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
try {
  Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,WindowsBase,System.Windows.Forms,System.Drawing
  Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Collections.Generic;
public static class AuricWindowBridge {
  public delegate bool EnumProc(IntPtr hwnd, IntPtr extra);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc callback, IntPtr extra);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hwnd);
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hwnd);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hwnd);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int count);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint first, uint second, bool attach);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hwnd);
  [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
  [DllImport("user32.dll")] public static extern IntPtr GetWindowLongPtrW(IntPtr hwnd, int index);
  [DllImport("user32.dll")] public static extern int GetWindowLongW(IntPtr hwnd, int index);
  public static bool PasswordStyle(IntPtr hwnd) { if(hwnd==IntPtr.Zero)return false; long style=IntPtr.Size==8?GetWindowLongPtrW(hwnd,-16).ToInt64():GetWindowLongW(hwnd,-16); return (style & 32)!=0; }
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; public POINT(int x,int y) { X=x; Y=y; } }
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hwnd, out RECT rect);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hwnd);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT point);
  [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr hwnd, uint flag);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint x, uint y, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern void keybd_event(byte key, byte scan, uint flags, UIntPtr extra);
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx,dy; public uint data,flags,time; public UIntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort vk,scan; public uint flags,time; public UIntPtr extra; }
  [StructLayout(LayoutKind.Explicit)] public struct UNION { [FieldOffset(0)] public MOUSEINPUT mouse; [FieldOffset(0)] public KEYBDINPUT key; }
  [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public UNION value; }
  [DllImport("user32.dll", SetLastError=true)] public static extern uint SendInput(uint count, INPUT[] data, int size);
  public static long[] Windows() { var result=new List<long>(); EnumWindows((hwnd,extra)=>{if(IsWindowVisible(hwnd)) result.Add(hwnd.ToInt64()); return true;},IntPtr.Zero);return result.ToArray(); }
  public static uint Pid(IntPtr hwnd) { uint pid; GetWindowThreadProcessId(hwnd,out pid); return pid; }
  public static bool Focus(IntPtr hwnd) {
    uint ignored; uint current=GetCurrentThreadId(), foreground=GetWindowThreadProcessId(GetForegroundWindow(),out ignored);
    bool attached=foreground!=0 && foreground!=current && AttachThreadInput(current,foreground,true);
    try { BringWindowToTop(hwnd); SetForegroundWindow(hwnd); return GetForegroundWindow()==hwnd; }
    finally { if(attached) AttachThreadInput(current,foreground,false); }
  }
  public static string Title(IntPtr hwnd) { var text=new StringBuilder(1024);GetWindowText(hwnd,text,text.Capacity);return text.ToString(); }
  public static void Text(string text) { foreach(char c in text) { var inputs=new INPUT[2]; inputs[0].type=1;inputs[0].value.key.scan=c;inputs[0].value.key.flags=4;inputs[1]=inputs[0];inputs[1].value.key.flags=6; if(SendInput(2,inputs,Marshal.SizeOf(typeof(INPUT)))!=2) throw new Exception("Windows no permitió escribir en esa ventana."); } }
}
'@
  [void][AuricWindowBridge]::SetThreadDpiAwarenessContext([IntPtr](-4))
  $request = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Payload)) | ConvertFrom-Json
  function Window-Info([long]$handle) {
    $window = [IntPtr]$handle
    if (-not [AuricWindowBridge]::IsWindow($window)) { throw 'La ventana ya no existe.' }
    $processIdValue = [AuricWindowBridge]::Pid($window)
    $processValue = Get-Process -Id $processIdValue -ErrorAction Stop
    $rectangle = New-Object AuricWindowBridge+RECT
    [void][AuricWindowBridge]::GetWindowRect($window,[ref]$rectangle)
    $executable = ''; try { $executable = $processValue.Path } catch {}
    return @{ id=[string]$handle; pid=[int]$processIdValue; title=[AuricWindowBridge]::Title($window); process=$processValue.ProcessName; executable=$executable; left=$rectangle.Left; top=$rectangle.Top; width=($rectangle.Right-$rectangle.Left); height=($rectangle.Bottom-$rectangle.Top); minimized=[AuricWindowBridge]::IsIconic($window) }
  }
  function Sensitive-Field($element) {
    if (-not $element) { return $true }
    $current=$element.Current
    if ($current.IsPassword -or $current.Name -match 'password|contrase[nñ]a|api.?key|token|card.?number|security.?code') { return $true }
    if ($current.ControlType -eq [System.Windows.Automation.ControlType]::Edit -or $current.ClassName -match 'edit') {
      return [AuricWindowBridge]::PasswordStyle([IntPtr]$current.NativeWindowHandle)
    }
    return $false
  }
  if ($request.op -eq 'probe') { $value = @{ ready=$true; inputSize=[Runtime.InteropServices.Marshal]::SizeOf([type][AuricWindowBridge+INPUT]) } }
  elseif ($request.op -eq 'list') {
    $windows = @(); foreach ($handle in [AuricWindowBridge]::Windows()) { try { $info=Window-Info $handle; if ($info.title -and $info.width -gt 50 -and $info.height -gt 50) { $windows += $info } } catch {} }
    $value = @{ windows=$windows }
  } else {
    if ([string]$request.id -notmatch '^\d{1,20}$') { throw 'Ventana no válida.' }
    $info = Window-Info ([long]$request.id)
    if ([int]$request.pid -ne $info.pid) { throw 'La ventana cambió de proceso. Conéctala de nuevo.' }
    $window = [IntPtr]([long]$request.id)
    $value = $info
    if ($request.op -ne 'info') {
      if ($info.minimized) { throw 'La ventana está minimizada. Restáurala antes de continuar.' }
      if ($request.op -eq 'inspect') {
        if (-not [AuricWindowBridge]::Focus($window)) { throw 'No se pudo activar la ventana. Abrela y vuelve a intentarlo.' }
        Start-Sleep -Milliseconds 100
        if ($request.kind -eq 'click') {
          $point = New-Object System.Windows.Point ($info.left + [int]$request.x),($info.top + [int]$request.y)
          $element = [System.Windows.Automation.AutomationElement]::FromPoint($point)
        } else {
          $element = [System.Windows.Automation.AutomationElement]::FocusedElement
        }
        if (-not $element -or $element.Current.ProcessId -ne $info.pid) { throw 'No se pudo comprobar el elemento de esta ventana.' }
        $ancestorNames=@(); $parentElement=$element
        for($depth=0;$depth -lt 5;$depth++){ try{$parentElement=[System.Windows.Automation.TreeWalker]::ControlViewWalker.GetParent($parentElement);if(-not $parentElement){break};$ancestorNames+=$parentElement.Current.Name}catch{break} }
        $value = @{ window=$info; name=$element.Current.Name; type=$element.Current.ControlType.ProgrammaticName; className=$element.Current.ClassName; ancestors=($ancestorNames -join ' / '); password=(Sensitive-Field $element) }
      } elseif ($request.op -in @('click','type','press')) {
        [void][AuricWindowBridge]::Focus($window)
        Start-Sleep -Milliseconds 100
        if ([AuricWindowBridge]::GetForegroundWindow() -ne $window) { throw 'La ventana no tiene el foco. No se envió ninguna entrada.' }
        if ($request.op -eq 'click') {
          $x=$info.left+[int]$request.x; $y=$info.top+[int]$request.y
          if ([AuricWindowBridge]::GetAncestor([AuricWindowBridge]::WindowFromPoint((New-Object AuricWindowBridge+POINT $x,$y)),2) -ne $window) { throw 'Otra ventana está delante del punto. No se hizo clic.' }
          $target=[System.Windows.Automation.AutomationElement]::FromPoint((New-Object System.Windows.Point $x,$y))
          if (-not $target -or $target.Current.ProcessId -ne $info.pid -or (Sensitive-Field $target)) { throw 'No se actúa en campos de credenciales ni en elementos sin comprobar.' }
          [void][AuricWindowBridge]::SetCursorPos($x,$y)
          [AuricWindowBridge]::mouse_event(2,0,0,0,[UIntPtr]::Zero); [AuricWindowBridge]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
        } else {
          $focused = [System.Windows.Automation.AutomationElement]::FocusedElement
          if (-not $focused -or $focused.Current.ProcessId -ne $info.pid -or (Sensitive-Field $focused)) { throw 'No se escribe en contraseñas ni en campos sin comprobar.' }
          if ($request.op -eq 'type') { [AuricWindowBridge]::Text([string]$request.text) }
          else {
            $names=@{Enter=13;Return=13;Tab=9;Escape=27;Backspace=8;Delete=46;ArrowLeft=37;ArrowUp=38;ArrowRight=39;ArrowDown=40;Home=36;End=35;PageUp=33;PageDown=34;Space=32}
            $parts=([string]$request.key).Split('+'); $keyName=$parts[-1]; $modifiers=@()
            foreach($part in $parts[0..([Math]::Max(0,$parts.Length-2))]) { if($parts.Length -eq 1){break}; if($part -eq 'Ctrl'){$modifiers+=17}elseif($part -eq 'Shift'){$modifiers+=16}elseif($part -eq 'Alt'){$modifiers+=18}else{throw 'Modificador no permitido.'} }
            if($names.ContainsKey($keyName)){$virtual=$names[$keyName]}elseif($keyName -match '^[A-Z0-9]$'){$virtual=[int][char]$keyName}else{throw 'Tecla no permitida.'}
            foreach($modifier in $modifiers){[AuricWindowBridge]::keybd_event($modifier,0,0,[UIntPtr]::Zero)}
            [AuricWindowBridge]::keybd_event($virtual,0,0,[UIntPtr]::Zero);[AuricWindowBridge]::keybd_event($virtual,0,2,[UIntPtr]::Zero)
            [Array]::Reverse($modifiers);foreach($modifier in $modifiers){[AuricWindowBridge]::keybd_event($modifier,0,2,[UIntPtr]::Zero)}
          }
        }
        $value = @{ performed=$true; window=$info }
      } else { throw 'Acción desconocida.' }
    }
  }
  @{ok=$true;value=$value} | ConvertTo-Json -Depth 8 -Compress | Write-Output
} catch { @{ok=$false;error=$_.Exception.Message} | ConvertTo-Json -Depth 3 -Compress | Write-Output }
