'use strict';
const fs = require('fs');
const path = require('path');
const safe = require('./net-safe');
const { RELAY_ORIGIN, withRelaySignature } = require('./relay-sign');
const DAY = 86400000;
const AA_URL = 'https://artificialanalysis.ai/api/v2/language/models/free';
const CATALOG_URL = 'https://models.dev/api.json';
const CENTRAL_URL = RELAY_ORIGIN + '/v1/model-intelligence';
const clean = value => String(value ?? '').replace(/[\x00-\x1f]/g, '').slice(0, 240);
const number = value => value != null && value !== '' && Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : null;

function aaRows(body) {
  if (!Array.isArray(body?.data) || body.data.length > 5000) throw new Error('Artificial Analysis devolvió un catálogo no válido.');
  return body.data.map(row => ({
    id: clean(row.id), name: clean(row.name), slug: clean(row.slug), creator: clean(row.model_creator?.name),
    released: clean(row.release_date), version: number(body.intelligence_index_version),
    index: number(row.evaluations?.artificial_analysis_intelligence_index),
    coding: number(row.evaluations?.artificial_analysis_coding_index),
    agentic: number(row.evaluations?.artificial_analysis_agentic_index),
    speed: number(row.performance?.median_output_tokens_per_second ?? row.median_output_tokens_per_second),
    latency: number(row.performance?.median_time_to_first_token_seconds ?? row.median_time_to_first_token_seconds)
  })).filter(row => row.id && row.slug && row.name);
}
function catalogRows(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error('El catálogo público no tiene el formato esperado.');
  const result = [];
  for (const [provider, record] of Object.entries(body)) {
    for (const [id, model] of Object.entries(record?.models || {})) {
      if (result.length >= 30000) break;
      result.push({ provider: clean(provider), id: clean(id), name: clean(model.name || id),
        context: number(model.limit?.context), output: number(model.limit?.output),
        tools: model.tool_call === true, vision: model.modalities?.input?.includes('image') === true,
        inputPrice: number(model.cost?.input), outputPrice: number(model.cost?.output), released: clean(model.release_date),
        updated: clean(model.last_updated) });
    }
  }
  if (!result.length) throw new Error('El catálogo público está vacío; se conserva la copia anterior.');
  return result;
}
class ModelIntelligence {
  constructor({ dir, secrets, hostMap, request } = {}) {
    this.dir = dir; this.secrets = secrets; this.hostMap = hostMap;
    this.request = request || this.getJson.bind(this); this.pending = null;
    this.data = { version: 1, benchmarks: [], catalog: [], observed: {}, enabled: true, updatedAt: null, aaUpdatedAt: null };
    try { Object.assign(this.data, JSON.parse(fs.readFileSync(path.join(dir, 'model-intelligence.json'), 'utf8'))); } catch {}
    this.data.benchmarks = Array.isArray(this.data.benchmarks) ? this.data.benchmarks : [];
    this.data.catalog = Array.isArray(this.data.catalog) ? this.data.catalog : [];
    this.data.observed = this.data.observed && typeof this.data.observed === 'object' && !Array.isArray(this.data.observed) ? this.data.observed : {};
  }
  save() {
    fs.mkdirSync(this.dir, { recursive: true });
    const target = path.join(this.dir, 'model-intelligence.json');
    const tmp = target + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(this.data)); fs.renameSync(tmp, target);
  }
  status() { return { ...this.data, aaConfigured: this.data.centralConfigured === true || !!this.secrets?.get('benchmark:aa'), attribution: 'Artificial Analysis · models.dev', aaUrl: 'https://artificialanalysis.ai/', catalogUrl: 'https://models.dev/' }; }
  configure({ key, enabled } = {}) {
    if (typeof enabled === 'boolean') this.data.enabled = enabled;
    if (key != null) {
      if (typeof key !== 'string' || key.length > 600 || /[\r\n]/.test(key)) throw new Error('La clave no es válida.');
      this.secrets.set('benchmark:aa', key.trim());
      this.data.aaUpdatedAt = null;
    }
    this.save(); return this.status();
  }
  async getJson(url, headers = {}) {
    if (url === CENTRAL_URL) headers = withRelaySignature(url, 'GET', headers);
    const hop = await safe.openSafe(url, { headers: { Accept: 'application/json', ...headers }, maxRedirects: 0, hostMap: this.hostMap, timeoutMs: 20000 });
    const { buffer, truncated } = await safe.readLimited(safe.decodedStream(hop.res), 32 * 1024 * 1024);
    if (hop.res.statusCode !== 200) throw new Error(`La fuente respondió HTTP ${hop.res.statusCode}.`);
    if (truncated) throw new Error('El catálogo excede el tamaño permitido.');
    return JSON.parse(buffer.toString('utf8'));
  }
  async refresh(force = false) {
    if (!this.data.enabled) return this.status();
    if (this.pending) return this.pending;
    if (!force && this.data.lastAttempt && Date.now() - Date.parse(this.data.lastAttempt) < 3600000) return this.status();
    this.pending = this.refreshSources(force).finally(() => this.pending = null);
    return this.pending;
  }
  async refreshSources(force) {
    const errors = [];
    const due = date => force || !date || Date.now() - Date.parse(date) >= DAY;
    if (due(this.data.updatedAt)) {
      try { this.data.catalog = catalogRows(await this.request(CATALOG_URL)); this.data.updatedAt = new Date().toISOString(); }
      catch (error) { const secret = this.secrets?.get('benchmark:aa'); errors.push({ source: 'models.dev', message: (secret ? String(error.message).split(secret).join('***') : String(error.message)).slice(0, 300) }); }
    }
    const key = this.secrets?.get('benchmark:aa');
    if (!key && due(this.data.aaUpdatedAt)) {
      try {
        const body = await this.request(CENTRAL_URL);
        if (!body || typeof body.configured !== 'boolean' || !Array.isArray(body.benchmarks) || body.benchmarks.length > 10000) throw new Error('El servicio de puntuaciones todavía no está actualizado.');
        this.data.centralConfigured = body.configured;
        this.data.centralCode = clean(body.code || '');
        if (body.benchmarks.length && body.fetchedAt && Number.isFinite(Date.parse(body.fetchedAt))) {
          const rows = body.benchmarks.map(row => ({ id: clean(row.id), name: clean(row.name), slug: clean(row.slug), creator: clean(row.creator), released: clean(row.released), version: number(row.version), index: number(row.index), coding: number(row.coding), agentic: number(row.agentic), speed: number(row.speed), latency: number(row.latency) })).filter(row => row.id && row.name && row.slug);
          if (rows.length) { this.data.benchmarks = rows; this.data.indexVersion = number(body.indexVersion); this.data.aaUpdatedAt = body.fetchedAt; }
        }
        if (body.stale) errors.push({ source: 'Artificial Analysis', message: 'La fuente no se pudo renovar; se conserva la última copia disponible.' });
      } catch { errors.push({ source: 'Artificial Analysis', message: 'Puntuaciones centrales temporalmente no disponibles. Se conserva la copia guardada.' }); }
    }
    if (key && due(this.data.aaUpdatedAt)) {
      try {
        let page = 1, rows = [], version = null;
        do {
          const body = await this.request(AA_URL + '?page=' + page, { 'x-api-key': key });
          rows.push(...aaRows(body)); version = number(body.intelligence_index_version);
          if (!body.pagination?.has_more) break;
          if (++page > 15) throw new Error('Artificial Analysis devolvió demasiadas páginas.');
        } while (true);
        if (!rows.length) throw new Error('Artificial Analysis no devolvió modelos; se conserva la copia anterior.');
        this.data.benchmarks = rows; this.data.indexVersion = version; this.data.aaUpdatedAt = new Date().toISOString();
      } catch (error) { errors.push({ source: 'Artificial Analysis', message: String(error.message).split(key).join('***').slice(0, 300) }); }
    }
    this.data.errors = errors; this.data.lastAttempt = new Date().toISOString(); this.save();
    return this.status();
  }
  observe({ provider, model, elapsedMs, outputTokens, error, rateLimits } = {}) {
    const key = clean(provider) + '::' + clean(model);
    if (!provider || !model || !/^[\w.:-]+$/.test(String(provider))) return this.status();
    if (!Object.hasOwn(this.data.observed, key) && Object.keys(this.data.observed).length >= 1000) return this.status();
    const old = Object.hasOwn(this.data.observed, key) ? this.data.observed[key] : {};
    const ms = number(elapsedMs), tokens = number(outputTokens);
    const sample = ms > 0 && tokens > 0 ? tokens / (ms / 1000) : null;
    this.data.observed[key] = { samples: Math.min(100000, (old.samples || 0) + 1),
      successes: (old.successes || 0) + (!error ? 1 : 0), failures: (old.failures || 0) + (error ? 1 : 0),
      speed: sample != null ? (old.speed == null ? sample : old.speed * .75 + sample * .25) : old.speed ?? null,
      // Las respuestas de error del proveedor pueden repetir claves o contenido
      // privado. Para las estadísticas basta registrar que la llamada falló.
      elapsedMs: ms, lastError: error ? 'La solicitud no terminó correctamente.' : '', at: new Date().toISOString(),
      rateLimits: rateLimits && typeof rateLimits === 'object' ? Object.fromEntries(Object.entries(rateLimits).filter(([name]) => /^(limit|remaining|reset)(Requests|Tokens)$/.test(name)).map(([name, value]) => [name, number(value)])) : old.rateLimits || {} };
    this.save(); return { key, sample: this.data.observed[key] };
  }
}
function register({ app, ipcMain, secrets, hostMap }) {
  const manager = new ModelIntelligence({ dir: app.getPath('userData'), secrets, hostMap });
  for (const [op, fn] of Object.entries({ status: () => manager.status(), refresh: force => process.env.AURIC_E2E === '1' && process.env.AURIC_E2E_INTELLIGENCE !== '1' ? manager.status() : manager.refresh(force === true), configure: spec => manager.configure(spec), observe: sample => manager.observe(sample) }))
    ipcMain.handle('auric:model-intelligence-' + op, async (_event, ...args) => { try { return { ok: true, value: await fn(...args) }; } catch (error) { return { ok: false, error: String(error.message) }; } });
  return manager;
}
module.exports = { register, ModelIntelligence, aaRows, catalogRows, AA_URL, CATALOG_URL, CENTRAL_URL };
