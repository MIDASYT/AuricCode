'use strict';
// Sesiones de juego de Godot controlables por el agente (juego en segundo plano, controlado por el agente).
// - El juego corre completo con un arnés (resources/godot/auric_harness.gd) que lee comandos de un archivo.
// - Los datos del juego (user://) van a un perfil aislado: el progreso real del usuario no se toca.
// - La ventana se abre fuera de pantalla y sin foco; el audio queda audible salvo que se pida silencio.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { spawn } = require('child_process');
const { randomUUID } = require('crypto');

const HARNESS_SOURCE = path.join(__dirname, 'resources', 'godot', 'auric_harness.gd');
const OFFSCREEN = '20000,20000';

// Defensa en profundidad: eval/call/set ya exigen permiso de ejecución en la app, y además se rechazan las expresiones que
// intentan salir del juego (procesos, archivos, red, singletons del motor, llamadas por nombre).
const FORBIDDEN_CODE =
  /\b(OS|Engine|ClassDB|JavaClassWrapper|GDScript|GDExtension\w*|DirAccess|FileAccess|ResourceSaver|ResourceLoader|HTTPClient|HTTPRequest|TCPServer|UDPServer|StreamPeer\w*|PacketPeer\w*|WebSocketPeer|WebRTC\w*|Thread|Mutex|ProjectSettings|IP|Marshalls)\b|\b(execute|shell_open|create_process|set_script|source_code|get_singleton|kill|crash|call|callv|call_deferred|callable|bind|connect|load|preload|instantiate)\b/i;
function assertSafeGodotCode(cmd = {}) {
  if (!['eval', 'call', 'set'].includes(String(cmd.cmd))) return;
  for (const k of ['expr', 'method', 'prop']) {
    const v = cmd[k];
    if (typeof v === 'string' && FORBIDDEN_CODE.test(v)) throw new Error(`Expresión no permitida en ${k}: toca el sistema, archivos, red o llamadas por nombre.`);
  }
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

function isolatedEnv(base, profileRoot) {
  const roaming = path.join(profileRoot, 'AppData', 'Roaming'),
    local = path.join(profileRoot, 'AppData', 'Local');
  return {
    dirs: [roaming, local, path.join(profileRoot, 'xdg', 'data'), path.join(profileRoot, 'xdg', 'config'), path.join(profileRoot, 'xdg', 'cache')],
    env: {
      ...base,
      APPDATA: roaming,
      LOCALAPPDATA: local,
      XDG_DATA_HOME: path.join(profileRoot, 'xdg', 'data'),
      XDG_CONFIG_HOME: path.join(profileRoot, 'xdg', 'config'),
      XDG_CACHE_HOME: path.join(profileRoot, 'xdg', 'cache'),
      AURIC_TEST_PROFILE: profileRoot
    }
  };
}

function buildArgs(spec, sessionDir, harnessPath) {
  const args = ['--path', spec.cwd];
  const headless = spec.headless === true;
  if (headless) args.push('--headless');
  else {
    const w = Math.max(320, Math.min(3840, Number(spec.width) || 960)),
      h = Math.max(240, Math.min(2160, Number(spec.height) || 540));
    args.push('--windowed', '--resolution', `${w}x${h}`);
    if (spec.background !== false) args.push('--position', OFFSCREEN);
  }
  if (Array.isArray(spec.extraArgs)) args.push(...spec.extraArgs.map(String));
  args.push('--script', harnessPath, '--', `--auric-dir=${sessionDir}`);
  if (spec.scene) args.push(`--auric-scene=${String(spec.scene)}`);
  const live = Number(spec.liveMs === undefined ? 600 : spec.liveMs);
  if (!headless && live > 0) args.push(`--auric-live=${Math.max(200, Math.round(live))}`);
  if (spec.mute) args.push('--auric-mute');
  if (!headless && spec.background !== false) args.push('--auric-background');
  args.push(`--auric-idle=${Math.max(0, Math.round(Number(spec.idleSeconds === undefined ? 900 : spec.idleSeconds)))}`);
  return args;
}

async function writeAtomic(file, text) {
  const tmp = `${file}.${process.pid}.t`;
  await fsp.writeFile(tmp, text, 'utf8');
  await fsp.rename(tmp, file);
}

class GodotSessionManager {
  /**
   * @param {{userDataDir:string, processes:Map, killTree:(proc)=>void, harnessSource?:string, onBeforeSpawn?:Function}} o
   */
  constructor(o) {
    this.userDataDir = o.userDataDir;
    this.processes = o.processes || new Map();
    this.killTree = o.killTree;
    this.harnessSource = o.harnessSource || HARNESS_SOURCE;
    this.sessions = new Map();
  }

  async pruneOld(maxAgeMs = 24 * 3600 * 1000) {
    const root = path.join(this.userDataDir, 'test-profiles');
    let names = [];
    try {
      names = await fsp.readdir(root);
    } catch {
      return;
    }
    for (const n of names) {
      if (this.sessions.has(n)) continue;
      try {
        const st = await fsp.stat(path.join(root, n));
        if (Date.now() - st.mtimeMs > maxAgeMs) await fsp.rm(path.join(root, n), { recursive: true, force: true });
      } catch {}
    }
  }

  async start(spec) {
    if (!spec.executable) throw new Error('No se encontró Godot. Añádelo al PATH o indica el ejecutable.');
    if (!spec.cwd || !fs.existsSync(path.join(spec.cwd, 'project.godot'))) throw new Error('La carpeta no contiene project.godot.');
    const id = randomUUID(),
      profileRoot = path.join(this.userDataDir, 'test-profiles', id),
      sessionDir = path.join(profileRoot, 'session'),
      harnessPath = path.join(sessionDir, 'auric_harness.gd');
    await fsp.mkdir(sessionDir, { recursive: true });
    await fsp.copyFile(this.harnessSource, harnessPath);
    let env = { ...process.env };
    const isolate = spec.isolateUserData !== false;
    if (isolate) {
      const iso = isolatedEnv(process.env, profileRoot);
      for (const d of iso.dirs) await fsp.mkdir(d, { recursive: true });
      env = iso.env;
    }
    const args = buildArgs(spec, sessionDir, harnessPath);
    const proc = spawn(spec.executable, args, {
      cwd: spec.cwd,
      env,
      windowsHide: spec.headless === true,
      detached: process.platform !== 'win32',
      stdio: ['ignore', 'pipe', 'pipe']
    });
    const info = {
      id,
      label: String(spec.label || 'Godot sesión de juego'),
      kind: 'godot-session',
      mode: spec.headless ? 'headless' : 'game',
      command: spec.executable,
      args,
      cwd: spec.cwd,
      pid: proc.pid,
      startedAt: new Date().toISOString(),
      status: 'running',
      out: '',
      err: '',
      profileRoot: isolate ? profileRoot : '',
      isolateUserData: isolate
    };
    this.processes.set(id, { proc, info });
    const s = { id, proc, info, sessionDir, profileRoot, queue: Promise.resolve(), seq: 0, exited: false, spec };
    this.sessions.set(id, s);
    proc.stdout.on('data', d => {
      info.out = (info.out + d.toString()).slice(-160000);
      info.lastOutAt = new Date().toISOString();
    });
    proc.stderr.on('data', d => {
      info.err = (info.err + d.toString()).slice(-100000);
      info.lastErrAt = new Date().toISOString();
    });
    proc.on('close', code => {
      s.exited = true;
      info.status = info.status === 'stopped' ? 'stopped' : 'exited';
      info.exitCode = code;
      info.closedAt = new Date().toISOString();
    });
    proc.on('error', err => {
      s.exited = true;
      info.status = 'error';
      info.err = (info.err + '\n' + String(err?.message || err || '')).trim().slice(-100000);
    });
    // Espera a que el arnés confirme que la escena principal cargó.
    const readyFile = path.join(sessionDir, 'ready.json'),
      deadline = Date.now() + Math.max(8000, Number(spec.startTimeoutMs) || 45000);
    while (Date.now() < deadline) {
      if (s.exited) {
        await this.stop(id, { keepProfile: false }).catch(() => {});
        throw new Error(`Godot se cerró al iniciar (código ${info.exitCode}).\n${(info.err || info.out).slice(-1800)}`);
      }
      try {
        const ready = JSON.parse(await fsp.readFile(readyFile, 'utf8'));
        if (ready.ok === false) {
          await this.stop(id).catch(() => {});
          throw new Error(ready.error || 'El juego no pudo iniciar.');
        }
        return { ...info, ready };
      } catch (e) {
        if (e && e.message && !/ENOENT|JSON/i.test(e.message)) throw e;
      }
      await sleep(120);
    }
    await this.stop(id).catch(() => {});
    throw new Error(`Godot no cargó la escena a tiempo.\n${(info.err || info.out).slice(-1800)}`);
  }

  get(id) {
    const s = this.sessions.get(id);
    if (!s) throw new Error('Sesión de Godot no encontrada (¿ya se cerró?). Inicia una con godot_session_start.');
    return s;
  }

  async command(id, cmd, opts = {}) {
    const s = this.get(id);
    assertSafeGodotCode(cmd);
    const run = async () => {
      if (s.exited) throw new Error(`El juego ya terminó (código ${s.info.exitCode}).\n${(s.info.err || s.info.out).slice(-1200)}`);
      const rid = `${Date.now()}-${++s.seq}`,
        payload = { ...cmd, id: rid },
        waitMs = Number(cmd.ms) || 0,
        timeout = opts.timeoutMs || Math.max(20000, waitMs + 15000);
      await writeAtomic(path.join(s.sessionDir, 'cmd.json'), JSON.stringify(payload));
      const resFile = path.join(s.sessionDir, `res-${rid}.json`),
        deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        try {
          const txt = await fsp.readFile(resFile, 'utf8');
          fsp.unlink(resFile).catch(() => {});
          const res = JSON.parse(txt);
          if (res.file) {
            const png = path.join(s.sessionDir, res.file);
            try {
              res.png = (await fsp.readFile(png)).toString('base64');
              fsp.unlink(png).catch(() => {});
            } catch {}
          }
          if (cmd.cmd === 'quit') s.info.status = 'stopped';
          return res;
        } catch (e) {
          if (e && e.code && e.code !== 'ENOENT') throw e;
        }
        if (s.exited) throw new Error(`El juego se cerró durante el comando (código ${s.info.exitCode}).\n${(s.info.err || s.info.out).slice(-1200)}`);
        await sleep(35);
      }
      throw new Error('El juego no respondió al comando a tiempo (¿está congelado o en un bucle infinito?).');
    };
    const p = s.queue.then(run, run);
    s.queue = p.catch(() => {});
    return p;
  }

  /** Último fotograma en vivo (PNG base64) para el panel Preview, o null. */
  async frame(id, sinceMs = 0) {
    const s = this.sessions.get(id);
    if (!s) return null;
    const f = path.join(s.sessionDir, 'live.png');
    try {
      const st = await fsp.stat(f);
      if (st.mtimeMs <= sinceMs) return { at: st.mtimeMs, same: true };
      return { at: st.mtimeMs, png: (await fsp.readFile(f)).toString('base64'), exited: s.exited };
    } catch {
      return s.exited ? { at: 0, exited: true } : null;
    }
  }

  async stop(id, { keepProfile = false } = {}) {
    const s = this.sessions.get(id);
    if (!s) return false;
    s.info.status = s.exited ? s.info.status : 'stopped';
    if (!s.exited) {
      try {
        await Promise.race([this.command(id, { cmd: 'quit' }, { timeoutMs: 1500 }), sleep(1600)]);
      } catch {}
      if (!s.exited) await sleep(150);
      if (!s.exited) this.killTree(s.proc);
    }
    this.sessions.delete(id);
    if (!keepProfile) {
      // El proceso puede tardar un instante en soltar los archivos.
      setTimeout(() => fsp.rm(s.profileRoot, { recursive: true, force: true }).catch(() => {}), 1500).unref?.();
    }
    return true;
  }

  stopAll() {
    for (const s of this.sessions.values()) if (!s.exited) this.killTree(s.proc);
    this.sessions.clear();
  }
}

module.exports = { GodotSessionManager, assertSafeGodotCode, buildArgs, isolatedEnv, HARNESS_SOURCE, OFFSCREEN };
