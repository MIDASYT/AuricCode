// Mi PC: cliente de Ollama (estado, modelos, descarga con progreso, chat con streaming) y comprobación del catálogo.
// Solo habla con Ollama en ESTE equipo (127.0.0.1) y, para comprobar la lista de modelos, con el registro oficial por https.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawn } = require('node:child_process');
const netSafe = require('./net-safe');
const models = require('./local-models');
const hardware = require('./hardware');

const DEFAULT_HOST = 'http://127.0.0.1:11434';
const REGISTRY = 'https://registry.ollama.ai';
const MANIFEST_ACCEPT = 'application/vnd.docker.distribution.manifest.v2+json';

class LocalAIError extends Error {
  constructor(code, message, extra = {}) {
    super(message);
    this.name = 'LocalAIError';
    this.code = code;
    Object.assign(this, extra);
  }
}

// Solo se acepta Ollama en este mismo equipo.
function parseHost(raw) {
  const text = String(raw || DEFAULT_HOST).trim() || DEFAULT_HOST;
  let u;
  try {
    u = new URL(/^https?:\/\//i.test(text) ? text : `http://${text}`);
  } catch {
    throw new LocalAIError('BAD_HOST', 'La dirección de Ollama no es válida.');
  }
  const host = u.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (!['127.0.0.1', 'localhost', '::1'].includes(host) || u.username || u.password)
    throw new LocalAIError('BAD_HOST', 'Mi PC solo usa Ollama de este mismo equipo (127.0.0.1).');
  if (u.protocol !== 'http:') throw new LocalAIError('BAD_HOST', 'Ollama local se usa con http://127.0.0.1.');
  return `http://${host.includes(':') ? `[${host}]` : host}:${u.port || '11434'}`;
}

function parseParamsB(text) {
  const m = String(text || '').match(/([\d.]+)\s*([KMBT])/i);
  if (!m) return 0;
  const n = Number(m[1]);
  const mult = { K: 1e-6, M: 1e-3, B: 1, T: 1000 }[m[2].toUpperCase()];
  return Number.isFinite(n) ? n * mult : 0;
}

// ── Traducción de errores de Ollama a mensajes claros ───────────────────────────────────────────
function errorFromOllama(status, bodyText, ctx = {}) {
  let detail = String(bodyText || '').trim();
  try {
    const j = JSON.parse(detail);
    if (j && typeof j === 'object') detail = String(j.error || j.message || detail);
  } catch {}
  const model = ctx.model || 'el modelo';
  const technical = detail ? `\n\nDetalle técnico: ${detail.slice(0, 400)}` : '';
  if (
    /requires more (system )?memory|out of memory|unable to allocate|memory layout|cudamalloc|not enough memory|insufficient memory|failed to allocate/i.test(
      detail
    )
  )
    return new LocalAIError(
      'NO_MEMORY',
      `Tu PC no tiene memoria libre suficiente para «${model}»${ctx.numCtx ? ` con un contexto de ${ctx.numCtx}` : ''}. Cierra otros programas, elige un modelo más pequeño o baja el contexto en Ajustes → Proveedores → Mi PC.${technical}`,
      { status, detail }
    );
  if (/does not support tools/i.test(detail))
    return new LocalAIError('NO_TOOLS', `«${model}» no admite herramientas. Se usará como chat normal.${technical}`, { status, detail });
  if (/does not support thinking|think value/i.test(detail))
    return new LocalAIError('NO_THINKING', `«${model}» no admite el modo de razonamiento.${technical}`, { status, detail });
  if (status === 404 || /not found|try pulling it first|no such model/i.test(detail))
    return new LocalAIError(
      'MODEL_NOT_FOUND',
      `El modelo «${model}» no está descargado en tu PC. Ve a Ajustes → Proveedores → Mi PC y pulsa «Descargar».${technical}`,
      { status, detail }
    );
  if (/no space left|disk full|not enough space|insufficient disk/i.test(detail))
    return new LocalAIError(
      'DISK_FULL',
      `No queda espacio en el disco para guardar el modelo. Libera espacio o borra modelos que no uses.${technical}`,
      { status, detail }
    );
  if (status === 429 || status === 503 || /server busy|too many (concurrent )?requests|queue is full/i.test(detail))
    return new LocalAIError('BUSY', 'Ollama está ocupado con otra petición. Espera unos segundos y vuelve a intentarlo.' + technical, {
      status,
      detail
    });
  if (/runner process (has terminated|no longer running)|exit status|0xc0000/i.test(detail))
    return new LocalAIError(
      'SERVER',
      `El motor del modelo se cerró de forma inesperada. Suele pasar por falta de memoria o por un controlador de la tarjeta gráfica; prueba con un modelo más pequeño o actualiza Ollama.${technical}`,
      { status, detail }
    );
  if (status === 400) return new LocalAIError('BAD_REQUEST', `Ollama rechazó la petición.${technical}`, { status, detail });
  return new LocalAIError('SERVER', `Ollama respondió con un error${status ? ` (${status})` : ''}.${technical}`, { status, detail });
}

function offError(err) {
  const code = err?.cause?.code || err?.code || '';
  if (
    ['ECONNREFUSED', 'ECONNRESET', 'EHOSTUNREACH', 'UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_SOCKET'].includes(code) ||
    /fetch failed|ECONNREFUSED/i.test(String(err?.message || ''))
  )
    return new LocalAIError('OFF', 'Ollama está apagado. Ve a Ajustes → Proveedores → Mi PC y pulsa «Iniciar Ollama».', { cause: err });
  return null;
}

// Convierte los mensajes de Auric (ya aplanados por la interfaz) al formato nativo de Ollama.
function convertMessages(messages = []) {
  const out = [];
  for (const m of Array.isArray(messages) ? messages : []) {
    const role = ['system', 'user', 'assistant', 'tool'].includes(m?.role) ? m.role : 'user';
    const item = { role, content: String(m?.content ?? '') };
    if (role === 'tool') {
      if (m.name) item.tool_name = String(m.name);
    } else if (role === 'user' && Array.isArray(m.images) && m.images.length) {
      item.images = m.images.filter(x => typeof x === 'string' && x).slice(0, 8);
    } else if (role === 'assistant') {
      if (m.reasoning) item.thinking = String(m.reasoning);
      if (Array.isArray(m.toolCalls) && m.toolCalls.length)
        item.tool_calls = m.toolCalls.map(c => ({
          function: { name: String(c.tool || c.name || ''), arguments: c.args && typeof c.args === 'object' ? c.args : {} }
        }));
    }
    out.push(item);
  }
  return out;
}

function convertTools(tools = []) {
  return (Array.isArray(tools) ? tools : [])
    .map(t =>
      t?.type === 'function' && t.function
        ? t
        : t?.name
          ? {
              type: 'function',
              function: { name: t.name, description: t.description || '', parameters: t.parameters || { type: 'object', properties: {} } }
            }
          : null
    )
    .filter(Boolean);
}

function thinkParam(level, info) {
  const lv = String(level ?? 'auto').toLowerCase();
  if (!info?.thinking || lv === 'auto' || lv === '') return undefined;
  const gptOss = /gpt-oss/i.test(info.name || '');
  if (['none', 'off', 'false'].includes(lv)) return gptOss ? 'low' : false;
  if (['low', 'medium', 'high'].includes(lv)) return gptOss ? lv : true;
  if (['minimal'].includes(lv)) return gptOss ? 'low' : true;
  return gptOss ? 'medium' : true;
}

async function* ndjsonLines(res, { idleMs = 120000, firstMs = 600000, onTimeout } = {}) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buf = '';
  let first = true;
  let timer = null;
  const arm = () => {
    clearTimeout(timer);
    timer = setTimeout(() => onTimeout?.(), first ? firstMs : idleMs);
  };
  try {
    arm();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      first = false;
      arm();
      buf += decoder.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (line) yield line;
      }
      if (buf.length > 8 * 1024 * 1024) throw new LocalAIError('SERVER', 'Ollama devolvió una línea demasiado larga.');
    }
    buf += decoder.decode();
    if (buf.trim()) yield buf.trim();
  } finally {
    clearTimeout(timer);
    try {
      reader.releaseLock();
    } catch {}
  }
}

function createLocalAI(deps = {}) {
  const host = parseHost(deps.host);
  const doFetch = deps.fetch || globalThis.fetch;
  const getHardware = deps.getHardware || (() => hardware.detectHardware({ modelsDir: deps.modelsDir }));
  const exeCandidates = deps.exeCandidates || defaultExeCandidates;
  const spawnFn = deps.spawn || spawn;
  const registryHost = deps.registry || REGISTRY;
  const showCache = new Map();
  const pulls = new Map();
  const chats = new Map();
  let hwCache = null;

  async function hw(force = false) {
    if (!hwCache || force || Date.now() - hwCache.at > 120000) hwCache = { at: Date.now(), value: await getHardware() };
    return hwCache.value;
  }

  // El límite de tiempo y la cancelación siguen activos también mientras se lee la respuesta en streaming.
  async function call(method, route, { body, timeoutMs = 8000, signal } = {}) {
    const timeoutSignal = AbortSignal.timeout(timeoutMs);
    const combined = signal ? AbortSignal.any([signal, timeoutSignal]) : timeoutSignal;
    try {
      return await doFetch(host + route, {
        method,
        headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: combined
      });
    } catch (e) {
      if (signal?.aborted) {
        const r = signal.reason;
        throw r instanceof LocalAIError ? r : new LocalAIError('ABORTED', 'Cancelado.');
      }
      if (timeoutSignal.aborted) throw new LocalAIError('TIMEOUT', 'Ollama tardó demasiado en responder.');
      throw offError(e) || new LocalAIError('SERVER', `No se pudo hablar con Ollama: ${e?.message || e}`);
    }
  }
  async function json(method, route, opts = {}) {
    const res = await call(method, route, opts);
    const text = await res.text();
    if (!res.ok) throw errorFromOllama(res.status, text, opts.ctx || {});
    try {
      return text ? JSON.parse(text) : {};
    } catch {
      throw new LocalAIError('SERVER', 'Ollama devolvió una respuesta que no se pudo leer.');
    }
  }

  function findExe() {
    for (const p of exeCandidates()) {
      try {
        if (p && fs.statSync(p).isFile()) return p;
      } catch {}
    }
    return '';
  }

  async function status() {
    try {
      const v = await json('GET', '/api/version', { timeoutMs: 1500 });
      return { state: 'running', version: String(v.version || ''), host };
    } catch (e) {
      if (e.code !== 'OFF' && e.code !== 'TIMEOUT') return { state: 'error', message: e.message, host };
      const exe = findExe();
      return exe ? { state: 'installed', exe, host } : { state: 'missing', host };
    }
  }

  async function start({ waitMs = 30000 } = {}) {
    const st = await status();
    if (st.state === 'running') return st;
    if (st.state !== 'installed')
      throw new LocalAIError('MISSING', 'Ollama no está instalado en este equipo. Instálalo desde Ajustes → Proveedores → Mi PC.');
    const env = { ...process.env };
    const child = spawnFn(st.exe, ['serve'], { detached: true, stdio: 'ignore', windowsHide: true, env });
    child.on?.('error', () => {});
    child.unref?.();
    const t0 = Date.now();
    while (Date.now() - t0 < waitMs) {
      await new Promise(r => setTimeout(r, 400));
      const s = await status();
      if (s.state === 'running') return s;
    }
    throw new LocalAIError('OFF', 'Ollama no llegó a encenderse. Ábrelo desde el menú Inicio y vuelve a intentarlo.');
  }

  async function installed() {
    const tags = await json('GET', '/api/tags', { timeoutMs: 8000 });
    let loaded = [];
    try {
      loaded = (await json('GET', '/api/ps', { timeoutMs: 4000 })).models || [];
    } catch {}
    const ps = new Map(loaded.map(m => [m.name || m.model, m]));
    return (tags.models || []).map(m => {
      const name = String(m.name || m.model || '');
      const p = ps.get(name);
      return {
        name,
        sizeBytes: Number(m.size) || 0,
        sizeGB: Math.round(((Number(m.size) || 0) / 1e9) * 100) / 100,
        digest: String(m.digest || '').slice(0, 12),
        modifiedAt: String(m.modified_at || ''),
        family: String(m.details?.family || ''),
        paramSize: String(m.details?.parameter_size || ''),
        paramsB: parseParamsB(m.details?.parameter_size),
        quant: String(m.details?.quantization_level || ''),
        loaded: !!p,
        vramBytes: Number(p?.size_vram) || 0,
        expiresAt: String(p?.expires_at || '')
      };
    });
  }

  async function show(name, { force = false } = {}) {
    const cached = showCache.get(name);
    if (cached && !force && Date.now() - cached.at < 60000) return cached.value;
    const data = await json('POST', '/api/show', { body: { model: name }, ctx: { model: name } });
    const mi = data.model_info || {};
    const arch = String(mi['general.architecture'] || data.details?.family || '');
    const get = k => mi[`${arch}.${k}`];
    const arr = v => (Array.isArray(v) ? (v.length ? v.reduce((a, b) => a + Number(b || 0), 0) / v.length : 0) : Number(v) || 0);
    const blocks = Number(get('block_count')) || 0;
    const heads = arr(get('attention.head_count'));
    const kvHeads = arr(get('attention.head_count_kv')) || heads;
    const embed = Number(get('embedding_length')) || 0;
    const keyLen = Number(get('attention.key_length')) || (heads ? embed / heads : 0);
    const valLen = Number(get('attention.value_length')) || keyLen;
    const caps = Array.isArray(data.capabilities) ? data.capabilities.map(x => String(x).toLowerCase()) : null;
    const tagsRow = (await installed().catch(() => [])).find(m => m.name === name);
    const value = {
      name,
      capabilities: caps || [],
      capsKnown: !!caps,
      tools: caps ? caps.includes('tools') : null,
      thinking: caps ? caps.includes('thinking') : false,
      vision: caps ? caps.includes('vision') : false,
      embedding: caps ? caps.includes('embedding') && !caps.includes('completion') : false,
      contextLength: Number(get('context_length')) || 0,
      architecture: arch,
      paramsB: parseParamsB(data.details?.parameter_size) || tagsRow?.paramsB || 0,
      quant: String(data.details?.quantization_level || ''),
      kvBytesPerToken: blocks && kvHeads && keyLen ? Math.round(blocks * kvHeads * (keyLen + valLen) * 2) : 0,
      sizeBytes: tagsRow?.sizeBytes || 0
    };
    showCache.set(name, { at: Date.now(), value });
    return value;
  }

  // Cuánto contexto pedir y cómo se ve en este equipo (usa los datos reales del modelo instalado).
  async function planFor(name, { numCtx = 'auto' } = {}) {
    const info = await show(name);
    const h = await hw();
    const p = models.contextForInstalled({ info, hw: h, requested: numCtx === 'auto' ? null : numCtx });
    return { ...p, info };
  }

  async function remove(name) {
    const res = await call('DELETE', '/api/delete', { body: { model: name, name }, timeoutMs: 20000 });
    const text = await res.text();
    if (!res.ok) throw errorFromOllama(res.status, text, { model: name });
    showCache.delete(name);
    return { ok: true };
  }

  // Descarga con progreso. onProgress({pct, completed, total, status, speedBps, etaSec, layers}).
  async function pull(name, { onProgress, signal } = {}) {
    const clean = models.normalizeModelName(name);
    if (!clean)
      throw new LocalAIError('BAD_REQUEST', 'El nombre del modelo no es válido. Usa el formato nombre:etiqueta, por ejemplo qwen3:8b.');
    if (pulls.has(clean)) throw new LocalAIError('BUSY', `«${clean}» ya se está descargando.`);
    const ctl = new AbortController();
    pulls.set(clean, ctl);
    const onAbort = () => ctl.abort();
    signal?.addEventListener('abort', onAbort, { once: true });
    const layers = new Map();
    let lastPct = 0;
    let lastAt = Date.now();
    let lastBytes = 0;
    let speed = 0;
    try {
      const res = await call('POST', '/api/pull', {
        body: { model: clean, name: clean, stream: true },
        timeoutMs: 60000 * 60 * 6,
        signal: ctl.signal
      });
      if (!res.ok) throw errorFromOllama(res.status, await res.text(), { model: clean });
      let lastStatus = '';
      const idle = new LocalAIError('TIMEOUT', 'La descarga se quedó sin respuesta. Vuelve a pulsar «Descargar»: continúa donde se quedó.');
      for await (const line of ndjsonLines(res, { idleMs: 180000, firstMs: 180000, onTimeout: () => ctl.abort(idle) })) {
        let o;
        try {
          o = JSON.parse(line);
        } catch {
          continue;
        }
        if (o.error) throw errorFromOllama(0, o.error, { model: clean });
        lastStatus = String(o.status || lastStatus);
        if (o.digest && o.total) layers.set(o.digest, { total: Number(o.total), completed: Number(o.completed || 0) });
        let total = 0;
        let completed = 0;
        for (const l of layers.values()) {
          total += l.total;
          completed += Math.min(l.completed, l.total);
        }
        const now = Date.now();
        if (now - lastAt >= 400 && completed >= lastBytes) {
          const inst = ((completed - lastBytes) / (now - lastAt)) * 1000;
          speed = speed ? speed * 0.7 + inst * 0.3 : inst;
          lastAt = now;
          lastBytes = completed;
        }
        let pct = total ? Math.min(99.9, (completed / total) * 100) : 0;
        if (/^(verifying|writing|removing|success)/i.test(lastStatus)) pct = Math.max(pct, 99);
        if (/^success/i.test(lastStatus)) pct = 100;
        pct = Math.max(pct, lastPct);
        lastPct = pct;
        onProgress?.({
          status: lastStatus,
          pct: Math.round(pct * 10) / 10,
          completed,
          total,
          speedBps: Math.round(speed),
          etaSec: speed > 1 && total ? Math.round((total - completed) / speed) : null,
          layers: layers.size
        });
      }
      if (!/^success/i.test(lastStatus))
        throw new LocalAIError(
          'PULL_FAILED',
          'La descarga terminó sin confirmar que el modelo quedó completo. Vuelve a pulsar «Descargar»: continúa donde se quedó.'
        );
      showCache.delete(clean);
      return { ok: true, name: clean };
    } catch (e) {
      if (ctl.signal.aborted) {
        const r = ctl.signal.reason;
        if (r instanceof LocalAIError && r.code === 'TIMEOUT') throw r;
        throw new LocalAIError('ABORTED', 'Descarga cancelada. Lo ya descargado se conserva y continuará la próxima vez.', {
          cancelled: true
        });
      }
      if (e instanceof LocalAIError) throw e;
      throw (
        offError(e) ||
        new LocalAIError(
          'SERVER',
          `Se cortó la conexión con Ollama durante la descarga: ${e?.message || e}. Vuelve a pulsar «Descargar»: continúa donde se quedó.`
        )
      );
    } finally {
      signal?.removeEventListener('abort', onAbort);
      pulls.delete(clean);
    }
  }
  function cancelPull(name) {
    const ctl = pulls.get(models.normalizeModelName(name));
    if (!ctl) return false;
    ctl.abort();
    return true;
  }

  // Chat con streaming. Devuelve el texto completo, las llamadas a herramientas y el uso.
  async function chat(req = {}) {
    const name = models.normalizeModelName(req.model);
    if (!name) throw new LocalAIError('BAD_REQUEST', 'Elige un modelo de Mi PC.');
    const id = String(req.requestId || `chat-${Date.now()}`);
    const ctl = new AbortController();
    chats.set(id, ctl);
    try {
      let st = await status();
      if (st.state === 'installed' && req.autoStart !== false) {
        req.onNotice?.('Iniciando Ollama…');
        st = await start();
      }
      if (st.state === 'missing')
        throw new LocalAIError('MISSING', 'Ollama no está instalado. Instálalo desde Ajustes → Proveedores → Mi PC.');
      if (st.state === 'installed')
        throw new LocalAIError('OFF', 'Ollama está apagado. Ve a Ajustes → Proveedores → Mi PC y pulsa «Iniciar Ollama».');
      let info;
      try {
        info = await show(name);
      } catch (e) {
        if (e.code === 'MODEL_NOT_FOUND') throw e;
        info = { name, tools: null, thinking: false };
      }
      let plan =
        req.numCtx && req.numCtx !== 'auto' ? { numCtx: Number(req.numCtx) } : await planFor(name, {}).catch(() => ({ numCtx: 8192 }));
      let numCtx = plan.numCtx || 8192;
      const messages = convertMessages(req.messages);
      const asked = convertTools(req.tools);
      const tools = info.tools === false ? [] : asked;
      const toolsDropped = info.tools === false && asked.length > 0;
      let think = thinkParam(req.think, info);
      let lastError = null;
      for (let attempt = 0; attempt < 6; attempt++) {
        const body = { model: name, messages, stream: true, options: { num_ctx: numCtx } };
        if (tools.length) body.tools = tools;
        if (think !== undefined) body.think = think;
        if (req.keepAlive) body.keep_alive = req.keepAlive;
        if (Number.isFinite(Number(req.temperature))) body.options.temperature = Number(req.temperature);
        try {
          return { ...(await streamChat(body, name, numCtx, ctl, req)), toolsDropped };
        } catch (e) {
          lastError = e;
          // Poca memoria libre: se reintenta con la mitad del contexto (mínimo 4096) antes de rendirse.
          if (e.code === 'NO_MEMORY' && !e.partial && numCtx > 4096 && !ctl.signal.aborted) {
            numCtx = Math.max(4096, Math.floor(numCtx / 2 / 1024) * 1024);
            req.onNotice?.(`Poca memoria libre: pruebo con un contexto más corto (${numCtx}).`);
            continue;
          }
          if (e.code === 'NO_THINKING' && think !== undefined) {
            think = undefined;
            continue;
          }
          throw e;
        }
      }
      throw lastError;
    } finally {
      chats.delete(id);
    }
  }

  async function streamChat(body, name, numCtx, ctl, req) {
    const res = await call('POST', '/api/chat', { body, timeoutMs: 60000 * 60, signal: ctl.signal });
    if (!res.ok) throw errorFromOllama(res.status, await res.text(), { model: name, numCtx });
    let text = '';
    let thinking = '';
    const toolCalls = [];
    let last = {};
    const t0 = Date.now();
    try {
      for await (const line of ndjsonLines(res, {
        idleMs: req.idleMs || 180000,
        firstMs: req.firstMs || 900000,
        onTimeout: () => ctl.abort(new LocalAIError('TIMEOUT', 'El modelo dejó de responder.'))
      })) {
        let o;
        try {
          o = JSON.parse(line);
        } catch {
          continue;
        }
        if (o.error) {
          const err = errorFromOllama(500, o.error, { model: name, numCtx });
          err.partial = !!(text || toolCalls.length);
          throw err;
        }
        const msg = o.message || {};
        if (msg.content) {
          text += msg.content;
          req.onDelta?.({ text: msg.content });
        }
        if (msg.thinking) {
          thinking += msg.thinking;
          req.onDelta?.({ thinking: msg.thinking });
        }
        for (const c of Array.isArray(msg.tool_calls) ? msg.tool_calls : []) {
          const fn = c.function || {};
          let args = fn.arguments;
          if (typeof args === 'string')
            try {
              args = JSON.parse(args);
            } catch {
              args = {};
            }
          toolCalls.push({
            id: String(c.id || `call_${toolCalls.length + 1}`),
            name: String(fn.name || ''),
            args: args && typeof args === 'object' ? args : {}
          });
        }
        if (o.done) last = o;
      }
    } catch (e) {
      if (ctl.signal.aborted) {
        const r = ctl.signal.reason;
        if (r instanceof LocalAIError) throw r;
        throw new LocalAIError('ABORTED', 'Cancelado.', { partialText: text });
      }
      if (e?.name === 'TimeoutError') throw new LocalAIError('TIMEOUT', 'Ollama tardó demasiado en responder.');
      if (e instanceof LocalAIError) throw e;
      throw offError(e) || new LocalAIError('SERVER', `Se cortó la conexión con Ollama: ${e?.message || e}`, { partialText: text });
    }
    const promptTokens = Number(last.prompt_eval_count) || 0;
    const completionTokens = Number(last.eval_count) || 0;
    const evalNs = Number(last.eval_duration) || 0;
    return {
      text,
      reasoning: thinking,
      toolCalls,
      finishReason: String(last.done_reason || (toolCalls.length ? 'tool_calls' : 'stop')),
      numCtx,
      usage: {
        promptTokens,
        completionTokens,
        totalMs: last.total_duration ? Math.round(Number(last.total_duration) / 1e6) : Date.now() - t0,
        loadMs: last.load_duration ? Math.round(Number(last.load_duration) / 1e6) : 0,
        tokensPerSecond: evalNs > 0 ? Math.round((completionTokens / (evalNs / 1e9)) * 10) / 10 : 0
      },
      contextTruncated: promptTokens > 0 && promptTokens >= numCtx - 8
    };
  }
  function abortChat(id) {
    const ctl = chats.get(String(id));
    if (!ctl) return false;
    ctl.abort();
    return true;
  }

  // ── Comprobación contra el registro de Ollama (existencia, tamaño real y herramientas) ───────────
  async function registryGet(urlPath, { accept, maxBytes = 1024 * 1024, signal } = {}) {
    const url = registryHost.replace(/\/+$/, '') + urlPath;
    const { res } = await netSafe.openSafe(url, {
      headers: accept ? { Accept: accept } : {},
      hostMap: deps.hostMap,
      resolver: deps.resolver,
      allowHttp: !!deps.allowHttpRegistry,
      timeoutMs: 8000,
      maxRedirects: 3,
      signal
    });
    if (res.statusCode === 404) {
      res.resume?.();
      return { status: 404, text: '' };
    }
    if (res.statusCode < 200 || res.statusCode >= 300) {
      res.resume?.();
      return { status: res.statusCode, text: '' };
    }
    const { buffer } = await netSafe.readLimited(netSafe.decodedStream(res), maxBytes);
    return { status: 200, text: buffer.toString('utf8') };
  }

  async function verifyOne(id, { signal } = {}) {
    const clean = models.normalizeModelName(id);
    const [repo, tag] = clean.split(':');
    const ns = repo.includes('/') ? repo : `library/${repo}`;
    const out = { id: clean, checkedAt: Date.now() };
    try {
      const m = await registryGet(`/v2/${ns}/manifests/${encodeURIComponent(tag)}`, { accept: MANIFEST_ACCEPT, signal });
      if (m.status === 404) return { ...out, exists: false };
      if (m.status !== 200) return { ...out, exists: null, error: `El registro respondió ${m.status}.` };
      const mf = JSON.parse(m.text);
      const layers = Array.isArray(mf.layers) ? mf.layers : [];
      const heavy = layers.filter(l => /image\.(model|projector|adapter)$/.test(String(l.mediaType || '')));
      const bytes = heavy.reduce((a, l) => a + (Number(l.size) || 0), 0);
      const vision = layers.some(l => /image\.projector$/.test(String(l.mediaType || ''))) ? true : null;
      let tools = null;
      const tpl = layers.find(l => /image\.template$/.test(String(l.mediaType || '')) && Number(l.size) > 0 && Number(l.size) < 65536);
      let hasParser = false;
      if (mf.config?.digest && Number(mf.config.size) < 65536) {
        try {
          const c = await registryGet(`/v2/${ns}/blobs/${mf.config.digest}`, { signal });
          if (c.status === 200) {
            const cj = JSON.parse(c.text);
            hasParser = !!(cj.parser || cj.renderer);
            out.quant = String(cj.file_type || '');
            out.params = String(cj.model_type || '');
          }
        } catch {}
      }
      if (tpl) {
        try {
          const t = await registryGet(`/v2/${ns}/blobs/${tpl.digest}`, { signal });
          if (t.status === 200) tools = /\.Tools\b|\.ToolCalls\b/.test(t.text) ? true : hasParser ? null : false;
        } catch {}
      }
      return { ...out, exists: true, sizeGB: Math.round((bytes / 1e9) * 100) / 100, tools, vision };
    } catch (e) {
      return { ...out, exists: null, error: String(e?.message || e).slice(0, 160) };
    }
  }

  async function verifyCatalog(ids, { onProgress, signal, concurrency = 4 } = {}) {
    const list = [...new Set(ids.map(models.normalizeModelName).filter(Boolean))];
    const results = {};
    let i = 0;
    let done = 0;
    async function worker() {
      while (i < list.length && !signal?.aborted) {
        const id = list[i++];
        results[id] = await verifyOne(id, { signal });
        onProgress?.({ done: ++done, total: list.length, id });
      }
    }
    await Promise.all(Array.from({ length: Math.min(concurrency, list.length) }, worker));
    return results;
  }

  return {
    host,
    status,
    start,
    installed,
    show,
    planFor,
    remove,
    pull,
    cancelPull,
    chat,
    abortChat,
    verifyCatalog,
    verifyOne,
    hardware: hw,
    findExe,
    _test: { errorFromOllama, convertMessages, convertTools, thinkParam, parseHost }
  };
}

function defaultExeCandidates() {
  const e = process.env;
  const list = [];
  if (process.platform === 'win32') {
    if (e.LOCALAPPDATA) list.push(path.join(e.LOCALAPPDATA, 'Programs', 'Ollama', 'ollama.exe'));
    if (e.ProgramFiles) list.push(path.join(e.ProgramFiles, 'Ollama', 'ollama.exe'));
  } else list.push('/usr/local/bin/ollama', '/usr/bin/ollama', path.join(os.homedir(), '.local', 'bin', 'ollama'));
  for (const dir of String(e.PATH || '').split(path.delimiter)) {
    if (!dir) continue;
    list.push(path.join(dir, process.platform === 'win32' ? 'ollama.exe' : 'ollama'));
  }
  return list;
}

// ── Integración con Electron (IPC) ──────────────────────────────────────────────────────────────
function register({ app, ipcMain, shell, getWindow, hostMap, shippedCatalogFile }) {
  const userFile = () => path.join(app.getPath('userData'), 'local-models.json');
  const shippedFile = shippedCatalogFile || path.join(__dirname, 'resources', 'local-models.json');
  const e2eHost = process.env.AURIC_E2E === '1' ? process.env.AURIC_OLLAMA_HOST : '';
  const e2eRegistry = process.env.AURIC_E2E === '1' ? process.env.AURIC_OLLAMA_REGISTRY : '';
  // Solo en las pruebas E2E: equipo simulado para que las recomendaciones no dependan de la máquina que las ejecuta.
  let e2eHardware = null;
  if (process.env.AURIC_E2E === '1' && process.env.AURIC_E2E_HARDWARE) {
    const raw = process.env.AURIC_E2E_HARDWARE;
    // «@ruta»: se lee del archivo en cada consulta, así la prueba puede cambiar el equipo simulado mientras la app corre.
    e2eHardware = raw.startsWith('@')
      ? () => JSON.parse(fs.readFileSync(raw.slice(1), 'utf8'))
      : () => {
          try {
            return JSON.parse(raw);
          } catch {
            return null;
          }
        };
  }
  let ai = null;
  let lastHost = '';
  const getAI = rawHost => {
    const wanted = e2eHost || rawHost || DEFAULT_HOST;
    if (!ai || lastHost !== wanted) {
      ai = createLocalAI({
        host: wanted,
        hostMap,
        registry: e2eRegistry || undefined,
        getHardware: e2eHardware ? async () => e2eHardware() : undefined,
        modelsDir: process.env.OLLAMA_MODELS
      });
      lastHost = wanted;
    }
    return ai;
  };
  const send = (channel, payload) => {
    const win = getWindow?.();
    if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
  };
  function readUser() {
    try {
      return JSON.parse(fs.readFileSync(userFile(), 'utf8'));
    } catch {
      return {};
    }
  }
  function writeUser(data) {
    fs.mkdirSync(path.dirname(userFile()), { recursive: true });
    const tmp = userFile() + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
    fs.renameSync(tmp, userFile());
  }
  const safeErr = e => ({ code: e?.code || 'ERROR', message: String(e?.message || e) });
  const wrap =
    fn =>
    async (_e, ...args) => {
      try {
        return { ok: true, ...(await fn(...args)) };
      } catch (e) {
        return { ok: false, error: safeErr(e) };
      }
    };

  async function catalogView(rawHost) {
    const a = getAI(rawHost);
    const h = await a.hardware();
    const merged = models.mergeCatalog(models.loadShipped(shippedFile), readUser());
    let inst = [];
    let st = await a.status();
    if (st.state === 'running') inst = await a.installed().catch(() => []);
    const have = new Map(inst.map(m => [m.name.toLowerCase(), m]));
    const haveModel = id => have.get(id.toLowerCase()) || have.get(id.toLowerCase().replace(/:latest$/, '')) || null;
    const rec = models.recommendAll(merged.models, h);
    const rows = rec.rows.map(r => ({ ...r, installed: !!haveModel(r.id), installedInfo: haveModel(r.id) }));
    const extra = inst
      .filter(m => !merged.models.some(c => c.id.toLowerCase() === m.name.toLowerCase()))
      .map(m => ({ name: m.name, sizeGB: m.sizeGB, paramSize: m.paramSize, loaded: m.loaded }));
    return {
      status: st,
      hardware: h,
      reviewed: merged.reviewed,
      verified: merged.verified,
      source: merged.source,
      rows,
      pick: rec.pick,
      installed: inst,
      extraInstalled: extra,
      hiddenCount: merged.models.filter(m => m.hidden).length
    };
  }

  ipcMain.handle(
    'auric:local-status',
    wrap(async host => ({ status: await getAI(host).status() }))
  );
  ipcMain.handle(
    'auric:local-hardware',
    wrap(async () => ({ hardware: await getAI().hardware(true) }))
  );
  ipcMain.handle(
    'auric:local-start',
    wrap(async host => ({ status: await getAI(host).start() }))
  );
  ipcMain.handle(
    'auric:local-catalog',
    wrap(async host => ({ view: await catalogView(host) }))
  );
  ipcMain.handle(
    'auric:local-installed',
    wrap(async host => ({ models: await getAI(host).installed() }))
  );
  ipcMain.handle(
    'auric:local-show',
    wrap(async (host, name) => ({ info: await getAI(host).show(String(name || '')) }))
  );
  ipcMain.handle(
    'auric:local-delete',
    wrap(async (host, name) => getAI(host).remove(String(name || '')))
  );
  ipcMain.handle(
    'auric:local-catalog-edit',
    wrap(async edit => {
      const u = readUser();
      u.hidden = Array.isArray(u.hidden) ? u.hidden : [];
      u.custom = Array.isArray(u.custom) ? u.custom : [];
      const id = models.normalizeModelName(edit?.id);
      if (edit?.action === 'hide' && id && !u.hidden.includes(id)) u.hidden.push(id);
      else if (edit?.action === 'show' && id) u.hidden = u.hidden.filter(x => x !== id);
      else if (edit?.action === 'restore') {
        u.hidden = [];
        u.custom = [];
      } else if (edit?.action === 'add') {
        if (!id)
          throw new LocalAIError('BAD_REQUEST', 'Escribe el nombre del modelo con el formato nombre:etiqueta, por ejemplo qwen3:8b.');
        let raw = { ...(edit.entry || {}), id };
        if (!Number(raw.sizeGB)) {
          // La persona no conoce el tamaño: se consulta al registro de Ollama (existencia, tamaño real y herramientas).
          const v = await getAI().verifyOne(id);
          if (v.exists === false)
            throw new LocalAIError('NOT_FOUND', `La biblioteca de Ollama no tiene «${id}». Revisa el nombre exacto en ollama.com/library.`);
          if (v.exists !== true || !v.sizeGB)
            throw new LocalAIError(
              'REGISTRY_OFF',
              'No pude consultar la biblioteca de Ollama (¿sin internet?). Vuelve a intentarlo cuando tengas conexión.'
            );
          const fromTag = Number(String(id).match(/(\d+(?:\.\d+)?)b\b/i)?.[1]) || 0;
          const params = parseParamsB(v.params || '') || fromTag;
          raw = {
            ...raw,
            sizeGB: v.sizeGB,
            paramsB: params || undefined,
            tools: v.tools === true,
            vision: v.vision === true,
            note: raw.note || 'Añadido por ti. Tamaño y herramientas comprobados en la biblioteca de Ollama.'
          };
          u.checks = { ...(u.checks || {}), [id]: v };
        }
        const entry = models.normalizeEntry(raw, { custom: true });
        if (!entry)
          throw new LocalAIError('BAD_REQUEST', 'Escribe el nombre del modelo con el formato nombre:etiqueta, por ejemplo qwen3:8b.');
        u.custom = u.custom.filter(x => models.normalizeModelName(x.id) !== entry.id).concat([entry]);
        u.hidden = u.hidden.filter(x => x !== entry.id);
      } else if (edit?.action === 'remove-custom' && id) u.custom = u.custom.filter(x => models.normalizeModelName(x.id) !== id);
      else throw new LocalAIError('BAD_REQUEST', 'Acción de lista no válida.');
      writeUser(u);
      return {};
    })
  );
  let verifying = null;
  ipcMain.handle(
    'auric:local-verify',
    wrap(async () => {
      if (verifying) throw new LocalAIError('BUSY', 'Ya se está comprobando la lista.');
      verifying = new AbortController();
      try {
        const merged = models.mergeCatalog(models.loadShipped(shippedFile), readUser());
        const results = await getAI().verifyCatalog(
          merged.models.map(m => m.id),
          { signal: verifying.signal, onProgress: p => send('auric:local-verify-progress', p) }
        );
        const u = readUser();
        u.checks = { ...(u.checks || {}), ...results };
        writeUser(u);
        const missing = Object.values(results).filter(r => r.exists === false).length;
        const unreachable = Object.values(results).filter(r => r.exists === null).length;
        return { checked: Object.keys(results).length, missing, unreachable };
      } finally {
        verifying = null;
      }
    })
  );
  ipcMain.handle(
    'auric:local-pull',
    wrap(async (host, name) => {
      const a = getAI(host);
      const clean = models.normalizeModelName(name);
      if (!clean) throw new LocalAIError('BAD_REQUEST', 'El nombre del modelo no es válido.');
      // Se lanza sin esperar: el avance llega por eventos. El resultado final también llega por evento.
      a.pull(clean, { onProgress: p => send('auric:local-pull-progress', { name: clean, ...p }) })
        .then(() => send('auric:local-pull-done', { name: clean, ok: true }))
        .catch(e => send('auric:local-pull-done', { name: clean, ok: false, cancelled: !!e.cancelled, error: safeErr(e) }));
      return { started: clean };
    })
  );
  ipcMain.handle(
    'auric:local-pull-cancel',
    wrap(async (host, name) => ({ cancelled: getAI(host).cancelPull(String(name || '')) }))
  );
  ipcMain.handle('auric:local-chat', async (_e, req = {}) => {
    const a = getAI(req.host);
    const id = String(req.requestId || '');
    try {
      const out = await a.chat({
        ...req,
        onDelta: d => send('auric:local-delta', { requestId: id, ...d }),
        onNotice: text => send('auric:local-notice', { requestId: id, text })
      });
      return { ok: true, result: out };
    } catch (e) {
      return { ok: false, error: safeErr(e) };
    }
  });
  ipcMain.handle('auric:local-abort', async (_e, id) => ({ ok: true, aborted: !!ai?.abortChat(String(id || '')) }));
  ipcMain.handle('auric:local-open-library', async () => {
    await shell.openExternal('https://ollama.com/library');
    return { ok: true };
  });
  return { getAI, abortChat: id => !!ai?.abortChat(String(id || '')) };
}

module.exports = {
  createLocalAI,
  register,
  LocalAIError,
  errorFromOllama,
  convertMessages,
  convertTools,
  thinkParam,
  parseHost,
  parseParamsB,
  ndjsonLines,
  DEFAULT_HOST
};
