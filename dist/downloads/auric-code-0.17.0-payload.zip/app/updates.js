'use strict';
const { createHash } = require('crypto');
const safe = require('./net-safe');
const CHANNEL = 'https://auric-code.dressygrass3.chatgpt.site';
const MANIFEST_URL = CHANNEL + '/release.json';
function validateRelease(spec = {}) {
  const version = String(spec.version || spec.latestVersion || '');
  const sha256 = String(spec.sha256 || spec.installerSha256 || '').toLowerCase();
  if (!/^\d+\.\d+\.\d+$/.test(version) || !/^[a-f0-9]{64}$/.test(sha256)) throw Error('La publicación no incluye una versión y una huella válidas.');
  let url; try { url = new URL(String(spec.url || spec.installerUrl || '')); } catch { throw Error('Falta la dirección del instalador.'); }
  const exact = `/downloads/Auric-Code-Setup-${version}.exe`;
  const site = url.origin === CHANNEL && url.pathname === exact;
  const github = url.origin === 'https://github.com' && url.pathname === `/MIDASYT/AuricCode/releases/download/v${version}/Auric-Code-Setup-${version}.exe`;
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash || (!site && !github)) throw Error('El instalador no pertenece al canal de publicación de AuricCode.');
  return { version, url: url.href, sha256, latestVersion: version, installerUrl: url.href, installerSha256: sha256 };
}
async function checkManifest() {
  const hop = await safe.openSafe(MANIFEST_URL, {headers:{Accept:'application/json'},maxRedirects:0,timeoutMs:10000});
  if (hop.res.statusCode !== 200) throw Error('El canal de actualizaciones no está disponible ahora.');
  const {buffer,truncated} = await safe.readLimited(safe.decodedStream(hop.res), 64*1024);
  if (truncated) throw Error('El manifiesto de actualización es demasiado grande.');
  return validateRelease(JSON.parse(buffer.toString('utf8')));
}
function verifyInstaller(buffer, expected) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 2 || buffer.subarray(0,2).toString() !== 'MZ') throw Error('La descarga no es un instalador de Windows.');
  if (createHash('sha256').update(buffer).digest('hex') !== expected) throw Error('La huella del instalador no coincide. Vuelve a descargarlo.');
  return true;
}
module.exports = { CHANNEL, MANIFEST_URL, validateRelease, checkManifest, verifyInstaller };
