'use strict';
// Puente mínimo entre la barra del navegador de Auric (página local de confianza) y el proceso principal.
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('auricBrowserUI', {
  onState: fn => {
    ipcRenderer.on('auric-browser-ui:state', (_e, s) => fn(s));
    ipcRenderer.send('auric-browser-ui:ready');
  },
  onFocusAddress: fn => ipcRenderer.on('auric-browser-ui:focus-address', () => fn()),
  onToast: fn => ipcRenderer.on('auric-browser-ui:toast', (_e, t) => fn(String(t || ''))),
  go: text => ipcRenderer.send('auric-browser-ui:go', String(text || '').slice(0, 2100)),
  nav: action => ipcRenderer.send('auric-browser-ui:nav', String(action || '')),
  togglePause: () => ipcRenderer.send('auric-browser-ui:pause'),
  toggleComment: () => ipcRenderer.send('auric-browser-ui:comment-toggle'),
  sendComment: text => ipcRenderer.send('auric-browser-ui:comment-send', String(text || '').slice(0, 4000)),
  cancelComment: () => ipcRenderer.send('auric-browser-ui:comment-cancel')
});
