'use strict';
// Navegador de la IA (proceso principal).
//
// Una ventana propia, separada de Auric, con una sesión que vive solo en memoria: sin tus cookies, sin tus contraseñas, y al cerrarla
// se borra todo. La IA la maneja con herramientas (abrir, leer, clic, escribir…), pero este archivo es quien manda:
//   · cada sitio nuevo pide permiso a la persona (y los de pagos o banca piden confirmación en cada paso),
//   · la IA nunca escribe contraseñas, tarjetas ni códigos de seguridad,
//   · lo que sale de las páginas viaja siempre como «texto de fuera», nunca como órdenes,
//   · las páginas de Internet no pueden hablar con tu red local ni descargar archivos ni pedir cámara, micrófono o ubicación.
// Las reglas puras (direcciones, sitios sensibles, qué se pregunta) están en policy.js y se prueban sin Electron.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const dns = require('dns');
const crypto = require('crypto');
const policy = require('./policy');
const netSafe = require('../net-safe');

const TOP_H = 84; // alto de la barra (chrome.html)
const LOAD_TIMEOUT_MS = 30000; // cuánto se espera a que cargue una página antes de mostrar lo que llegó
const PANEL_H = 176; // alto del recuadro para comentar
const sleep = ms => new Promise(r => setTimeout(r, ms));
const clampInt = (v, lo, hi, d) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d;
};
const fail = error => ({ ok: false, error });
const done = text => ({ ok: true, text });

function register({ app, ipcMain, getWindow, iconPath }) {
  const electron = require('electron');
  const { BrowserWindow, WebContentsView, session, nativeImage } = electron;
  const e2e = process.env.AURIC_E2E === '1';
  // Solo las pruebas automáticas pueden acortar la espera de carga.
  const loadTimeoutMs = e2e && Number(process.env.AURIC_BROWSER_LOAD_TIMEOUT_MS) >= 500 ? Math.round(Number(process.env.AURIC_BROWSER_LOAD_TIMEOUT_MS)) : LOAD_TIMEOUT_MS;
  const userData = app.getPath('userData');
  const store = new policy.SiteStore({ file: path.join(userData, 'browser-sites.json') });
  const tokens = new policy.ConfirmTokens();

  let win = null;
  let view = null;
  let ses = null;
  let owner = ''; // chat que abrió la página que hay ahora
  let paused = false;
  let aiBusy = 0;
  let activityText = '';
  let commentMode = false;
  let commentPick = null;
  let panelOpen = false;
  let queue = Promise.resolve();
  let extraSensitive = [];
  let aiInput = 0; // >0 mientras la IA manda teclas o clics (para no confundirlos con atajos de la persona)
  let uiTimer = 0;
  let closing = false;
  const pending = new Map();
  let nextId = 1;
  const nav = { active: false, counter: 0, commits: 0, error: null, status: 0, chainUrl: '' };
  const notes = new Set();
  const dnsCache = new Map();

  const emitMain = (name, detail) => {
    try {
      const w = getWindow?.();
      if (w && !w.isDestroyed()) w.webContents.send('auric:event', { name, detail });
    } catch {}
  };
  const note = text => {
    if (notes.size < 12) notes.add(String(text).slice(0, 300));
  };
  const takeNotes = () => {
    const a = [...notes];
    notes.clear();
    return a;
  };
  const viewWc = () => (view && !view.webContents.isDestroyed() ? view.webContents : null);
  const currentUrl = () => {
    const wc = viewWc();
    return wc ? wc.getURL() : '';
  };
  const hasPageUrl = u => /^https?:/i.test(String(u || ''));

  // ── Estado hacia la barra y hacia Auric ────────────────────────────────────────────────────────────────────
  function history(wc) {
    try {
      const h = wc.navigationHistory;
      return { back: !!h.canGoBack(), forward: !!h.canGoForward() };
    } catch {
      return { back: false, forward: false };
    }
  }
  function permissionLabel(url) {
    const p = policy.parseUrl(url);
    if (!p.ok) return { text: '', kind: '' };
    const sens = policy.sensitiveUrl(p.url, extraSensitive);
    if (sens) return store.allowed(p.key, { sensitive: true }) ? { text: 'Sitio sensible · confirmado por unos minutos', kind: 'warn' } : { text: 'Sitio sensible: la IA pedirá confirmación', kind: 'warn' };
    const a = store.allowed(p.key);
    if (a === 'siempre') return { text: 'La IA puede usar este sitio', kind: 'ok' };
    if (a === 'sesion') return { text: 'La IA puede usar este sitio (esta sesión)', kind: 'ok' };
    return { text: p.local ? 'Sitio de tu red: la IA pedirá permiso' : 'La IA pedirá permiso para este sitio', kind: 'ask' };
  }
  function uiState() {
    const wc = viewWc();
    const url = wc ? wc.getURL() : '';
    const h = wc ? history(wc) : { back: false, forward: false };
    return {
      url: hasPageUrl(url) ? url : '',
      title: wc ? wc.getTitle() : '',
      hasPage: hasPageUrl(url),
      canGoBack: h.back,
      canGoForward: h.forward,
      loading: !!(wc && (wc.isLoading() || nav.active)),
      paused,
      ai: { busy: aiBusy > 0, text: activityText },
      commentMode,
      pick: commentPick ? { tag: commentPick.tag, kind: policy.kindEs(commentPick.kind, ''), label: commentPick.label, hint: commentPick.hint } : null,
      perm: hasPageUrl(url) ? permissionLabel(url) : { text: '', kind: '' }
    };
  }
  function pushUI() {
    clearTimeout(uiTimer);
    uiTimer = setTimeout(() => {
      try {
        if (win && !win.isDestroyed()) win.webContents.send('auric-browser-ui:state', uiState());
      } catch {}
    }, 30);
    uiTimer.unref?.();
  }
  function publicState() {
    const wc = viewWc();
    return { open: !!(win && !win.isDestroyed()), url: wc && hasPageUrl(wc.getURL()) ? wc.getURL() : '', title: wc ? wc.getTitle() : '', paused, sites: store.list() };
  }
  const emitState = () => emitMain('browser-state', publicState());
  function setActivity(text) {
    activityText = text || '';
    pushUI();
  }

  // ── Sesión aislada y endurecida ────────────────────────────────────────────────────────────────────────────
  async function resolvesPrivate(host) {
    const hit = dnsCache.get(host);
    if (hit && Date.now() - hit.at < 300000) return hit.priv;
    let priv = false;
    try {
      const rows = await Promise.race([dns.promises.lookup(host, { all: true }), sleep(1500).then(() => Promise.reject(new Error('timeout')))]);
      priv = rows.some(r => netSafe.isPrivateAddress(r.address));
    } catch {}
    dnsCache.set(host, { priv, at: Date.now() });
    if (dnsCache.size > 500) dnsCache.delete(dnsCache.keys().next().value);
    return priv;
  }
  function onBeforeRequest(details, callback) {
    try {
      const pageUrl = currentUrl();
      const verdict = policy.shouldBlockRequest({ pageUrl, requestUrl: details.url, method: details.method, resourceType: details.resourceType });
      if (verdict.block) {
        note(`Auric bloqueó una petición de la página (${verdict.reason})`);
        return callback({ cancel: true });
      }
      const t = policy.safeParse(details.url);
      const p = policy.safeParse(pageUrl);
      const tInfo = t && /^https?:$/.test(t.protocol) ? policy.hostInfo(t.hostname) : null;
      const pInfo = p && /^https?:$/.test(p.protocol) ? policy.hostInfo(p.hostname) : null;
      const topLevelGet = details.resourceType === 'mainFrame' && String(details.method).toUpperCase() === 'GET';
      // Segunda capa (de mejor esfuerzo): un nombre «público» que en realidad apunta a tu red local.
      if (!tInfo || tInfo.local || tInfo.ip || !pInfo || pInfo.local || topLevelGet) return callback({});
      resolvesPrivate(tInfo.host)
        .then(priv => {
          if (priv) note('Auric bloqueó una petición de la página hacia tu red local.');
          callback(priv ? { cancel: true } : {});
        })
        .catch(() => callback({}));
    } catch {
      callback({});
    }
  }
  function browserSession() {
    if (ses) return ses;
    ses = session.fromPartition('auric-browser'); // sin «persist:»: solo memoria
    const ua = ses
      .getUserAgent()
      .replace(/\sElectron\/[\d.]+/i, '')
      .replace(/(Gecko\))\s[^\s/]+\/[\d.]+(\sChrome\/)/i, '$1$2');
    ses.setUserAgent(ua, 'es-CL,es;q=0.9,en;q=0.8');
    ses.setPermissionRequestHandler((_wc, _permission, cb) => cb(false)); // cámara, micrófono, ubicación, avisos…: nunca
    ses.setPermissionCheckHandler((_wc, permission) => permission === 'clipboard-sanitized-write');
    try {
      ses.setDevicePermissionHandler(() => false);
    } catch {}
    try {
      ses.setSpellCheckerEnabled(false);
    } catch {}
    ses.on('will-download', (event, item) => {
      event.preventDefault();
      let name = '';
      try {
        name = item.getFilename();
      } catch {}
      note(`La página intentó descargar un archivo${name ? ` («${policy.cleanLabel(name, 60)}»)` : ''}. Auric no descarga desde el navegador; si la persona lo pide, usa download_file.`);
    });
    ses.webRequest.onBeforeRequest({ urls: ['<all_urls>'] }, onBeforeRequest);
    return ses;
  }
  async function wipeSession() {
    const s = ses;
    if (!s) return;
    try {
      await s.clearStorageData();
      await s.clearCache();
      await s.clearAuthCache();
      await s.clearHostResolverCache();
    } catch {}
  }

  // ── Ventana y página ───────────────────────────────────────────────────────────────────────────────────────
  function layout() {
    if (!win || win.isDestroyed() || !view) return;
    const [w, h] = win.getContentSize();
    const bottom = panelOpen ? PANEL_H : 0;
    view.setBounds({ x: 0, y: TOP_H, width: Math.max(0, w), height: Math.max(0, h - TOP_H - bottom) });
  }
  function rejectPending(message) {
    for (const [id, p] of pending) {
      clearTimeout(p.timer);
      p.reject(new Error(message));
      pending.delete(id);
    }
  }
  function shortcut(event, input) {
    if (aiInput > 0 || input.type !== 'keyDown') return;
    const wc = viewWc();
    if (!wc) return;
    const key = String(input.key || '');
    const ctrl = input.control || input.meta;
    if (input.alt && key === 'ArrowLeft') {
      event.preventDefault();
      history(wc).back && wc.navigationHistory.goBack();
    } else if (input.alt && key === 'ArrowRight') {
      event.preventDefault();
      history(wc).forward && wc.navigationHistory.goForward();
    } else if (key === 'F5' || (ctrl && key.toLowerCase() === 'r')) {
      event.preventDefault();
      wc.reload();
    } else if (ctrl && key.toLowerCase() === 'l') {
      event.preventDefault();
      win?.webContents.focus();
      win?.webContents.send('auric-browser-ui:focus-address');
    } else if (key === 'Escape' && commentMode) {
      event.preventDefault();
      cancelComment();
    }
  }
  function createView() {
    const v = new WebContentsView({
      webPreferences: {
        session: browserSession(),
        preload: path.join(__dirname, 'page-preload.js'),
        sandbox: true,
        contextIsolation: true,
        nodeIntegration: false,
        nodeIntegrationInSubFrames: false,
        webSecurity: true,
        allowRunningInsecureContent: false,
        webviewTag: false,
        plugins: false,
        spellcheck: false,
        backgroundThrottling: false,
        enableWebSQL: false,
        navigateOnDragDrop: false,
        autoplayPolicy: 'user-gesture-required'
      }
    });
    const wc = v.webContents;
    try {
      wc.setWebRTCIPHandlingPolicy('disable_non_proxied_udp'); // no filtra las direcciones de tu red
    } catch {}
    wc.setWindowOpenHandler(({ url }) => {
      // Ventanas emergentes: nunca se abren aparte; si es una dirección web normal, se abre en esta misma página.
      const p = policy.parseUrl(url);
      if (p.ok) setTimeout(() => !wc.isDestroyed() && wc.loadURL(p.url).catch(() => {}), 0);
      else note('La página intentó abrir una ventana con una dirección no permitida y Auric la bloqueó.');
      return { action: 'deny' };
    });
    const guardNav = (event, urlArg, redirect) => {
      const url = typeof urlArg === 'string' ? urlArg : event?.url;
      if (!/^https?:\/\//i.test(String(url || ''))) {
        event.preventDefault();
        note(`La página intentó ir a una dirección no permitida (${String(url || '').slice(0, 30)}…) y Auric la bloqueó.`);
        return;
      }
      // Una página de Internet no puede llevarte sola a tu propio computador o a tu red local (ni con un enlace ni con una redirección).
      const main = event?.isMainFrame !== false;
      if (policy.blocksLocalHop(redirect && main ? nav.chainUrl : wc.getURL(), url)) {
        event.preventDefault();
        note('La página intentó llevarte a una dirección de tu propio computador o de tu red local y Auric lo bloqueó.');
        return;
      }
      if (redirect && main) nav.chainUrl = url;
    };
    wc.on('will-navigate', (event, url) => guardNav(event, url, false));
    wc.on('will-redirect', (event, url) => guardNav(event, url, true));
    // Un salto desde una página web hacia un archivo del computador (file://) ya lo frena Chromium antes de avisar; solo se le cuenta a la IA.
    wc.on('console-message', (...a) => {
      const msg = String(a[0] && typeof a[0] === 'object' && 'message' in a[0] ? a[0].message : (a[2] ?? ''));
      if (/^Not allowed to load local resource: /i.test(msg)) note('La página intentó ir a una dirección no permitida (un archivo de tu computador) y el navegador la bloqueó.');
    });
    wc.on('did-start-navigation', (a, b, c, d) => {
      const det = a && typeof a === 'object' && 'isMainFrame' in a ? a : { isMainFrame: d ?? c, isSameDocument: !!b, url: b };
      if (!det.isMainFrame || det.isSameDocument) return;
      nav.active = true;
      nav.counter++;
      nav.error = null;
      nav.status = 0;
      nav.chainUrl = String(det.url || '');
      rejectPending('NAVIGATED');
      pushUI();
    });
    wc.on('did-navigate', (_e, _url, code) => {
      nav.status = Number(code) || 0;
      nav.commits++;
      pushUI();
    });
    wc.on('did-navigate-in-page', pushUI);
    wc.on('page-title-updated', (_e, title) => {
      try {
        if (win && !win.isDestroyed()) win.setTitle(`${policy.cleanLabel(title, 80) || 'Sin título'} — Navegador de Auric`);
      } catch {}
      pushUI();
      emitState();
    });
    wc.on('did-start-loading', pushUI);
    wc.on('did-stop-loading', () => {
      nav.active = false;
      pushUI();
      emitState();
    });
    wc.on('did-fail-load', (_e, code, desc, url, isMainFrame) => {
      if (!isMainFrame || code === -3) return; // -3 = cancelada (p. ej. una redirección)
      nav.error = { code, desc, url };
    });
    wc.on('render-process-gone', () => {
      rejectPending('CRASHED');
      note('La página se cerró por un error interno.');
      pushUI();
    });
    wc.on('before-input-event', shortcut);
    wc.on('context-menu', e => e.preventDefault());
    try {
      wc.debugger.attach('1.3');
      wc.debugger.on('detach', () => {});
      wc.debugger.sendCommand('Page.enable').catch(() => {});
      // Avisos de la página (alert/confirm/prompt): se cierran solos y la IA se entera de lo que decían.
      wc.debugger.on('message', (_e, method, params) => {
        if (method !== 'Page.javascriptDialogOpening') return;
        const kind = String(params?.type || 'alert');
        note(`La página mostró un aviso (${kind}): «${policy.cleanLabel(params?.message || '', 160)}». Auric lo cerró.`);
        wc.debugger.sendCommand('Page.handleJavaScriptDialog', { accept: kind === 'beforeunload' }).catch(() => {});
      });
    } catch {}
    return v;
  }
  async function ensureWindow({ show = true, focus = false } = {}) {
    if (win && !win.isDestroyed() && viewWc()) {
      if (win.isMinimized()) win.restore();
      if (show && !win.isVisible()) win.showInactive();
      if (focus) win.focus();
      return;
    }
    if (win && !win.isDestroyed()) {
      try {
        win.destroy();
      } catch {}
    }
    closing = false;
    win = new BrowserWindow({
      width: 1180,
      height: 820,
      minWidth: 760,
      minHeight: 520,
      show: false,
      backgroundColor: '#07090d',
      title: 'Navegador de Auric',
      icon: iconPath ? iconPath() : undefined,
      autoHideMenuBar: true,
      webPreferences: {
        preload: path.join(__dirname, 'chrome-preload.js'),
        contextIsolation: true,
        sandbox: true,
        nodeIntegration: false,
        backgroundThrottling: false
      }
    });
    win.setMenuBarVisibility(false);
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    win.webContents.on('will-navigate', e => e.preventDefault());
    win.webContents.on('before-input-event', (event, input) => {
      if (input.type === 'keyDown' && input.alt && (input.key === 'ArrowLeft' || input.key === 'ArrowRight')) shortcut(event, input);
    });
    view = createView();
    win.contentView.addChildView(view);
    layout();
    win.on('resize', layout);
    win.on('maximize', layout);
    win.on('unmaximize', layout);
    win.on('enter-full-screen', layout);
    win.on('leave-full-screen', layout);
    win.on('closed', () => {
      win = null;
      view = null;
      teardown();
    });
    await win.loadFile(path.join(__dirname, 'chrome.html'));
    if (show) focus ? win.show() : win.showInactive();
    pushUI();
    emitState();
  }
  // Se puede llamar muchas veces (al cerrar la ventana, al pedir cerrar, al apagar la app): lo que la IA tenía
  // (permisos de la sesión, dueño, avisos pendientes) se borra SIEMPRE; solo el vaciado del almacenamiento
  // y el aviso a la pantalla se hacen una vez por ventana.
  function teardown() {
    rejectPending('CLOSED');
    store.clearSession();
    owner = '';
    paused = false;
    commentMode = false;
    commentPick = null;
    panelOpen = false;
    aiBusy = 0;
    activityText = '';
    notes.clear();
    if (closing) return;
    closing = true;
    wipeSession();
    emitState();
  }
  async function closeBrowser() {
    const w = win;
    const v = view;
    win = null;
    view = null;
    try {
      const wc = v && v.webContents;
      if (wc && !wc.isDestroyed()) {
        try {
          wc.debugger.detach();
        } catch {}
        wc.close({ waitForBeforeUnload: false });
      }
    } catch {}
    try {
      if (w && !w.isDestroyed()) w.destroy();
    } catch {}
    teardown();
    await wipeSession();
  }

  // ── Hablar con la página (lector en el mundo aislado) ──────────────────────────────────────────────────────
  function callPage(op, args = {}, timeoutMs = 15000) {
    return new Promise((resolve, reject) => {
      const wc = viewWc();
      if (!wc) return reject(new Error('NO_PAGE'));
      const id = nextId++;
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error('TIMEOUT'));
      }, timeoutMs);
      pending.set(id, { resolve, reject, timer });
      try {
        wc.send('auric-browser:cmd', { id, op, args });
      } catch (err) {
        clearTimeout(timer);
        pending.delete(id);
        reject(err);
      }
    });
  }
  ipcMain.on('auric-browser:res', (e, msg) => {
    const wc = viewWc();
    if (!wc || e.sender !== wc || (e.senderFrame && e.senderFrame.parent)) return;
    const p = pending.get(msg?.id);
    if (!p) return;
    pending.delete(msg.id);
    clearTimeout(p.timer);
    if (msg.ok) p.resolve(msg.value);
    else p.reject(new Error(String(msg.error || 'Error de la página')));
  });
  const pageError = err => {
    const m = String(err?.message || err);
    if (m === 'TIMEOUT') return 'La página no responde (puede estar ocupada). Inténtalo otra vez, o ciérrala con browser_close y vuelve a abrirla.';
    if (m === 'NAVIGATED') return 'La página cambió mientras la leía. Vuelve a leerla con browser_read.';
    if (m === 'NO_PAGE' || m === 'CLOSED') return 'No hay una página abierta. Usa browser_open con una dirección.';
    if (m === 'CRASHED') return 'La página se cerró por un error interno. Ábrela de nuevo con browser_open.';
    return `No se pudo leer la página (${m}).`;
  };
  async function callPageRetry(op, args, timeoutMs) {
    try {
      return await callPage(op, args, timeoutMs);
    } catch (err) {
      if (String(err?.message) !== 'TIMEOUT' && String(err?.message) !== 'NAVIGATED') throw err;
      await sleep(250);
      return await callPage(op, args, timeoutMs);
    }
  }
  async function cdp(method, params = {}) {
    const wc = viewWc();
    if (!wc) throw new Error('NO_PAGE');
    if (!wc.debugger.isAttached()) wc.debugger.attach('1.3');
    return wc.debugger.sendCommand(method, params);
  }
  async function withAiInput(fn) {
    aiInput++;
    try {
      return await fn();
    } finally {
      setTimeout(() => (aiInput = Math.max(0, aiInput - 1)), 120).unref?.();
    }
  }
  const mouseClick = (x, y) =>
    withAiInput(async () => {
      await cdp('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none', buttons: 0 });
      await sleep(40);
      await cdp('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', buttons: 1, clickCount: 1 });
      await sleep(40);
      await cdp('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', buttons: 0, clickCount: 1 });
    });
  const keyPress = def =>
    withAiInput(async () => {
      const base = { key: def.key, code: def.code, windowsVirtualKeyCode: def.vk, nativeVirtualKeyCode: def.vk, modifiers: def.shift ? 8 : 0 };
      await cdp('Input.dispatchKeyEvent', { ...base, type: def.text ? 'keyDown' : 'rawKeyDown', text: def.text, unmodifiedText: def.text });
      await cdp('Input.dispatchKeyEvent', { ...base, type: 'keyUp' });
    });
  const typeText = text =>
    withAiInput(async () => {
      const chars = [...text];
      if (chars.length > 150) return cdp('Input.insertText', { text });
      for (const ch of chars) {
        if (ch === '\n') await keyPress(policy.KEYS.enter);
        else {
          await cdp('Input.dispatchKeyEvent', { type: 'keyDown', key: ch, text: ch, unmodifiedText: ch });
          await cdp('Input.dispatchKeyEvent', { type: 'keyUp', key: ch });
        }
      }
    });

  // ── Cargar y esperar ───────────────────────────────────────────────────────────────────────────────────────
  function waitLoaded(ms) {
    return new Promise(resolve => {
      const wc = viewWc();
      if (!wc) return resolve(false);
      if (!wc.isLoading() && !nav.active) return resolve(true);
      let timer;
      const check = () => {
        if (!wc.isDestroyed() && !wc.isLoading() && !nav.active) finish(true);
      };
      const finish = ok => {
        clearTimeout(timer);
        if (!wc.isDestroyed()) wc.removeListener('did-stop-loading', check);
        resolve(ok);
      };
      timer = setTimeout(() => finish(false), ms);
      wc.on('did-stop-loading', check);
    });
  }
  async function navigateTo(url) {
    const wc = viewWc();
    if (!wc) return fail('No hay ventana de navegador.');
    nav.error = null;
    nav.status = 0;
    const commitsBefore = nav.commits;
    let timedOut = false;
    try {
      await Promise.race([
        wc.loadURL(url),
        sleep(loadTimeoutMs).then(() => {
          timedOut = true;
        })
      ]);
    } catch (err) {
      // ERR_ABORTED: la página se redirigió sola o la persona navegó; lo que importa es dónde terminó.
      if (!/ERR_ABORTED/.test(String(err?.code || err?.message || ''))) nav.error = nav.error || { code: err?.errno || 0, desc: String(err?.code || err?.message || ''), url };
    }
    if (timedOut) {
      const secs = Math.max(1, Math.round(loadTimeoutMs / 1000));
      try {
        wc.stop();
      } catch {}
      // Si el sitio no llegó a responder nada, lo que se ve sigue siendo la página anterior: no se la presentamos como si fuera la nueva.
      if (nav.commits === commitsBefore) {
        await waitLoaded(2000);
        return fail(`El sitio no respondió a tiempo (esperé más de ${secs} segundos) y la página no se abrió. Puede estar caído o muy lento: prueba más tarde o con otra dirección.`);
      }
      note(`La página tardó más de ${secs} segundos en cargar; se muestra lo que alcanzó a llegar.`);
    }
    await waitLoaded(6000);
    // El motivo en cristiano + lo que Auric bloqueó por el camino (una redirección a tu red local, un salto a un archivo…).
    const failLoad = () => {
      const msg = policy.loadErrorMessage(nav.error.code, nav.error.desc, url);
      const why = takeNotes();
      return fail(why.length ? `${msg} ${why.join(' ')}` : msg);
    };
    if (nav.error && !hasPageUrl(wc.getURL())) return failLoad();
    if (!hasPageUrl(wc.getURL())) {
      const why = takeNotes();
      return fail(why.length ? `No se abrió la página. ${why.join(' ')}` : 'La página no se pudo abrir.');
    }
    if (nav.error && !timedOut) return failLoad();
    return { ok: true };
  }
  // waitNav: cuánto esperar a ver si la acción provoca un cambio de página (un clic sí suele; escribir en un campo casi nunca).
  async function settle(before, waitNav = 700) {
    const wc = viewWc();
    if (!wc) return;
    const t0 = Date.now();
    while (Date.now() - t0 < waitNav && nav.counter === before.nav && wc.getURL() === before.url) await sleep(50);
    if (nav.counter !== before.nav || wc.isLoading()) await waitLoaded(20000);
    try {
      await callPage('waitStable', { quietMs: 250, maxMs: 2500 }, 6000);
    } catch {}
  }

  // ── Permisos por sitio ─────────────────────────────────────────────────────────────────────────────────────
  function siteNeeds(p, sens, extra = {}) {
    return {
      type: 'site',
      url: p.url,
      key: p.key,
      host: p.unicodeHost || p.host,
      local: !!p.local,
      idn: !!p.idn,
      sensitive: sens ? { cat: sens.cat, why: sens.why, label: policy.CAT_LABEL[sens.cat] || '' } : null,
      ...extra
    };
  }
  function gateUrl(url) {
    const p = policy.parseUrl(url);
    if (!p.ok) return { error: p.error };
    const sens = policy.sensitiveUrl(p.url, extraSensitive);
    if (store.allowed(p.key, { sensitive: !!sens })) return { ok: true, p, sens };
    return { needs: siteNeeds(p, sens) };
  }
  // La página que hay ahora: ¿está permitido su sitio? (y si por sus campos resulta ser de pagos, ¿se confirmó?)
  async function gatePage() {
    const wc = viewWc();
    const url = wc ? wc.getURL() : '';
    if (!hasPageUrl(url)) return { fail: 'No hay una página abierta. Usa browser_open con una dirección.' };
    const p = policy.parseUrl(url);
    if (!p.ok) return { fail: p.error };
    let signals = {};
    try {
      signals = (await callPageRetry('signals', {}, 6000)) || {};
    } catch (err) {
      return { fail: pageError(err) };
    }
    const sens = policy.classifyPage({ url: p.url, signals, extra: extraSensitive });
    if (!store.allowed(p.key, { sensitive: !!sens })) return { needs: siteNeeds(p, sens) };
    return { ok: true, wc, url, p, sens };
  }
  function ownerCheck(ctx) {
    if (ctx.sessionId && owner && ctx.sessionId !== owner)
      return 'El navegador lo estaba usando otro chat. Abre la página con browser_open para usarlo desde este chat.';
    return '';
  }

  // ── Presentar la página al modelo ──────────────────────────────────────────────────────────────────────────
  function formatPage(snap, { sens = null, status = 0, extraNotes = [] } = {}) {
    const trusted = [];
    if (status >= 400) trusted.push(`Aviso: el sitio respondió con error HTTP ${status}.`);
    if (sens) trusted.push(`Aviso: esta página parece de ${policy.CAT_LABEL[sens.cat] || 'pagos o banca'} (${sens.why}). Cada acción pedirá confirmación a la persona.`);
    const sc = snap.scroll || { y: 0, vh: 1, total: 1, max: 0 };
    const pct = sc.max > 0 ? Math.round((sc.y / sc.max) * 100) : 0;
    const screens = Math.max(1, Math.ceil(sc.total / Math.max(1, sc.vh)));
    trusted.push(`Posición: ${pct} % de la página · pantalla ${Math.min(screens, Math.floor(sc.y / Math.max(1, sc.vh)) + 1)} de ${screens} · ${snap.refs} elementos con número (usa ese número en browser_click, browser_type o browser_select).`);
    let body = snap.text || (snap.mode === 'diff' ? '(sin cambios visibles en el texto)' : '(la página no muestra texto)');
    if (snap.next != null) body += `\n[… continúa: usa browser_read con offset=${snap.next}]`;
    if (snap.truncated) body += '\n[La página es enorme: solo se leyó una parte.]';
    const inside = `Página: ${policy.cleanLabel(snap.title, 160) || '(sin título)'}\nDirección: ${policy.cleanPageText(snap.url)}\n${snap.mode === 'diff' ? 'Cambios desde la última lectura:' : 'Contenido:'}\n${body}`;
    const extras = [...extraNotes, ...takeNotes()];
    return `${trusted.join('\n')}\n${policy.wrapPageText(inside)}${extras.length ? '\n' + extras.map(x => `Nota de Auric: ${x}`).join('\n') : ''}`;
  }
  // Después de una acción: si el sitio sigue permitido se enseña lo que cambió; si no, se retiene el contenido.
  async function afterAction(before, doneText, waitNav = 700) {
    await settle(before, waitNav);
    const wc = viewWc();
    if (!wc) return done(`${doneText}\nLa página se cerró.`);
    const url = wc.getURL();
    const urlChanged = url !== before.url;
    const g = await gatePage();
    if (g.fail) return done(`${doneText}\n${g.fail}`);
    if (g.needs) {
      return done(
        `${doneText}\n${urlChanged ? `La página ahora es ${policy.cleanLabel(url, 100)}. ` : ''}` +
          `No puedo leerla todavía: ${g.needs.sensitive ? 'parece de pagos o banca y la persona debe confirmarlo' : `el sitio ${g.needs.host} aún no está permitido`}. ` +
          'Usa browser_read para pedir el permiso.'
      );
    }
    let snap;
    try {
      snap = await callPageRetry('snapshot', urlChanged ? { maxChars: 3500 } : { diff: true, maxChars: 2500 }, 15000);
    } catch (err) {
      return done(`${doneText}\n${pageError(err)}`);
    }
    return done(`${doneText}\n${formatPage(snap, { sens: g.sens, status: urlChanged ? nav.status : 0 })}`);
  }
  const stamp = wc => ({ url: wc.getURL(), nav: nav.counter });

  // ── Decidir una acción de la IA ────────────────────────────────────────────────────────────────────────────
  async function authorize(op, pg, { el, text, submit, ref, ctx }) {
    const decision = policy.decideAction(op, { page: { sensitive: pg.sens }, el, text, submit, extra: extraSensitive });
    if (decision.action === 'refuse') return { out: fail(decision.message) };
    if (decision.action === 'confirm') {
      const binding = { op, ref: ref ?? null, key: pg.p.key, text: text == null ? '' : crypto.createHash('sha1').update(String(text)).digest('hex'), submit: !!submit };
      if (!ctx.confirm || !tokens.consume(ctx.confirm, binding)) {
        const what =
          op === 'click'
            ? `Hacer clic en ${policy.kindEs(el?.kind)} «${policy.cleanLabel(el?.label || '', 80)}»`
            : op === 'type'
              ? `Escribir ${String(text).length} caracteres en «${policy.cleanLabel(el?.label || '', 60)}»${submit ? ' y enviarlo' : ''}`
              : op === 'select'
                ? `Elegir una opción en «${policy.cleanLabel(el?.label || '', 60)}»`
                : `Pulsar la tecla ${text}`;
        return {
          out: {
            ok: false,
            needs: {
              type: 'action',
              op,
              key: pg.p.key,
              host: pg.p.unicodeHost || pg.p.host,
              reason: decision.reason,
              what,
              detail: op === 'type' ? `Texto: «${policy.cleanLabel(text, 120)}»` : '',
              token: tokens.issue(binding)
            }
          }
        };
      }
    }
    return { ok: true };
  }
  const missingRef = ref => fail(`El número #${ref} ya no existe en la página (la página cambió). Usa browser_read para ver los números actuales.`);
  const cleanRef = args => {
    const n = Math.round(Number(args?.ref));
    return Number.isFinite(n) && n > 0 && n < 1e6 ? n : 0;
  };

  // ── Operaciones ────────────────────────────────────────────────────────────────────────────────────────────
  const OPS = {
    async open(args, ctx) {
      const g = gateUrl(args.url);
      if (g.error) return fail(g.error);
      if (g.needs) return { ok: false, needs: g.needs };
      await ensureWindow({ show: true });
      owner = ctx.sessionId || owner;
      setActivity(`Abriendo ${policy.cleanLabel(g.p.url, 80)}…`);
      const r = await navigateTo(g.p.url);
      if (!r.ok) return r;
      const pg = await gatePage();
      if (pg.fail) return fail(pg.fail);
      if (pg.needs) return { ok: false, needs: { ...pg.needs, redirected: g.p.key !== pg.needs.key } };
      let snap;
      try {
        snap = await callPageRetry('snapshot', { maxChars: clampInt(args.maxChars, 1000, 30000, 6000) }, 20000);
      } catch (err) {
        return fail(pageError(err));
      }
      return done(formatPage(snap, { sens: pg.sens, status: nav.status }));
    },
    async read(args, ctx) {
      const bad = ownerCheck(ctx);
      if (bad) return fail(bad);
      const pg = await gatePage();
      if (pg.fail) return fail(pg.fail);
      if (pg.needs) return { ok: false, needs: pg.needs };
      setActivity('Leyendo la página…');
      let snap;
      try {
        snap = await callPageRetry('snapshot', { offset: clampInt(args.offset, 0, 5e6, 0), maxChars: clampInt(args.maxChars, 1000, 30000, 6000) }, 20000);
      } catch (err) {
        return fail(pageError(err));
      }
      return done(formatPage(snap, { sens: pg.sens, status: 0 }));
    },
    async click(args, ctx) {
      const bad = ownerCheck(ctx);
      if (bad) return fail(bad);
      const ref = cleanRef(args);
      if (!ref) return fail('Falta el número del elemento (el que aparece como [#n] al leer la página).');
      const pg = await gatePage();
      if (pg.fail) return fail(pg.fail);
      if (pg.needs) return { ok: false, needs: pg.needs };
      let d;
      try {
        d = await callPageRetry('describe', { ref }, 8000);
      } catch (err) {
        return fail(pageError(err));
      }
      if (d.missing) return missingRef(ref);
      if (d.kind === 'select') return fail('Es una lista desplegable: usa browser_select con su número y la opción que quieres.');
      const auth = await authorize('click', pg, { el: d, ref, ctx });
      if (auth.out) return auth.out;
      let prep;
      try {
        prep = await callPageRetry('prepareClick', { ref }, 8000);
      } catch (err) {
        return fail(pageError(err));
      }
      if (prep.missing) return missingRef(ref);
      if (prep.hidden) return fail('Ese elemento no se ve en la página (no se puede hacer clic).');
      if (prep.covered) return fail(`No se pudo hacer clic: ${prep.covered} lo tapa. Cierra ese aviso o ventana (o desplázate) y vuelve a leer la página.`);
      setActivity(`Haciendo clic en «${policy.cleanLabel(d.label, 50)}»…`);
      const before = stamp(pg.wc);
      try {
        await mouseClick(prep.x, prep.y);
      } catch (err) {
        return fail(pageError(err));
      }
      return afterAction(before, `Clic hecho en #${ref} (${policy.kindEs(d.kind)} «${policy.cleanLabel(d.label, 60)}»).`);
    },
    async type(args, ctx) {
      const bad = ownerCheck(ctx);
      if (bad) return fail(bad);
      const ref = cleanRef(args);
      if (!ref) return fail('Falta el número del campo (el que aparece como [#n] al leer la página).');
      let text = String(args.text ?? '');
      if (text.length > 5000) return fail('El texto es demasiado largo (máximo 5000 caracteres).');
      const submit = args.submit === true || args.submit === 'true';
      const clear = !(args.clear === false || args.clear === 'false');
      const pg = await gatePage();
      if (pg.fail) return fail(pg.fail);
      if (pg.needs) return { ok: false, needs: pg.needs };
      let d;
      try {
        d = await callPageRetry('describe', { ref }, 8000);
      } catch (err) {
        return fail(pageError(err));
      }
      if (d.missing) return missingRef(ref);
      const auth = await authorize('type', pg, { el: d, text, submit, ref, ctx });
      if (auth.out) return auth.out;
      if (d.tag === 'input') text = text.replace(/[\r\n]+/g, ' ');
      text = text.replace(/\t/g, '  ');
      let f;
      try {
        f = await callPageRetry('focusField', { ref, clear }, 8000);
      } catch (err) {
        return fail(pageError(err));
      }
      if (f.missing) return missingRef(ref);
      if (!f.focused) return fail('No se pudo poner el cursor en ese campo (¿está tapado o desactivado?).');
      setActivity(`Escribiendo en «${policy.cleanLabel(d.label, 50)}»…`);
      const before = stamp(pg.wc);
      try {
        if (text) await typeText(text);
        else if (clear) await keyPress(policy.KEYS.backspace);
        if (submit) await keyPress(policy.KEYS.enter);
      } catch (err) {
        return fail(pageError(err));
      }
      let valueNote = '';
      try {
        const v = await callPage('fieldValue', { ref }, 5000);
        valueNote = v.hidden ? '' : ` Ahora contiene: «${policy.cleanLabel(v.value, 120)}».`;
      } catch {}
      return afterAction(before, `Escribí en #${ref} (${policy.kindEs(d.kind)} «${policy.cleanLabel(d.label, 60)}»).${valueNote}${submit ? ' Pulsé Enter para enviarlo.' : ''}`, submit ? 700 : 120);
    },
    async select(args, ctx) {
      const bad = ownerCheck(ctx);
      if (bad) return fail(bad);
      const ref = cleanRef(args);
      if (!ref) return fail('Falta el número de la lista (el que aparece como [#n] al leer la página).');
      const value = String(args.value ?? args.option ?? '');
      if (!value) return fail('Falta la opción que quieres elegir (su texto o su valor).');
      const pg = await gatePage();
      if (pg.fail) return fail(pg.fail);
      if (pg.needs) return { ok: false, needs: pg.needs };
      let d;
      try {
        d = await callPageRetry('describe', { ref }, 8000);
      } catch (err) {
        return fail(pageError(err));
      }
      if (d.missing) return missingRef(ref);
      if (d.kind !== 'select') return fail('Ese elemento no es una lista desplegable.');
      const auth = await authorize('select', pg, { el: d, text: value, ref, ctx });
      if (auth.out) return auth.out;
      setActivity(`Eligiendo «${policy.cleanLabel(value, 40)}»…`);
      const before = stamp(pg.wc);
      let r;
      try {
        r = await callPageRetry('selectOption', { ref, value }, 8000);
      } catch (err) {
        return fail(pageError(err));
      }
      if (r.missing) return missingRef(ref);
      if (r.notFound) return fail(`No encontré esa opción. Opciones: ${(r.options || []).map(o => policy.cleanLabel(o, 50)).join(' | ')}`);
      if (r.disabled) return fail('Esa opción está desactivada.');
      return afterAction(before, `Elegí «${policy.cleanLabel(r.selected, 60)}» en #${ref} («${policy.cleanLabel(d.label, 50)}»).`, 450);
    },
    async press(args, ctx) {
      const bad = ownerCheck(ctx);
      if (bad) return fail(bad);
      const def = policy.normalizeKey(args.key);
      if (!def) return fail(`Tecla no permitida. Puedes usar: ${policy.KEY_NAMES.join(', ')}.`);
      const pg = await gatePage();
      if (pg.fail) return fail(pg.fail);
      if (pg.needs) return { ok: false, needs: pg.needs };
      let active = {};
      try {
        active = await callPageRetry('activeInfo', {}, 6000);
      } catch (err) {
        return fail(pageError(err));
      }
      const el = active && !active.none ? active : null;
      // Enter envía el formulario del campo activo: se trata como «enviar».
      const auth = await authorize('press', pg, { el: def.name === 'enter' ? el : el ? { ...el, submitLabel: '' } : null, text: def.key, ctx });
      if (auth.out) return auth.out;
      setActivity(`Pulsando ${def.key}…`);
      const before = stamp(pg.wc);
      try {
        await keyPress(def);
      } catch (err) {
        return fail(pageError(err));
      }
      return afterAction(before, `Tecla ${def.key} pulsada.`);
    },
    async scroll(args, ctx) {
      const bad = ownerCheck(ctx);
      if (bad) return fail(bad);
      const dir = String(args.direction || 'down').toLowerCase();
      if (!['down', 'up', 'top', 'bottom'].includes(dir)) return fail('direction debe ser down, up, top o bottom.');
      const pg = await gatePage();
      if (pg.fail) return fail(pg.fail);
      if (pg.needs) return { ok: false, needs: pg.needs };
      setActivity('Desplazando la página…');
      let before;
      try {
        before = await callPageRetry('scrollInfo', {}, 5000);
        if (dir === 'top' || dir === 'bottom') await callPage('scrollTo', { where: dir }, 5000);
        else {
          const px = clampInt(args.amount, 50, 6000, Math.round(before.vh * 0.85)) * (dir === 'up' ? -1 : 1);
          await withAiInput(() => cdp('Input.dispatchMouseEvent', { type: 'mouseWheel', x: Math.round(before.vw / 2), y: Math.round(before.vh / 2), deltaX: 0, deltaY: px }));
          await sleep(260);
        }
        await callPage('waitStable', { quietMs: 200, maxMs: 1800 }, 4000).catch(() => {});
      } catch (err) {
        return fail(pageError(err));
      }
      let snap;
      try {
        snap = await callPageRetry('snapshot', { diff: true, maxChars: 2500 }, 15000);
      } catch (err) {
        return fail(pageError(err));
      }
      const moved = snap.scroll.y !== before.y;
      const atEnd = snap.scroll.y >= snap.scroll.max - 2;
      const lead = moved ? 'Me desplacé.' : dir === 'up' || dir === 'top' ? 'No se movió: ya estás al principio de la página.' : 'No se movió: ya estás al final de la página.';
      return done(`${lead}${atEnd && moved ? ' Llegué al final.' : ''}\n${formatPage(snap, { sens: pg.sens })}`);
    },
    async nav(args, ctx) {
      const bad = ownerCheck(ctx);
      if (bad) return fail(bad);
      const wc = viewWc();
      if (!wc || !hasPageUrl(wc.getURL())) return fail('No hay una página abierta. Usa browser_open con una dirección.');
      const action = String(args.action || '').toLowerCase();
      const h = history(wc);
      if (action === 'back' && !h.back) return fail('No hay una página anterior en el historial.');
      if (action === 'forward' && !h.forward) return fail('No hay una página siguiente en el historial.');
      if (!['back', 'forward', 'reload'].includes(action)) return fail('action debe ser back, forward o reload.');
      setActivity(action === 'back' ? 'Volviendo a la página anterior…' : action === 'forward' ? 'Yendo a la página siguiente…' : 'Recargando…');
      const before = stamp(wc);
      if (action === 'back') wc.navigationHistory.goBack();
      else if (action === 'forward') wc.navigationHistory.goForward();
      else wc.reload();
      await settle(before);
      const pg = await gatePage();
      if (pg.fail) return fail(pg.fail);
      if (pg.needs) return { ok: false, needs: pg.needs };
      let snap;
      try {
        snap = await callPageRetry('snapshot', { maxChars: 4000 }, 15000);
      } catch (err) {
        return fail(pageError(err));
      }
      return done(formatPage(snap, { sens: pg.sens, status: nav.status }));
    },
    async capture(args, ctx) {
      const bad = ownerCheck(ctx);
      if (bad) return fail(bad);
      const pg = await gatePage();
      if (pg.fail) return fail(pg.fail);
      if (pg.needs) return { ok: false, needs: pg.needs };
      setActivity('Sacando una captura…');
      await ensureWindow({ show: true });
      try {
        let img = await pg.wc.capturePage();
        let { width, height } = img.getSize();
        if (!width || !height) return fail('La captura salió vacía (¿la ventana está minimizada?).');
        if (width > 1280) {
          img = img.resize({ width: 1280, quality: 'good' });
          ({ width, height } = img.getSize());
        }
        const jpeg = img.toJPEG(82);
        return { ok: true, text: `Captura de la ventana del navegador (${width}×${height}). Mira la imagen adjunta. Página: ${policy.cleanLabel(await pg.wc.getTitle(), 100)}.`, image: { base64: jpeg.toString('base64'), mime: 'image/jpeg', width, height } };
      } catch (err) {
        return fail(`No se pudo sacar la captura (${String(err?.message || err).slice(0, 120)}).`);
      }
    },
    async close() {
      await closeBrowser();
      return done('Navegador cerrado. La sesión y todo lo que guardaron las páginas se borraron.');
    },
    async status() {
      return { ok: true, ...publicState() };
    }
  };

  async function run(op, args, ctx) {
    if (!Object.prototype.hasOwnProperty.call(OPS, op)) return fail('Operación de navegador desconocida.');
    if (ctx.enabled === false) return fail('El navegador de la IA está desactivado en Configuración → Navegador.');
    return enqueue(async () => {
      extraSensitive = ctx.extraSensitive;
      if (paused && op !== 'close' && op !== 'status') return { ok: false, paused: true, error: 'La persona pausó el control de la IA en la ventana del navegador. Pídele que pulse «Reanudar IA» para seguir.' };
      aiBusy++;
      pushUI();
      try {
        return await OPS[op](args, ctx);
      } catch (err) {
        return fail(`Error del navegador: ${String(err?.message || err).slice(0, 200)}`);
      } finally {
        aiBusy = Math.max(0, aiBusy - 1);
        if (!aiBusy) activityText = '';
        pushUI();
      }
    });
  }
  function enqueue(fn) {
    const p = queue.then(fn, fn);
    queue = p.catch(() => {});
    return p;
  }

  // ── Comentarios de la persona ──────────────────────────────────────────────────────────────────────────────
  async function startComment() {
    if (!viewWc()) return;
    commentMode = true;
    commentPick = null;
    panelOpen = false;
    layout();
    try {
      await callPage('pickStart', {}, 5000);
    } catch {
      commentMode = false;
      win?.webContents.send('auric-browser-ui:toast', 'Abre primero una página para poder comentarla.');
    }
    pushUI();
  }
  async function cancelComment() {
    commentMode = false;
    commentPick = null;
    panelOpen = false;
    layout();
    try {
      await callPage('pickStop', {}, 3000);
      await callPage('pickClear', {}, 3000);
    } catch {}
    pushUI();
  }
  const isUi = e => !!(win && !win.isDestroyed() && e.sender === win.webContents);
  const isPage = e => {
    const wc = viewWc();
    return !!(wc && e.sender === wc && !(e.senderFrame && e.senderFrame.parent));
  };
  const cut = (v, n) => String(v == null ? '' : v).slice(0, n);
  ipcMain.on('auric-browser:pick', (e, info) => {
    if (!isPage(e) || !commentMode) return;
    commentPick = {
      tag: cut(info?.tag, 20),
      kind: cut(info?.kind, 20),
      ref: Number(info?.ref) > 0 ? Number(info.ref) : 0,
      label: policy.cleanLabel(info?.label, 120),
      text: policy.cleanLabel(info?.text, 220),
      href: policy.cleanLabel(info?.href, 160),
      hint: policy.cleanLabel(info?.hint, 90),
      url: cut(info?.url, 600),
      title: policy.cleanLabel(info?.title, 160)
    };
    panelOpen = true;
    layout();
    pushUI();
  });
  ipcMain.on('auric-browser:pick-cancel', e => {
    if (!isPage(e)) return;
    commentMode = false;
    commentPick = null;
    panelOpen = false;
    layout();
    pushUI();
  });
  async function saveCommentImage() {
    const wc = viewWc();
    if (!wc) return null;
    try {
      let img = await wc.capturePage();
      const s = img.getSize();
      if (!s.width || !s.height) return null;
      if (s.width > 1280) img = img.resize({ width: 1280, quality: 'good' });
      const dir = path.join(userData, 'generated');
      await fsp.mkdir(dir, { recursive: true });
      const file = path.join(dir, `navegador-comentario-${Date.now()}.jpg`);
      const buf = img.toJPEG(82);
      await fsp.writeFile(file, buf);
      return { path: file, name: path.basename(file), size: buf.length, mime: 'image/jpeg' };
    } catch {
      return null;
    }
  }
  async function sendComment(text) {
    const body = String(text || '').trim().slice(0, 4000);
    if (!body || !commentPick) return;
    const pick = commentPick;
    const wc = viewWc();
    const image = await saveCommentImage(); // sale con el elemento resaltado
    emitMain('browser-comment', {
      text: body,
      owner,
      page: { url: wc ? wc.getURL() : pick.url, title: wc ? wc.getTitle() : pick.title },
      element: { kind: policy.kindEs(pick.kind, ''), ref: pick.ref, label: pick.label, text: pick.text, href: pick.href, hint: pick.hint },
      image
    });
    await cancelComment();
    win?.webContents.send('auric-browser-ui:toast', 'Comentario enviado al chat de Auric.');
  }

  // ── Barra del navegador (confianza: página local) ──────────────────────────────────────────────────────────
  ipcMain.on('auric-browser-ui:ready', e => isUi(e) && pushUI());
  ipcMain.on('auric-browser-ui:go', (e, text) => {
    if (!isUi(e)) return;
    const wc = viewWc();
    if (!wc) return;
    const p = policy.parseUrl(text);
    if (!p.ok) return win?.webContents.send('auric-browser-ui:toast', p.error);
    wc.loadURL(p.url).catch(() => {});
  });
  ipcMain.on('auric-browser-ui:nav', (e, action) => {
    if (!isUi(e)) return;
    const wc = viewWc();
    if (!wc) return;
    if (action === 'back' && history(wc).back) wc.navigationHistory.goBack();
    else if (action === 'forward' && history(wc).forward) wc.navigationHistory.goForward();
    else if (action === 'reload') wc.reload();
    else if (action === 'stop') wc.stop();
  });
  ipcMain.on('auric-browser-ui:pause', e => {
    if (!isUi(e)) return;
    paused = !paused;
    pushUI();
    emitState();
  });
  ipcMain.on('auric-browser-ui:comment-toggle', e => {
    if (!isUi(e)) return;
    commentMode ? cancelComment() : startComment();
  });
  ipcMain.on('auric-browser-ui:comment-cancel', e => isUi(e) && cancelComment());
  ipcMain.on('auric-browser-ui:comment-send', (e, text) => isUi(e) && sendComment(text));

  // ── Llamadas desde Auric (solo la ventana principal) ───────────────────────────────────────────────────────
  const assertMain = e => {
    const w = getWindow?.();
    if (!w || w.isDestroyed() || e.sender !== w.webContents) throw new Error('Llamada no permitida.');
  };
  const cleanCtx = ctx => ({
    sessionId: cut(ctx?.sessionId, 80),
    enabled: ctx?.enabled !== false,
    confirm: cut(ctx?.confirm, 64),
    extraSensitive: Array.isArray(ctx?.extraSensitive) ? ctx.extraSensitive.slice(0, 50).map(x => cut(x, 100).toLowerCase()).filter(Boolean) : []
  });
  ipcMain.handle('auric:browser-run', async (e, op, args, ctx) => {
    try {
      assertMain(e);
      return await run(String(op || ''), args && typeof args === 'object' ? args : {}, cleanCtx(ctx));
    } catch (err) {
      return fail(String(err?.message || err));
    }
  });
  ipcMain.handle('auric:browser-grant', (e, spec) => {
    try {
      assertMain(e);
      const p = policy.parseUrl(spec?.url);
      if (!p.ok) return fail(p.error);
      const extra = cleanCtx({ extraSensitive: spec?.extraSensitive }).extraSensitive;
      // El permiso «sensible» lo decide Auric (la dirección) o lo pide la propia página (campos de tarjeta); la ventana solo puede ponerlo más estricto.
      const sens = !!policy.sensitiveUrl(p.url, extra) || spec?.sensitive === true;
      // Una dirección de tu propio computador o red nunca queda permitida «para siempre» (mañana ese puerto puede ser otro programa).
      const granted = store.grant(p.key, spec?.scope === 'always' && !p.local ? 'always' : 'session', { sensitive: sens });
      pushUI();
      emitState();
      return { ok: true, granted, key: p.key };
    } catch (err) {
      return fail(String(err?.message || err));
    }
  });
  ipcMain.handle('auric:browser-sites', e => {
    try {
      assertMain(e);
      return { ok: true, ...publicState() };
    } catch (err) {
      return fail(String(err?.message || err));
    }
  });
  ipcMain.handle('auric:browser-forget', (e, key) => {
    try {
      assertMain(e);
      const r = store.revoke(cut(key, 300));
      pushUI();
      emitState();
      return { ok: true, removed: r };
    } catch (err) {
      return fail(String(err?.message || err));
    }
  });
  ipcMain.handle('auric:browser-show', async e => {
    try {
      assertMain(e);
      await ensureWindow({ show: true, focus: true });
      return { ok: true };
    } catch (err) {
      return fail(String(err?.message || err));
    }
  });
  ipcMain.handle('auric:browser-close', async e => {
    try {
      assertMain(e);
      await closeBrowser();
      return { ok: true };
    } catch (err) {
      return fail(String(err?.message || err));
    }
  });

  app.on('before-quit', () => {
    try {
      if (win && !win.isDestroyed()) win.destroy();
    } catch {}
  });
  if (e2e)
    global.__auricBrowserTest = {
      store,
      tokens,
      state: () => ({ win, view, nav, paused, owner, commentMode, commentPick, panelOpen }),
      callPage,
      uiState,
      policy
    };
  return { store, run, closeBrowser };
}

module.exports = { register, TOP_H, PANEL_H };
