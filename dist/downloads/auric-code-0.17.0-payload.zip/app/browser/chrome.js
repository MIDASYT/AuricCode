'use strict';
// Barra del navegador de Auric. Todo texto que viene de una página (título, dirección) se pone con textContent, nunca como HTML.
(function () {
  const $ = id => document.getElementById(id);
  const api = window.auricBrowserUI;
  const el = {
    back: $('back'), forward: $('forward'), reload: $('reload'), reloadIcon: $('reloadIcon'), stopIcon: $('stopIcon'),
    form: $('addrForm'), addr: $('addr'), lock: $('lock'), comment: $('commentBtn'), pause: $('pauseBtn'), pauseText: $('pauseText'),
    dot: $('dot'), ai: $('aiText'), perm: $('permText'), progress: $('progress'), panel: $('panel'), pickInfo: $('pickInfo'),
    text: $('commentText'), send: $('commentSend'), cancel: $('commentCancel'), toast: $('toast')
  };
  let state = {};
  let editing = false;
  let toastTimer = 0;

  function show(s) {
    state = s || {};
    el.back.disabled = !state.canGoBack;
    el.forward.disabled = !state.canGoForward;
    el.reloadIcon.classList.toggle('hidden', !!state.loading);
    el.stopIcon.classList.toggle('hidden', !state.loading);
    el.reload.title = state.loading ? 'Detener' : 'Recargar (F5)';
    el.progress.classList.toggle('on', !!state.loading || !!(state.ai && state.ai.busy));
    if (!editing && document.activeElement !== el.addr) el.addr.value = state.url || '';
    const https = /^https:/i.test(state.url || '');
    el.lock.className = 'lock ' + (https ? 'ok' : state.url ? 'warn' : '');
    el.lock.title = https ? 'Conexión cifrada (https)' : state.url ? 'Conexión sin cifrar (http)' : '';
    el.pauseText.textContent = state.paused ? 'Reanudar IA' : 'Pausar IA';
    el.pause.classList.toggle('on', !!state.paused);
    el.comment.classList.toggle('on', !!state.commentMode);
    const ai = state.ai || {};
    el.dot.className = 'dot' + (state.paused ? ' paused' : ai.busy ? ' busy' : '');
    el.ai.textContent = state.paused
      ? 'IA en pausa: tú controlas esta ventana.'
      : ai.busy
        ? ai.text || 'La IA está trabajando en esta página…'
        : state.commentMode && !state.pick
          ? 'Haz clic en lo que quieras comentar (Esc para cancelar).'
          : state.hasPage
            ? 'La IA puede usar esta página cuando se lo pidas.'
            : 'La IA no está usando el navegador.';
    const perm = state.perm || {};
    el.perm.textContent = perm.text || '';
    el.perm.className = 'perm ' + (perm.kind || '');
    el.perm.classList.toggle('hidden', !perm.text);
    el.panel.classList.toggle('hidden', !state.pick);
    if (state.pick) {
      const p = state.pick;
      el.pickInfo.textContent = ('Elemento: ' + (p.kind && p.kind !== 'other' ? p.kind + ' ' : '') + (p.label || p.hint || p.tag || '')).slice(0, 140);
      if (!el.text.dataset.open) {
        el.text.dataset.open = '1';
        el.text.value = '';
        setTimeout(() => el.text.focus(), 30);
      }
    } else delete el.text.dataset.open;
  }
  function toast(t) {
    el.toast.textContent = t;
    el.toast.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.add('hidden'), 3600);
  }

  el.back.onclick = () => api.nav('back');
  el.forward.onclick = () => api.nav('forward');
  el.reload.onclick = () => api.nav(state.loading ? 'stop' : 'reload');
  el.pause.onclick = () => api.togglePause();
  el.comment.onclick = () => api.toggleComment();
  el.cancel.onclick = () => api.cancelComment();
  el.send.onclick = () => {
    const t = el.text.value.trim();
    if (!t) return toast('Escribe tu comentario antes de enviarlo.');
    api.sendComment(t);
  };
  el.text.addEventListener('keydown', e => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) el.send.click();
    if (e.key === 'Escape') el.cancel.click();
  });
  el.form.addEventListener('submit', e => {
    e.preventDefault();
    editing = false;
    api.go(el.addr.value);
    el.addr.blur();
  });
  el.addr.addEventListener('focus', () => {
    editing = true;
    el.addr.select();
  });
  el.addr.addEventListener('blur', () => {
    editing = false;
    el.addr.value = state.url || '';
  });
  window.addEventListener('keydown', e => {
    if (e.key === 'Escape' && state.commentMode) api.cancelComment();
  });
  api.onFocusAddress(() => el.addr.focus());
  api.onToast(toast);
  api.onState(show);
})();
