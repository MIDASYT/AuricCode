'use strict';
// Navegador de la IA — lector y «manos» de la página.
// Corre en un mundo AISLADO de la página (contextIsolation): el código del sitio no puede verlo, llamarlo ni cambiar sus funciones.
// No expone nada a la página (no hay contextBridge). Solo el proceso principal le habla, por el canal interno `auric-browser:cmd`.
// Todo lo que sale de aquí es TEXTO que el proceso principal presenta al modelo como contenido de fuera (nunca como órdenes).
const { ipcRenderer } = require('electron');

if (window.top === window) {
  // Misma expresión que policy.js (SECRET_NAME_SOURCE): una prueba comprueba que no se separen.
  const SECRET_NAME_SOURCE =
    '(pass(?!enger)(word|wd|phrase|code)?|contrase[ñn]a|clave|\\bpin\\b|cvv|cvc|csc|cvn|security.?code|c[oó]digo.?de.?seguridad|card.?(number|num|no)|cc.?(number|num|exp|csc|cvc|name)|n[uú]mero.?de.?tarjeta|tarjeta|\\botp\\b|one.?time|verification.?code|c[oó]digo.?de.?verificaci[oó]n|\\btoken\\b|2fa|mfa|totp|secret|credit.?card)';
  const SECRET_NAME_RE = new RegExp(SECRET_NAME_SOURCE, 'i');
  const SECRET_AUTOCOMPLETE_RE = /(^|\s)(current-password|new-password|one-time-code|cc-[a-z-]+)(\s|$)/i;
  // Qué tipo de dato secreto es (solo sirve para avisar mejor): «cc» suelto no cuenta, porque aparece dentro de «acceso», «account»…
  const CARD_KIND_RE = /tarjeta|credit.?card|(^|[^a-z])card|(^|[^a-z])cc([^a-z]|$)|(^|[^a-z])cc.?(number|num|exp|csc|cvc|name)|cvv|cvc|csc|cvn/i;

  const MAX_NODES = 40000;
  const MAX_CHARS = 400000;
  const MAX_DEPTH = 140;
  const SKIP = new Set([
    'SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'HEAD', 'META', 'LINK', 'TITLE', 'BASE', 'OBJECT', 'EMBED', 'APPLET', 'AREA', 'MAP', 'PARAM',
    'SOURCE', 'TRACK', 'DATALIST', 'OPTION', 'OPTGROUP', 'SVG', 'svg', 'MATH', 'math'
  ]);
  const ROLE_KIND = {
    button: 'button', link: 'link', checkbox: 'checkbox', radio: 'radio', switch: 'checkbox', tab: 'tab', menuitem: 'menuitem',
    menuitemcheckbox: 'menuitem', menuitemradio: 'menuitem', option: 'option', combobox: 'field', textbox: 'field', searchbox: 'field',
    slider: 'slider', treeitem: 'menuitem'
  };
  const KIND_ES = {
    link: 'enlace', button: 'botón', field: 'campo', textarea: 'área de texto', select: 'lista', checkbox: 'casilla', radio: 'opción', file: 'selector de archivo',
    slider: 'control deslizante', tab: 'pestaña', menuitem: 'elemento de menú', option: 'opción', summary: 'desplegable', editor: 'editor de texto', clickable: 'elemento clicable'
  };

  let nextRef = 1;
  const refToEl = new Map(); // número -> WeakRef(elemento)
  const elToRef = new WeakMap();
  let prevLines = null;

  const clip = (s, n) => {
    s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
  };
  const q = s => String(s).replace(/"/g, "'");
  // Igual que clip, pero deja visibles los saltos de línea (⏎): así la IA puede comprobar lo que escribió en un área de texto o un editor.
  const clipLines = (s, n) => clip(String(s == null ? '' : s).replace(/\r/g, '').replace(/[ \t]*\n[ \t]*/g, ' ⏎ '), n);
  const textOf = el => (el.value != null ? el.value : el.innerText != null ? el.innerText : el.textContent);

  // ── Color y visibilidad (lo que una persona NO ve, la IA tampoco lo lee) ─────────────────────────────────
  function parseColor(str) {
    const m = /^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+%?))?\s*\)$/i.exec(String(str || '').trim());
    if (!m) return null;
    let a = m[4] == null ? 1 : m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
    if (!Number.isFinite(a)) a = 1;
    return { r: +m[1], g: +m[2], b: +m[3], a };
  }
  const bgCache = new WeakMap();
  // Color de fondo sólido detrás de un elemento; null = no se sabe (imagen, degradado…).
  function solidBackground(el) {
    let cur = el;
    for (let i = 0; i < 14 && cur && cur.nodeType === 1; i++) {
      if (bgCache.has(cur)) return bgCache.get(cur);
      const cs = getComputedStyle(cur);
      if (cs.backgroundImage && cs.backgroundImage !== 'none') return null;
      const c = parseColor(cs.backgroundColor);
      if (c && c.a > 0.9) return c;
      if (c && c.a > 0.05) return null;
      cur = cur.parentElement || (cur.getRootNode && cur.getRootNode().host) || null;
    }
    return { r: 255, g: 255, b: 255, a: 1 }; // el lienzo por defecto
  }
  function textInvisible(el, cs) {
    const c = parseColor(cs.color);
    if (!c) return false;
    if (c.a < 0.1) return true;
    const fill = parseColor(cs.webkitTextFillColor);
    if (fill && fill.a < 0.1) return true;
    const bg = solidBackground(el);
    if (!bg) return false;
    return Math.abs(c.r - bg.r) + Math.abs(c.g - bg.g) + Math.abs(c.b - bg.b) <= 12;
  }
  function hiddenByStyle(el, cs) {
    if (cs.display === 'none') return true;
    if (cs.visibility === 'hidden' || cs.visibility === 'collapse') return true;
    if (parseFloat(cs.opacity) < 0.05) return true;
    if (parseFloat(cs.fontSize) === 0) return true;
    if (cs.clipPath && /inset\((?:50|100)%/.test(cs.clipPath)) return true;
    if (cs.clip && /rect\(\s*0(px)?[,\s]+0(px)?[,\s]+0(px)?[,\s]+0(px)?\s*\)/.test(cs.clip)) return true;
    const ti = parseFloat(cs.textIndent);
    if (Number.isFinite(ti) && ti <= -900) return true;
    if (cs.display === 'contents') return false;
    const pos = cs.position;
    if (pos === 'absolute' || pos === 'fixed' || cs.overflow !== 'visible') {
      const r = el.getBoundingClientRect();
      if ((r.width <= 1 || r.height <= 1) && cs.overflow !== 'visible') return true;
      if (r.width > 0 && r.right + window.scrollX < -5) return true;
      if (r.height > 0 && r.bottom + window.scrollY < -5) return true;
    }
    return false;
  }

  // ── Elementos con los que se puede actuar ───────────────────────────────────────────────────────────────────
  function inputKind(el) {
    const t = String(el.type || 'text').toLowerCase();
    if (t === 'hidden') return null;
    if (t === 'submit' || t === 'button' || t === 'reset' || t === 'image') return 'button';
    if (t === 'checkbox') return 'checkbox';
    if (t === 'radio') return 'radio';
    if (t === 'file') return 'file';
    if (t === 'range') return 'slider';
    return 'field';
  }
  function interactiveKind(el, cs) {
    const tag = el.localName;
    if (tag === 'a') return el.hasAttribute('href') ? 'link' : (el.hasAttribute('role') && ROLE_KIND[el.getAttribute('role').toLowerCase()]) || null;
    if (tag === 'button') return 'button';
    if (tag === 'input') return inputKind(el);
    if (tag === 'textarea') return 'textarea';
    if (tag === 'select') return 'select';
    if (tag === 'summary') return 'summary';
    const role = (el.getAttribute('role') || '').toLowerCase();
    if (role && ROLE_KIND[role]) return ROLE_KIND[role];
    if (el.isContentEditable && el.getAttribute('contenteditable') !== null && el.getAttribute('contenteditable') !== 'false') return 'editor';
    if (el.hasAttribute('onclick') || (el.tabIndex >= 0 && cs.cursor === 'pointer')) return 'clickable';
    return null;
  }
  function textOfIds(ids) {
    return String(ids || '')
      .split(/\s+/)
      .map(id => (id ? document.getElementById(id) : null))
      .filter(Boolean)
      .map(n => n.textContent)
      .join(' ');
  }
  function labelOf(el, kind) {
    const aria = el.getAttribute('aria-label');
    if (aria && aria.trim()) return clip(aria, 90);
    const by = el.getAttribute('aria-labelledby');
    if (by) {
      const t = clip(textOfIds(by), 90);
      if (t) return t;
    }
    if (kind === 'field' || kind === 'textarea' || kind === 'select' || kind === 'checkbox' || kind === 'radio' || kind === 'file' || kind === 'slider') {
      if (el.labels && el.labels.length) {
        const t = clip([...el.labels].map(l => l.textContent).join(' '), 90);
        if (t) return t;
      }
      const ph = el.getAttribute('placeholder');
      if (ph && ph.trim()) return clip(ph, 90);
    }
    if (el.localName === 'input' && kind === 'button') {
      const v = el.value || el.getAttribute('alt');
      if (v) return clip(v, 90);
    }
    let t = clip(el.innerText != null ? el.innerText : el.textContent, 90);
    if (!t) {
      const img = el.querySelector && el.querySelector('img[alt]');
      if (img && img.alt) t = clip(img.alt, 90);
    }
    if (!t) t = clip(el.getAttribute('title') || el.getAttribute('alt') || el.getAttribute('name') || el.getAttribute('data-testid') || '', 90);
    if (!t && el.querySelector) {
      const svgt = el.querySelector('svg title');
      if (svgt) t = clip(svgt.textContent, 90);
    }
    return t;
  }
  function secretWhy(el) {
    const tag = el.localName;
    if (tag !== 'input' && tag !== 'textarea') return '';
    const t = String(el.type || '').toLowerCase();
    if (t === 'password') return 'contraseña';
    const ac = el.getAttribute('autocomplete') || '';
    if (SECRET_AUTOCOMPLETE_RE.test(ac)) return /cc-/i.test(ac) ? 'tarjeta' : /one-time/i.test(ac) ? 'código' : 'contraseña';
    if (t === 'checkbox' || t === 'radio' || t === 'submit' || t === 'button' || t === 'file' || t === 'hidden') return '';
    let lab = '';
    try {
      lab = el.labels && el.labels.length ? [...el.labels].map(l => l.textContent).join(' ') : '';
    } catch {}
    const hay = [el.name, el.id, el.getAttribute('placeholder'), el.getAttribute('aria-label'), lab].filter(Boolean).join(' ');
    if (SECRET_NAME_RE.test(hay)) return CARD_KIND_RE.test(hay) ? 'tarjeta' : /otp|one.?time|verif|2fa|mfa|totp/i.test(hay) ? 'código' : 'contraseña';
    return '';
  }
  function isEditable(el) {
    const tag = el.localName;
    if (tag === 'textarea') return !el.readOnly && !el.disabled;
    if (tag === 'input') {
      const t = String(el.type || 'text').toLowerCase();
      if (['hidden', 'checkbox', 'radio', 'button', 'submit', 'reset', 'image', 'file', 'range', 'color'].includes(t)) return false;
      return !el.readOnly && !el.disabled;
    }
    return !!el.isContentEditable;
  }
  function submitLabelOf(el) {
    const form = el.form || (el.closest && el.closest('form'));
    if (!form) return '';
    const b = form.querySelector('button[type="submit"], input[type="submit"], button:not([type])');
    return b ? labelOf(b, 'button') : '';
  }
  function hostOf(url) {
    try {
      const u = new URL(url, location.href);
      return /^https?:$/.test(u.protocol) ? u.hostname : '';
    } catch {
      return '';
    }
  }
  function refFor(el) {
    let n = elToRef.get(el);
    if (!n) {
      n = nextRef++;
      elToRef.set(el, n);
      refToEl.set(n, new WeakRef(el));
    }
    return n;
  }
  function resolve(ref) {
    const w = refToEl.get(Number(ref));
    const el = w && w.deref();
    return el && el.isConnected ? el : null;
  }
  function shortHref(href) {
    try {
      const u = new URL(href, location.href);
      if (!/^https?:$/.test(u.protocol)) return '';
      const rel = u.origin === location.origin ? u.pathname + u.search : u.href;
      return clip(rel, 110);
    } catch {
      return '';
    }
  }

  function marker(el, kind, ref) {
    const num = ref ? `#${ref} ` : '';
    const es = KIND_ES[kind] || kind;
    const label = labelOf(el, kind);
    const flags = [];
    const sec = secretWhy(el);
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') flags.push('desactivado');
    let extra = '';
    if (sec) {
      return `[${num}${es} de ${sec}${label ? ` "${q(label)}"` : ''} — la IA no puede escribir aquí; la persona lo hace en la ventana]`;
    }
    if (kind === 'link') {
      const h = shortHref(el.getAttribute('href') || el.href || '');
      if (h) extra = ` → ${h}`;
    } else if (kind === 'field' || kind === 'textarea') {
      const t = String(el.type || '').toLowerCase();
      const tipo = kind === 'field' && t && t !== 'text' ? ` ${t}` : '';
      const v = clipLines(textOf(el), 50);
      return `[${num}${es}${tipo}${label ? ` "${q(label)}"` : ''}${v ? ` valor="${q(v)}"` : ' vacío'}${flags.length ? ' (' + flags.join(', ') + ')' : ''}]`;
    } else if (kind === 'editor') {
      const v = clipLines(textOf(el), 50);
      return `[${num}${es}${label ? ` "${q(label)}"` : ''}${v ? ` contenido="${q(v)}"` : ' vacío'}]`;
    } else if (kind === 'checkbox' || kind === 'radio') {
      const on = el.checked === true || el.getAttribute('aria-checked') === 'true';
      flags.unshift(on ? 'marcada' : 'sin marcar');
    } else if (kind === 'select') {
      const opts = [...el.options].slice(0, 14).map(o => clip(o.label || o.text || o.value, 40));
      const sel = el.selectedOptions && el.selectedOptions[0] ? clip(el.selectedOptions[0].label || el.selectedOptions[0].text, 40) : '';
      extra = ` opciones: ${opts.join(' | ')}${el.options.length > 14 ? ' …' : ''}${sel ? `; elegida: ${sel}` : ''}`;
    } else if (kind === 'tab' || kind === 'menuitem' || kind === 'option') {
      if (el.getAttribute('aria-selected') === 'true' || el.getAttribute('aria-current')) flags.push('activa');
    } else if (kind === 'summary') {
      const d = el.parentElement;
      if (d && d.localName === 'details') flags.push(d.open ? 'abierto' : 'cerrado');
    } else if (kind === 'file') {
      extra = ' (la persona elige el archivo)';
    }
    return `[${num}${es}${label ? ` "${q(label)}"` : ''}${extra}${flags.length ? ' (' + flags.join(', ') + ')' : ''}]`;
  }

  // ── Texto de la página con los elementos numerados dentro ───────────────────────────────────────────────────
  function build(maxRefs) {
    const lines = [];
    let cur = '';
    let chars = 0;
    let nodes = 0;
    let refCount = 0;
    let stop = false;
    const signals = { card: false, password: false, frames: [] };
    const seenFrames = new Set();
    let bullet = ''; // «- » pendiente: se pone delante de la primera línea con texto del elemento de lista
    function flush() {
      let t = cur.replace(/[ \t\u00a0]+/g, ' ').trim();
      cur = '';
      if (!t) return;
      if (bullet) {
        if (!t.startsWith('#')) t = bullet + t;
        bullet = '';
      }
      lines.push(t);
      chars += t.length + 1;
      if (chars > MAX_CHARS) stop = true;
    }
    function add(s) {
      cur += s;
    }
    function noteSecret(el) {
      const w = secretWhy(el);
      if (!w) return;
      if (w === 'tarjeta') signals.card = true;
      if (w === 'contraseña' && String(el.type).toLowerCase() === 'password') signals.password = true;
    }
    function walk(node, depth, pre) {
      if (stop || depth > MAX_DEPTH) return;
      if (node.nodeType === 3) {
        const v = node.nodeValue;
        if (!v) return;
        if (pre) {
          const parts = v.split('\n');
          parts.forEach((p, i) => {
            if (i > 0) flush();
            add(p);
          });
        } else add(v.replace(/\s+/g, ' '));
        return;
      }
      if (node.nodeType !== 1) return;
      if (++nodes > MAX_NODES) {
        stop = true;
        return;
      }
      const el = node;
      if (SKIP.has(el.tagName) || SKIP.has(el.localName)) return;
      if (el.id === '__auric_pick__') return;
      const cs = getComputedStyle(el);
      if (hiddenByStyle(el, cs)) return;
      const tag = el.localName;
      const display = cs.display;
      const block = display !== 'contents' && !/^inline/.test(display) && display !== 'table-cell';
      if (tag === 'iframe' || tag === 'frame') {
        const h = hostOf(el.getAttribute('src') || '');
        if (h && !seenFrames.has(h)) {
          seenFrames.add(h);
          signals.frames.push(h);
        }
        flush();
        add(`[marco incrustado${h ? ' de ' + h : ''}: su contenido no se puede leer]`);
        flush();
        return;
      }
      if (tag === 'img') {
        const alt = clip(el.getAttribute('alt') || '', 80);
        const r = el.getBoundingClientRect();
        if (alt && r.width >= 24 && r.height >= 24) add(` [imagen: ${q(alt)}] `);
        return;
      }
      if (tag === 'video' || tag === 'audio') return void add(` [${tag}] `);
      if (tag === 'canvas') return void add(' [lienzo] ');
      if (tag === 'br') return void flush();
      if (tag === 'hr') return void flush();
      const kind = interactiveKind(el, cs);
      if (kind) {
        noteSecret(el);
        if (textInvisible(el, cs) && kind !== 'field' && kind !== 'textarea' && kind !== 'select' && kind !== 'checkbox' && kind !== 'radio') return;
        const ref = refCount < maxRefs ? refFor(el) : 0;
        if (ref) refCount++;
        const own = block && kind !== 'link' && kind !== 'button';
        if (own) flush();
        add(` ${marker(el, kind, ref)} `);
        if (own) flush();
        // Enlaces, botones, campos, pestañas… se explican solos (su etiqueta ya es su texto); un contenedor «clicable» sí deja leer lo que contiene.
        if (kind !== 'clickable') return;
      } else if (textInvisible(el, cs) && [...el.childNodes].some(c => c.nodeType === 3 && c.nodeValue.trim())) {
        return;
      }
      if (/^H[1-6]$/.test(el.tagName)) {
        flush();
        add('#'.repeat(Number(el.tagName[1])) + ' ');
      } else if (tag === 'li') {
        flush();
        bullet = '- ';
      } else if (tag === 'tr') flush();
      else if (tag === 'td' || tag === 'th') {
        if (cur.trim() && !/\|\s*$/.test(cur)) add(' | ');
      } else if (block) flush();
      const inPre = pre || tag === 'pre';
      if (el.shadowRoot) for (const c of el.shadowRoot.childNodes) walk(c, depth + 1, inPre);
      for (const c of el.childNodes) {
        if (stop) break;
        walk(c, depth + 1, inPre);
      }
      if (/^H[1-6]$/.test(el.tagName) || tag === 'li' || tag === 'tr' || tag === 'p' || block) flush();
    }
    const root = document.body || document.documentElement;
    if (root) walk(root, 0, false);
    flush();
    return { lines, refCount, truncated: stop, signals };
  }
  function scrollInfo() {
    const de = document.documentElement;
    const total = Math.max(de ? de.scrollHeight : 0, document.body ? document.body.scrollHeight : 0);
    return { y: Math.round(window.scrollY), vh: window.innerHeight, vw: window.innerWidth, total, max: Math.max(0, total - window.innerHeight) };
  }
  function cut(text, offset, maxChars) {
    offset = Math.max(0, Number(offset) || 0);
    maxChars = Math.max(500, Math.min(30000, Number(maxChars) || 6000));
    if (offset >= text.length) return { text: '', next: null, offset };
    let end = Math.min(text.length, offset + maxChars);
    if (end < text.length) {
      const nl = text.lastIndexOf('\n', end);
      if (nl > offset + maxChars * 0.5) end = nl;
    }
    return { text: text.slice(offset, end), next: end < text.length ? end : null, offset };
  }

  // ── Operaciones que pide el proceso principal ───────────────────────────────────────────────────────────────
  const OPS = {
    snapshot({ offset = 0, maxChars = 6000, diff = false, maxRefs = 220 } = {}) {
      const t0 = performance.now();
      const built = build(maxRefs);
      let chosen = built.lines;
      let mode = 'full';
      if (diff && prevLines) {
        chosen = built.lines.filter(l => !prevLines.has(l));
        mode = 'diff';
      }
      prevLines = new Set(built.lines);
      const all = chosen.join('\n');
      const c = cut(all, offset, maxChars);
      return {
        mode,
        text: c.text,
        total: all.length,
        offset: c.offset,
        next: c.next,
        refs: built.refCount,
        truncated: built.truncated,
        signals: built.signals,
        scroll: scrollInfo(),
        title: clip(document.title, 200),
        url: location.href,
        readyState: document.readyState,
        ms: Math.round(performance.now() - t0)
      };
    },
    describe({ ref }) {
      const el = resolve(ref);
      if (!el) return { missing: true };
      const cs = getComputedStyle(el);
      const kind = interactiveKind(el, cs) || (el.localName === 'label' ? 'label' : 'other');
      const secret = secretWhy(el);
      const r = el.getBoundingClientRect();
      const href = el.localName === 'a' ? el.href || '' : '';
      const form = el.form || (el.closest && el.closest('form'));
      const action = form ? form.getAttribute('action') || '' : '';
      return {
        ref: Number(ref),
        tag: el.localName,
        kind,
        type: String(el.type || '').toLowerCase(),
        label: labelOf(el, kind),
        secret: secret || '',
        editable: isEditable(el),
        file: kind === 'file',
        disabled: !!(el.disabled || el.getAttribute('aria-disabled') === 'true'),
        href: href && /^https?:/i.test(href) ? href : '',
        hrefHost: href ? hostOf(href) : '',
        formActionHost: (kind === 'button' || el.type === 'submit') && action ? hostOf(action) : '',
        submitLabel: submitLabelOf(el),
        rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }
      };
    },
    // Lleva el elemento a la vista y busca un punto donde un clic de verdad le llegue a él (y no a un cartel encima).
    prepareClick({ ref }) {
      const el = resolve(ref);
      if (!el) return { missing: true };
      try {
        el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'instant' });
      } catch {
        el.scrollIntoView();
      }
      const r = el.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) return { hidden: true };
      const vw = window.innerWidth,
        vh = window.innerHeight;
      const px = f => Math.min(vw - 2, Math.max(2, r.left + r.width * f));
      const py = f => Math.min(vh - 2, Math.max(2, r.top + r.height * f));
      const pts = [[0.5, 0.5], [0.25, 0.5], [0.75, 0.5], [0.5, 0.25], [0.5, 0.75], [0.15, 0.15], [0.85, 0.85]];
      let covered = '';
      for (const [fx, fy] of pts) {
        const x = px(fx),
          y = py(fy);
        let top = document.elementFromPoint(x, y);
        while (top && top.shadowRoot && top.shadowRoot.elementFromPoint) {
          const inner = top.shadowRoot.elementFromPoint(x, y);
          if (!inner || inner === top) break;
          top = inner;
        }
        if (!top) continue;
        const lab = top.closest && top.closest('label');
        if (top === el || el.contains(top) || top.contains(el) || (lab && lab.control === el)) return { x: Math.round(x), y: Math.round(y), tag: el.localName };
        if (!covered) covered = `${top.localName}${top.id ? '#' + top.id : ''} "${clip(top.innerText || top.getAttribute('aria-label') || '', 50)}"`;
      }
      return { covered: covered || 'otro elemento' };
    },
    focusField({ ref, clear = false }) {
      const el = resolve(ref);
      if (!el) return { missing: true };
      try {
        el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'instant' });
      } catch {}
      el.focus({ preventScroll: true });
      if (clear) {
        try {
          if (typeof el.select === 'function') el.select();
          else if (el.isContentEditable) {
            const range = document.createRange();
            range.selectNodeContents(el);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
          }
        } catch {}
      } else if (typeof el.setSelectionRange === 'function') {
        try {
          const n = String(el.value || '').length;
          el.setSelectionRange(n, n);
        } catch {}
      }
      return { focused: document.activeElement === el || el.contains(document.activeElement) };
    },
    fieldValue({ ref }) {
      const el = resolve(ref);
      if (!el) return { missing: true };
      if (secretWhy(el)) return { value: '', hidden: true };
      return { value: clipLines(textOf(el), 160) };
    },
    activeInfo() {
      const el = document.activeElement;
      if (!el || el === document.body || el === document.documentElement) return { none: true };
      const cs = getComputedStyle(el);
      const kind = interactiveKind(el, cs) || 'other';
      return {
        tag: el.localName,
        kind,
        type: String(el.type || '').toLowerCase(),
        label: labelOf(el, kind),
        secret: secretWhy(el),
        editable: isEditable(el),
        submitLabel: submitLabelOf(el)
      };
    },
    selectOption({ ref, value }) {
      const el = resolve(ref);
      if (!el) return { missing: true };
      if (el.localName !== 'select') return { notSelect: true };
      const want = String(value == null ? '' : value).trim();
      const lower = want.toLowerCase();
      const opts = [...el.options];
      let hit = opts.find(o => o.value === want) || opts.find(o => (o.label || o.text || '').trim() === want);
      if (!hit) hit = opts.find(o => (o.label || o.text || '').trim().toLowerCase() === lower);
      if (!hit && lower) hit = opts.find(o => (o.label || o.text || '').toLowerCase().includes(lower));
      if (!hit) return { notFound: true, options: opts.slice(0, 30).map(o => clip(o.label || o.text || o.value, 60)) };
      if (hit.disabled) return { disabled: true };
      el.focus({ preventScroll: true });
      hit.selected = true;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return { selected: clip(hit.label || hit.text || hit.value, 80), value: hit.value };
    },
    scrollTo({ where }) {
      if (where === 'top') window.scrollTo({ top: 0, behavior: 'instant' });
      else if (where === 'bottom') window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'instant' });
      return scrollInfo();
    },
    scrollInfo() {
      return scrollInfo();
    },
    waitStable({ quietMs = 250, maxMs = 3000 } = {}) {
      return new Promise(resolveWait => {
        let done = false;
        let timer;
        let hard;
        const finish = () => {
          if (done) return;
          done = true;
          try {
            obs.disconnect();
          } catch {}
          clearTimeout(timer);
          clearTimeout(hard);
          resolveWait({ ms: Math.round(performance.now() - t0) });
        };
        const t0 = performance.now();
        const obs = new MutationObserver(() => {
          clearTimeout(timer);
          timer = setTimeout(finish, quietMs);
        });
        try {
          obs.observe(document, { subtree: true, childList: true, attributes: true, characterData: true });
        } catch {}
        timer = setTimeout(finish, quietMs);
        hard = setTimeout(finish, maxMs);
      });
    },
    // Modo «comentar»: la persona señala un elemento de la página; la página no recibe el clic.
    pickStart() {
      stopPick();
      startPick();
      return { on: true };
    },
    pickStop() {
      stopPick();
      return { on: false };
    },
    pickClear() {
      removeOverlay();
      return { cleared: true };
    },
    // Lo mínimo para saber si la página es «sensible» (pide tarjeta, incrusta pagos) sin leer todo su texto.
    signals() {
      const out = { card: false, password: false, frames: [] };
      const seen = new Set();
      for (const el of document.querySelectorAll('input,textarea,iframe')) {
        if (el.localName === 'iframe') {
          const h = hostOf(el.getAttribute('src') || '');
          if (h && !seen.has(h)) {
            seen.add(h);
            out.frames.push(h);
          }
          continue;
        }
        const w = secretWhy(el);
        if (!w) continue;
        const cs = getComputedStyle(el);
        if (hiddenByStyle(el, cs)) continue;
        if (w === 'tarjeta') out.card = true;
        if (String(el.type).toLowerCase() === 'password') out.password = true;
      }
      return out;
    },
    ping() {
      return { ok: true, url: location.href, ready: document.readyState };
    }
  };

  // ── Señalar elementos (comentarios de la persona) ───────────────────────────────────────────────────────────
  let overlay = null;
  let pickHandlers = null;
  function ensureOverlay() {
    if (overlay && overlay.isConnected) return overlay;
    overlay = document.createElement('div');
    overlay.id = '__auric_pick__';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.style.cssText =
      'all:initial;position:fixed;z-index:2147483647;pointer-events:none;border:2px solid #d8ac3e;background:rgba(216,172,62,.18);box-shadow:0 0 0 99999px rgba(0,0,0,.08);border-radius:4px;display:none;transition:all .06s ease-out;box-sizing:border-box';
    (document.documentElement || document.body).appendChild(overlay);
    return overlay;
  }
  function removeOverlay() {
    if (overlay) overlay.remove();
    overlay = null;
  }
  function placeOverlay(el) {
    const o = ensureOverlay();
    const r = el.getBoundingClientRect();
    o.style.display = 'block';
    o.style.left = r.left + 'px';
    o.style.top = r.top + 'px';
    o.style.width = Math.max(4, r.width) + 'px';
    o.style.height = Math.max(4, r.height) + 'px';
  }
  function deepTarget(ev) {
    const p = ev.composedPath ? ev.composedPath() : [];
    const t = p.find(n => n && n.nodeType === 1) || ev.target;
    return t && t.id === '__auric_pick__' ? null : t;
  }
  function meaningful(el) {
    if (!el || el.nodeType !== 1) return document.body;
    const near = el.closest && el.closest('a,button,input,select,textarea,summary,label,[role=button],[role=link],h1,h2,h3,h4,h5,h6,li,p,img,td,th,figure');
    return near || el;
  }
  function pickInfo(el) {
    const cs = getComputedStyle(el);
    const kind = interactiveKind(el, cs);
    const r = el.getBoundingClientRect();
    const ref = kind ? refFor(el) : 0;
    const secret = secretWhy(el);
    const id = el.id ? '#' + String(el.id).slice(0, 40) : '';
    const cls = el.classList && el.classList.length ? '.' + [...el.classList].slice(0, 2).map(c => String(c).slice(0, 24)).join('.') : '';
    return {
      tag: el.localName,
      kind: kind || 'other',
      ref,
      label: secret ? '' : labelOf(el, kind || 'other'),
      text: secret ? '' : clip(el.innerText || el.textContent || '', 220),
      href: el.localName === 'a' ? shortHref(el.getAttribute('href') || '') : '',
      hint: `${el.localName}${id}${cls}`.slice(0, 90),
      rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) },
      url: location.href,
      title: clip(document.title, 160)
    };
  }
  function stopPick() {
    if (pickHandlers) {
      for (const [type, fn] of pickHandlers) window.removeEventListener(type, fn, true);
      pickHandlers = null;
    }
    document.documentElement && (document.documentElement.style.cursor = '');
  }
  function startPick() {
    const swallow = ev => {
      ev.preventDefault();
      ev.stopImmediatePropagation();
    };
    const onMove = ev => {
      const t = deepTarget(ev);
      if (t) placeOverlay(meaningful(t));
    };
    const onClick = ev => {
      swallow(ev);
      const t = deepTarget(ev);
      if (!t) return;
      const el = meaningful(t);
      placeOverlay(el);
      stopPick();
      ipcRenderer.send('auric-browser:pick', pickInfo(el));
    };
    const onKey = ev => {
      if (ev.key === 'Escape') {
        swallow(ev);
        stopPick();
        removeOverlay();
        ipcRenderer.send('auric-browser:pick-cancel');
      }
    };
    pickHandlers = [
      ['mousemove', onMove],
      ['click', onClick],
      ['mousedown', swallow],
      ['mouseup', swallow],
      ['pointerdown', swallow],
      ['pointerup', swallow],
      ['touchstart', swallow],
      ['keydown', onKey],
      ['submit', swallow],
      ['dblclick', swallow],
      ['contextmenu', swallow]
    ];
    for (const [type, fn] of pickHandlers) window.addEventListener(type, fn, true);
    document.documentElement && (document.documentElement.style.cursor = 'crosshair');
  }

  ipcRenderer.on('auric-browser:cmd', async (_e, msg) => {
    const id = msg && msg.id;
    let res;
    try {
      const fn = msg && Object.prototype.hasOwnProperty.call(OPS, msg.op) ? OPS[msg.op] : null;
      if (!fn) throw new Error('Operación desconocida.');
      res = { id, ok: true, value: await fn(msg.args || {}) };
    } catch (err) {
      res = { id, ok: false, error: String((err && err.message) || err).slice(0, 400) };
    }
    ipcRenderer.send('auric-browser:res', res);
  });
}
