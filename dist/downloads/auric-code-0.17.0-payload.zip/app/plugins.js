'use strict';
// Plugins de Auric Code — gestor (disco, red e IPC). La lógica pura está en plugins-core / plugins-review / plugins-registry / plugins-exec.
//
// Un plugin = paquete con skills + instrucciones + servidores MCP + conectores, con manifiesto, versión, permisos visibles,
// revisión de seguridad al instalar y desinstalación limpia.
//
// Reglas que este módulo hace cumplir:
//  · Nada se instala sin que la persona vea la revisión y pulse «Instalar» (y marque «Entiendo el riesgo» si hay riesgo alto).
//    Los bytes que se instalan son EXACTAMENTE los que se revisaron (el paquete se guarda en memoria con un código de un solo uso).
//  · Nada se ejecuta al instalar. Un servidor del plugin solo arranca cuando la IA lo usa y tu modo de permisos lo permite.
//  · Si los archivos de un plugin cambian después de instalarlo, el plugin se desactiva hasta que lo vuelvas a revisar.
//  · Un plugin nunca modifica tus archivos ni toca otras carpetas: se guarda solo en su propia carpeta dentro de los datos de Auric.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const core = require('./plugins-core');
const review = require('./plugins-review');
const registry = require('./plugins-registry');
const pexec = require('./plugins-exec');
const netSafe = require('./net-safe');
const zip = require('./zip');
const { parseSkillFrontmatter } = require('./skill-format');

const LOCK_SCHEMA = 'auric-plugin-lock/1';
const STAGE_TTL_MS = 15 * 60 * 1000;
const MAX_STAGED = 8;
const MAX_DOWNLOAD = 60 * 1024 * 1024;
const GITHUB_HOSTS = new Set(['github.com', 'codeload.github.com']);
const REGISTRY_HOSTS = new Set([new URL(registry.REGISTRY_ORIGIN).hostname]);
const PLUGIN_SKILL_CAP = 12000; // caracteres de cada skill de plugin que se agregan a la conversación
const PLUGIN_INSTRUCTIONS_CAP = 8000;
const PLUGIN_BLOCK_CAP = 40000;
const SKIP_DIRS = new Set(['.git', 'node_modules', '__pycache__', '.venv', 'venv']);

const isObj = v => !!v && typeof v === 'object' && !Array.isArray(v);
const randHex = n => crypto.randomBytes(n).toString('hex');
const nowIso = () => new Date().toISOString();
const err = (message, code) => new core.PluginError(message, code);
const exists = async p => {
  try {
    await fsp.access(p);
    return true;
  } catch {
    return false;
  }
};
const inside = (root, target) => {
  const rel = path.relative(root, target);
  return !!rel && !rel.startsWith('..') && !path.isAbsolute(rel);
};
async function rmrf(p) {
  await fsp.rm(p, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 });
}
async function renameRetry(a, b) {
  let last;
  for (let i = 0; i < 6; i++) {
    try {
      return await fsp.rename(a, b);
    } catch (e) {
      last = e;
      if (!['EPERM', 'EBUSY', 'EACCES', 'ENOTEMPTY'].includes(e.code)) throw e;
      await new Promise(r => setTimeout(r, 200 * (i + 1)));
    }
  }
  throw last;
}
// «<skills>», «</system>»… dentro del texto de un plugin: se vuelven inofensivos para que no puedan cerrar el bloque donde Auric los coloca.
const neutralizeDelimiters = text => String(text ?? '').replace(/<(\/?)(skills?|plugin_skills|plugin_instructions|system|instructions?|untrusted|external_content|developer|assistant)\b/gi, '‹$1$2');

// Lee una carpeta entera (sin seguir enlaces simbólicos) con topes de cantidad y tamaño.
async function readTree(dir, { maxFiles = core.LIMITS.maxFiles * 4, maxBytes = core.LIMITS.maxTotalBytes * 4 } = {}) {
  const out = new Map();
  const notes = { symlinks: 0, skipped: 0 };
  let bytes = 0;
  const walk = async (abs, rel) => {
    const entries = await fsp.readdir(abs, { withFileTypes: true });
    for (const d of entries) {
      if (SKIP_DIRS.has(d.name)) {
        notes.skipped++;
        continue;
      }
      const a = path.join(abs, d.name);
      const r = rel ? `${rel}/${d.name}` : d.name;
      if (d.isSymbolicLink()) {
        notes.symlinks++;
        continue;
      }
      if (d.isDirectory()) await walk(a, r);
      else if (d.isFile()) {
        const st = await fsp.stat(a);
        bytes += st.size;
        if (out.size + 1 > maxFiles || bytes > maxBytes) throw err('La carpeta tiene demasiados archivos o pesa demasiado para ser un plugin.', 'PLUGIN_LIMIT');
        out.set(r, await fsp.readFile(a));
      }
    }
  };
  await walk(dir, '');
  return { files: out, notes };
}

// ZIP → Map. Rechaza el ZIP entero ante rutas peligrosas, archivos cifrados o nombres repetidos; ignora enlaces simbólicos.
function zipToFiles(buf, { subdir = '' } = {}) {
  let z;
  try {
    z = zip.readZip(buf, { maxEntries: 40000, maxEntryBytes: core.LIMITS.maxFileBytes * 2, maxTotalBytes: 400 * 1024 * 1024 });
  } catch (e) {
    throw err(`El archivo ZIP no se pudo leer: ${String(e.message || e).slice(0, 160)}`, 'PLUGIN_BAD_ZIP');
  }
  // Una ruta que sale de la carpeta (../, absoluta, con unidad) es un ataque: se rechaza el ZIP entero.
  // Un nombre que solo Windows no admite (CON, «a:b»…) se ignora, porque en otros sistemas es un archivo normal.
  const traversal = raw => /(^|[\\/])\.\.([\\/]|$)/.test(raw) || /^([\\/]|[a-zA-Z]:)/.test(raw) || /\u0000/.test(raw);
  for (const e of z.entries) {
    if (e.unsafe && traversal(String(e.rawName))) throw err(`El ZIP trae una ruta peligrosa («${String(e.rawName).slice(0, 80)}») y se rechazó completo.`, 'PLUGIN_UNSAFE_PATH');
    if (e.encrypted) throw err('El ZIP tiene archivos cifrados: Auric no los abre.', 'PLUGIN_BAD_ZIP');
    if (e.duplicate) throw err(`El ZIP trae dos veces el mismo archivo («${String(e.name).slice(0, 80)}»).`, 'PLUGIN_BAD_ZIP');
  }
  const notes = { symlinks: z.entries.filter(e => e.isSymlink).length, unsupportedNames: z.entries.filter(e => e.unsafe && !e.isDir).length };
  let live = z.entries.filter(e => !e.isDir && !e.isSymlink && e.name);
  // Carpeta única que envuelve todo (los ZIP de GitHub vienen como «repo-1a2b3c/…»)
  let wrapper = '';
  if (live.length && live.every(e => e.name.includes('/'))) {
    const first = live[0].name.split('/')[0];
    if (live.every(e => e.name.split('/')[0] === first)) wrapper = first;
  }
  const strip = n => (wrapper ? n.slice(wrapper.length + 1) : n);
  const sub = subdir ? subdir.replace(/\/+$/, '') + '/' : '';
  live = live
    .map(e => ({ e, rel: strip(e.name) }))
    .filter(x => (sub ? x.rel.startsWith(sub) : true))
    .map(x => ({ e: x.e, rel: sub ? x.rel.slice(sub.length) : x.rel }))
    .filter(x => x.rel && !x.rel.split('/').some(p => SKIP_DIRS.has(p)));
  if (sub && !live.length) throw err(`No hay archivos dentro de la carpeta «${subdir}» del paquete.`, 'PLUGIN_EMPTY');
  if (live.length > core.LIMITS.maxFiles) throw err(`El paquete tiene demasiados archivos (${live.length}; máximo ${core.LIMITS.maxFiles}). Si es un repositorio grande, indica la carpeta del plugin (…/tree/rama/carpeta).`, 'PLUGIN_LIMIT');
  const declared = live.reduce((n, x) => n + x.e.size, 0);
  if (declared > core.LIMITS.maxTotalBytes) throw err(`El paquete pesa demasiado (${Math.round(declared / 1048576)} MB; máximo ${core.LIMITS.maxTotalBytes / 1048576} MB).`, 'PLUGIN_LIMIT');
  const files = new Map();
  for (const x of live) files.set(x.rel, z.read(x.e));
  return { files, wrapper, notes };
}

// Qué hacer cuando el paquete trae los plugins dentro de carpetas (depende de dónde se importó).
function multipleHint(source, folders) {
  const one = folders[0] || 'carpeta';
  if (source.type === 'github') {
    const base = `https://github.com/${source.owner}/${source.repo}/tree/${source.ref || '<rama>'}`;
    return `Abre en GitHub la carpeta del plugin que quieres y pega esa dirección (termina en ${base.replace('https://github.com/', '…/')}/${one}).`;
  }
  if (source.type === 'zip') return 'Descomprime el ZIP y usa «Importar carpeta» con la carpeta del plugin que quieres.';
  return 'Elige directamente la carpeta del plugin que quieres.';
}

const zipNotes = notes => [
  ...(notes.symlinks ? [`Se ignoraron ${notes.symlinks} enlace(s) simbólico(s) del paquete.`] : []),
  ...(notes.unsupportedNames ? [`Se ignoraron ${notes.unsupportedNames} archivo(s) con nombres que Windows no admite.`] : [])
];

class PluginManager {
  constructor(opts = {}) {
    if (!opts.root) throw new Error('PluginManager requiere root');
    this.root = opts.root;
    this.officialDir = opts.officialDir || '';
    this.appVersion = opts.appVersion || '0.0.0';
    this.safeStorage = opts.safeStorage || null;
    this.hostMap = opts.hostMap || null;
    this.resolver = opts.resolver || null;
    this.connectors = opts.connectors || (() => null);
    this.builtinConnectorIds = opts.builtinConnectorIds || (() => new Set());
    this.nodePath = opts.nodePath || process.execPath;
    this.platform = opts.platform || process.platform;
    this.env = opts.env || process.env;
    this.userAgent = opts.userAgent || 'Auric-Code';
    this.log = opts.log || (() => {});
    this.onChange = opts.onChange || (() => {});
    this.stopMcpPrefix = opts.stopMcpPrefix || (() => {});
    this.probe = opts.probe || null; // (nombre) => Promise<boolean> | boolean  (pruebas)
    this.which = opts.which || null; // (nombre) => Promise<string[]> (pruebas)
    this.staged = new Map();
    this.integrityCache = new Map();
    this.toolCache = new Map();
    this.registryCache = new Map();
    this._chain = Promise.resolve();
    this._index = null;
    this._secrets = null;
    this._memSecrets = {};
  }

  // ── Rutas ─────────────────────────────────────────────────────────────────────────────────────
  dirOf(id) {
    if (!core.PLUGIN_ID_RE.test(String(id))) throw err('Identificador de plugin no válido.', 'PLUGIN_BAD_ID');
    const d = path.join(this.root, id);
    if (!inside(this.root, d)) throw err('Identificador de plugin no válido.', 'PLUGIN_BAD_ID');
    return d;
  }
  filesDir(id) {
    return path.join(this.dirOf(id), 'files');
  }
  dataDir(id) {
    return path.join(this.dirOf(id), 'data');
  }
  _serial(fn) {
    const run = this._chain.then(fn, fn);
    this._chain = run.catch(() => {});
    return run;
  }

  // ── Índice y candado de cada plugin ───────────────────────────────────────────────────────────
  _readIndex() {
    if (this._index) return this._index;
    const file = path.join(this.root, 'index.json');
    try {
      const j = JSON.parse(fs.readFileSync(file, 'utf8'));
      this._index = { plugins: isObj(j.plugins) ? j.plugins : {} };
    } catch (e) {
      if (e.code !== 'ENOENT') {
        try {
          fs.renameSync(file, `${file}.${Date.now()}.bad`);
        } catch {}
      }
      this._index = { plugins: {} };
    }
    return this._index;
  }
  async _writeIndex() {
    await fsp.mkdir(this.root, { recursive: true });
    const file = path.join(this.root, 'index.json');
    const tmp = `${file}.${process.pid}.${randHex(3)}.tmp`;
    await fsp.writeFile(tmp, JSON.stringify({ schema: 1, plugins: this._readIndex().plugins }, null, 2));
    await renameRetry(tmp, file);
  }
  async _readLock(id) {
    const dir = this.dirOf(id); // un identificador manipulado se rechaza aquí, no se confunde con «no instalado»
    try {
      const j = JSON.parse(await fsp.readFile(path.join(dir, 'plugin.lock.json'), 'utf8'));
      return isObj(j) && j.schema === LOCK_SCHEMA ? j : null;
    } catch {
      return null;
    }
  }

  // ── Integridad ────────────────────────────────────────────────────────────────────────────────
  async _walk(dir) {
    const out = [];
    const walk = async (abs, rel) => {
      let entries;
      try {
        entries = await fsp.readdir(abs, { withFileTypes: true });
      } catch {
        return;
      }
      for (const d of entries) {
        const a = path.join(abs, d.name);
        const r = rel ? `${rel}/${d.name}` : d.name;
        if (d.isSymbolicLink()) out.push({ rel: r, abs: a, size: 0, mtimeMs: 0, symlink: true });
        else if (d.isDirectory()) await walk(a, r);
        else if (d.isFile()) {
          const st = await fsp.stat(a);
          out.push({ rel: r, abs: a, size: st.size, mtimeMs: st.mtimeMs });
        }
      }
    };
    await walk(dir, '');
    return out;
  }
  /** Compara los archivos instalados con los que se revisaron. `force` vuelve a calcular todo (se usa antes de ejecutar algo). */
  async integrity(id, { force = false } = {}) {
    const lock = await this._readLock(id);
    if (!lock) return { status: 'missing', changed: [], missing: [], extra: [], detail: 'Falta el registro de instalación del plugin.' };
    const dir = this.filesDir(id);
    const walked = await this._walk(dir);
    const sig = crypto.createHash('sha256').update(walked.map(w => `${w.rel}|${w.size}|${Math.round(w.mtimeMs)}|${w.symlink ? 1 : 0}`).join('\n')).digest('hex');
    const cached = this.integrityCache.get(id);
    if (!force && cached && cached.sig === sig && cached.treeSha256 === lock.treeSha256) return cached.result;
    const want = new Map(lock.files.map(f => [f.path, f]));
    const changed = [];
    const extra = [];
    const seen = new Set();
    for (const w of walked) {
      seen.add(w.rel);
      const f = want.get(w.rel);
      if (w.symlink || !f) {
        extra.push(w.rel);
        continue;
      }
      if (w.size !== f.size) {
        changed.push(w.rel);
        continue;
      }
      if (core.sha256(await fsp.readFile(w.abs)) !== f.sha256) changed.push(w.rel);
    }
    const missing = [...want.keys()].filter(k => !seen.has(k));
    const ok = !changed.length && !missing.length && !extra.length;
    const result = {
      status: ok ? 'ok' : missing.length && !changed.length && !extra.length && missing.length === want.size ? 'missing' : 'modified',
      changed: changed.slice(0, 10),
      missing: missing.slice(0, 10),
      extra: extra.slice(0, 10),
      detail: ok ? '' : `${changed.length} cambiado(s), ${missing.length} faltante(s), ${extra.length} nuevo(s) desde la instalación.`
    };
    this.integrityCache.set(id, { sig, treeSha256: lock.treeSha256, result });
    return result;
  }

  // ── Programas del PC ──────────────────────────────────────────────────────────────────────────
  async _whichLines(cmd) {
    if (this.which) return (await this.which(cmd)) || [];
    return new Promise(resolve => {
      execFile(this.platform === 'win32' ? 'where' : 'which', [cmd], { timeout: 2500, windowsHide: true, env: this.env }, (e, out) => resolve(e ? [] : String(out || '').split(/\r?\n/).map(l => l.trim()).filter(Boolean)));
    });
  }
  async probeTool(name) {
    const hit = this.toolCache.get(name);
    if (hit && Date.now() - hit.at < 60000) return hit.ok;
    let ok = false;
    if (this.probe) ok = !!(await this.probe(name));
    else {
      const cands = { python: ['python', 'python3', 'py'], docker: ['docker', 'podman'], dotnet: ['dotnet'] }[name] || [name];
      for (const c of cands) {
        const lines = await this._whichLines(c);
        if (this.platform === 'win32' ? !!pexec.pickWindowsCommand(lines) : lines.length) {
          ok = true;
          break;
        }
      }
    }
    this.toolCache.set(name, { at: Date.now(), ok });
    return ok;
  }
  async _resolveBare(name) {
    const lines = await this._whichLines(name);
    const found = this.platform === 'win32' ? pexec.pickWindowsCommand(lines) : lines[0] || '';
    if (!found) throw err(`No se encontró el programa «${name}» en este PC. Instálalo y vuelve a intentar.`, 'PLUGIN_COMMAND_NOT_FOUND');
    return found;
  }

  // ── Resumen para la pantalla ──────────────────────────────────────────────────────────────────
  summarizeModel(model) {
    const m = model.manifest;
    return {
      id: m.id,
      name: m.name,
      version: m.version,
      description: m.description,
      author: m.author,
      homepage: m.homepage,
      license: m.license,
      origin: model.origin,
      requires: m.requires,
      permissions: m.permissions,
      skills: model.skills.map(s => ({ id: s.id, name: s.name, description: s.description, triggers: s.triggers, markers: s.markers, derived: s.derived })),
      instructions: !!model.instructions,
      mcp: model.mcp.map(x => ({ id: x.id, name: x.name, description: x.description, commandLine: [x.command, ...x.args].join(' '), cwd: x.cwd, env: Object.keys(x.env) })),
      connectors: model.connectors.map(c => ({ id: c.id, name: c.name, description: c.description, url: c.url, ref: c.ref, auth: c.auth })),
      stats: model.stats,
      notes: model.notes,
      ignored: model.ignored
    };
  }
  async _describe(id) {
    const entry = this._readIndex().plugins[id];
    if (!entry) return null;
    const lock = await this._readLock(id);
    if (!lock) {
      return { id, name: id, version: entry.version || '', broken: true, enabled: false, active: false, integrity: { status: 'missing', changed: [], missing: [], extra: [], detail: 'Falta el registro de instalación.' }, source: entry.source || {}, skills: [], mcp: [], connectors: [], secrets: [] };
    }
    const integ = await this.integrity(id);
    const enabled = entry.enabled !== false;
    const declared = lock.manifest.permissions?.env || [];
    const stored = this._loadSecrets()[id] || {};
    const c = lock.components;
    return {
      id,
      name: lock.manifest.name,
      version: lock.manifest.version,
      description: lock.manifest.description,
      author: lock.manifest.author,
      homepage: lock.manifest.homepage,
      license: lock.manifest.license,
      origin: lock.origin,
      official: entry.source?.type === 'official',
      enabled,
      active: enabled && integ.status === 'ok',
      integrity: integ,
      installedAt: entry.installedAt,
      updatedAt: entry.updatedAt,
      source: entry.source || {},
      folder: this.filesDir(id),
      requires: lock.manifest.requires,
      permissions: lock.manifest.permissions,
      skills: c.skills.map(s => ({ id: s.id, name: s.name, description: s.description, triggers: s.triggers, markers: s.markers, derived: s.derived })),
      instructions: !!c.instructions,
      mcp: c.mcp.map(x => ({ id: x.id, name: x.name, description: x.description, serverId: `${id}/${x.id}`, commandLine: [x.command, ...x.args].join(' '), cwd: x.cwd })),
      connectors: c.connectors.map(x => ({ ...x, connectedAs: entry.connectorIds?.[x.id] || '' })),
      secrets: declared.map(name => ({ name, state: stored[name] != null ? 'stored' : this.env[name] ? 'env' : 'missing' })),
      persistentSecrets: this._encOk(),
      review: lock.review,
      ignored: lock.ignored || [],
      notes: lock.notes || [],
      stats: lock.stats
    };
  }
  async list() {
    const out = [];
    for (const id of Object.keys(this._readIndex().plugins).sort()) {
      const d = await this._describe(id);
      if (d) out.push(d);
    }
    return out;
  }

  // ── Catálogo local (plugins oficiales incluidos en la app) ────────────────────────────────────
  async _officialIds() {
    if (!this.officialDir || !(await exists(this.officialDir))) return [];
    const out = [];
    for (const d of await fsp.readdir(this.officialDir, { withFileTypes: true })) if (d.isDirectory() && core.PLUGIN_ID_RE.test(d.name)) out.push(d.name);
    return out.sort();
  }
  async catalog() {
    const installed = this._readIndex().plugins;
    const out = [];
    for (const id of await this._officialIds()) {
      try {
        const { files } = await readTree(path.join(this.officialDir, id));
        const { model } = core.prepareModel(files, { name: id });
        const have = installed[model.manifest.id];
        const lock = have ? await this._readLock(model.manifest.id) : null;
        out.push({
          id: model.manifest.id,
          folder: id,
          name: model.manifest.name,
          version: model.manifest.version,
          description: model.manifest.description,
          author: model.manifest.author,
          skills: model.skills.length,
          skillNames: model.skills.map(s => s.name).slice(0, 8),
          mcp: model.mcp.length,
          connectors: model.connectors.length,
          instructions: !!model.instructions,
          installed: !!have,
          installedVersion: lock?.manifest.version || '',
          updateAvailable: !!lock && core.compareVersions(lock.manifest.version, model.manifest.version) < 0
        });
      } catch (e) {
        this.log('plugin oficial ilegible', id, e.message);
      }
    }
    return out;
  }

  // ── Cargar un paquete (todas las fuentes terminan en un Map ruta → bytes) ─────────────────────
  async _fetch(url, { maxBytes = 2 * 1024 * 1024, hosts = null, accept = 'application/json', timeoutMs = 25000 } = {}) {
    const opened = await netSafe.openSafe(url, {
      headers: { 'User-Agent': this.userAgent, Accept: accept, 'Accept-Encoding': 'identity' },
      hostMap: this.hostMap,
      resolver: this.resolver,
      timeoutMs,
      maxRedirects: 5,
      onHop: h => {
        const to = new URL(h.to).hostname;
        if (hosts && !hosts.has(to)) throw err(`La descarga intentó ir a otro sitio (${to}) y Auric la bloqueó.`, 'PLUGIN_REDIRECT');
      }
    });
    const res = opened.res;
    try {
      if (res.statusCode === 404) throw err('No se encontró lo que pediste (el enlace no existe o es privado). Auric solo descarga cosas públicas.', 'PLUGIN_NOT_FOUND');
      if (res.statusCode >= 400) throw err(`El sitio respondió con un error (HTTP ${res.statusCode}).`, 'PLUGIN_HTTP');
      const { buffer, truncated } = await netSafe.readLimited(netSafe.decodedStream(res), maxBytes);
      if (truncated) throw err(`La descarga supera el tamaño permitido (${Math.round(maxBytes / 1048576)} MB).`, 'PLUGIN_TOO_BIG');
      return buffer;
    } finally {
      res.destroy?.();
    }
  }
  async _loadGithub(input) {
    const g = core.parseGithubInput(input);
    const ref = g.ref || 'HEAD';
    const tries = [`https://github.com/${g.owner}/${g.repo}/archive/${ref}.zip`, `https://codeload.github.com/${g.owner}/${g.repo}/zip/${ref}`];
    let buf = null;
    let lastErr = null;
    for (const url of tries) {
      try {
        buf = await this._fetch(url, { maxBytes: MAX_DOWNLOAD, hosts: GITHUB_HOSTS, accept: 'application/zip, application/octet-stream', timeoutMs: 60000 });
        break;
      } catch (e) {
        lastErr = e;
        if (e.code !== 'PLUGIN_NOT_FOUND') break;
      }
    }
    if (!buf) {
      if (lastErr && lastErr.code === 'PLUGIN_NOT_FOUND')
        throw err(`No se encontró «${g.owner}/${g.repo}${g.ref ? '@' + g.ref : ''}» en GitHub. Revisa que el nombre esté bien escrito, que la rama o versión exista y que el repositorio sea público (Auric no entra a repositorios privados).`, 'PLUGIN_NOT_FOUND');
      throw lastErr || err('No se pudo descargar el repositorio.', 'PLUGIN_HTTP');
    }
    const { files, wrapper, notes } = zipToFiles(buf, { subdir: g.subdir });
    return {
      files,
      hint: { name: g.repo },
      source: { type: 'github', owner: g.owner, repo: g.repo, ref: g.ref, subdir: g.subdir, resolved: wrapper },
      notes: zipNotes(notes)
    };
  }
  async _loadZipFile(file) {
    const p = path.resolve(String(file || ''));
    const st = await fsp.stat(p).catch(() => null);
    if (!st || !st.isFile()) throw err('No se encontró el archivo ZIP.', 'PLUGIN_NOT_FOUND');
    if (st.size > MAX_DOWNLOAD) throw err('El ZIP pesa demasiado para ser un plugin.', 'PLUGIN_TOO_BIG');
    const { files, notes } = zipToFiles(await fsp.readFile(p));
    return { files, hint: { name: path.basename(p, path.extname(p)) }, source: { type: 'zip', path: p, name: path.basename(p) }, notes: zipNotes(notes) };
  }
  async _loadFolder(dir) {
    const p = path.resolve(String(dir || ''));
    const st = await fsp.stat(p).catch(() => null);
    if (!st || !st.isDirectory()) throw err('No se encontró la carpeta.', 'PLUGIN_NOT_FOUND');
    const { files, notes } = await readTree(p);
    const extra = [];
    if (notes.symlinks) extra.push(`Se ignoraron ${notes.symlinks} enlace(s) simbólico(s).`);
    if (notes.skipped) extra.push(`Se ignoraron ${notes.skipped} carpeta(s) de herramientas (.git, node_modules…).`);
    return { files, hint: { name: path.basename(p) }, source: { type: 'folder', path: p, name: path.basename(p) }, notes: extra };
  }
  async _loadSingleFile(file) {
    const p = path.resolve(String(file || ''));
    const st = await fsp.stat(p).catch(() => null);
    if (!st || !st.isFile()) throw err('No se encontró el archivo.', 'PLUGIN_NOT_FOUND');
    if (st.size > 1024 * 1024) throw err('El archivo es demasiado grande para ser un manifiesto o una skill.', 'PLUGIN_TOO_BIG');
    const buf = await fsp.readFile(p);
    const ext = path.extname(p).toLowerCase();
    let name;
    if (ext === '.json') {
      let j;
      try {
        j = JSON.parse(core.textOf(buf));
      } catch {
        throw err('El archivo no es un JSON válido.', 'PLUGIN_BAD_MANIFEST');
      }
      name = isObj(j) && /^auric-plugin\//.test(String(j.schema || '')) ? core.MANIFEST_FILE : 'plugin.json';
    } else if (ext === '.md') name = 'SKILL.md';
    else throw err('Solo se pueden importar archivos .json (manifiesto), .md (una skill), carpetas o ZIP.', 'PLUGIN_SOURCE');
    return { files: new Map([[name, buf]]), hint: { name: path.basename(p, ext) }, source: { type: 'file', path: p, name: path.basename(p) }, notes: [] };
  }
  async _loadOfficial(id) {
    const folder = String(id || '');
    if (!core.PLUGIN_ID_RE.test(folder) || !(await this._officialIds()).includes(folder)) throw err('Ese plugin oficial no existe.', 'PLUGIN_NOT_FOUND');
    const { files } = await readTree(path.join(this.officialDir, folder));
    return { files, hint: { name: folder }, source: { type: 'official', id: folder }, notes: [] };
  }

  // ── Registro oficial MCP ──────────────────────────────────────────────────────────────────────
  async registrySearch({ query = '', cursor = '' } = {}) {
    const q = String(query || '').trim().slice(0, 80);
    let page = null;
    let usedPath = '';
    for (const p of registry.API_PATHS) {
      for (const latest of [true, false]) {
        try {
          const buf = await this._fetch(registry.listUrl({ path: p, search: q, cursor, limit: 30, latest }), { hosts: REGISTRY_HOSTS, maxBytes: 3 * 1024 * 1024 });
          page = registry.parsePage(JSON.parse(buf.toString('utf8')));
          usedPath = p;
          break;
        } catch (e) {
          if (e instanceof SyntaxError) throw err('El registro respondió algo que Auric no entiende.', 'REGISTRY_BAD_RESPONSE');
          if (!['PLUGIN_NOT_FOUND', 'PLUGIN_HTTP'].includes(e.code)) throw e;
        }
      }
      if (page) break;
    }
    if (!page) throw err('No se pudo consultar el registro oficial de servidores MCP (puede estar caído o haber cambiado).', 'REGISTRY_UNAVAILABLE');
    const entries = page.entries.filter(e => registry.matchesQuery(e, q));
    const now = Date.now();
    for (const e of entries) this.registryCache.set(e.name, { at: now, entry: e });
    for (const [k, v] of this.registryCache) if (now - v.at > 10 * 60 * 1000) this.registryCache.delete(k);
    return { items: entries.map(registry.summarize), nextCursor: page.nextCursor, path: usedPath, total: page.entries.length };
  }
  async _loadRegistry(name) {
    const key = String(name || '').slice(0, 200);
    if (!key) throw err('Falta el nombre del servidor.', 'PLUGIN_SOURCE');
    let entry = this.registryCache.get(key)?.entry;
    if (!entry) {
      let lastErr;
      for (const p of registry.API_PATHS) {
        try {
          const buf = await this._fetch(registry.itemUrl(key, 'latest', p), { hosts: REGISTRY_HOSTS });
          entry = registry.normalizeEntry(JSON.parse(buf.toString('utf8')));
          if (entry) break;
        } catch (e) {
          lastErr = e;
        }
      }
      if (!entry) throw lastErr?.code ? lastErr : err('No se encontró ese servidor en el registro.', 'PLUGIN_NOT_FOUND');
    }
    const { files, unresolved } = registry.entryToPlugin(entry);
    return { files, hint: { name: entry.name }, source: { type: 'registry', name: entry.name, version: entry.version }, notes: unresolved.length ? [`Faltan datos obligatorios que el registro no define: ${unresolved.join('; ')}.`] : [] };
  }

  // ── Preparar (cargar + revisar) e instalar ────────────────────────────────────────────────────
  _purgeStaged() {
    const now = Date.now();
    for (const [t, s] of this.staged) if (now - s.at > STAGE_TTL_MS) this.staged.delete(t);
    while (this.staged.size > MAX_STAGED) this.staged.delete(this.staged.keys().next().value);
  }
  async _reviewCtx(model, official) {
    const tools = {};
    for (const t of review.toolsNeeded(model)) tools[t] = await this.probeTool(t);
    return { appVersion: this.appVersion, tools, official, builtinConnectorIds: this.builtinConnectorIds() };
  }
  /** Carga el paquete, lo revisa y lo deja en memoria. Devuelve lo que la pantalla enseña y un código de un solo uso para instalarlo. */
  async prepare(source = {}) {
    this._purgeStaged();
    let loaded;
    switch (String(source.type || '')) {
      case 'official':
        loaded = await this._loadOfficial(source.id);
        break;
      case 'github':
        loaded = await this._loadGithub(source.input);
        break;
      case 'zip':
        loaded = await this._loadZipFile(source.path);
        break;
      case 'folder':
        loaded = await this._loadFolder(source.path);
        break;
      case 'file':
        loaded = await this._loadSingleFile(source.path);
        break;
      case 'registry':
        loaded = await this._loadRegistry(source.name);
        break;
      default:
        throw err('No se entendió de dónde importar el plugin.', 'PLUGIN_SOURCE');
    }
    let built;
    try {
      built = core.prepareModel(loaded.files, { ...loaded.hint, stripWrapper: false });
    } catch (e) {
      if (e && e.code === 'PLUGIN_MULTIPLE') e.message = `${e.message} ${multipleHint(loaded.source, e.folders || [])}`;
      throw e;
    }
    const { model, files } = built;
    for (const n of loaded.notes || []) model.notes.push(n);
    const official = loaded.source.type === 'official';
    const rev = review.reviewModel(model, files, await this._reviewCtx(model, official));
    const prevEntry = this._readIndex().plugins[model.manifest.id];
    const prevLock = prevEntry ? await this._readLock(model.manifest.id) : null;
    const diff = prevLock ? core.diffModels(prevLock, model) : null;
    const token = randHex(16);
    this.staged.set(token, { files, model, review: rev, source: loaded.source, at: Date.now() });
    return {
      token,
      plugin: this.summarizeModel(model),
      review: rev,
      source: loaded.source,
      replacing: prevLock ? { version: prevLock.manifest.version, official: prevEntry.source?.type === 'official', sourceType: prevEntry.source?.type || '', enabled: prevEntry.enabled !== false } : null,
      diff,
      sameVersion: !!prevLock && core.compareVersions(prevLock.manifest.version, model.manifest.version) === 0 && prevLock.treeSha256 === model.treeSha256
    };
  }
  discard(token) {
    return this.staged.delete(String(token));
  }

  async install(token, { acknowledged = false } = {}) {
    return this._serial(async () => {
      this._purgeStaged();
      const st = this.staged.get(String(token));
      if (!st) throw err('La revisión caducó. Vuelve a elegir el plugin para revisarlo de nuevo.', 'PLUGIN_STAGE_EXPIRED');
      if (st.review.blocked) throw err(st.review.blocked.message, st.review.blocked.code);
      if (st.review.needsAck && acknowledged !== true) throw err('Este plugin tiene señales de riesgo alto. Marca «Entiendo el riesgo» para instalarlo.', 'PLUGIN_NEEDS_ACK');
      const { model, files } = st;
      const id = model.manifest.id;
      const dest = this.dirOf(id);
      await fsp.mkdir(this.root, { recursive: true });
      const tmp = path.join(this.root, `.install-${id}-${randHex(4)}`);
      let swapped = false;
      let old = '';
      try {
        const filesDir = path.join(tmp, 'files');
        await fsp.mkdir(filesDir, { recursive: true });
        for (const [rel, buf] of files) {
          const target = path.join(filesDir, ...rel.split('/'));
          if (!inside(filesDir, target)) throw err(`Ruta no permitida en el paquete: ${rel}`, 'PLUGIN_UNSAFE_PATH');
          await fsp.mkdir(path.dirname(target), { recursive: true });
          await fsp.writeFile(target, buf, { flag: 'wx' });
        }
        await fsp.mkdir(path.join(tmp, 'data'), { recursive: true });
        const prevEntry = this._readIndex().plugins[id];
        const lock = {
          schema: LOCK_SCHEMA,
          id,
          origin: model.origin,
          manifest: model.manifest,
          installedAt: prevEntry?.installedAt || nowIso(),
          updatedAt: nowIso(),
          source: st.source,
          treeSha256: model.treeSha256,
          files: model.files,
          stats: model.stats,
          components: {
            skills: model.skills,
            instructions: model.instructions,
            mcp: model.mcp,
            connectors: model.connectors
          },
          review: { level: st.review.level, counts: st.review.counts, acknowledged: acknowledged === true, findings: st.review.findings.filter(f => f.severity !== 'info').map(f => ({ id: f.id, severity: f.severity, title: f.title })) },
          ignored: model.ignored,
          notes: model.notes
        };
        await fsp.writeFile(path.join(tmp, 'plugin.lock.json'), JSON.stringify(lock, null, 2));
        // Lo escrito en disco debe ser lo revisado: se vuelve a leer y a comprobar antes de dar el plugin por instalado.
        const back = await this._walk(filesDir);
        const table = [];
        for (const w of back.sort((a, b) => (a.rel < b.rel ? -1 : 1))) table.push({ path: w.rel, size: w.size, sha256: core.sha256(await fsp.readFile(w.abs)), kind: core.fileKind(w.rel) });
        if (core.treeDigest(table) !== model.treeSha256) throw err('Lo que se escribió en el disco no coincide con lo que se revisó. No se instaló nada.', 'PLUGIN_VERIFY_FAILED');
        // Cambio de carpeta (el plugin anterior se conserva hasta que el nuevo está en su sitio)
        this.stopMcpPrefix(`${id}/`);
        if (await exists(dest)) {
          old = `${dest}.old-${randHex(3)}`;
          await renameRetry(dest, old);
        }
        try {
          await renameRetry(tmp, dest);
          swapped = true;
        } catch (e) {
          if (old) await renameRetry(old, dest).catch(() => {});
          throw e;
        }
        if (old) {
          if (await exists(path.join(old, 'data'))) {
            await rmrf(path.join(dest, 'data'));
            await renameRetry(path.join(old, 'data'), path.join(dest, 'data'));
          }
          await rmrf(old);
        }
        const idx = this._readIndex();
        idx.plugins[id] = {
          version: model.manifest.version,
          enabled: prevEntry ? prevEntry.enabled !== false : true,
          installedAt: lock.installedAt,
          updatedAt: lock.updatedAt,
          source: st.source,
          origin: model.origin,
          treeSha256: model.treeSha256,
          connectorIds: prevEntry?.connectorIds || {}
        };
        await this._writeIndex();
        this.integrityCache.delete(id);
        this.staged.delete(String(token));
        this.log('plugin instalado', id, model.manifest.version);
      } catch (e) {
        if (!swapped) await rmrf(tmp).catch(() => {});
        throw e;
      }
      this.onChange({ id, action: 'install' });
      return this._describe(id);
    });
  }

  async uninstall(id, { removeConnectors = false } = {}) {
    return this._serial(async () => {
      const idx = this._readIndex();
      const entry = idx.plugins[id];
      if (!entry) throw err('Ese plugin no está instalado.', 'PLUGIN_NOT_FOUND');
      const dir = this.dirOf(id);
      this.stopMcpPrefix(`${id}/`);
      const removed = { files: true, connectors: [], secrets: 0 };
      if (removeConnectors) {
        for (const customId of Object.values(entry.connectorIds || {})) {
          try {
            await this.connectors()?.removeCustom(customId);
            removed.connectors.push(customId);
          } catch (e) {
            this.log('no se pudo quitar el conector', customId, e.message);
          }
        }
      }
      await rmrf(dir);
      delete idx.plugins[id];
      await this._writeIndex();
      const secrets = this._loadSecrets();
      if (secrets[id]) {
        removed.secrets = Object.keys(secrets[id]).length;
        delete secrets[id];
        this._saveSecrets();
      }
      this.integrityCache.delete(id);
      this.log('plugin desinstalado', id);
      this.onChange({ id, action: 'uninstall' });
      return removed;
    });
  }
  async setEnabled(id, enabled) {
    return this._serial(async () => {
      const idx = this._readIndex();
      if (!idx.plugins[id]) throw err('Ese plugin no está instalado.', 'PLUGIN_NOT_FOUND');
      idx.plugins[id].enabled = !!enabled;
      await this._writeIndex();
      if (!enabled) this.stopMcpPrefix(`${id}/`);
      this.onChange({ id, action: enabled ? 'enable' : 'disable' });
      return this._describe(id);
    });
  }
  async verify(id) {
    const ids = id ? [id] : Object.keys(this._readIndex().plugins);
    const out = {};
    for (const i of ids) out[i] = await this.integrity(i, { force: true });
    return out;
  }

  // ── Claves del plugin (cifradas con el almacén del sistema; nunca vuelven a la pantalla) ───────
  _encOk() {
    try {
      return !!this.safeStorage?.isEncryptionAvailable?.();
    } catch {
      return false;
    }
  }
  _secFile() {
    return path.join(this.root, 'secrets.bin');
  }
  _loadSecrets() {
    if (this._secrets) return this._secrets;
    this._secrets = { ...this._memSecrets };
    try {
      if (this._encOk()) this._secrets = JSON.parse(this.safeStorage.decryptString(fs.readFileSync(this._secFile())));
    } catch {}
    return this._secrets;
  }
  _saveSecrets() {
    const data = this._loadSecrets();
    if (!this._encOk()) {
      this._memSecrets = JSON.parse(JSON.stringify(data));
      return false;
    }
    fs.mkdirSync(this.root, { recursive: true });
    const tmp = `${this._secFile()}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, this.safeStorage.encryptString(JSON.stringify(data)));
    fs.renameSync(tmp, this._secFile());
    return true;
  }
  async _declaredEnv(id) {
    const lock = await this._readLock(id);
    if (!lock) throw err('Ese plugin no está instalado.', 'PLUGIN_NOT_FOUND');
    return lock.manifest.permissions?.env || [];
  }
  async setSecret(id, name, value) {
    const declared = await this._declaredEnv(id);
    const n = String(name || '');
    if (!declared.includes(n)) throw err(`El plugin no declaró la clave «${n.slice(0, 40)}».`, 'PLUGIN_SECRET_UNDECLARED');
    if (pexec.NEVER.test(n)) throw err('Esa variable no se le puede entregar a un plugin.', 'PLUGIN_SECRET_BLOCKED');
    const v = String(value ?? '');
    if (!v || v.length > 4000 || /[\u0000\r\n]/.test(v)) throw err('El valor no es válido (vacío, demasiado largo o con saltos de línea).', 'PLUGIN_SECRET_BAD');
    const all = this._loadSecrets();
    all[id] = { ...(all[id] || {}), [n]: v };
    const persistent = this._saveSecrets();
    this.onChange({ id, action: 'secret' });
    return { saved: true, persistent };
  }
  async clearSecret(id, name) {
    await this._declaredEnv(id);
    const all = this._loadSecrets();
    if (all[id]) {
      delete all[id][String(name || '')];
      if (!Object.keys(all[id]).length) delete all[id];
      this._saveSecrets();
    }
    this.onChange({ id, action: 'secret' });
    return { cleared: true };
  }

  // ── Piezas activas (las usa el resto de la app) ───────────────────────────────────────────────
  async _activeIds() {
    const out = [];
    for (const [id, e] of Object.entries(this._readIndex().plugins)) {
      if (e.enabled === false) continue;
      const lock = await this._readLock(id);
      if (!lock) continue;
      const integ = await this.integrity(id);
      out.push({ id, lock, integ });
    }
    return out;
  }
  /** Skills de los plugins activos (con su texto leído y comprobado contra la huella de la instalación). */
  async skillsForScan() {
    const skills = [];
    const errors = [];
    for (const { id, lock, integ } of await this._activeIds()) {
      if (integ.status !== 'ok') {
        errors.push({ folder: this.filesDir(id), error: `El plugin «${lock.manifest.name}» cambió desde que lo instalaste y está desactivado. Vuelve a importarlo para revisarlo.` });
        continue;
      }
      const hashOf = new Map(lock.files.map(f => [f.path, f.sha256]));
      for (const sk of lock.components.skills) {
        try {
          const abs = path.join(this.filesDir(id), ...sk.file.split('/'));
          const buf = await fsp.readFile(abs);
          if (core.sha256(buf) !== hashOf.get(sk.file)) throw new Error('el archivo cambió');
          const parsed = parseSkillFrontmatter(core.textOf(buf));
          let procedure = neutralizeDelimiters(parsed.procedure);
          if (procedure.length > PLUGIN_SKILL_CAP) procedure = `${procedure.slice(0, PLUGIN_SKILL_CAP)}\n\n[Auric recortó esta skill: era demasiado larga para agregarla completa a la conversación.]`;
          skills.push({
            id: `${id}/${sk.id}`,
            name: sk.name,
            description: sk.description,
            icon: '',
            logo: '',
            color: '',
            triggers: sk.triggers,
            markers: sk.markers,
            tags: [],
            procedure,
            path: abs,
            folder: path.dirname(abs),
            source: 'plugin',
            readOnly: true,
            pluginId: id,
            pluginName: lock.manifest.name
          });
        } catch (e) {
          errors.push({ folder: this.filesDir(id), error: `No se pudo leer la skill «${sk.name}» del plugin «${lock.manifest.name}»: ${String(e.message || e).slice(0, 100)}` });
        }
      }
    }
    return { skills, errors };
  }
  /** Instrucciones de los plugins activos para el prompt (ya neutralizadas y con tope de tamaño). */
  async instructionsForPrompt() {
    const out = [];
    let total = 0;
    for (const { id, lock, integ } of await this._activeIds()) {
      if (integ.status !== 'ok' || !lock.components.instructions) continue;
      try {
        const buf = await fsp.readFile(path.join(this.filesDir(id), ...lock.components.instructions.file.split('/')));
        if (core.sha256(buf) !== lock.components.instructions.sha256) continue;
        let text = neutralizeDelimiters(core.textOf(buf).trim());
        if (text.length > PLUGIN_INSTRUCTIONS_CAP) text = `${text.slice(0, PLUGIN_INSTRUCTIONS_CAP)}\n[recortado por Auric]`;
        if (total + text.length > PLUGIN_BLOCK_CAP) break;
        total += text.length;
        out.push({ pluginId: id, pluginName: lock.manifest.name, text });
      } catch {}
    }
    return out;
  }
  /** Servidores MCP de los plugins activos, para que la app los ofrezca a la IA. */
  async mcpServers() {
    const out = [];
    for (const { id, lock, integ } of await this._activeIds()) {
      if (integ.status !== 'ok') continue;
      for (const x of lock.components.mcp) out.push({ id: `${id}/${x.id}`, name: x.name, description: x.description, pluginId: id, pluginName: lock.manifest.name, serverId: x.id, commandLine: [x.command, ...x.args].join(' '), cwd: x.cwd });
    }
    return out;
  }

  /**
   * Convierte un servidor de plugin en lo que realmente se ejecuta (comando completo, carpeta, entorno mínimo).
   * Vuelve a comprobar TODOS los archivos justo antes: si algo cambió desde que lo revisaste, no arranca.
   */
  async resolveMcp(ref = {}, ctx = {}) {
    const id = String(ref.plugin || '');
    const sid = String(ref.server || '');
    const entry = this._readIndex().plugins[id];
    if (!entry || entry.enabled === false) throw err(`El plugin «${id}» no está instalado o está desactivado.`, 'PLUGIN_DISABLED');
    const lock = await this._readLock(id);
    const srv = lock?.components?.mcp?.find(m => m.id === sid);
    if (!srv) throw err(`El plugin «${id}» no tiene un servidor «${sid}».`, 'PLUGIN_NOT_FOUND');
    const integ = await this.integrity(id, { force: true });
    if (integ.status !== 'ok') throw err(`Los archivos del plugin «${lock.manifest.name}» cambiaron desde que lo instalaste (${integ.detail}). Auric no ejecuta nada de él hasta que lo vuelvas a revisar.`, 'PLUGIN_MODIFIED');
    const dataDir = this.dataDir(id);
    await fsp.mkdir(dataDir, { recursive: true });
    const roots = (Array.isArray(ctx.roots) ? ctx.roots : []).map(r => String(r?.path || r || '').trim()).filter(Boolean);
    const vars = { PLUGIN_DIR: this.filesDir(id), PLUGIN_DATA: dataDir, WORKSPACE: roots[0] || '', AURIC_NODE: this.nodePath };
    const declared = new Set(lock.manifest.permissions?.env || []);
    const secrets = this._loadSecrets()[id] || {};
    const lookup = name => (secrets[name] != null ? secrets[name] : this.env[name]);
    const expand = text => core.expandPlaceholders(pexec.expandRefs(text, { declared, lookup }).text, vars);
    const usesNode = /^\$\{AURIC_NODE\}$/.test(srv.command);
    let command = expand(srv.command);
    const args = srv.args.map(expand);
    if (!/[\\/]/.test(command)) command = await this._resolveBare(command);
    let cwd = dataDir;
    if (srv.cwd === 'workspace') {
      if (!roots[0]) throw err('Este servidor necesita que tengas un proyecto abierto.', 'PLUGIN_NEEDS_WORKSPACE');
      cwd = roots[0];
    }
    const env = pexec.baseEnv(this.env, this.platform);
    for (const [k, v] of Object.entries(srv.env || {})) {
      if (pexec.NEVER.test(k)) continue;
      env[k] = expand(v);
    }
    if (usesNode) env.ELECTRON_RUN_AS_NODE = '1';
    env.AURIC_PLUGIN_DIR = vars.PLUGIN_DIR;
    env.AURIC_PLUGIN_DATA = dataDir;
    if (roots[0]) env.AURIC_WORKSPACE = roots[0];
    const plan = pexec.planSpawn({ command, args, platform: this.platform, comspec: this.env.ComSpec || this.env.COMSPEC || 'cmd.exe' });
    return { id: `${id}/${sid}`, command: plan.file, args: plan.args, cwd, env, isolated: true, verbatim: plan.verbatim, pluginId: id };
  }

  // ── Conectores del plugin ─────────────────────────────────────────────────────────────────────
  async connectConnector(id, connectorId, input = {}) {
    const entry = this._readIndex().plugins[id];
    const lock = entry ? await this._readLock(id) : null;
    const c = lock?.components.connectors.find(x => x.id === String(connectorId));
    if (!c) throw err('Ese conector no pertenece al plugin.', 'PLUGIN_NOT_FOUND');
    if (!c.url) return { ref: c.ref };
    const mgr = this.connectors();
    if (!mgr) throw err('Los conectores no están disponibles.', 'PLUGIN_NO_CONNECTORS');
    if (entry.connectorIds?.[c.id]) return { customId: entry.connectorIds[c.id], already: true };
    const before = new Set(mgr.catalog().map(x => x.id));
    let result;
    let failure = null;
    try {
      result = await mgr.addCustom({ name: c.name, url: c.url, token: String(input.token || ''), description: c.description });
    } catch (e) {
      failure = e;
    }
    const created = mgr.catalog().find(x => !before.has(x.id) && x.custom && x.url === c.url);
    const customId = result?.id || created?.id || '';
    if (customId) {
      entry.connectorIds = { ...(entry.connectorIds || {}), [c.id]: customId };
      await this._writeIndex();
      this.onChange({ id, action: 'connector' });
    }
    if (failure) throw failure;
    return { customId, connected: !!result?.connected, toolCount: result?.toolCount || 0 };
  }
}

// ── Gestor único y registro de los IPC ─────────────────────────────────────────────────────────
let defaultManager = null;
function getManager() {
  return defaultManager;
}
function register({ app, ipcMain, safeStorage, shell, getWindow, hostMap, connectors, builtinConnectorIds, appVersion, officialDir, stopMcpPrefix, log }) {
  const mgr = new PluginManager({
    root: path.join(app.getPath('userData'), 'auric-plugins'),
    officialDir,
    appVersion,
    safeStorage,
    hostMap,
    connectors,
    builtinConnectorIds,
    userAgent: `Auric-Code/${appVersion}`,
    stopMcpPrefix,
    log: log || (() => {}),
    onChange: detail => {
      try {
        getWindow?.()?.webContents?.send('auric:event', { name: 'plugins-changed', detail });
      } catch {}
    }
  });
  defaultManager = mgr;
  const wrap =
    fn =>
    async (_e, ...args) => {
      try {
        return { ok: true, value: await fn(...args) };
      } catch (e) {
        return { ok: false, error: String(e?.message || e), code: e?.code || '' };
      }
    };
  const h = (name, fn) => ipcMain.handle(`auric:plugins-${name}`, wrap(fn));
  h('list', () => mgr.list());
  h('catalog', () => mgr.catalog());
  h('prepare', source => mgr.prepare(source || {}));
  h('discard', token => mgr.discard(token));
  h('install', (token, opts) => mgr.install(String(token || ''), { acknowledged: opts?.acknowledged === true }));
  h('uninstall', (id, opts) => mgr.uninstall(String(id || ''), { removeConnectors: opts?.removeConnectors === true }));
  h('set-enabled', (id, enabled) => mgr.setEnabled(String(id || ''), enabled === true));
  h('verify', id => mgr.verify(id ? String(id) : ''));
  h('secret-set', (id, name, value) => mgr.setSecret(String(id || ''), String(name || ''), value));
  h('secret-clear', (id, name) => mgr.clearSecret(String(id || ''), String(name || '')));
  h('connect', (id, connectorId, input) => mgr.connectConnector(String(id || ''), String(connectorId || ''), input || {}));
  h('registry-search', opts => mgr.registrySearch(opts || {}));
  h('mcp-servers', () => mgr.mcpServers());
  h('instructions', () => mgr.instructionsForPrompt());
  h('reveal', async id => {
    const d = mgr.dirOf(String(id || ''));
    if (!(await exists(d))) throw err('Ese plugin no está instalado.', 'PLUGIN_NOT_FOUND');
    shell?.showItemInFolder?.(path.join(mgr.filesDir(String(id))));
    return true;
  });
  return mgr;
}

module.exports = { register, getManager, PluginManager, readTree, zipToFiles, neutralizeDelimiters, LOCK_SCHEMA, PLUGIN_SKILL_CAP };
