'use strict';
// Registro oficial de servidores MCP (https://registry.modelcontextprotocol.io): leer sus respuestas y convertir una entrada en un plugin.
// Parte PURA (sin red). El registro está en «vista previa» y su formato cambió con el tiempo (camelCase actual, snake_case antiguo; cada
// elemento puede venir envuelto en {server, _meta} o suelto), así que aquí se aceptan las dos formas. Todo lo que viene del registro es
// texto de terceros: solo se muestra, y el plugin resultante pasa por la MISMA revisión de seguridad que cualquier otro.
const core = require('./plugins-core');

const REGISTRY_ORIGIN = 'https://registry.modelcontextprotocol.io';
const API_PATHS = ['/v0.1/servers', '/v0/servers'];

const isObj = v => !!v && typeof v === 'object' && !Array.isArray(v);
const pick = (o, ...keys) => {
  for (const k of keys) if (o && o[k] != null) return o[k];
  return undefined;
};
const text = (v, max) => core.str(typeof v === 'string' ? v : '', max);

function listUrl({ path = API_PATHS[0], search = '', limit = 20, cursor = '', latest = true } = {}) {
  const u = new URL(REGISTRY_ORIGIN + path);
  const q = String(search || '').trim().slice(0, 80);
  if (q) u.searchParams.set('search', q);
  u.searchParams.set('limit', String(Math.max(1, Math.min(50, Number(limit) || 20))));
  if (cursor) u.searchParams.set('cursor', String(cursor).slice(0, 300));
  if (latest) u.searchParams.set('version', 'latest');
  return u.href;
}
function itemUrl(name, version = 'latest', path = API_PATHS[0]) {
  return `${REGISTRY_ORIGIN}${path}/${encodeURIComponent(String(name))}/versions/${encodeURIComponent(String(version))}`;
}

// ── Lectura de una entrada ──────────────────────────────────────────────────────────────────────
function normalizeKeyValues(list, max = 30) {
  const out = [];
  for (const raw of Array.isArray(list) ? list.slice(0, max) : []) {
    if (!isObj(raw)) continue;
    const name = text(raw.name, 64);
    if (!name) continue;
    out.push({
      name,
      description: text(raw.description, 200),
      required: !!pick(raw, 'isRequired', 'is_required'),
      secret: !!pick(raw, 'isSecret', 'is_secret'),
      value: typeof raw.value === 'string' ? raw.value : undefined,
      default: typeof raw.default === 'string' ? raw.default : undefined,
      hasVariables: isObj(raw.variables) && Object.keys(raw.variables).length > 0
    });
  }
  return out;
}
function normalizeArgs(list, max = 30) {
  const out = [];
  for (const raw of Array.isArray(list) ? list.slice(0, max) : []) {
    if (!isObj(raw)) continue;
    const type = raw.type === 'named' ? 'named' : 'positional';
    out.push({
      type,
      name: text(raw.name, 80),
      value: typeof raw.value === 'string' ? raw.value : undefined,
      default: typeof raw.default === 'string' ? raw.default : undefined,
      valueHint: text(pick(raw, 'valueHint', 'value_hint'), 60),
      required: !!pick(raw, 'isRequired', 'is_required'),
      hasVariables: isObj(raw.variables) && Object.keys(raw.variables).length > 0
    });
  }
  return out;
}

// Acepta {server, _meta}, el servidor suelto, y las dos escrituras de los campos.
function normalizeEntry(item) {
  if (!isObj(item)) return null;
  const s = isObj(item.server) ? item.server : item;
  const name = text(s.name, 200);
  if (!name) return null;
  const meta = isObj(item._meta) ? item._meta : isObj(s._meta) ? s._meta : {};
  const official = isObj(meta['io.modelcontextprotocol.registry/official']) ? meta['io.modelcontextprotocol.registry/official'] : {};
  const repo = isObj(s.repository) ? s.repository : {};
  const packages = [];
  for (const p of Array.isArray(s.packages) ? s.packages.slice(0, 10) : []) {
    if (!isObj(p)) continue;
    const type = text(pick(p, 'registryType', 'registry_type', 'registry_name'), 20).toLowerCase();
    const identifier = text(pick(p, 'identifier', 'name'), 400);
    if (!type || !identifier) continue;
    const transport = isObj(p.transport) ? p.transport : { type: text(pick(p, 'transport_type'), 30) || 'stdio' };
    packages.push({
      type,
      identifier,
      version: text(p.version, 60),
      runtimeHint: text(pick(p, 'runtimeHint', 'runtime_hint'), 20).toLowerCase(),
      transport: { type: text(transport.type, 30).toLowerCase() || 'stdio', url: text(transport.url, 400) },
      env: normalizeKeyValues(pick(p, 'environmentVariables', 'environment_variables')),
      runtimeArgs: normalizeArgs(pick(p, 'runtimeArguments', 'runtime_arguments')),
      packageArgs: normalizeArgs(pick(p, 'packageArguments', 'package_arguments')),
      fileSha256: text(pick(p, 'fileSha256', 'file_sha256'), 80)
    });
  }
  const remotes = [];
  for (const r of Array.isArray(s.remotes) ? s.remotes.slice(0, 6) : []) {
    if (!isObj(r)) continue;
    const url = text(r.url, 500);
    if (!url) continue;
    remotes.push({
      type: text(pick(r, 'type', 'transport_type'), 30).toLowerCase() || 'streamable-http',
      url,
      headers: normalizeKeyValues(r.headers, 10)
    });
  }
  return {
    name,
    title: text(s.title, 100),
    description: text(s.description, 400),
    version: text(s.version, 60),
    websiteUrl: text(pick(s, 'websiteUrl', 'website_url'), 300),
    repositoryUrl: text(repo.url, 300),
    status: text(official.status || s.status, 20) || 'active',
    isLatest: official.isLatest !== false,
    packages,
    remotes
  };
}

function parsePage(json) {
  const root = isObj(json) ? json : {};
  const list = Array.isArray(root.servers) ? root.servers : Array.isArray(root) ? root : [];
  const entries = [];
  const seen = new Map();
  for (const it of list) {
    const e = normalizeEntry(it);
    if (!e || e.status === 'deleted') continue;
    const prev = seen.get(e.name);
    if (prev) {
      // Varias versiones del mismo servidor: se queda la más nueva.
      if (core.compareVersions(e.version, prev.version) > 0) {
        entries[entries.indexOf(prev)] = e;
        seen.set(e.name, e);
      }
      continue;
    }
    seen.set(e.name, e);
    entries.push(e);
  }
  const meta = isObj(root.metadata) ? root.metadata : {};
  return { entries, nextCursor: text(pick(meta, 'nextCursor', 'next_cursor') || '', 300) };
}

const matchesQuery = (e, q) => {
  const needle = core.slug(q, 60).replace(/-/g, ' ');
  if (!needle) return true;
  const hay = core.slug(`${e.name} ${e.title} ${e.description}`, 800).replace(/-/g, ' ');
  return needle.split(' ').every(w => hay.includes(w));
};

// Lo que se enseña en la lista de resultados (sin los detalles técnicos).
function summarize(e) {
  const kinds = [...new Set(e.packages.map(p => p.type))];
  const usable = pickPackage(e) || null;
  return {
    name: e.name,
    title: e.title || e.name.split('/').pop(),
    description: e.description,
    version: e.version,
    repositoryUrl: /^https:\/\//i.test(e.repositoryUrl) ? e.repositoryUrl : '',
    websiteUrl: /^https:\/\//i.test(e.websiteUrl) ? e.websiteUrl : '',
    status: e.status,
    packageTypes: kinds,
    remote: e.remotes.some(r => safeRemoteUrl(r.url)),
    installable: !!usable || e.remotes.some(r => safeRemoteUrl(r.url)),
    needs: usable ? usable.env.filter(v => v.required).map(v => v.name) : []
  };
}

// ── Conversión a plugin ─────────────────────────────────────────────────────────────────────────
const PREFERENCE = ['npm', 'pypi', 'oci', 'nuget'];
// Un identificador que empiece con «-» se leería como una opción del programa (p. ej. --registry=…): se rechaza.
const IDENT_RE = {
  npm: /^(?:@[a-z0-9][a-z0-9._~-]*\/)?[a-z0-9][a-z0-9._~-]*$/,
  pypi: /^[A-Za-z0-9][A-Za-z0-9._-]*$/,
  nuget: /^[A-Za-z0-9][A-Za-z0-9._-]*$/,
  oci: /^[a-z0-9][a-z0-9._\-/:@]*$/
};
const VERSION_RE = /^[0-9A-Za-z][0-9A-Za-z.+_~-]*$/;
const validPackage = p => PREFERENCE.includes(p.type) && IDENT_RE[p.type].test(p.identifier) && p.identifier.length <= 200 && (!p.version || (VERSION_RE.test(p.version) && p.type !== 'oci'));
function pickPackage(e) {
  const stdio = e.packages.filter(p => (p.transport.type || 'stdio') === 'stdio' && validPackage(p));
  stdio.sort((a, b) => PREFERENCE.indexOf(a.type) - PREFERENCE.indexOf(b.type));
  return stdio[0] || null;
}
function safeRemoteUrl(url) {
  if (/[{}]/.test(url)) return '';
  const u = core.httpsUrl(url);
  return u ? u.href : '';
}
const staticArg = a => (a.value != null && a.value !== '' ? a.value : a.default != null && a.default !== '' ? a.default : undefined);
function renderArgs(list, unresolved, label) {
  const out = [];
  for (const a of list) {
    const v = staticArg(a);
    const name = a.name || a.valueHint || 'un valor';
    if (a.hasVariables || v === undefined || /\{[^}]*\}/.test(String(v))) {
      if (a.required) unresolved.push(`${label}: ${name}`);
      continue;
    }
    if (a.type === 'named' && a.name) {
      if (a.name.endsWith('=')) out.push(a.name + v);
      else {
        out.push(a.name);
        if (v !== '') out.push(String(v));
      }
    } else out.push(String(v));
  }
  return out;
}

/**
 * Convierte una entrada del registro en los archivos de un plugin (un auric-plugin.json).
 * Devuelve { files, unresolved } o lanza PluginError si Auric no sabe ejecutar nada de esa entrada.
 */
function entryToPlugin(e) {
  const pkg = pickPackage(e);
  const remotes = e.remotes.map(r => ({ ...r, safe: safeRemoteUrl(r.url) })).filter(r => r.safe && ['streamable-http', 'http', 'sse'].includes(r.type));
  if (!pkg && !remotes.length) {
    const kinds = [...new Set(e.packages.map(p => p.type))];
    throw new core.PluginError(
      kinds.length
        ? `Este servidor se distribuye como ${kinds.join(', ')}, y Auric solo sabe ejecutar paquetes npm, PyPI, Docker o NuGet, o conectarse a servidores remotos.`
        : 'Esta entrada del registro no trae nada que Auric pueda ejecutar o a lo que pueda conectarse.',
      'REGISTRY_UNSUPPORTED'
    );
  }
  const unresolved = [];
  const mcp = [];
  const envNames = [];
  const runs = [];
  if (pkg) {
    const ver = pkg.version && core.parseVersion(pkg.version) ? pkg.version : pkg.version || '';
    const runtime = renderArgs(pkg.runtimeArgs, unresolved, 'Opción de ejecución');
    const pargs = renderArgs(pkg.packageArgs, unresolved, 'Argumento');
    const env = {};
    for (const v of pkg.env) {
      const fixed = v.value !== undefined && v.value !== '' && !v.hasVariables && !/\{[^}]*\}/.test(v.value) ? v.value : undefined;
      if (fixed !== undefined && !v.secret) env[v.name] = fixed;
      else if (v.default !== undefined && v.default !== '' && !v.required && !v.secret) env[v.name] = v.default;
      else if (v.required || v.secret) {
        env[v.name] = `\${${v.name}}`;
        envNames.push(v.name);
      }
    }
    let command = '',
      args = [];
    if (pkg.type === 'npm') {
      command = 'npx';
      args = [...runtime, '-y', ver ? `${pkg.identifier}@${ver}` : pkg.identifier, ...pargs];
    } else if (pkg.type === 'pypi') {
      command = 'uvx';
      args = [...runtime, ver ? `${pkg.identifier}@${ver}` : pkg.identifier, ...pargs];
    } else if (pkg.type === 'nuget') {
      command = 'dnx';
      args = [...runtime, ver ? `${pkg.identifier}@${ver}` : pkg.identifier, '--yes', ...pargs];
    } else if (pkg.type === 'oci') {
      command = 'docker';
      args = ['run', '-i', '--rm', ...Object.keys(env).flatMap(k => ['-e', k]), ...runtime, pkg.identifier, ...pargs];
    }
    const id = core.slug(e.name.split('/').pop(), 38) || 'servidor';
    mcp.push({ id, name: e.title || e.name.split('/').pop(), description: e.description, command, args, env, cwd: 'plugin' });
    runs.push([command, ...args].join(' '));
  }
  const connectors = remotes.slice(0, 4).map((r, i) => {
    let host = 'remoto';
    try {
      host = new URL(r.safe).hostname;
    } catch {}
    return { id: core.slug(`${host}-${i + 1}`, 38), name: `${e.title || e.name.split('/').pop()} (${host})`, description: e.description, url: r.safe, auth: r.headers.some(h => /^authorization$/i.test(h.name)) ? 'token' : 'oauth' };
  });
  const id = ('mcp-' + core.slug(e.name, 44)).slice(0, 48).replace(/-+$/, '');
  const hostsDeclared = connectors.map(c => new URL(c.url).hostname);
  const manifest = {
    schema: core.SCHEMA,
    id: id.length >= 3 ? id : 'mcp-servidor',
    name: e.title || e.name.split('/').pop(),
    version: core.parseVersion(e.version) ? e.version : '0.0.0',
    description: e.description || `Servidor MCP «${e.name}» del registro oficial.`,
    ...(e.websiteUrl && /^https:\/\//i.test(e.websiteUrl) ? { homepage: e.websiteUrl } : e.repositoryUrl && /^https:\/\//i.test(e.repositoryUrl) ? { homepage: e.repositoryUrl } : {}),
    permissions: {
      env: envNames,
      network: hostsDeclared,
      runs,
      notes: `Convertido automáticamente desde la entrada «${e.name}» del registro oficial de servidores MCP. Quien lo publicó es un tercero y Auric no revisó el código del paquete.${unresolved.length ? ' Faltan datos obligatorios que el registro no define: ' + unresolved.join('; ') + '.' : ''}`
    },
    ...(mcp.length ? { mcp } : {}),
    ...(connectors.length ? { connectors } : {})
  };
  const files = new Map([[core.MANIFEST_FILE, Buffer.from(JSON.stringify(manifest, null, 2), 'utf8')]]);
  return { files, unresolved, manifest };
}

module.exports = { REGISTRY_ORIGIN, API_PATHS, listUrl, itemUrl, normalizeEntry, parsePage, matchesQuery, summarize, pickPackage, entryToPlugin, safeRemoteUrl };
