'use strict';
// Revisión de seguridad de un plugin ANTES de instalarlo. Es pura: no toca el disco ni la red.
// Qué hace: lista, en palabras simples, qué programas va a ejecutar, a qué sitios se conecta, qué claves pide, qué archivos trae
// y qué le dice a la IA; y marca con «atención» o «riesgo alto» las señales conocidas de trampa.
// Qué NO hace (y la pantalla lo dice): no puede garantizar que un plugin sea seguro. Es una revisión por reglas y un plugin
// escrito con cuidado puede esquivarla. Por eso los programas de un plugin SIEMPRE se muestran enteros y nunca se ejecutan en silencio.
const core = require('./plugins-core');

const SEV = { info: 0, warn: 1, danger: 2 };
const AREAS = ['programs', 'files', 'network', 'secrets', 'instructions', 'requirements', 'general'];

const fold = s =>
  String(s ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
const shorten = (s, n = 140) => {
  const t = String(s ?? '').replace(/\s+/g, ' ').trim();
  return t.length > n ? t.slice(0, n - 1) + '…' : t;
};
// Caracteres invisibles que esconden texto: se hacen visibles para que la persona vea que están.
const INVISIBLE_RE = /[\u200b\u200c\u2060-\u2064\u202a-\u202e\u2066-\u2069\u00ad\u061c\u180e\ufeff]|[\u{e0000}-\u{e007f}]/gu;
const visible = s => String(s).replace(INVISIBLE_RE, c => `⟦U+${c.codePointAt(0).toString(16).toUpperCase().padStart(4, '0')}⟧`);

class Findings {
  constructor() {
    this.list = [];
    this.byId = new Map();
  }
  add(f) {
    const prev = f.id ? this.byId.get(f.id) : null;
    if (prev) {
      for (const it of f.items || []) if (!prev.items.includes(it) && prev.items.length < 8) prev.items.push(it);
      if (SEV[f.severity] > SEV[prev.severity]) prev.severity = f.severity;
      return prev;
    }
    const row = { id: f.id || `f${this.list.length}`, severity: f.severity, area: f.area, title: f.title, detail: f.detail || '', items: (f.items || []).slice(0, 8) };
    this.list.push(row);
    this.byId.set(row.id, row);
    return row;
  }
}

// ── Programas (servidores MCP) ──────────────────────────────────────────────────────────────────
const baseCommand = cmd => {
  const raw = String(cmd || '').trim();
  if (/^\$\{AURIC_NODE\}$/.test(raw)) return 'auric-node';
  const name = raw.replace(/\\/g, '/').split('/').pop().toLowerCase();
  return name.replace(/\.(exe|cmd|bat|com|ps1)$/i, '');
};
const SHELL_CMDS = new Set(['cmd', 'powershell', 'pwsh', 'bash', 'sh', 'zsh', 'fish', 'wsl', 'dash', 'ksh', 'csh', 'tcsh']);
const LOLBINS = new Set(['wscript', 'cscript', 'mshta', 'rundll32', 'regsvr32', 'msiexec', 'certutil', 'bitsadmin', 'wmic', 'schtasks', 'reg', 'sc', 'net', 'netsh', 'curl', 'wget', 'invoke-webrequest', 'iwr', 'telnet', 'nc', 'ncat', 'ssh', 'scp', 'ftp', 'tftp', 'taskkill', 'powershell_ise', 'installutil', 'regasm', 'regsvcs', 'msbuild', 'forfiles', 'pcalua', 'sudo', 'su', 'runas']);
const INTERPRETERS = new Set(['node', 'nodejs', 'bun', 'deno', 'python', 'python3', 'py', 'pythonw', 'ruby', 'perl', 'php', 'java', 'javaw', 'dotnet', 'go', 'lua', 'auric-node']);
const RUNNERS = new Set(['npx', 'bunx', 'pnpx', 'uvx', 'pipx']);
const INLINE_FLAGS = {
  node: ['-e', '--eval', '-p', '--print', '--input-type'],
  nodejs: ['-e', '--eval', '-p', '--print'],
  'auric-node': ['-e', '--eval', '-p', '--print'],
  bun: ['-e', '--eval', '-p'],
  deno: ['eval'],
  python: ['-c'],
  python3: ['-c'],
  py: ['-c'],
  pythonw: ['-c'],
  ruby: ['-e'],
  perl: ['-e', '-E'],
  php: ['-r'],
  lua: ['-e']
};
const BINARY_EXT = /\.(exe|dll|msi|msix|scr|com|sys|ocx|cpl|bin|node|so|dylib|jar|appimage|lnk)$/i;
const SCRIPT_EXT = /\.(bat|cmd|ps1|psm1|vbs|vbe|wsf|hta)$/i;
const isAbs = p => /^(?:[a-zA-Z]:[\\/]|\/|\\\\)/.test(String(p));
const isUnc = p => /^\\\\|^\/\/[^/]/.test(String(p));
const PLACEHOLDER_ROOT = /^\$\{(?:PLUGIN_DIR|PLUGIN_DATA|WORKSPACE)\}/;
const envRefs = text => [...String(text).matchAll(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g)].map(m => m[1]).filter(n => !['PLUGIN_DIR', 'PLUGIN_DATA', 'WORKSPACE', 'AURIC_NODE'].includes(n));
const urlHosts = text => [...String(text).matchAll(/\bhttps?:\/\/([^\s/"'`)<>\]\\]+)/gi)].map(m => m[1].toLowerCase().replace(/:\d+$/, '').replace(/^[^@]*@/, ''));

// Qué programa del PC necesita cada comando (para avisar si no está instalado).
const TOOL_OF = { node: 'node', nodejs: 'node', npx: 'node', npm: 'node', pnpx: 'node', pnpm: 'node', yarn: 'node', bun: 'node', bunx: 'node', python: 'python', python3: 'python', py: 'python', pythonw: 'python', pip: 'python', pip3: 'python', pipx: 'python', uvx: 'python', uv: 'python', docker: 'docker', podman: 'docker', git: 'git', java: 'java', javaw: 'java', dotnet: 'dotnet', dnx: 'dotnet' };
function toolsNeeded(model) {
  const out = new Set(model.manifest.requires?.tools || []);
  for (const srv of model.mcp || []) {
    const t = TOOL_OF[baseCommand(srv.command)];
    if (t) out.add(t);
  }
  return out;
}

// Devuelve [{ severity, code, text }] para un servidor MCP.
function classifyMcp(srv) {
  const out = [];
  const add = (severity, code, text) => out.push({ severity, code, text });
  const cmd = String(srv.command || '');
  const args = (srv.args || []).map(String);
  const base = baseCommand(cmd);
  const all = [cmd, ...args];

  if (isUnc(cmd) || all.some(a => isUnc(a))) add('danger', 'unc', 'Usa una ruta de red (\\\\servidor\\…): el programa vendría de otro equipo.');
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(cmd)) add('danger', 'url-command', 'El «programa» es una dirección de internet.');
  if (all.some(a => /(^|[\\/])\.\.([\\/]|$)/.test(a))) add('danger', 'parent-path', 'Usa rutas con «..» que salen de la carpeta del plugin.');

  if (SHELL_CMDS.has(base)) {
    const next = args.map(a => a.toLowerCase());
    const first = base === 'cmd' ? next.findIndex(a => a === '/c' || a === '/k') : -1;
    const launcher = first >= 0 ? baseCommand(args[first + 1] || '') : '';
    const rest = first >= 0 ? args.slice(first + 2) : [];
    const meta = args.some(a => /[&|<>^`]|\$\(/.test(a));
    if (base === 'cmd' && first >= 0 && ['npx', 'node', 'python', 'python3', 'uvx', 'uv', 'bunx'].includes(launcher) && !meta && !rest.some(a => /^-(c|e|-eval|-print|p)$/i.test(a)))
      add('warn', 'cmd-launcher', `Abre una consola de Windows (cmd) solo para lanzar «${launcher}». Es un patrón común, pero Auric no puede comprobar nada más allá de eso.`);
    else add('danger', 'shell', `Abre una consola (${base}) y le pasa órdenes: Auric no puede saber qué va a hacer en realidad.`);
    if (next.some(a => ['-encodedcommand', '-enc', '-e', '-ec', '-encoded'].includes(a))) add('danger', 'encoded-command', 'Pasa una orden codificada (base64): está pensada para que no se pueda leer.');
    if (next.some(a => /(^|\b)(iex|invoke-expression|downloadstring|downloadfile|invoke-webrequest|iwr)\b/.test(a))) add('danger', 'download-exec', 'Descarga y ejecuta código de internet.');
    if (next.some(a => ['-windowstyle', '-w'].includes(a)) && next.some(a => a === 'hidden')) add('danger', 'hidden-window', 'Pide ejecutarse con la ventana oculta.');
    if (next.some(a => a === 'bypass')) add('danger', 'bypass-policy', 'Pide saltarse la política de ejecución de scripts de Windows.');
  } else if (LOLBINS.has(base)) {
    add('danger', 'lolbin', `Usa «${base}», un programa de Windows que se usa a menudo para descargar o ejecutar cosas sin que se note.`);
  } else if (RUNNERS.has(base) || ((base === 'npm' || base === 'pnpm' || base === 'yarn') && /^(exec|dlx|x)$/i.test(args[0] || ''))) {
    const nonFlags = args.filter(a => !a.startsWith('-'));
    const spec = nonFlags[base === 'npm' || base === 'pnpm' || base === 'yarn' ? 1 : 0] || '';
    add('warn', 'package-runner', `Descarga y ejecuta de internet el paquete «${shorten(spec || '?', 60)}» (con «${base}»). Su código puede cambiar después de que lo revises.`);
    if (spec && !/@\d/.test(spec.replace(/^@/, '')) && !/==\d/.test(spec)) add('warn', 'unpinned', `El paquete «${shorten(spec, 60)}» no tiene versión fija: cada vez puede bajar una versión distinta.`);
    if (/^(https?:|git\+|github:|gitlab:|bitbucket:|file:)/i.test(spec) || /^[\w.-]+\/[\w.-]+$/.test(spec)) add('warn', 'package-source', 'El paquete viene de una dirección o repositorio directo, no del registro normal.');
    if (args.some(a => /^--(registry|index-url|extra-index-url)/i.test(a))) add('warn', 'custom-registry', 'Usa un registro de paquetes distinto del oficial.');
    if (args.some(a => /^(-y|--yes)$/i.test(a))) add('info', 'yes-flag', 'Se instala sin preguntar (-y).');
  } else if (base === 'docker' || base === 'podman') {
    add('warn', 'container', `Ejecuta un contenedor (${base}); necesita tenerlo instalado.`);
    const rootMount = v => /^(?:[a-zA-Z]:[\\/]?|\/)(?::|$)/.test(String(v || '')) || /docker\.sock/.test(String(v || ''));
    const mounts = args.flatMap((a, i) => (/^(-v|--volume|--mount)$/.test(a) ? [args[i + 1]] : /^(-v|--volume|--mount)=/.test(a) ? [a.split('=').slice(1).join('=')] : []));
    if (args.some(a => /^--(privileged|pid=host|net(work)?=host|cap-add)/i.test(a)) || mounts.some(rootMount))
      add('danger', 'container-privileged', 'El contenedor pide acceso total al equipo (privilegiado, red del equipo o disco completo).');
  } else if (INTERPRETERS.has(base)) {
    const flags = INLINE_FLAGS[base] || [];
    if (args.some(a => flags.includes(a) || flags.some(f => f.startsWith('--') && a.startsWith(f + '='))))
      add('danger', 'inline-code', `Lleva el código escrito dentro de los argumentos (${base} ${shorten(args.find(a => flags.includes(a)) || '', 12)}): no hay archivo que revisar.`);
    const script = args.find(a => !a.startsWith('-'));
    if (script && isAbs(script) && !PLACEHOLDER_ROOT.test(script)) add('warn', 'abs-script', `Ejecuta un archivo fuera del plugin: ${shorten(script, 80)}.`);
    if (script && /^https?:\/\//i.test(script)) add('danger', 'remote-script', 'Ejecuta un archivo directamente desde internet.');
    if (base === 'python' || base === 'python3' || base === 'py') if (args[0] === '-m' && args[1] === 'pip') add('warn', 'pip', 'Instala paquetes de Python.');
    if (base === 'auric-node') add('info', 'auric-node', 'Usa el motor interno de Auric: no hace falta instalar Node.js.');
    else add('warn', 'interpreter', `Necesita «${base}» instalado en tu PC y ejecuta código del plugin.`);
  } else if (BINARY_EXT.test(cmd)) {
    add('danger', 'binary', `Ejecuta un programa ya compilado (${shorten(cmd.split(/[\\/]/).pop(), 50)}): no se puede leer ni revisar.`);
  } else if (SCRIPT_EXT.test(cmd)) {
    add('warn', 'script-cmd', `Ejecuta un script de Windows (${shorten(cmd.split(/[\\/]/).pop(), 50)}). Se revisa su contenido más abajo.`);
  } else {
    add('warn', 'program', `Ejecuta el programa «${shorten(cmd, 60)}», que debe estar instalado en tu PC.`);
  }

  if (isAbs(cmd) && !PLACEHOLDER_ROOT.test(cmd) && !out.some(o => o.code === 'unc')) add('warn', 'abs-command', `Usa una ruta fija de tu PC (${shorten(cmd, 80)}), que puede no existir o ser otra cosa.`);
  if (args.some(a => /\$\(|`|;\s*\w|&&|\|\|/.test(a)) && !out.some(o => ['shell', 'cmd-launcher'].includes(o.code))) add('danger', 'shell-meta', 'Un argumento contiene símbolos de consola (; && || ` $()) que no deberían ir ahí.');
  return out;
}

// ── Texto: instrucciones para la IA y comandos sugeridos ───────────────────────────────────────
const TEXT_RULES = [
  // Trampas contra la IA (prompt injection)
  { id: 'override', severity: 'danger', area: 'instructions', negatable: true, title: 'Intenta anular las reglas anteriores de la IA', re: /\b(ignor\w*|olvid\w*|desatiend\w*|descart\w*)\s+(todas?\s+)?(las\s+|tus\s+|sus\s+|los\s+)?(instrucciones|reglas|indicaciones|ordenes|restricciones|limites)\s+(anteriores|previas|de\s+arriba|del\s+sistema|originales|de\s+seguridad)\b|\b(ignore|disregard|forget|override)\s+(all\s+|any\s+|the\s+|your\s+|every\s+)*(previous|prior|above|earlier|system|safety|original)\s+(instructions?|rules?|prompts?|messages?|guidelines?|restrictions?)\b|\bnuevo\s+prompt\s+del\s+sistema\b|\bnew\s+system\s+prompt\b|\bfrom\s+now\s+on\s+you\s+(are|will|must)\b|\ba\s+partir\s+de\s+ahora\s+(eres|debes|vas\s+a)\b/ },
  { id: 'role-hijack', severity: 'danger', area: 'instructions', title: 'Intenta cambiar el modo de la IA (sin restricciones)', re: /\b(modo\s+(dios|desarrollador|developer|sin\s+restricciones|sin\s+filtros)|developer\s+mode|god\s+mode|jailbreak|\bDAN\b|do\s+anything\s+now|sin\s+(ninguna\s+)?(restriccion|limite|filtro)es?\s+(de\s+seguridad|eticos?))\b/i },
  { id: 'hide', severity: 'danger', area: 'instructions', title: 'Pide ocultarle cosas a la persona', re: /\bno\s+(le\s+|se\s+lo\s+)?(digas|cuentes|menciones|avises|informes|muestres|reveles|comentes|notifiques)\s+(nada\s+)?(a|al)\s+(la\s+)?(usuari[oa]|persona|humano|cliente)|\b(do\s+not|don'?t|never)\s+(tell|inform|mention|reveal|show|notify|let)\s+(this\s+to\s+)?(the\s+)?(user|human|person)|\bwithout\s+(the\s+)?(user|human)\s+(knowing|noticing|seeing)|\bsin\s+que\s+(la\s+persona|el\s+usuario|nadie)\s+(lo\s+)?(sepa|note|vea|se\s+entere)|\b(covertly|stealthily)\b|\boculta\s+(esto|esta\s+accion|lo\s+que)|\bhide\s+(this|that|it)\s+from\b/ },
  { id: 'skip-permissions', negatable: true, severity: 'danger', area: 'instructions', title: 'Pide saltarse los permisos o las confirmaciones', re: /\bsin\s+(pedir|solicitar|preguntar|esperar)\s+(el\s+|la\s+|tu\s+)?(permiso|confirmacion|autorizacion|aprobacion|consentimiento)|\bwithout\s+(asking|requesting|waiting\s+for)\s+(for\s+)?(permission|confirmation|approval|consent)|\b(skip|bypass|disable|circumvent|evita|omite|salta|salta?te|desactiva|elude|esquiva)\w*\s+(the\s+|el\s+|los\s+|las\s+|la\s+|todos\s+los\s+)?(permission|permisos?|confirmacion(es)?|aprobacion(es)?|approval|dialogos?|prompts?|checks?|verificaciones|guardrails|safeguards)|\bauto-?\s?approve|\baprueba\s+(todo\s+)?automaticamente|\bno\s+pidas\s+(permiso|confirmacion)|\bnunca\s+pidas\s+(permiso|confirmacion)|\b(use|usa|cambia\s+a|switch\s+to)\s+(el\s+)?(full|completo)\s+(mode|modo|access)\b/ },
  { id: 'exfiltrate', negatable: true, severity: 'danger', area: 'instructions', title: 'Habla de enviar claves o datos a internet', re: /\b(exfiltr\w*|(env[ií]a\w*|manda\w*|sube\w*|transmite\w*|copia\w*|publica\w*|send\w*|upload\w*|post\w*|forward\w*|leak\w*)\b.{0,70}\b(claves?|contrasenas?|tokens?|api[ _-]?keys?|credenciales|passwords?|credentials|secrets?|secretos?|cookies|variables\s+de\s+entorno|environment\s+variables|archivos?\s+(privados|personales)|private\s+files?)\b.{0,90}\b(https?:\/\/|webhook|servidor|server|url|correo|email|discord|telegram|pastebin|requestbin|ngrok))\b/ },
  { id: 'break-structure', severity: 'danger', area: 'instructions', title: 'Intenta cerrar las etiquetas con las que Auric separa las instrucciones', re: /<\/?\s*(skills?|plugin_skills|plugin_instructions|system|instructions?|untrusted|external_content|developer|assistant)\b[^>]*>/i, raw: true },
  // Comandos delicados que sugiere ejecutar
  { id: 'download-exec', negatable: true, severity: 'danger', area: 'instructions', title: 'Sugiere descargar y ejecutar código de internet', re: /\b(curl|wget|iwr|irm|invoke-webrequest|invoke-restmethod)\b[^\n|]{0,200}\|\s*(sh|bash|zsh|pwsh|powershell|iex|python3?|node)\b|\b(iex|invoke-expression)\s*\(?\s*(new-object|\(?iwr|\(?irm|invoke-)|downloadstring\s*\(|\bmshta\s+https?:|\bregsvr32\b[^\n]*\/i:https?:|\bcertutil\b[^\n]*-urlcache|\bbitsadmin\b[^\n]*\/transfer/ },
  { id: 'encoded-command', negatable: true, severity: 'danger', area: 'instructions', title: 'Incluye órdenes codificadas para que no se lean', re: /-(encodedcommand|enc|ec)\s+[A-Za-z0-9+\/=]{20,}|frombase64string\s*\(|\bbase64\s+(-d|--decode)\b[^\n|]*\|\s*(sh|bash|zsh)/ },
  { id: 'destructive', negatable: true, severity: 'danger', area: 'instructions', title: 'Sugiere comandos que borran o formatean', re: /\brm\s+-[a-z]*[rf][a-z]*\s+(-[a-z]+\s+)*(\/|~|\$home|\*|\.\s*$)|\bremove-item\b[^\n]*-recurse[^\n]*-force[^\n]*(c:\\|\$env:|\*)|\bformat\s+[a-z]:|\bdel\s+\/[fsq][^\n]*\b[a-z]:\\|\brd\s+\/s\s+\/q\s+[a-z]:\\|\bmkfs\b|\bdd\s+if=\S+\s+of=\/dev\/|:\(\)\s*\{\s*:\s*\|\s*:&\s*\}\s*;|\bchmod\s+-r\s+777\s+\/|\bdiskpart\b|\bcipher\s+\/w/ },
  { id: 'persistence', negatable: true, severity: 'danger', area: 'instructions', title: 'Sugiere dejar algo funcionando para siempre en el PC', re: /\bschtasks\b[^\n]*\/create|\breg\s+add\b[^\n]*\\run\b|currentversion\\run\b|\bnew-service\b|\bsc(\.exe)?\s+create\b|\bregister-scheduledtask\b|\bstartup\s+folder\b|carpeta\s+de\s+inicio|\bcrontab\s+-|\blaunchctl\s+load|\bsystemctl\s+enable\b|\.bashrc|\.zshrc|\.profile\b/ },
  { id: 'defender', negatable: true, severity: 'danger', area: 'instructions', title: 'Sugiere apagar o engañar al antivirus', re: /\b(set|add)-mppreference\b|\bexclusionpath\b|\bdisablerealtimemonitoring\b|\bdisable\s+(windows\s+)?defender\b|\bdesactiva\w*\s+(el\s+)?(antivirus|defender|firewall|cortafuegos)\b|\bnetsh\s+advfirewall\b[^\n]*(off|disable)|\bset-executionpolicy\s+(bypass|unrestricted)\b/ },
  // Cosas que merecen atención
  { id: 'secret-places', severity: 'warn', area: 'instructions', title: 'Habla de lugares donde se guardan contraseñas o claves', re: /\.ssh\b|\bid_(rsa|ed25519|ecdsa)\b|\.aws[\\/]credentials|\.git-credentials|\.npmrc\b|\.docker[\\/]config|\blogin\s+data\b|\blocal\s+state\b|\blogins\.json\b|\bkey[34]\.db\b|\bwallet\.dat\b|credential\s+manager|administrador\s+de\s+credenciales|\bkeychain\b|\.kube[\\/]config/ },
  { id: 'memory-write', severity: 'warn', area: 'instructions', title: 'Pide guardar cosas en la memoria o en archivos de reglas de tus proyectos', re: /\bupdate_memory\b|\b(guarda|anota|recuerda|memoriza|save|remember|store)\b[^\n]{0,60}\b(en\s+(la\s+)?memoria|permanentemente|para\s+(siempre|futuras?\s+(conversaciones|sesiones))|in\s+(your\s+)?memory|for\s+future\s+(sessions|conversations))|\b(escrib\w+|edit\w+|modific\w+|add\w*|write|append)\b[^\n]{0,40}\b(AURIC|AGENTS|CLAUDE)\.md\b/ },
  { id: 'installs', negatable: true, severity: 'warn', area: 'instructions', title: 'Sugiere instalar programas en tu PC', re: /\bnpm\s+(i|install)\s+(-g|--global)\b|\bpip3?\s+install\b|\bwinget\s+install\b|\bchoco\s+install\b|\bscoop\s+install\b|\bapt(-get)?\s+install\b|\bbrew\s+install\b|\bsudo\s+\w+/ },
  { id: 'input-capture', severity: 'warn', area: 'instructions', title: 'Menciona capturar teclado, pantalla o portapapeles', re: /\bgetasynckeystate\b|\bsetwindowshookex\b|\bkeylogg\w*\b|\bpynput\b|\bimagegrab\b|\bdesktopcapturer\b|\brobotjs\b|\bclipboardy\b|\bpyperclip\b/ }
];

const SCRIPT_RULES = [
  { id: 'code-exec', severity: 'warn', area: 'programs', title: 'El código puede lanzar otros programas', re: /\bchild_process\b|\bexecsync\s*\(|\bspawnsync\s*\(|\bos\.system\s*\(|\bos\.popen\s*\(|\bsubprocess\.|\bpopen\s*\(|\bstart-process\b|\bwscript\.shell\b|\bshellexecute\w*\b|\bcreateobject\s*\(|\binvoke-expression\b|\biex\s*\(/ },
  { id: 'code-net', severity: 'info', area: 'network', title: 'El código se conecta a internet', re: /\bfetch\s*\(|\bxmlhttprequest\b|\bhttps?\.(request|get)\s*\(|\bnet\.(connect|createconnection)\s*\(|\bwebsocket\b|\brequests\.(get|post|put|delete|request)\s*\(|\burllib\b|\bhttp\.client\b|\bsocket\.socket\b|\binvoke-(webrequest|restmethod)\b|\bnet\.webclient\b|\bdownloadstring\b|\bdownloadfile\b|\baxios\b|\bundici\b/ },
  { id: 'code-secret-places', severity: 'danger', area: 'files', title: 'El código toca lugares donde se guardan contraseñas o claves', re: /\.ssh\b|\bid_(rsa|ed25519)\b|\.aws[\\/]credentials|\.git-credentials|\.npmrc\b|\.docker[\\/]config|\blogin\s+data\b|\blocal\s+state\b|\blogins\.json\b|\bkey[34]\.db\b|wallet\.dat|credential\s*manager|\bcryptunprotectdata\b|appdata[\\/]+(roaming|local)[\\/]+(microsoft[\\/]+credentials|mozilla|google[\\/]+chrome|microsoft[\\/]+edge|opera|brave)|chrome[\\/]user\s+data|\.kube[\\/]config|keychain\b/ },
  { id: 'code-env-dump', severity: 'warn', area: 'secrets', title: 'El código lee todas tus variables de entorno', re: /json\.stringify\s*\(\s*process\.env\s*\)|object\.(entries|keys|values)\s*\(\s*process\.env\s*\)|\{\s*\.\.\.process\.env\s*\}|dict\s*\(\s*os\.environ\s*\)|os\.environ\.(items|copy|keys|values)\s*\(|\bprintenv\b|get-childitem\s+env:|gci\s+env:|\bdir\s+env:/ },
  { id: 'code-obfuscated', severity: 'warn', area: 'programs', title: 'Código difícil de revisar (ofuscado o que se arma a sí mismo)', re: /\beval\s*\(|new\s+function\s*\(|\bexec\s*\(\s*compile\s*\(|\bmarshal\.loads\b|\b__import__\s*\(|\batob\s*\(\s*['"`][A-Za-z0-9+\/=]{80,}|b64decode\s*\(\s*['"][A-Za-z0-9+\/=]{80,}|frombase64string\s*\(|(\\x[0-9a-f]{2}){20,}|string\.fromcharcode\s*\([^)]{80,}\)/ },
  { id: 'code-persistence', severity: 'danger', area: 'programs', title: 'El código intenta quedarse funcionando en el PC', re: /\bschtasks\b|currentversion[\\/]+run\b|\bregister-scheduledtask\b|\bnew-service\b|\bsc\s+create\b|\bstartup\b[\\/]|\\start\s+menu\\programs\\startup|\bcrontab\b|\blaunchctl\b|\bsystemctl\s+enable\b|\.bashrc|\.zshrc/ },
  { id: 'code-defender', severity: 'danger', area: 'programs', title: 'El código intenta apagar o engañar al antivirus', re: /\b(set|add)-mppreference\b|\bexclusionpath\b|\bdisablerealtimemonitoring\b|\bnetsh\s+advfirewall\b|\bset-executionpolicy\b/ },
  { id: 'code-miner', severity: 'danger', area: 'programs', title: 'Parece minería de criptomonedas', re: /stratum\+tcp|\bxmrig\b|\bcryptonight\b|\bcoinhive\b|\bminerd\b|\bnicehash\b|\bmonero\b.*\bpool\b/ },
  { id: 'code-input-capture', severity: 'warn', area: 'programs', title: 'El código puede registrar teclado, pantalla o portapapeles', re: /\bgetasynckeystate\b|\bsetwindowshookex\w*\b|\bkeylogg\w*\b|\bpynput\b|\bimagegrab\b|\bdesktopcapturer\b|\brobotjs\b|\bclipboardy\b|\bpyperclip\b|\bnavigator\.clipboard\b|\bgetclipboarddata\b|\bkeyboard\.(hook|on_press|add_hotkey)\b|\bpyautogui\b/ }
];
const SCRIPT_EXT_RE = /\.(js|mjs|cjs|ts|py|pyw|sh|bash|ps1|psm1|bat|cmd|vbs|vbe|wsf|hta|rb|pl|php|lua)$/i;
const NS_HOSTS = new Set(['json-schema.org', 'www.w3.org', 'w3.org', 'schemas.xmlsoap.org', 'schemas.microsoft.com', 'example.com', 'example.org', 'www.example.com', 'localhost', '127.0.0.1', '0.0.0.0', 'xmlns.com', 'purl.org', 'ns.adobe.com', 'schema.org', 'www.apache.org', 'opensource.org', 'creativecommons.org', 'spdx.org', 'github.com', 'raw.githubusercontent.com', 'npmjs.com', 'www.npmjs.com', 'nodejs.org', 'developer.mozilla.org', 'docs.python.org', 'en.wikipedia.org', 'es.wikipedia.org', 'tools.ietf.org', 'datatracker.ietf.org', 'www.rfc-editor.org', 'modelcontextprotocol.io', 'stackoverflow.com']);

const hostAllowed = (host, declared) => (declared || []).some(d => d === host || (d.startsWith('*.') && (host === d.slice(2) || host.endsWith(d.slice(1)))));

// «nunca ejecutes rm -rf /» es una advertencia, no una orden: si lo que sigue viene negado, no se marca.
const NEGATION_RE = /\b(no|nunca|jamas|never|don'?t|dont|do\s+not|not|evita|evitar|avoid|prohibido|forbidden)\s+(?:\w+\s+){0,2}$/;
const negated = (subject, index) => NEGATION_RE.test(subject.slice(Math.max(0, index - 24), index));

// Texto de un archivo → coincidencias por regla (una por línea, con la frase que la activó).
function scanLines(text, rules, where, add) {
  const lines = String(text).split(/\r?\n/);
  const hits = new Map();
  for (let i = 0; i < lines.length; i++) {
    const original = lines[i];
    if (!original.trim()) continue;
    const line = original.length > 2500 ? original.slice(0, 2500) : original;
    const folded = fold(line);
    for (const rule of rules) {
      const subject = rule.raw ? line : folded;
      const m = rule.re.exec(subject);
      if (!m) continue;
      if (rule.negatable && negated(subject, m.index)) continue;
      const arr = hits.get(rule.id) || [];
      if (arr.length < 3) arr.push(`${where}, línea ${i + 1}: «${visible(shorten(original, 110))}»`);
      hits.set(rule.id, arr);
    }
  }
  // Frases que cruzan dos líneas seguidas (p. ej. «no le digas» / «al usuario»): se unen por pares.
  for (let i = 0; i + 1 < lines.length; i++) {
    if (!lines[i].trim() || !lines[i + 1].trim()) continue;
    const joined = `${lines[i].slice(0, 1200)} ${lines[i + 1].slice(0, 1200)}`;
    const folded = fold(joined);
    for (const rule of rules) {
      if (hits.has(rule.id)) continue;
      const subject = rule.raw ? joined : folded;
      const m = rule.re.exec(subject);
      if (m && !(rule.negatable && negated(subject, m.index))) hits.set(rule.id, [`${where}, líneas ${i + 1}-${i + 2}: «${visible(shorten(joined, 110))}»`]);
    }
  }
  for (const rule of rules) {
    const items = hits.get(rule.id);
    if (items) add({ id: `${rule.id}`, severity: rule.severity, area: rule.area, title: rule.title, items });
  }
}

function scanInvisible(text, where, add) {
  const found = [];
  let count = 0;
  const kinds = new Set();
  for (const m of String(text).matchAll(INVISIBLE_RE)) {
    if (m.index === 0 && m[0] === '\ufeff') continue;
    count++;
    kinds.add(`U+${m[0].codePointAt(0).toString(16).toUpperCase().padStart(4, '0')}`);
    if (found.length < 2) found.push(`${where}: «${visible(shorten(String(text).slice(Math.max(0, m.index - 25), m.index + 25), 60))}»`);
  }
  const tagChars = /[\u{e0000}-\u{e007f}]/u.test(text);
  const bidi = /[\u202a-\u202e\u2066-\u2069]/.test(text);
  if (tagChars || bidi || count >= 3)
    add({ id: 'invisible', severity: 'danger', area: 'instructions', title: 'Contiene texto invisible o que cambia el sentido de lectura', detail: 'Hay caracteres que no se ven en pantalla pero la IA sí lee (se usan para esconder órdenes).', items: [...found, `${count} caracteres invisibles (${[...kinds].slice(0, 4).join(', ')})`] });
  else if (count > 0) add({ id: 'invisible', severity: 'warn', area: 'instructions', title: 'Contiene algún carácter invisible', items: found });
}

function scanTextFile(text, where, add) {
  scanInvisible(text, where, add);
  scanLines(text, TEXT_RULES, where, add);
  const blob = /[A-Za-z0-9+/]{240,}={0,2}/.exec(text);
  if (blob) add({ id: 'blob', severity: 'warn', area: 'instructions', title: 'Trae un bloque largo de letras y números sin sentido (podría ser código escondido)', items: [`${where}: «${shorten(blob[0], 60)}»`] });
  const comment = [...String(text).matchAll(/<!--([\s\S]{40,}?)-->/g)].find(m => /\b(ia|ai|assistant|asistente|modelo|model|instruc|ignore|ignora|usuario|user|prompt|secret|clave|token)\b/i.test(fold(m[1])));
  if (comment) add({ id: 'hidden-comment', severity: 'warn', area: 'instructions', title: 'Tiene comentarios ocultos (<!-- -->) dirigidos a la IA', items: [`${where}: «${shorten(comment[1], 100)}»`] });
}

function scanScriptFile(text, where, add, ctx) {
  scanInvisible(text, where, add);
  scanLines(text, SCRIPT_RULES, where, add);
  scanLines(text, TEXT_RULES.filter(r => ['download-exec', 'encoded-command', 'destructive', 'defender'].includes(r.id)), where, add);
  const longest = Math.max(0, ...String(text).split(/\r?\n/).slice(0, 4000).map(l => l.length));
  if (longest > 1500 && !/\.(json|map)$/i.test(where)) add({ id: 'code-minified', severity: 'warn', area: 'programs', title: 'Código comprimido en líneas larguísimas (no se puede revisar a simple vista)', items: [`${where}: línea de ${longest} caracteres`] });
  for (const h of urlHosts(text)) ctx.hosts.add(h);
}

// ── Revisión completa ───────────────────────────────────────────────────────────────────────────
function reviewModel(model, files, ctx = {}) {
  const F = new Findings();
  const add = f => F.add(f);
  const m = model.manifest;
  const perm = m.permissions || { declared: false, network: [], env: [], runs: [], files: '', notes: '' };
  const textOf = path => {
    const buf = files.get(path);
    return buf ? core.textOf(buf) : '';
  };
  const blocked = [];
  const hosts = new Set();

  // Compatibilidad
  if (m.requires?.auric && ctx.appVersion && core.satisfies(m.requires.auric, ctx.appVersion) === false)
    blocked.push({ code: 'INCOMPATIBLE', message: `Este plugin necesita Auric ${m.requires.auric} y esta es la versión ${ctx.appVersion}.` });
  for (const t of m.requires?.tools || []) {
    if (ctx.tools && ctx.tools[t] === false) add({ id: `tool-${t}`, severity: 'warn', area: 'requirements', title: `Necesita «${t}» y no está instalado en este PC`, detail: 'Sin ese programa, la parte que lo usa no va a arrancar. Puedes instalarlo y volver a intentar.' });
    else if (ctx.tools && ctx.tools[t] === true) add({ id: `tool-${t}`, severity: 'info', area: 'requirements', title: `Necesita «${t}» (ya está instalado)` });
    else add({ id: `tool-${t}`, severity: 'info', area: 'requirements', title: `Necesita «${t}» instalado en tu PC` });
  }

  // Programas
  const usedTools = new Set([...toolsNeeded(model)].filter(t => !(model.manifest.requires?.tools || []).includes(t)));
  for (const srv of model.mcp) {
    const issues = classifyMcp(srv);
    const line = [srv.command, ...srv.args].join(' ');
    const worst = issues.reduce((a, i) => (SEV[i.severity] > SEV[a] ? i.severity : a), 'warn');
    // Un servidor que viene DENTRO de Auric (plugin oficial), corre con el motor interno de Auric y ejecuta un archivo de su propia
    // carpeta no es una descarga de terceros: se informa, pero no como aviso.
    const script = srv.args.find(a => !String(a).startsWith('-')) || '';
    const bundled = !!ctx.official && baseCommand(srv.command) === 'auric-node' && /^\$\{PLUGIN_DIR\}\/[^\s]+$/.test(script) && issues.every(i => i.severity === 'info');
    add({
      id: `mcp-${srv.id}`,
      severity: bundled ? 'info' : worst === 'info' ? 'warn' : worst,
      area: 'programs',
      title: `Ejecuta un programa en tu PC: «${srv.name}»`,
      detail: `${bundled ? 'Es un programa pequeño que viene incluido con Auric (no se descarga de internet). ' : 'Es un programa que se queda funcionando mientras usas Auric. '}Corre con tus mismos permisos de Windows: Auric no puede encerrarlo en una caja ni limitar lo que lea o escriba una vez que arranca.`,
      items: [`Comando exacto: ${shorten(line, 220)}`, ...issues.map(i => `${i.severity === 'danger' ? '⛔' : i.severity === 'warn' ? '⚠' : 'ℹ'} ${i.text}`)]
    });
    for (const h of urlHosts(line)) hosts.add(h);
    // Variables de entorno (o argumentos) donde se le entrega algo de tu PC
    const refOf = (where, name) => {
      if (/^AURIC_/i.test(name)) {
        add({ id: `env-blocked-${name}`, severity: 'danger', area: 'secrets', title: `Pide la variable interna de Auric «${name}»`, detail: 'Auric nunca entrega sus variables internas a un plugin: no se le dará.', items: [`${srv.name}: ${where}`] });
      } else if (!perm.env.includes(name)) {
        add({ id: `env-undeclared-${name}`, severity: 'danger', area: 'secrets', title: `Pide tu variable «${name}» sin haberlo declarado`, detail: 'No se le entregará. Un plugin honesto declara las claves que usa en «permissions.env».', items: [`${srv.name}: ${where}`] });
      } else if (/(key|token|secret|passw|pwd|credential|auth|cookie|session|private)/i.test(name)) {
        add({ id: `env-secret-${name}`, severity: 'warn', area: 'secrets', title: `Le entrega tu variable «${name}» (parece una clave)`, detail: 'Solo la recibe ese programa. Puedes guardarla dentro de Auric (cifrada) o definirla en tu PC; si no existe, recibe un valor vacío.', items: [`${srv.name}: ${where}`] });
      } else add({ id: `env-${name}`, severity: 'info', area: 'secrets', title: `Le entrega tu variable «${name}»`, items: [`${srv.name}: ${where}`] });
    };
    for (const [k, v] of Object.entries(srv.env || {})) {
      for (const name of envRefs(v)) refOf(`${k}=\${${name}}`, name);
      if (!envRefs(v).length && /^(sk-[A-Za-z0-9_-]{16,}|ghp_[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{30,}|xox[abp]-[A-Za-z0-9-]{20,}|AKIA[0-9A-Z]{16})/.test(v))
        add({ id: 'embedded-key', severity: 'warn', area: 'secrets', title: 'Trae una clave escrita dentro (no es tuya)', detail: 'Alguien dejó una clave dentro del plugin. No la uses ni la compartas.', items: [`${srv.name}: ${k}`] });
    }
    for (const a of [srv.command, ...srv.args]) for (const name of envRefs(a)) refOf(`argumento «${shorten(a, 50)}»`, name);
    if (srv.cwd === 'workspace') add({ id: 'cwd-workspace', severity: 'info', area: 'files', title: 'Arranca con la carpeta de tu proyecto como carpeta de trabajo', detail: 'Necesita tener un proyecto abierto. No significa que solo pueda ver esa carpeta.' });
    // «auric-node» y «node» significan lo mismo aquí (el motor de JavaScript de Auric); se compara por nombre de programa, no por texto.
    const runsBase = perm.runs.map(r => baseCommand(r));
    const srvBase = baseCommand(srv.command);
    if (perm.declared && perm.runs.length && !perm.runs.some(r => line.includes(r) || r.includes(srv.command)) && !runsBase.includes(srvBase) && !(srvBase === 'auric-node' && runsBase.includes('node')))
      add({ id: `runs-undeclared-${srv.id}`, severity: 'warn', area: 'programs', title: `«${srv.name}» ejecuta algo distinto de lo que el plugin declara`, items: [`Declarado: ${shorten(perm.runs.join(' | '), 100)}`, `Real: ${shorten(line, 100)}`] });
  }
  for (const tool of usedTools) {
    if (ctx.tools && ctx.tools[tool] === false) add({ id: `tool-${tool}`, severity: 'warn', area: 'requirements', title: `Necesita «${tool}» y no está instalado en este PC`, detail: 'El servidor de este plugin no va a arrancar hasta que lo instales.' });
  }
  if (model.mcp.length) add({ id: 'mcp-warning', severity: 'info', area: 'programs', title: 'Auric te preguntará antes de usar ese programa', detail: 'Según tu modo de permisos, la primera vez que la IA quiera usar sus herramientas verás una ventana con el comando exacto.' });

  // Archivos del paquete
  const kinds = { binary: [], script: [], secret: [] };
  for (const f of model.files) if (kinds[f.kind]) kinds[f.kind].push(f.path);
  if (kinds.binary.length)
    add({ id: 'files-binary', severity: 'danger', area: 'files', title: `Trae ${kinds.binary.length} programa(s) ya compilado(s)`, detail: 'Un programa compilado no se puede leer ni revisar. Solo instálalo si confías de verdad en quien lo hizo.', items: kinds.binary.slice(0, 8) });
  if (kinds.secret.length) add({ id: 'files-secret', severity: 'warn', area: 'files', title: `Trae ${kinds.secret.length} archivo(s) que parecen claves o contraseñas`, items: kinds.secret.slice(0, 8) });
  if (kinds.script.length) add({ id: 'files-script', severity: 'info', area: 'files', title: `Trae ${kinds.script.length} archivo(s) de código`, detail: 'Auric los busca señales de peligro (abajo). Nada se ejecuta al instalar: solo si un servidor del plugin los usa o si tú le pides a la IA que los use.', items: kinds.script.slice(0, 8) });
  add({ id: 'files-total', severity: 'info', area: 'files', title: `${model.stats.files} archivo(s), ${model.stats.bytes < 1048576 ? Math.max(1, Math.round(model.stats.bytes / 1024)) + ' KB' : (model.stats.bytes / 1048576).toFixed(1) + ' MB'} en total` });

  // Texto que se le da a la IA + código del paquete
  const toScan = [];
  for (const s of model.skills) toScan.push({ where: `skill «${s.name}» (${s.file})`, path: s.file, kind: 'text' });
  if (model.instructions) toScan.push({ where: `instrucciones (${model.instructions.file})`, path: model.instructions.file, kind: 'text' });
  toScan.push({ where: 'manifiesto', path: core.MANIFEST_FILE, kind: 'text' });
  let scannedBytes = 0;
  let skipped = 0;
  const scriptCtx = { hosts };
  for (const t of toScan) {
    const text = textOf(t.path);
    if (!text) continue;
    scannedBytes += text.length;
    scanTextFile(text, t.where, add);
  }
  for (const f of model.files) {
    if (!SCRIPT_EXT_RE.test(f.path)) continue;
    if (f.size > 1024 * 1024 || scannedBytes > 8 * 1024 * 1024) {
      skipped++;
      continue;
    }
    const text = textOf(f.path);
    scannedBytes += text.length;
    scanScriptFile(text, f.path, add, scriptCtx);
  }
  if (skipped) add({ id: 'scan-skipped', severity: 'warn', area: 'files', title: `${skipped} archivo(s) de código eran demasiado grandes y no se revisaron` });
  // Otros archivos de texto sueltos (documentos de ayuda, datos) por si traen órdenes escondidas para la IA
  for (const f of model.files) {
    if (!/\.(md|txt|json|ya?ml|toml)$/i.test(f.path) || f.size > 256 * 1024) continue;
    if (model.skills.some(s => s.file === f.path) || f.path === model.instructions?.file || f.path === core.MANIFEST_FILE) continue;
    const text = textOf(f.path);
    scanInvisible(text, f.path, add);
    if (/^(readme|license|changelog)/i.test(f.path.split('/').pop())) continue;
    scanLines(text, TEXT_RULES.filter(r => ['override', 'hide', 'skip-permissions', 'exfiltrate', 'role-hijack'].includes(r.id)), f.path, add);
  }

  // Skills: cuándo se usan, cuánto texto agregan, campos que se ignoran
  if (model.skills.length) {
    const sorted = model.skills.map(s => `${s.name}${s.derived ? ' (cuando la conversación habla de: ' + s.triggers.slice(0, 4).join(', ') + ')' : s.triggers.length ? ' (cuando se menciona: ' + s.triggers.slice(0, 4).join(', ') + ')' : s.markers.length ? ' (en proyectos con: ' + s.markers.slice(0, 3).join(', ') + ')' : ' (siempre)'}`);
    add({ id: 'skills-list', severity: 'info', area: 'general', title: `${model.skills.length} skill(s): instrucciones de trabajo para la IA`, detail: 'Las skills solo dan orientación a la IA. No pueden darle permisos ni saltarse las confirmaciones de Auric.', items: sorted.slice(0, 8) });
    const always = model.skills.filter(s => !s.triggers.length && !s.markers.length);
    if (always.length) add({ id: 'skills-always', severity: 'info', area: 'general', title: `${always.length} skill(s) se aplican en todas las conversaciones`, items: always.map(s => s.name).slice(0, 6) });
    const ignored = [...new Set(model.skills.flatMap(s => s.ignoredFields || []))];
    if (ignored.length) add({ id: 'skills-ignored', severity: 'info', area: 'general', title: `Auric ignora estos campos de las skills: ${ignored.slice(0, 6).join(', ')}`, detail: 'Algunos formatos usan campos (como «allowed-tools») para dar permisos. En Auric no existen: ninguna skill puede darse permisos.' });
  }
  const textChars = model.skills.reduce((n, s) => n + (s.chars || 0), 0) + (model.instructions?.chars || 0);
  if (textChars > 24000)
    add({ id: 'big-text', severity: 'warn', area: 'general', title: `Agrega mucho texto a la conversación (unos ${Math.round(textChars / 1000)} mil caracteres)`, detail: 'Con modelos gratuitos o locales esto gasta tu límite o puede llenar su memoria de contexto más rápido.' });
  if (model.instructions) add({ id: 'has-instructions', severity: 'info', area: 'general', title: 'Trae instrucciones que se agregan a todas tus conversaciones', detail: 'Se muestran a la IA como orientación de un tercero, no como órdenes tuyas.' });
  if (model.ignored?.length) for (const ig of model.ignored) add({ id: `ignored-${ig.what}`, severity: 'info', area: 'general', title: `${ig.what}: no se usa`, detail: ig.why });

  // Conexiones a internet
  for (const c of model.connectors) {
    if (c.url) {
      const host = new URL(c.url).hostname;
      hosts.add(host);
      add({ id: `conn-${c.id}`, severity: 'warn', area: 'network', title: `Se conecta al servicio externo «${c.name}» (${host})`, detail: 'Solo se conecta cuando tú pulsas «Conectar» en el plugin; ahí el servicio te pedirá iniciar sesión. Lo que la IA lea de ese servicio se trata como datos, no como órdenes.', items: [c.url] });
    } else {
      const known = ctx.builtinConnectorIds ? ctx.builtinConnectorIds.has(c.ref) : true;
      add({ id: `conn-${c.id}`, severity: known ? 'info' : 'warn', area: 'network', title: known ? `Usa el conector «${c.ref}» que Auric ya trae` : `Pide un conector («${c.ref}») que esta versión de Auric no conoce`, detail: known ? 'Se conecta aparte, en Complementos → Conectores, con tu permiso.' : '' });
    }
  }
  const real = [...hosts].filter(h => h && !NS_HOSTS.has(h) && /[a-z0-9]/.test(h));
  if (real.length) {
    const undeclared = perm.declared ? real.filter(h => !hostAllowed(h, perm.network)) : [];
    add({ id: 'net-hosts', severity: 'info', area: 'network', title: `Menciona estos sitios de internet: ${real.slice(0, 6).join(', ')}${real.length > 6 ? '…' : ''}`, items: real.slice(0, 10) });
    if (undeclared.length) add({ id: 'net-undeclared', severity: 'warn', area: 'network', title: 'Usa sitios que el plugin no declaró', detail: 'El plugin declara qué sitios usa («permissions.network»), pero el código menciona otros.', items: undeclared.slice(0, 8) });
  }
  if (perm.network.length) add({ id: 'net-declared', severity: 'info', area: 'network', title: `Declara que se conecta a: ${perm.network.slice(0, 6).join(', ')}` });
  if (!perm.declared && (model.mcp.length || model.files.some(f => SCRIPT_EXT_RE.test(f.path))))
    add({ id: 'no-permissions', severity: 'warn', area: 'general', title: 'No declara qué permisos usa', detail: 'Este paquete no trae la sección «permissions». Auric solo puede mostrarte lo que encontró por su cuenta.' });
  if (perm.notes) add({ id: 'perm-notes', severity: 'info', area: 'general', title: 'Nota del autor sobre permisos', detail: perm.notes });

  if (ctx.official) add({ id: 'official', severity: 'info', area: 'general', title: 'Plugin oficial incluido con Auric Code', detail: 'Viene dentro de la propia aplicación; no se descarga de internet.' });
  if (model.origin === 'claude') add({ id: 'foreign-format', severity: 'info', area: 'general', title: 'Es un paquete en el formato de otro programa', detail: 'Auric usó sus skills y servidores. Todo lo demás (comandos, agentes, hooks) se ignora.' });
  for (const n of model.notes || []) add({ id: `note-${F.list.length}`, severity: 'info', area: 'general', title: n });

  // Orden: peligro primero, luego atención, luego información; dentro, por área
  const rank = f => [-SEV[f.severity], AREAS.indexOf(f.area)];
  const findings = F.list.slice().sort((a, b) => {
    const ra = rank(a),
      rb = rank(b);
    return ra[0] - rb[0] || ra[1] - rb[1];
  });
  const counts = { danger: 0, warn: 0, info: 0 };
  for (const f of findings) counts[f.severity]++;
  const level = counts.danger ? 'danger' : counts.warn ? 'warn' : 'info';
  return { level, counts, findings, blocked: blocked[0] || null, needsAck: level === 'danger', scanned: { bytes: scannedBytes, skipped }, disclaimer: 'Esta revisión busca señales conocidas de peligro. No puede garantizar que un plugin sea seguro: instala solo lo que venga de quien confías.' };
}

module.exports = { reviewModel, classifyMcp, baseCommand, toolsNeeded, TOOL_OF, scanTextFile, scanScriptFile, TEXT_RULES, SCRIPT_RULES, SEV, AREAS, visible, fold };
