'use strict';
// Git con permiso. Lo que ve la IA es UNA herramienta («git») con acciones; lo que ocurre de verdad es esto:
//   1) prepare(): se validan los argumentos, se mira el repositorio y se calcula el comando EXACTO y lo que se enseñará a la persona.
//   2) approve(): la persona acepta (o la política lo permite sin preguntar). «Subir» y lo destructivo preguntan SIEMPRE.
//   3) run(): se vuelve a mirar el repositorio; si cambió desde que se decidió, no se hace nada. Se guardan copias de seguridad
//      antes de lo destructivo y se ejecuta exactamente el comando guardado.
// Git se ejecuta siempre con su ruta completa (nunca buscando «git» dentro de la carpeta del proyecto), sin shell, sin pedir datos por
// terminal y con las opciones que apagan lo que un repositorio ajeno podría usar para ejecutar programas.
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const core = require('./git-core');
const { OPS, READ_OPS, resolveOperation } = require('./git-ops');
const { fail } = core;

const TICKET_TTL_MS = 10 * 60 * 1000;
const MIN_GIT = [2, 30];
const DEFAULT_CAP = 4 * 1024 * 1024;
const ERR_CAP = 256 * 1024;
const TIMEOUT = { read: 60000, write: 120000, network: 300000 };
const LOG_ROTATE_BYTES = 1024 * 1024;
const APP_IDENT = {
  GIT_AUTHOR_NAME: 'Auric Code',
  GIT_AUTHOR_EMAIL: 'auric@localhost',
  GIT_COMMITTER_NAME: 'Auric Code',
  GIT_COMMITTER_EMAIL: 'auric@localhost'
};

// Opciones que se pasan SIEMPRE a Git y ganan a cualquier configuración del repositorio.
const HARDEN = [
  '-c',
  'core.fsmonitor=false',
  '-c',
  'core.pager=cat',
  '-c',
  'core.quotepath=false',
  '-c',
  'diff.external=',
  '-c',
  'color.ui=false',
  '-c',
  'protocol.ext.allow=never',
  '-c',
  'commit.gpgSign=false',
  '-c',
  'tag.gpgSign=false',
  '-c',
  'log.showSignature=false',
  '-c',
  'merge.verifySignatures=false',
  '-c',
  'gc.auto=0',
  '-c',
  'maintenance.auto=false',
  '-c',
  'submodule.recurse=false',
  '-c',
  'fetch.recurseSubmodules=false',
  '-c',
  'push.recurseSubmodules=no',
  '-c',
  'push.gpgSign=false',
  '-c',
  'safe.bareRepository=explicit',
  '-c',
  'advice.detachedHead=false',
  '-c',
  'advice.statusHints=false',
  '-c',
  'credential.interactive=false'
];
// Variables que redirigirían Git a otro repositorio o a otro programa: no se heredan.
const DROP_ENV =
  /^(GIT_DIR|GIT_WORK_TREE|GIT_INDEX_FILE|GIT_OBJECT_DIRECTORY|GIT_ALTERNATE_OBJECT_DIRECTORIES|GIT_COMMON_DIR|GIT_NAMESPACE|GIT_PREFIX|GIT_PAGER|GIT_EXTERNAL_DIFF|GIT_EDITOR|GIT_SEQUENCE_EDITOR|GIT_REPLACE_REF_BASE|GIT_NO_REPLACE_OBJECTS|GIT_GRAFT_FILE|GIT_SHALLOW_FILE)$/i;

function gitEnv(base = process.env, extra = {}) {
  const env = {};
  for (const [k, v] of Object.entries(base || {})) if (v != null && !DROP_ENV.test(k)) env[k] = v;
  Object.assign(env, {
    GIT_TERMINAL_PROMPT: '0',
    GCM_INTERACTIVE: '0',
    GCM_GUI_PROMPT: '0',
    GIT_PAGER: 'cat',
    GIT_EDITOR: ':',
    GIT_SEQUENCE_EDITOR: ':',
    GIT_MERGE_AUTOEDIT: 'no',
    LC_ALL: 'C',
    LANGUAGE: 'C'
  });
  return Object.assign(env, extra);
}

// ── Rutas ────────────────────────────────────────────────────────────────────────────────────────
const canon = p => {
  try {
    return fs.realpathSync.native(p);
  } catch {
    return path.resolve(p);
  }
};
const fold = s => (process.platform === 'win32' ? s.toLowerCase() : s);
function isInside(child, parent) {
  const c = fold(canon(child)),
    p = fold(canon(parent));
  return c === p || c.startsWith(p.endsWith(path.sep) ? p : p + path.sep);
}

// ── Encontrar git ────────────────────────────────────────────────────────────────────────────────
let gitCache = null;
function resetGitCache() {
  gitCache = null;
}
function candidateGitPaths(env = process.env, platform = process.platform) {
  const exe = platform === 'win32' ? 'git.exe' : 'git';
  const sep = platform === 'win32' ? ';' : ':';
  const lib = platform === 'win32' ? path.win32 : path.posix;
  const out = [];
  const entries = String(env.PATH || env.Path || '')
    .split(sep)
    .map(s => s.trim().replace(/^"|"$/g, ''));
  for (const dir of entries) if (dir && lib.isAbsolute(dir) && !/^\\\\/.test(dir)) out.push(lib.join(dir, exe));
  if (platform === 'win32') {
    for (const base of [env.ProgramFiles, env['ProgramFiles(x86)'], env.LOCALAPPDATA && lib.join(env.LOCALAPPDATA, 'Programs')]) {
      if (base) out.push(lib.join(base, 'Git', 'cmd', 'git.exe'), lib.join(base, 'Git', 'bin', 'git.exe'));
    }
  } else out.push('/usr/bin/git', '/usr/local/bin/git', '/opt/homebrew/bin/git');
  return [...new Set(out)];
}
function versionOf(gitPath, env) {
  return new Promise(resolve => {
    let out = '';
    let child;
    try {
      child = spawn(gitPath, ['--version'], { cwd: os.tmpdir(), env: gitEnv(env), windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
    } catch {
      return resolve(null);
    }
    const timer = setTimeout(() => child.kill(), 10000);
    child.stdout.on('data', d => (out += d));
    child.on('error', () => {
      clearTimeout(timer);
      resolve(null);
    });
    child.on('close', () => {
      clearTimeout(timer);
      const m = /git version (\d+)\.(\d+)(?:\.(\d+))?/.exec(out);
      resolve(m ? { text: out.trim(), parts: [Number(m[1]), Number(m[2]), Number(m[3] || 0)] } : null);
    });
  });
}
// Busca git por su ruta completa. Nunca usa una carpeta relativa del PATH ni nada que esté dentro de las carpetas «a evitar»
// (la del proyecto): en Windows, buscar «git» a secas puede ejecutar un git.exe que viene dentro de un proyecto ajeno.
async function resolveGit({ avoidDirs = [], env = process.env, platform = process.platform, force = false } = {}) {
  if (!force && gitCache && !avoidDirs.some(d => isInside(gitCache.path, d))) return gitCache;
  for (const cand of candidateGitPaths(env, platform)) {
    if (avoidDirs.some(d => d && isInside(cand, d))) continue;
    let st;
    try {
      st = await fsp.stat(cand);
    } catch {
      continue;
    }
    if (!st.isFile()) continue;
    const v = await versionOf(cand, env);
    if (!v) continue;
    if (v.parts[0] < MIN_GIT[0] || (v.parts[0] === MIN_GIT[0] && v.parts[1] < MIN_GIT[1]))
      throw fail(
        'GIT_OLD',
        `Tu Git (${v.text}) es muy antiguo. Auric necesita la versión ${MIN_GIT.join('.')} o una más nueva (git-scm.com).`
      );
    gitCache = { path: cand, version: v.text, parts: v.parts };
    return gitCache;
  }
  throw fail(
    'GIT_MISSING',
    'Git no está instalado en este equipo (o Auric no lo encuentra). Instálalo desde git-scm.com y vuelve a intentarlo.'
  );
}

// ── Ejecutar git ─────────────────────────────────────────────────────────────────────────────────
function runGit(gitPath, args, { cwd, env, input = null, timeoutMs = TIMEOUT.read, maxBytes = DEFAULT_CAP, signal = null } = {}) {
  return new Promise((resolve, reject) => {
    let child;
    try {
      child = spawn(gitPath, [...HARDEN, ...args], {
        cwd,
        env,
        windowsHide: true,
        stdio: [input == null ? 'ignore' : 'pipe', 'pipe', 'pipe']
      });
    } catch (e) {
      return reject(fail('GIT_SPAWN', `No se pudo iniciar Git: ${e.message}`));
    }
    const out = [],
      err = [];
    let outLen = 0,
      errLen = 0,
      truncated = false,
      timedOut = false,
      aborted = false;
    const kill = () => {
      try {
        if (process.platform === 'win32' && child.pid)
          spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
        else child.kill('SIGKILL');
      } catch {}
    };
    const timer = setTimeout(() => {
      timedOut = true;
      kill();
    }, timeoutMs);
    const onAbort = () => {
      aborted = true;
      kill();
    };
    if (signal) {
      if (signal.aborted) onAbort();
      else signal.addEventListener('abort', onAbort, { once: true });
    }
    const collect = (chunks, len, cap, d) => {
      if (len >= cap) return { len: len + d.length, over: true };
      chunks.push(len + d.length > cap ? d.subarray(0, cap - len) : d);
      return { len: len + d.length, over: len + d.length > cap };
    };
    child.stdout.on('data', d => {
      const r = collect(out, outLen, maxBytes, d);
      outLen = r.len;
      if (r.over) truncated = true;
    });
    child.stderr.on('data', d => {
      const r = collect(err, errLen, ERR_CAP, d);
      errLen = r.len;
    });
    child.on('error', e => {
      clearTimeout(timer);
      reject(
        e.code === 'ENOENT'
          ? fail('GIT_MISSING', 'Git no está instalado en este equipo.')
          : fail('GIT_SPAWN', `No se pudo ejecutar Git: ${e.message}`)
      );
    });
    child.on('close', (code, sig) => {
      clearTimeout(timer);
      resolve({
        code: code ?? (sig ? 1 : 0),
        stdout: Buffer.concat(out).toString('utf8'),
        stderr: Buffer.concat(err).toString('utf8'),
        truncated,
        timedOut,
        aborted
      });
    });
    if (input != null) {
      child.stdin.on('error', () => {});
      child.stdin.end(input);
    }
  });
}

// ── Mensajes de error claros ─────────────────────────────────────────────────────────────────────
const FRIENDLY = [
  [/not a git repository/i, 'Esta carpeta no es un repositorio de Git.'],
  [
    /detected dubious ownership/i,
    'Git no confía en esta carpeta porque pertenece a otro usuario del equipo. Auric no cambia esa protección de seguridad.'
  ],
  [
    /Author identity unknown|unable to auto-detect email|empty ident name|Committer identity unknown/i,
    'Git no sabe quién eres (falta tu nombre y tu correo).'
  ],
  [
    /index\.lock/i,
    'Otro programa está usando Git en esta carpeta ahora mismo (existe el archivo .git/index.lock). Espera a que termine; Auric no lo borra.'
  ],
  [
    /Authentication failed|could not read (Username|Password)|terminal prompts disabled|Permission denied \(publickey|The requested URL returned error: 40[13]|HTTP 40[13]/i,
    'El servidor no aceptó el inicio de sesión. Revisa que tengas permiso y que Git tenga tus credenciales guardadas.'
  ],
  [
    /Could not resolve host|unable to access|Failed to connect|Connection timed out|Network is unreachable|Connection refused/i,
    'No se pudo conectar con el servidor. Revisa tu conexión a internet.'
  ],
  [
    /non-fast-forward|\[rejected\]|fetch first|Updates were rejected|stale info/i,
    'El servidor rechazó la subida porque tiene cambios que tú no tienes. Trae primero los cambios (pull o fetch) y revisa.'
  ],
  [
    /Not possible to fast-forward/i,
    'Tu rama y la del servidor se separaron: no se puede avanzar sin mezclar. Usa fetch y merge para decidir cómo unirlas.'
  ],
  [
    /would be overwritten by (checkout|merge)|local changes to the following files would be overwritten/i,
    'Tienes cambios sin guardar que chocan con lo que se quiere traer. Guárdalos (commit) o apártalos (stash) primero.'
  ],
  [/refusing to merge unrelated histories/i, 'Esas dos ramas no comparten historia: Git se niega a unirlas.'],
  [/nothing to commit|no changes added to commit/i, 'No hay nada que guardar.'],
  [/not fully merged/i, 'La rama no está fusionada. Con force:true se borra igualmente (queda una copia de seguridad).'],
  [/pathspec .* did not match|did not match any file/i, 'Alguna ruta no existe en el repositorio.'],
  [/paths are ignored by one of your \.gitignore/i, 'Esos archivos están ignorados por .gitignore.'],
  [/unmerged files|you have unmerged paths/i, 'Hay archivos en conflicto sin resolver.']
];
function friendlyGitMessage(stderr = '', stdout = '') {
  const t = `${stderr}\n${stdout}`;
  for (const [re, text] of FRIENDLY) if (re.test(t)) return text;
  return '';
}
function gitError(r, label = 'git') {
  if (r.timedOut) return fail('GIT_TIMEOUT', 'Git tardó demasiado y Auric lo detuvo.');
  if (r.aborted) return fail('GIT_ABORTED', 'La acción de Git se detuvo.');
  const detail = core
    .maskUrls(String(r.stderr || r.stdout || ''))
    .trim()
    .slice(0, 1500);
  const friendly = friendlyGitMessage(r.stderr, r.stdout);
  const code = /dubious ownership/i.test(r.stderr) ? 'DUBIOUS' : /not a git repository/i.test(r.stderr) ? 'NOT_A_REPO' : 'GIT_FAILED';
  return fail(code, `${friendly || `Git no pudo completar la acción (${label}).`}${detail ? `\n\nDetalle de Git:\n${detail}` : ''}`, {
    stderr: detail
  });
}

// ── Un repositorio abierto ───────────────────────────────────────────────────────────────────────
class RepoHandle {
  constructor(mgr, { gitPath, cwd, toplevel, gitDir, signal = null, extraEnv = {} }) {
    this.mgr = mgr;
    this.gitPath = gitPath;
    this.cwd = cwd;
    this.toplevel = toplevel;
    this.gitDir = gitDir;
    this.signal = signal;
    this.extraEnv = extraEnv;
    this._snap = null;
    this._remotes = null;
    this._cfg = null;
  }
  async git(args, { input = null, timeoutMs, readOnly = false, extraEnv = {}, maxBytes } = {}) {
    const env = gitEnv(this.mgr.env, { ...(readOnly ? { GIT_OPTIONAL_LOCKS: '0' } : {}), ...this.extraEnv, ...extraEnv });
    // Las consultas apagan los filtros peligrosos del repositorio (si no, Git los ejecutaría solo por comparar archivos).
    const pre = readOnly ? (await this.loadConfig()).neutralize : [];
    return runGit(this.gitPath, [...pre, ...args], {
      cwd: this.toplevel || this.cwd,
      env,
      input,
      timeoutMs: timeoutMs || TIMEOUT.read,
      maxBytes,
      signal: this.signal
    });
  }
  async loadConfig() {
    if (this._cfg) return this._cfg;
    const r = await runGit(this.gitPath, ['config', '--list', '--show-origin', '--show-scope', '-z'], {
      cwd: this.toplevel || this.cwd,
      env: gitEnv(this.mgr.env, { GIT_OPTIONAL_LOCKS: '0' }),
      timeoutMs: TIMEOUT.read
    });
    const findings = r.code === 0 ? core.riskyConfigFindings(core.parseConfigList(r.stdout)) : [];
    this._cfg = { findings, neutralize: core.filterNeutralizers(findings) };
    return this._cfg;
  }
  async must(args, opts) {
    const r = await this.git(args, opts);
    if (r.code !== 0) throw gitError(r, args[0]);
    return r;
  }
  errorFrom(r) {
    return gitError(r);
  }
  paths(list) {
    return core.validateRelPaths(list, { repoRoot: this.toplevel });
  }
  // Las rutas van siempre después de «--» y, si llevan comodines o empiezan por «:», como «literales» (sin tocar el resto del entorno de Git).
  specs(list) {
    return core.literalPathspecs(list);
  }
  async snapshot(refresh = false) {
    if (this._snap && !refresh) return this._snap;
    const r = await this.must(['status', '--porcelain=v2', '--branch', '-z', '--untracked-files=normal'], { readOnly: true });
    const st = core.parseStatusV2(r.stdout);
    this._snap = {
      st,
      head: st.branch.oid,
      branch: st.branch.head,
      upstream: st.branch.upstream,
      operation: await this.operationInProgress()
    };
    return this._snap;
  }
  async operationInProgress() {
    const marks = [
      ['MERGE_HEAD', 'merge'],
      ['CHERRY_PICK_HEAD', 'cherry-pick'],
      ['REVERT_HEAD', 'revert'],
      ['rebase-merge', 'rebase'],
      ['rebase-apply', 'rebase'],
      ['BISECT_LOG', 'bisect']
    ];
    for (const [file, op] of marks) {
      try {
        await fsp.access(path.join(this.gitDir, file));
        return op;
      } catch {}
    }
    return '';
  }
  async refExists(ref) {
    const r = await this.git(['show-ref', '--verify', '--quiet', ref], { readOnly: true });
    return r.code === 0;
  }
  async revSha(rev, message) {
    const r = await this.git(['rev-parse', '--verify', '--quiet', '--end-of-options', `${rev}^{commit}`], { readOnly: true });
    const sha = r.stdout.trim();
    if (r.code !== 0 || !/^[0-9a-f]{40,64}$/.test(sha)) throw fail('NO_REV', message || `No existe «${rev}».`);
    return sha;
  }
  async remotes() {
    if (this._remotes) return this._remotes;
    const names = (await this.must(['remote'], { readOnly: true })).stdout
      .split('\n')
      .map(s => s.trim())
      .filter(Boolean);
    const list = [];
    for (const name of names) {
      try {
        core.validateRemoteName(name);
      } catch {
        continue;
      }
      const f = await this.git(['remote', 'get-url', name], { readOnly: true });
      const p = await this.git(['remote', 'get-url', '--push', '--all', name], { readOnly: true });
      const fetchUrl = f.stdout.trim();
      const pushUrls = p.stdout
        .split('\n')
        .map(s => s.trim())
        .filter(Boolean);
      list.push({
        name,
        fetchUrl,
        pushUrls: pushUrls.length ? pushUrls : [fetchUrl],
        fetchInfo: core.describeRemoteUrl(fetchUrl),
        pushInfos: (pushUrls.length ? pushUrls : [fetchUrl]).map(core.describeRemoteUrl)
      });
    }
    this._remotes = list;
    return list;
  }
  async pickRemote(requested, { branch } = {}) {
    const list = await this.remotes();
    if (!list.length) throw fail('NO_REMOTE', 'Este repositorio no tiene ningún servidor remoto configurado (por ejemplo, GitHub).');
    if (requested) {
      const name = core.validateRemoteName(requested);
      const found = list.find(r => r.name === name);
      if (!found)
        throw fail('NO_REMOTE', `No existe un servidor remoto llamado «${name}». Los que hay: ${list.map(r => r.name).join(', ')}.`);
      return found;
    }
    if (branch) {
      const up = await this.git(['config', '--get', `branch.${branch}.remote`], { readOnly: true });
      const found = list.find(r => r.name === up.stdout.trim());
      if (found) return found;
    }
    if (list.length === 1) return list[0];
    const origin = list.find(r => r.name === 'origin');
    if (origin) return origin;
    throw fail('AMBIGUOUS', `Hay varios servidores remotos (${list.map(r => r.name).join(', ')}); indica cuál usar con "remote".`);
  }
  async hooks() {
    const r = await this.git(['rev-parse', '--git-path', 'hooks'], { readOnly: true });
    if (r.code !== 0) return [];
    const dir = path.resolve(this.toplevel, r.stdout.trim());
    let names;
    try {
      names = await fsp.readdir(dir);
    } catch {
      return [];
    }
    const out = [];
    for (const file of names.sort()) {
      if (file.endsWith('.sample') || file.startsWith('.')) continue;
      try {
        const st = await fsp.stat(path.join(dir, file));
        if (!st.isFile()) continue;
        if (process.platform !== 'win32' && !(st.mode & 0o111)) continue; // Git ignora los hooks sin permiso de ejecución
        const body = await fsp.readFile(path.join(dir, file)).then(b => b.subarray(0, 262144));
        const head = body.subarray(0, 600);
        const binary = head.includes(0);
        out.push({
          preview: binary ? '(archivo binario)' : head.toString('utf8').split(/\r?\n/).slice(0, 12).join('\n'),
          name: file.replace(/\.(exe|bat|cmd|ps1|sh)$/i, ''),
          file,
          bytes: st.size,
          modified: st.mtime.toISOString(),
          sig: crypto.createHash('sha256').update(body).digest('hex').slice(0, 20)
        });
      } catch {}
    }
    return out;
  }
  async configFindings() {
    return (await this.loadConfig()).findings;
  }
  async identity() {
    const a = await this.git(['var', 'GIT_AUTHOR_IDENT'], { readOnly: true });
    const c = await this.git(['var', 'GIT_COMMITTER_IDENT'], { readOnly: true });
    return { ok: a.code === 0 && c.code === 0 };
  }
}

// ── Utilidades ───────────────────────────────────────────────────────────────────────────────────
function stable(v) {
  if (Array.isArray(v)) return `[${v.map(stable).join(',')}]`;
  if (v && typeof v === 'object')
    return `{${Object.keys(v)
      .sort()
      .map(k => `${JSON.stringify(k)}:${stable(v[k])}`)
      .join(',')}}`;
  return JSON.stringify(v === undefined ? null : v);
}
const sha = v => crypto.createHash('sha256').update(stable(v)).digest('hex');
const quoteForShow = a => (/^[A-Za-z0-9_@%+=:,./~^{}\-]+$/.test(a) ? a : `'${String(a).replace(/'/g, "'\\''")}'`);
const normPerm = p => (p === 'workspace' ? 'guarded' : ['chat', 'readonly', 'ask', 'guarded', 'full'].includes(p) ? p : 'ask');
const stamp = () => {
  const d = new Date();
  const p = n => String(n).padStart(2, '0');
  return `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}-${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}-${crypto.randomBytes(2).toString('hex')}`;
};

// ── Administrador ────────────────────────────────────────────────────────────────────────────────
class GitManager {
  constructor({ logFile = '', env = process.env, now = () => Date.now() } = {}) {
    this.logFile = logFile;
    this.env = env;
    this.now = now;
    this.tickets = new Map();
    this.queues = new Map();
  }

  prune() {
    const t = this.now();
    for (const [id, tk] of this.tickets) if (tk.expiresAt < t && tk.state !== 'running') this.tickets.delete(id);
  }
  ticket(id) {
    this.prune();
    const tk = this.tickets.get(String(id || ''));
    if (!tk) throw fail('NO_TICKET', 'Esta acción de Git ya no está disponible (caducó o ya se hizo). Vuelve a pedirla.');
    return tk;
  }
  serial(key, fn) {
    const prev = this.queues.get(key) || Promise.resolve();
    const next = prev.then(fn, fn);
    this.queues.set(
      key,
      next.catch(() => {})
    );
    return next;
  }

  async discover(git, cwd) {
    const r = await runGit(git.path, ['rev-parse', '--show-toplevel', '--absolute-git-dir'], {
      cwd,
      env: gitEnv(this.env, { GIT_OPTIONAL_LOCKS: '0' })
    });
    if (r.code !== 0) {
      if (/not a git repository/i.test(r.stderr)) return null;
      throw gitError(r, 'rev-parse');
    }
    const [top, gdir] = r.stdout.trim().split('\n');
    return { toplevel: path.resolve(top), gitDir: path.resolve(cwd, gdir) };
  }

  openHandle(t, signal = null, { identity = true } = {}) {
    return new RepoHandle(this, {
      gitPath: t.gitPath,
      cwd: t.cwd,
      toplevel: t.toplevel,
      gitDir: t.gitDir,
      signal,
      extraEnv: identity ? t.identityEnv || {} : {}
    });
  }

  // Mira el repositorio y devuelve el plan + las decoraciones comunes (programas automáticos, configuración peligrosa, identidad).
  async analyze(opName, spec, ctx, h) {
    const op = OPS[opName];
    const plan = await op.plan({ h, a: spec, ctx });
    plan.warnings = [...(plan.warnings || [])];
    plan.effects = [...(plan.effects || [])];
    plan.steps = plan.steps || [];
    const parts = { plan: plan.digest ?? null };
    let escalate = !!plan.escalate;
    let hooks = [];
    let risky = [];
    if (plan.kind !== 'read') {
      hooks = core.relevantHooks(op.family, await h.hooks());
      if (hooks.length) {
        plan.warnings.push({
          level: 'warn',
          text: `Este proyecto tiene programas automáticos (hooks) que Git ejecutará ahora: ${hooks.map(x => x.name).join(', ')}. Pueden cambiar archivos o rechazar la acción.`
        });
        escalate = true;
        parts.hooks = hooks.map(x => [x.file, x.sig]);
      }
      risky = (await h.configFindings()).filter(f => !f.neutralized);
      const danger = risky.filter(f => f.level === 'danger');
      for (const f of danger) {
        plan.warnings.push({
          level: 'danger',
          text: `La configuración propia de este repositorio (${f.key}) ${f.text.charAt(0).toLowerCase()}${f.text.slice(1)}`
        });
      }
      if (danger.length) {
        escalate = true;
        parts.risky = danger.map(f => [f.key, f.value]);
      }
      const needsId = plan.needsIdentity ?? op.needsIdentity ?? false;
      plan.needsIdentity = false;
      if (needsId && !(await h.identity()).ok) {
        plan.needsIdentity = true;
        escalate = true;
        plan.warnings.push({
          level: 'info',
          text: 'Git no sabe tu nombre y tu correo. Escríbelos en la ventana: solo se usan para esta acción y Auric no los guarda en ninguna parte.'
        });
      }
      parts.id = plan.needsIdentity;
    }
    return { op, plan, escalate, hooks, risky, digest: sha({ op: opName, ...parts }) };
  }

  async prepare(spec = {}, ctx = {}) {
    this.prune();
    spec = JSON.parse(JSON.stringify(spec || {}));
    const perm = normPerm(ctx.permission);
    if (perm === 'chat') throw fail('CHAT_MODE', 'El modo Chat no permite usar Git en tu PC.');
    const roots = (ctx.roots || []).map(r => (typeof r === 'string' ? r : r?.path)).filter(Boolean);
    if (!roots.length) throw fail('NO_ROOT', 'No hay una carpeta de trabajo autorizada para usar Git.');
    const base = path.resolve(String(spec.root || spec.cwd || roots[0]));
    // «repo» es una subcarpeta (o ruta) dentro de la carpeta de trabajo donde vive el repositorio; nunca puede salirse de las carpetas autorizadas.
    if (spec.repo != null && (typeof spec.repo !== 'string' || /\0/.test(spec.repo)))
      throw fail('BAD_ARG', 'El campo "repo" debe ser una ruta de carpeta.');
    const cwd = spec.repo ? path.resolve(base, String(spec.repo)) : base;
    if (!roots.some(r => isInside(cwd, r))) throw fail('OUTSIDE', 'Esa carpeta está fuera de las carpetas autorizadas.');
    try {
      if (!(await fsp.stat(cwd)).isDirectory()) throw new Error('no dir');
    } catch {
      throw fail('NO_DIR', 'La carpeta de trabajo no existe.');
    }
    const opName = resolveOperation(spec);
    const op = OPS[opName];
    const git = await resolveGit({ avoidDirs: [cwd, ...roots], env: this.env });
    let found = await this.discover(git, cwd);
    let toplevel, gitDir;
    if (opName === 'init') {
      if (found && roots.some(r => isInside(found.toplevel, r)))
        throw fail('HAS_REPO', `Ya hay un repositorio de Git en ${found.toplevel}.`);
      toplevel = cwd;
      gitDir = path.join(cwd, '.git');
    } else {
      if (!found) throw fail('NOT_A_REPO', 'Esta carpeta no es un repositorio de Git. Para empezar uno usa la acción "init".');
      ({ toplevel, gitDir } = found);
    }
    const insideRoots = roots.some(r => isInside(toplevel, r));
    const readOnly = READ_OPS.has(opName);
    if (!insideRoots && !readOnly)
      throw fail(
        'REPO_OUTSIDE',
        `El repositorio está en ${toplevel}, que queda fuera de la carpeta de trabajo. Por seguridad Auric solo cambia repositorios que estén dentro de la carpeta abierta: abre la carpeta del repositorio.`
      );
    const t = {
      id: crypto.randomUUID(),
      opName,
      spec,
      ctx: { perm, roots, explicit: { force: !!ctx.explicit?.force, hard: !!ctx.explicit?.hard } },
      cwd,
      toplevel,
      gitDir,
      gitPath: git.path,
      state: 'ready',
      approved: false,
      approvedBy: '',
      identityEnv: null,
      createdAt: this.now(),
      expiresAt: this.now() + TICKET_TTL_MS
    };
    const h = this.openHandle(t);
    // Incluso add --dry-run puede reservar index.lock. Preparar y ejecutar
    // comparten la misma cola para que dos agentes no se estorben.
    const a = await this.serial(toplevel, () => this.analyze(opName, spec, t.ctx, h));
    const policy = core.confirmPolicy(a.plan.kind, perm);
    t.plan = a.plan;
    t.digest = a.digest;
    t.ask = policy.ask || a.escalate;
    t.always = policy.always;
    t.hooks = a.hooks;
    t.risky = a.risky;
    t.outside = !insideRoots;
    if (!a.plan.ack) {
      const danger = a.plan.warnings.some(w => w.level === 'danger');
      // Cada operación puede traer su propia frase de confirmación (por ejemplo, subir a la fuerza); si no, una general.
      const generic =
        a.plan.kind === 'destructive'
          ? 'Entiendo que esto no se puede deshacer por completo y quiero continuar'
          : 'Entiendo los avisos en rojo y quiero continuar';
      a.plan.ack = danger && t.ask ? String(a.plan.needsAck || generic) : '';
    }
    if (opName === 'init' && found)
      a.plan.warnings.unshift({
        level: 'info',
        text: `Hay un repositorio en una carpeta superior (${found.toplevel}). Este será uno nuevo y separado, solo para esta carpeta.`
      });
    if (t.outside)
      a.plan.warnings.unshift({
        level: 'info',
        text: `Este repositorio está en ${toplevel}, fuera de la carpeta abierta: solo se puede leer.`
      });
    this.tickets.set(t.id, t);
    return this.publicPlan(t);
  }

  publicPlan(t) {
    const p = t.plan;
    const display = p.steps.map(
      s => `git ${s.args.map(quoteForShow).join(' ')}${s.input != null ? '   ← el mensaje se envía aparte' : ''}`
    );
    return {
      id: t.id,
      op: t.opName,
      kind: p.kind,
      dialog: p.dialog || 'generic',
      title: p.title,
      summary: p.summary,
      repo: t.toplevel,
      repoName: path.basename(t.toplevel),
      display,
      ask: !!t.ask,
      always: !!t.always,
      ack: p.ack || '',
      needsIdentity: !!p.needsIdentity,
      warnings: p.warnings,
      effects: p.effects,
      data: p.data || {},
      hooks: t.hooks.map(h => ({ name: h.name, bytes: h.bytes, modified: h.modified, preview: h.preview })),
      risky: t.risky.map(r => ({ key: r.key, value: r.value, level: r.level, text: r.text })),
      backups: (p.backups || []).length > 0,
      network: !!p.network,
      outside: !!t.outside,
      expiresAt: t.expiresAt
    };
  }

  approve(id, decision = {}) {
    const t = this.ticket(id);
    if (t.state !== 'ready') throw fail('STATE', 'Esta acción ya se ejecutó o se canceló.');
    const user = decision.user === true;
    if (t.ask) {
      if (!user) throw fail('NEEDS_USER', 'Esta acción necesita que la persona la apruebe en una ventana.');
      if (t.plan.ack && decision.ack !== true) throw fail('NEEDS_ACK', 'Falta confirmar los avisos en rojo.');
    } else if (!user && decision.auto !== true) throw fail('NEEDS_APPROVAL', 'La acción no fue aprobada.');
    if (t.plan.needsIdentity) {
      const who = core.validateIdentity(decision.identity);
      t.identityEnv = {
        GIT_AUTHOR_NAME: who.name,
        GIT_AUTHOR_EMAIL: who.email,
        GIT_COMMITTER_NAME: who.name,
        GIT_COMMITTER_EMAIL: who.email
      };
    }
    OPS[t.opName].applyDecision?.(t.plan, decision);
    t.approved = true;
    t.approvedBy = user ? 'persona' : 'automático';
    return { ok: true };
  }

  cancel(id) {
    const t = this.tickets.get(String(id || ''));
    if (!t) return false;
    if (t.state === 'running') t.abort?.abort();
    else this.tickets.delete(t.id);
    return true;
  }

  async makeBackups(h, t) {
    const id = stamp();
    const made = [];
    const label = `Auric: copia antes de «${t.plan.title}»`.slice(0, 200);
    for (const b of t.plan.backups) {
      let sha = b.sha || '';
      if (b.kind === 'changes') {
        const r = await h.git(['stash', 'create', label], { extraEnv: APP_IDENT });
        sha = r.code === 0 ? r.stdout.trim() : '';
      }
      if (!sha) continue;
      const ref = `refs/auric/backup/${id}/${b.kind}${b.name ? `/${b.name}` : ''}`;
      await h.must(['update-ref', '-m', label, ref, sha]);
      made.push({ id, kind: b.kind, name: b.name || '', sha, ref });
    }
    return made;
  }

  async run(id) {
    const t = this.ticket(id);
    if (t.state !== 'ready') throw fail('STATE', 'Esta acción ya se ejecutó o se canceló.');
    if (t.plan.kind !== 'read' && !t.approved) throw fail('NOT_APPROVED', 'La acción todavía no fue aprobada.');
    t.state = 'running';
    t.abort = new AbortController();
    const started = this.now();
    const op = OPS[t.opName];
    let backups = [];
    let h = null;
    try {
      return await this.serial(t.toplevel, async () => {
        h = this.openHandle(t, t.abort.signal, { identity: false }); // se mira igual que al preparar (sin la identidad que escribió la persona)
        if (t.plan.kind !== 'read') {
          const again = await this.analyze(t.opName, t.spec, t.ctx, h);
          if (again.digest !== t.digest)
            throw fail(
              'STATE_CHANGED',
              'El repositorio cambió mientras se decidía (archivos, ramas o servidor). No se hizo nada. Vuelve a pedir la acción para ver los datos actualizados.'
            );
        }
        h = this.openHandle(t, t.abort.signal); // estado limpio (sin datos en caché) y con la identidad escrita por la persona, para ejecutar
        if (t.plan.backups?.length) backups = await this.makeBackups(h, t);
        const results = [];
        for (const step of t.plan.steps) {
          const timeoutMs = step.timeoutMs || (t.plan.network ? TIMEOUT.network : t.plan.kind === 'read' ? TIMEOUT.read : TIMEOUT.write);
          const r = await h.git(step.args, { input: step.input ?? null, timeoutMs, readOnly: !!step.readOnly, maxBytes: step.maxBytes });
          results.push(r);
          if (r.code !== 0 && !(op.failureIsResult && op.failureIsResult(r))) throw gitError(r, step.args[0]);
        }
        const fin = await op.finish({ h, a: t.spec, ctx: t.ctx }, results, t.plan);
        const note = backups.length
          ? `\nCopia de seguridad guardada (id ${backups[0].id}); se recupera con la acción backups restore.`
          : '';
        const extra = results.some(r => r.truncated) ? '\n(La salida de Git era muy larga y se recortó.)' : '';
        const out = {
          ok: true,
          op: t.opName,
          repo: t.toplevel,
          text: `${fin.text}${note}${extra}`,
          data: fin.data || {},
          backups: backups.map(b => ({ id: b.id, kind: b.kind, name: b.name }))
        };
        if (t.plan.kind !== 'read')
          await this.audit({
            t: new Date().toISOString(),
            repo: t.toplevel,
            op: t.opName,
            command: this.publicPlan(t).display,
            by: t.approvedBy,
            ok: true,
            ms: this.now() - started,
            backups: backups.map(b => b.ref)
          });
        return out;
      });
    } catch (e) {
      if (t.plan.kind !== 'read')
        await this.audit({
          t: new Date().toISOString(),
          repo: t.toplevel,
          op: t.opName,
          command: this.publicPlan(t).display,
          by: t.approvedBy,
          ok: false,
          error: String(e?.message || e).slice(0, 300),
          ms: this.now() - started,
          backups: backups.map(b => b.ref)
        });
      throw e;
    } finally {
      t.state = 'done';
      this.tickets.delete(t.id);
    }
  }

  async audit(entry) {
    if (!this.logFile) return;
    try {
      await fsp.mkdir(path.dirname(this.logFile), { recursive: true });
      try {
        if ((await fsp.stat(this.logFile)).size > LOG_ROTATE_BYTES) await fsp.rename(this.logFile, `${this.logFile}.1`);
      } catch {}
      await fsp.appendFile(this.logFile, `${JSON.stringify(entry)}\n`, 'utf8');
    } catch {}
  }
  async readLog(limit = 50) {
    if (!this.logFile) return [];
    try {
      const text = await fsp.readFile(this.logFile, 'utf8');
      return text
        .split('\n')
        .filter(Boolean)
        .slice(-Math.max(1, Math.min(500, Number(limit) || 50)))
        .map(l => {
          try {
            return JSON.parse(l);
          } catch {
            return null;
          }
        })
        .filter(Boolean)
        .reverse();
    } catch {
      return [];
    }
  }

  // git_status / git_diff de siempre, pero con el mismo git seguro y las mismas opciones de protección.
  async legacyRead(cwd, which) {
    cwd = path.resolve(String(cwd || ''));
    const git = await resolveGit({ avoidDirs: [cwd], env: this.env });
    const args = which === 'diff' ? ['diff', '--no-ext-diff', '--no-textconv', '--no-color', '--', '.'] : ['status', '--short', '--branch'];
    try {
      const r = await runGit(git.path, args, {
        cwd,
        env: gitEnv(this.env, { GIT_OPTIONAL_LOCKS: '0' }),
        timeoutMs: TIMEOUT.read,
        maxBytes: 12 * 1024 * 1024
      });
      return { exitCode: r.code, stdOut: r.stdout, stdErr: core.maskUrls(r.stderr || (r.timedOut ? 'Git tardó demasiado.' : '')) };
    } catch (e) {
      return { exitCode: 1, stdOut: '', stdErr: String(e?.message || e) };
    }
  }
}

let defaultManager = null;
function getManager() {
  if (!defaultManager) defaultManager = new GitManager({});
  return defaultManager;
}

// ── Registro de los IPC (main.js) ────────────────────────────────────────────────────────────────
function register({ app, ipcMain, hostEnv }) {
  const mgr = new GitManager({ logFile: path.join(app.getPath('userData'), 'git-log.jsonl'), env: hostEnv || process.env });
  defaultManager = mgr;
  const wrap =
    fn =>
    async (_e, ...args) => {
      try {
        return { ok: true, value: await fn(...args) };
      } catch (err) {
        return { ok: false, error: String(err?.message || err), code: err?.code || '' };
      }
    };
  ipcMain.handle(
    'auric:git-prepare',
    wrap((spec, ctx) => mgr.prepare(spec, ctx))
  );
  ipcMain.handle(
    'auric:git-approve',
    wrap((id, decision) => mgr.approve(id, decision))
  );
  ipcMain.handle(
    'auric:git-run',
    wrap(id => mgr.run(id))
  );
  ipcMain.handle(
    'auric:git-cancel',
    wrap(id => mgr.cancel(id))
  );
  ipcMain.handle(
    'auric:git-log',
    wrap(limit => mgr.readLog(limit))
  );
  return mgr;
}

module.exports = {
  register,
  getManager,
  GitManager,
  RepoHandle,
  resolveGit,
  resetGitCache,
  candidateGitPaths,
  runGit,
  gitEnv,
  gitError,
  friendlyGitMessage,
  HARDEN,
  APP_IDENT,
  isInside,
  stamp
};
