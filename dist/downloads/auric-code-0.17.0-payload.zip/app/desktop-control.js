'use strict';
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { execFile } = require('child_process');
const BLOCKED = /^(?:cmd|powershell|pwsh|windowsterminal|conhost|wt|taskmgr|consent|credentialuibroker|logonui|lockapp|securityhealth.*|msmpeng|avp|avast.*|avg.*|bitwarden|1password|keepass.*|lastpass|chrome|msedge|firefox|opera|brave|codex|chatgpt|electron)$/i;
const SENSITIVE = /password|contrase[nñ]a|token|api.?key|c[oó]digo de seguridad|tarjeta|credit.card|pagar|pay\b|buy\b|comprar|borrar|eliminar|delete|remove|send\b|enviar|publicar|publish|transfer|suscrib|subscribe|confirm|aceptar|install|instalar/i;
const NAVIGATION = /^(?:Tab|Shift\+Tab|Escape|Arrow(?:Left|Right|Up|Down)|PageUp|PageDown|Home|End)$/;
function allowedWindow(window, ownPid) {
  return !!(window && /^\d+$/.test(String(window.id)) && Number(window.pid) !== ownPid && window.executable && !BLOCKED.test(window.process) && !/auric code|windows security|seguridad de windows|password|contrase[nñ]a|sign.?in|iniciar sesi[oó]n|autenticaci[oó]n/i.test(window.title));
}
function windowsBridge(spec) {
  if (process.platform !== 'win32') return Promise.reject(new Error('El control de ventanas está disponible en Windows.'));
  const executable = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const payload = Buffer.from(JSON.stringify(spec)).toString('base64');
  return new Promise((resolve, reject) => execFile(executable, ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'desktop', 'bridge.ps1'), '-Payload', payload], { windowsHide: true, timeout: 15000, maxBuffer: 1024 * 1024, env: { SystemRoot: process.env.SystemRoot, WINDIR: process.env.WINDIR, TEMP: process.env.TEMP, TMP: process.env.TMP } }, (error, stdout) => {
    if (error) return reject(new Error('No se pudo consultar esta ventana de Windows.'));
    try { const result = JSON.parse(stdout.replace(/^\uFEFF/, '').trim()); if (!result.ok) throw new Error(result.error); resolve(result.value); } catch (error) { reject(error); }
  }));
}
class DesktopControl {
  constructor({ dir, bridge = windowsBridge, capture, ownPid = process.pid }) {
    this.dir = dir; this.bridge = bridge; this.capture = capture; this.ownPid = ownPid;
    this.connections = new Map(); this.tickets = new Map(); this.frames = new Map(); this.enabled = false;
    try { this.enabled = JSON.parse(fs.readFileSync(path.join(dir, 'desktop-control.json'), 'utf8')).enabled === true; } catch {}
  }
  configure(enabled) { this.enabled = enabled === true; fs.mkdirSync(this.dir, { recursive: true }); fs.writeFileSync(path.join(this.dir, 'desktop-control.json'), JSON.stringify({ enabled: this.enabled })); if (!this.enabled) { this.connections.clear(); this.frames.clear(); this.tickets.clear(); } return { enabled: this.enabled }; }
  scope(ctx) { if (!ctx?.sessionId || !ctx?.taskId) throw new Error('La acción debe pertenecer a una tarea.'); if (ctx.permission === 'chat') throw new Error('El modo Chat no controla aplicaciones.'); return ctx.sessionId + ':' + ctx.taskId; }
  ticket(scope, kind, value) { const id = crypto.randomUUID(); this.tickets.set(id, { scope, kind, value, until: Date.now() + 120000 }); return id; }
  approve(id, scope) { const ticket = this.tickets.get(id); this.tickets.delete(id); if (!ticket || ticket.scope !== scope || ticket.until < Date.now()) throw new Error('La confirmación caducó. Vuelve a revisar la acción.'); return ticket; }
  async run(spec = {}, ctx = {}) {
    if (!this.enabled) throw new Error('Activa Control de Windows en Ajustes para usar estas herramientas.');
    for (const [id, ticket] of this.tickets) if (ticket.until < Date.now()) this.tickets.delete(id);
    if (this.tickets.size > 200) this.tickets.clear();
    const scope = this.scope(ctx), action = String(spec.action || 'list');
    if (action === 'disconnect') { this.connections.delete(scope); this.frames.delete(scope); return { text: 'Ventana desconectada.' }; }
    if (action === 'list') return { windows: (await this.bridge({ op: 'list' })).windows.filter(window => allowedWindow(window, this.ownPid)) };
    if (action === 'connect') {
      const windows = (await this.bridge({ op: 'list' })).windows;
      const window = windows.find(window => String(window.id) === String(spec.id) && allowedWindow(window, this.ownPid));
      if (!window) throw new Error('Esa ventana no está disponible o no se puede controlar.');
      if (!spec.confirmation) return { needs: { type: 'connect', ticket: this.ticket(scope, 'connect', window), window } };
      const approved = this.approve(spec.confirmation, scope);
      if (approved.kind !== 'connect' || approved.value.id !== window.id || approved.value.pid !== window.pid) throw new Error('La ventana cambió. Revisa la selección.');
      this.connections.set(scope, window); this.frames.delete(scope); return { connected: window, text: 'Ventana conectada para esta tarea: ' + window.title };
    }
    const connection = this.connections.get(scope);
    if (!connection) throw new Error('Conecta una ventana y espera la aprobación del usuario.');
    const current = await this.bridge({ op: 'info', id: connection.id, pid: connection.pid });
    if (!allowedWindow(current, this.ownPid) || current.minimized || current.id !== connection.id || current.pid !== connection.pid) throw new Error('La ventana dejó de estar disponible. No se realizó ninguna acción.');
    if (action === 'capture') {
      const image = await this.capture(current);
      if (!image?.base64 || image.base64.length > 24 * 1024 * 1024 || !image.width || !image.height) throw new Error('No se obtuvo una captura válida de esta ventana.');
      const id = crypto.randomUUID(); this.frames.set(scope, { id, window: current, width: image.width, height: image.height, at: Date.now() });
      return { image, captureId: id, text: 'Captura actual de ' + current.title + '. Coordenadas de la imagen: ' + image.width + ' × ' + image.height };
    }
    if (!['click', 'type', 'press'].includes(action)) throw new Error('Acción de escritorio no válida.');
    const frame = this.frames.get(scope);
    if (!frame || frame.id !== spec.captureId || Date.now() - frame.at > 90000) throw new Error('Primero captura la ventana de nuevo. La referencia anterior no es válida.');
    if (['left','top','width','height'].some(key => frame.window[key] !== current[key])) throw new Error('La ventana se movió o cambió de tamaño. Captúrala de nuevo antes de actuar.');
    const command = { op: action, id: current.id, pid: current.pid };
    if (action === 'click') {
      if (!Number.isFinite(spec.x) || !Number.isFinite(spec.y) || spec.x < 0 || spec.y < 0 || spec.x >= frame.width || spec.y >= frame.height) throw new Error('El punto está fuera de la captura.');
      command.x = Math.floor(spec.x * current.width / frame.width); command.y = Math.floor(spec.y * current.height / frame.height);
    }
    if (action === 'type') { if (typeof spec.text !== 'string' || spec.text.length > 4000 || /[\x00-\x08\x0b-\x1f]/.test(spec.text)) throw new Error('Texto no válido.'); command.text = spec.text; }
    if (action === 'press') { if (!/^(?:(?:Ctrl|Shift|Alt)\+){0,2}(?:[A-Z0-9]|Enter|Return|Tab|Escape|Backspace|Delete|ArrowLeft|ArrowRight|ArrowUp|ArrowDown|Home|End|PageUp|PageDown|Space)$/.test(String(spec.key)) || /Ctrl\+Alt\+Delete/.test(spec.key)) throw new Error('Esa combinación no se permite.'); command.key = spec.key; }
    const element = await this.bridge({ op: 'inspect', id: current.id, pid: current.pid, kind: action, x: command.x, y: command.y });
    if (/terminal|powershell|command prompt|consola|cmd\.exe/i.test([element.name, element.className, element.ancestors].join(' '))) throw new Error('El control de Windows no escribe ni actúa en terminales integradas.');
    if (element.password || /password|contrase[nñ]a|api.?key|token|card.?number|n[uú]mero de tarjeta|security.?code|c[oó]digo de seguridad/i.test(element.name || '')) throw new Error('La IA no escribe ni actúa en campos de credenciales o datos de pago.');
    const requires = ctx.permission !== 'full' || SENSITIVE.test(element.name || '') || !element.name || action === 'press' && !NAVIGATION.test(spec.key);
    if (requires) {
      const digest = crypto.createHash('sha256').update(JSON.stringify({ command, element: { name: element.name, type: element.type }, title: current.title })).digest('hex');
      if (!spec.confirmation) return { needs: { type: 'action', ticket: this.ticket(scope, 'action', { digest, captureId: frame.id }), window: current, element: String(element.name || '(elemento sin nombre)').slice(0, 300), action, text: command.text || command.key || `${spec.x}, ${spec.y}` } };
      const approved = this.approve(spec.confirmation, scope);
      if (approved.kind !== 'action' || approved.value.digest !== digest || approved.value.captureId !== frame.id) throw new Error('La acción cambió desde su confirmación.');
    }
    await this.bridge(command); this.frames.delete(scope);
    return { text: 'Acción realizada en ' + current.title + '. Captura otra vez para comprobar el resultado.' };
  }
}
function register({ app, ipcMain, desktopCapturer }) {
  const manager = new DesktopControl({ dir: app.getPath('userData'), capture: async window => {
    const sources = await desktopCapturer.getSources({ types: ['window'], thumbnailSize: { width: 1800, height: 1200 } });
    const source = sources.find(source => source.id.split(':')[1] === String(window.id));
    if (!source || source.thumbnail.isEmpty()) throw new Error('No se pudo capturar esa ventana.');
    const size = source.thumbnail.getSize(); return { base64: source.thumbnail.toPNG().toString('base64'), mime: 'image/png', ...size };
  } });
  const wrap = fn => async (_e, ...args) => { try { return { ok: true, value: await fn(...args) }; } catch (error) { return { ok: false, error: String(error.message) }; } };
  ipcMain.handle('auric:desktop-status', wrap(() => ({ enabled: manager.enabled, supported: process.platform === 'win32' })));
  ipcMain.handle('auric:desktop-configure', wrap(enabled => manager.configure(enabled)));
  ipcMain.handle('auric:desktop-run', wrap((spec, ctx) => manager.run(spec, ctx)));
  return manager;
}
module.exports = { DesktopControl, register, windowsBridge, allowedWindow };
