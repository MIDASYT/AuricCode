const { contextBridge, ipcRenderer, webUtils } = require('electron');
const listeners = new Map();
const emitEvent = (name, detail) => {
  for (const fn of listeners.get(name) || []) {
    try {
      fn(detail || {});
    } catch {}
  }
};
ipcRenderer.on('auric:event', (_e, payload) => emitEvent(payload?.name, payload?.detail));
// Eventos de Mi PC (descargas de modelos, texto que llega en streaming y avisos) con nombres propios.
for (const [channel, name] of [
  ['auric:local-pull-progress', 'local-pull-progress'],
  ['auric:local-pull-done', 'local-pull-done'],
  ['auric:local-delta', 'local-delta'],
  ['auric:local-notice', 'local-notice'],
  ['auric:local-verify-progress', 'local-verify-progress'],
  ['auric:http-stream-progress', 'http-stream-progress']
])
  ipcRenderer.on(channel, (_e, detail) => emitEvent(name, detail));
contextBridge.exposeInMainWorld('auricDesktop', {
  ready: () => ipcRenderer.invoke('auric:renderer-ready'),
  on: (name, fn) => {
    const arr = listeners.get(name) || [];
    arr.push(fn);
    listeners.set(name, arr);
    // No debe devolver nada: el puente de Electron no puede copiar un Map al proceso de la página.
    return () => {
      listeners.set(
        name,
        (listeners.get(name) || []).filter(x => x !== fn)
      );
    };
  },
  storage: {
    get: key => ipcRenderer.invoke('auric:storage-get', key),
    set: (key, value) => ipcRenderer.invoke('auric:storage-set', key, value),
    remove: key => ipcRenderer.invoke('auric:storage-remove', key)
  },
  secrets: {
    get: key => ipcRenderer.invoke('auric:secret-get', key),
    set: (key, value) => ipcRenderer.invoke('auric:secret-set', key, value)
  },
  chooseFolder: (title, defaultPath) => ipcRenderer.invoke('auric:choose-folder', title, defaultPath),
  chooseFiles: options => ipcRenderer.invoke('auric:choose-files', options),
  pathForFile: file => webUtils.getPathForFile(file),
  saveDialog: options => ipcRenderer.invoke('auric:save-dialog', options),
  exportText: (target, content) => ipcRenderer.invoke('auric:export-text', target, content),
  exportBase64: (target, content) => ipcRenderer.invoke('auric:export-base64', target, content),
  confirm: options => ipcRenderer.invoke('auric:confirm', options),
  openExternal: url => ipcRenderer.invoke('auric:open-external', url),
  openPath: target => ipcRenderer.invoke('auric:open-path', target),
  reveal: target => ipcRenderer.invoke('auric:show-item', target),
  notify: (title, body) => ipcRenderer.invoke('auric:notification', title, body),
  trayEnable: () => ipcRenderer.invoke('auric:tray-enable'),
  hide: () => ipcRenderer.invoke('auric:window-hide'),
  show: () => ipcRenderer.invoke('auric:window-show'),
  focus: () => ipcRenderer.invoke('auric:window-focus'),
  exit: () => ipcRenderer.invoke('auric:exit'),
  openLogs: () => ipcRenderer.invoke('auric:open-logs'),
  appInfo: () => ipcRenderer.invoke('auric:app-info'),
  desktop: { status: () => ipcRenderer.invoke('auric:desktop-status'), configure: enabled => ipcRenderer.invoke('auric:desktop-configure', enabled), run: (spec, ctx) => ipcRenderer.invoke('auric:desktop-run', spec, ctx) },
  worktrees: (spec, ctx) => ipcRenderer.invoke('auric:task-worktrees', spec, ctx),
  modelIntel: { status: () => ipcRenderer.invoke('auric:model-intelligence-status'), refresh: force => ipcRenderer.invoke('auric:model-intelligence-refresh', force), configure: spec => ipcRenderer.invoke('auric:model-intelligence-configure', spec), observe: sample => ipcRenderer.invoke('auric:model-intelligence-observe', sample) },
  update: { check: () => ipcRenderer.invoke('auric:update-check'), install: spec => ipcRenderer.invoke('auric:update-install', spec) },
  gallery: {
    importFile: p => ipcRenderer.invoke('auric:gallery-import', p),
    removeFile: p => ipcRenderer.invoke('auric:gallery-remove-file', p)
  },
  fs: {
    stats: p => ipcRenderer.invoke('auric:fs-stats', p),
    exists: p => ipcRenderer.invoke('auric:fs-exists', p),
    readDir: p => ipcRenderer.invoke('auric:fs-read-dir', p),
    readFile: p => ipcRenderer.invoke('auric:fs-read-file', p),
    readBase64: p => ipcRenderer.invoke('auric:fs-read-base64', p),
    join: (...parts) => ipcRenderer.invoke('auric:path-join', ...parts),
    basename: p => ipcRenderer.invoke('auric:path-basename', p)
  },
  http: (url, method, options) => ipcRenderer.invoke('auric:http', url, method, options),
  httpStream: (url, method, options) => ipcRenderer.invoke('auric:http-stream', url, method, options),
  httpAbort: requestId => ipcRenderer.invoke('auric:http-abort', requestId),
  isE2E: () => ipcRenderer.invoke('auric:is-e2e'),
  dictate: options => ipcRenderer.invoke('auric:dictate', options),
  cancelDictation: () => ipcRenderer.invoke('auric:dictate-cancel'),
  specialPaths: () => ipcRenderer.invoke('auric:native-special-paths'),
  findPath: (name, options) => ipcRenderer.invoke('auric:native-find-path', name, options),
  agentFs: {
    readFile: (p, ctx) => ipcRenderer.invoke('auric:agent-read-file', p, ctx),
    writeFile: (p, c, ctx) => ipcRenderer.invoke('auric:agent-write-file', p, c, ctx),
    writeBase64: (p, c, ctx) => ipcRenderer.invoke('auric:agent-write-base64', p, c, ctx),
    mkdir: (p, ctx) => ipcRenderer.invoke('auric:agent-mkdir', p, ctx),
    move: (a, b, ctx) => ipcRenderer.invoke('auric:agent-move', a, b, ctx),
    trash: (p, ctx) => ipcRenderer.invoke('auric:agent-trash', p, ctx),
    copy: (a, b, ctx) => ipcRenderer.invoke('auric:agent-copy', a, b, ctx),
    exec: (command, options, ctx) => ipcRenderer.invoke('auric:agent-exec', command, options, ctx),
    gitStatus: (cwd, ctx) => ipcRenderer.invoke('auric:agent-git-status', cwd, ctx),
    gitDiff: (cwd, ctx) => ipcRenderer.invoke('auric:agent-git-diff', cwd, ctx)
  },
  trash: {
    list: () => ipcRenderer.invoke('auric:trash-list'),
    restore: id => ipcRenderer.invoke('auric:trash-restore', id),
    delete: id => ipcRenderer.invoke('auric:trash-delete', id),
    empty: () => ipcRenderer.invoke('auric:trash-empty'),
    cleanup: days => ipcRenderer.invoke('auric:trash-cleanup', days)
  },
  backups: {
    list: () => ipcRenderer.invoke('auric:backup-list'),
    create: (target, meta) => ipcRenderer.invoke('auric:backup-create', target, meta),
    restore: id => ipcRenderer.invoke('auric:backup-restore', id),
    delete: id => ipcRenderer.invoke('auric:backup-delete', id),
    cleanup: days => ipcRenderer.invoke('auric:backup-cleanup', days)
  },
  processes: {
    start: (command, options, ctx) => ipcRenderer.invoke('auric:process-start', command, options, ctx),
    list: () => ipcRenderer.invoke('auric:process-list'),
    output: (id, lines) => ipcRenderer.invoke('auric:process-output', id, lines),
    sendInput: (id, input, options) => ipcRenderer.invoke('auric:process-input', id, input, options),
    stop: id => ipcRenderer.invoke('auric:process-stop', id)
  },
  mcp: {
    listTools: (spec, ctx) => ipcRenderer.invoke('auric:mcp-list-tools', spec, ctx),
    callTool: (spec, name, args, ctx) => ipcRenderer.invoke('auric:mcp-call-tool', spec, name, args, ctx),
    stop: id => ipcRenderer.invoke('auric:mcp-stop', id)
  },
  connectors: {
    catalog: () => ipcRenderer.invoke('auric:connectors-catalog'),
    connect: (id, input) => ipcRenderer.invoke('auric:connectors-connect', id, input),
    cancel: id => ipcRenderer.invoke('auric:connectors-cancel', id),
    disconnect: id => ipcRenderer.invoke('auric:connectors-disconnect', id),
    removeCustom: id => ipcRenderer.invoke('auric:connectors-remove-custom', id),
    listTools: id => ipcRenderer.invoke('auric:connectors-list-tools', id),
    health: id => ipcRenderer.invoke('auric:connectors-health', id),
    callTool: (id, name, args) => ipcRenderer.invoke('auric:connectors-call-tool', id, name, args),
    addCustom: input => ipcRenderer.invoke('auric:connectors-add-custom', input)
  },
  skills: {
    scan: roots => ipcRenderer.invoke('auric:skills-scan', roots),
    migrate: () => ipcRenderer.invoke('auric:skills-migrate'),
    save: spec => ipcRenderer.invoke('auric:skills-save', spec),
    remove: id => ipcRenderer.invoke('auric:skills-delete', id),
    reveal: folder => ipcRenderer.invoke('auric:skills-reveal', folder)
  },
  plugins: {
    // Formato anterior (plugin.json suelto con un servidor MCP): se sigue leyendo para no romper lo que ya tenías instalado.
    scan: roots => ipcRenderer.invoke('auric:plugins-scan', roots),
    installManifest: source => ipcRenderer.invoke('auric:plugins-install-manifest', source),
    // Plugins de 0.15: todas devuelven { ok, value, error, code }.
    list: () => ipcRenderer.invoke('auric:plugins-list'),
    catalog: () => ipcRenderer.invoke('auric:plugins-catalog'),
    prepare: source => ipcRenderer.invoke('auric:plugins-prepare', source),
    discard: token => ipcRenderer.invoke('auric:plugins-discard', token),
    install: (token, opts) => ipcRenderer.invoke('auric:plugins-install', token, opts),
    uninstall: (id, opts) => ipcRenderer.invoke('auric:plugins-uninstall', id, opts),
    setEnabled: (id, enabled) => ipcRenderer.invoke('auric:plugins-set-enabled', id, enabled),
    verify: id => ipcRenderer.invoke('auric:plugins-verify', id),
    secretSet: (id, name, value) => ipcRenderer.invoke('auric:plugins-secret-set', id, name, value),
    secretClear: (id, name) => ipcRenderer.invoke('auric:plugins-secret-clear', id, name),
    connect: (id, connectorId, input) => ipcRenderer.invoke('auric:plugins-connect', id, connectorId, input),
    registrySearch: opts => ipcRenderer.invoke('auric:plugins-registry-search', opts),
    mcpServers: () => ipcRenderer.invoke('auric:plugins-mcp-servers'),
    instructions: () => ipcRenderer.invoke('auric:plugins-instructions'),
    reveal: id => ipcRenderer.invoke('auric:plugins-reveal', id)
  },
  local: {
    status: host => ipcRenderer.invoke('auric:local-status', host),
    hardware: () => ipcRenderer.invoke('auric:local-hardware'),
    start: host => ipcRenderer.invoke('auric:local-start', host),
    catalog: host => ipcRenderer.invoke('auric:local-catalog', host),
    installed: host => ipcRenderer.invoke('auric:local-installed', host),
    show: (host, name) => ipcRenderer.invoke('auric:local-show', host, name),
    remove: (host, name) => ipcRenderer.invoke('auric:local-delete', host, name),
    editCatalog: edit => ipcRenderer.invoke('auric:local-catalog-edit', edit),
    verify: () => ipcRenderer.invoke('auric:local-verify'),
    pull: (host, name) => ipcRenderer.invoke('auric:local-pull', host, name),
    cancelPull: (host, name) => ipcRenderer.invoke('auric:local-pull-cancel', host, name),
    chat: request => ipcRenderer.invoke('auric:local-chat', request),
    abort: id => ipcRenderer.invoke('auric:local-abort', id),
    openLibrary: () => ipcRenderer.invoke('auric:local-open-library')
  },
  downloads: {
    prepare: (spec, ctx) => ipcRenderer.invoke('auric:dl-prepare', spec, ctx),
    approve: id => ipcRenderer.invoke('auric:dl-approve', id),
    start: id => ipcRenderer.invoke('auric:dl-start', id),
    cancel: id => ipcRenderer.invoke('auric:dl-cancel', id),
    log: limit => ipcRenderer.invoke('auric:dl-log', limit),
    dir: () => ipcRenderer.invoke('auric:dl-dir'),
    remove: id => ipcRenderer.invoke('auric:dl-delete', id),
    show: id => ipcRenderer.invoke('auric:dl-show', id)
  },
  browser: {
    run: (op, args, ctx) => ipcRenderer.invoke('auric:browser-run', op, args, ctx),
    grant: spec => ipcRenderer.invoke('auric:browser-grant', spec),
    sites: () => ipcRenderer.invoke('auric:browser-sites'),
    forget: key => ipcRenderer.invoke('auric:browser-forget', key),
    show: () => ipcRenderer.invoke('auric:browser-show'),
    close: () => ipcRenderer.invoke('auric:browser-close')
  },
  git: {
    prepare: (spec, ctx) => ipcRenderer.invoke('auric:git-prepare', spec, ctx),
    approve: (id, decision) => ipcRenderer.invoke('auric:git-approve', id, decision),
    run: id => ipcRenderer.invoke('auric:git-run', id),
    cancel: id => ipcRenderer.invoke('auric:git-cancel', id),
    log: limit => ipcRenderer.invoke('auric:git-log', limit)
  },
  run: {
    prepare: (spec, ctx) => ipcRenderer.invoke('auric:run-prepare', spec, ctx),
    approve: id => ipcRenderer.invoke('auric:run-approve', id),
    start: id => ipcRenderer.invoke('auric:run-start', id)
  },
  godot: {
    detect: workspace => ipcRenderer.invoke('auric:godot-detect', workspace),
    start: (spec, ctx) => ipcRenderer.invoke('auric:godot-start', spec, ctx),
    sessionStart: (spec, ctx) => ipcRenderer.invoke('auric:godot-session-start', spec, ctx),
    sessionCommand: (id, cmd) => ipcRenderer.invoke('auric:godot-session-command', id, cmd),
    sessionFrame: (id, since) => ipcRenderer.invoke('auric:godot-session-frame', id, since),
    sessionStop: id => ipcRenderer.invoke('auric:godot-session-stop', id)
  },
  sqlite: { query: (target, sql, params, ctx) => ipcRenderer.invoke('auric:sqlite-query', target, sql, params, ctx) },
  index: {
    build: spec => ipcRenderer.invoke('auric:index-build', spec),
    search: (id, query, limit) => ipcRenderer.invoke('auric:index-search', id, query, limit)
  },
  speak: (text, options) => ipcRenderer.invoke('auric:speak', text, options),
  generateDocument: (type, target, spec, ctx, opts) => ipcRenderer.invoke('auric:document-generate', type, target, spec, ctx, opts),
  documents: {
    probe: (target, ctx) => ipcRenderer.invoke('auric:document-probe', target, ctx),
    read: (target, opts, ctx) => ipcRenderer.invoke('auric:document-read', target, opts, ctx),
    readUser: (target, opts) => ipcRenderer.invoke('auric:document-read-user', target, opts),
    preview: target => ipcRenderer.invoke('auric:document-preview', target)
  },
  previewCapture: url => ipcRenderer.invoke('auric:preview-capture', url),
  previewWindows: () => ipcRenderer.invoke('auric:preview-window-list'),
  previewWindowCapture: id => ipcRenderer.invoke('auric:preview-window-capture', id),
  previewWindowStreamSelect: id => ipcRenderer.invoke('auric:preview-window-stream-select', id),
  lspDiagnostics: (target, root, ctx) => ipcRenderer.invoke('auric:lsp-diagnostics', target, root, ctx),
  generated: { save: (name, data) => ipcRenderer.invoke('auric:generated-save', name, data) },
  // Imágenes con IA: todas devuelven { ok, value, error, code }. Las claves nunca vuelven a la pantalla.
  images: {
    status: () => ipcRenderer.invoke('auric:images-status'),
    save: (id, fields) => ipcRenderer.invoke('auric:images-save', id, fields),
    clear: id => ipcRenderer.invoke('auric:images-clear', id),
    setDefault: id => ipcRenderer.invoke('auric:images-default', id),
    generate: request => ipcRenderer.invoke('auric:images-generate', request),
    discard: paths => ipcRenderer.invoke('auric:images-discard', paths)
  }
});
