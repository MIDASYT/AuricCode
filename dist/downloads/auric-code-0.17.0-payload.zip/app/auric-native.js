const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');
const { spawn, exec, execFile, spawnSync } = require('child_process');
const { randomUUID } = require('crypto');
const { pathToFileURL } = require('url');
const { GodotSessionManager } = require('./godot-session');
const docs = require('./docs');
const { parseSkillFrontmatter } = require('./skill-format');

function normalize(p = '') {
  try {
    return path.resolve(String(p || ''));
  } catch {
    return String(p || '');
  }
}
function canonicalSync(input = '') {
  const resolved = normalize(input);
  try {
    return fs.realpathSync.native(resolved);
  } catch {}
  // For a path that does not exist yet, resolve the nearest existing parent.
  const tail = [];
  let cur = resolved;
  while (cur && !fs.existsSync(cur)) {
    const parent = path.dirname(cur);
    if (parent === cur) break;
    tail.unshift(path.basename(cur));
    cur = parent;
  }
  try {
    cur = fs.realpathSync.native(cur);
  } catch {
    cur = normalize(cur);
  }
  return path.resolve(cur, ...tail);
}
function inside(target, roots = []) {
  const t = canonicalSync(target).toLowerCase();
  return (roots || []).some(r => {
    const b = canonicalSync(r.path || r).toLowerCase();
    return t === b || t.startsWith(b + path.sep.toLowerCase());
  });
}
function cmdMayEscape(c = '') {
  c = String(c || '');
  const envEscape =
    /%(?:userprofile|appdata|localappdata|programdata|temp|tmp|homedrive|homepath|onedrive|windir|systemroot|cd)%/i.test(c) ||
    /\$env:(?:userprofile|appdata|localappdata|programdata|temp|tmp|homedrive|homepath|onedrive|windir|systemroot)\b/i.test(c) ||
    /\$\{env:(?:userprofile|appdata|localappdata|programdata|temp|tmp|homedrive|homepath|onedrive|windir|systemroot)\}/i.test(c) ||
    /(^|[\s"'])\$HOME(?:[\/\\]|\b)/i.test(c);
  return (
    /(^|[\s;&|])(cd|chdir|pushd|popd|set-location|sl)\b/i.test(c) ||
    /(^|[\s"'])\.\.[\/\\]/.test(c) ||
    /(^|[\s"'])[a-zA-Z]:[\/\\]/.test(c) ||
    /(^|[\s"'])\\\\[^\s]+/.test(c) ||
    envEscape ||
    /(^|[\s"'])~[\/\\]/.test(c)
  );
}
function assertAgent(ctx = {}, op = 'write', targets = []) {
  let mode = ctx.permission || 'guarded';
  if (mode === 'workspace') mode = 'guarded';
  const roots = ctx.roots || [];
  if (mode === 'full') return;
  if (mode === 'chat') throw new Error('El modo Chat no concede acceso local al PC.');
  const outside = targets.filter(Boolean).some(t => !inside(t, roots));
  if (outside && !ctx.externalApproved)
    throw new Error('Auric bloqueó una operación fuera de las carpetas autorizadas sin permiso explícito.');
  // Solo lectura permite leer sin preguntar; cualquier escritura/ejecución requiere aprobación explícita.
  if (mode === 'readonly' && op !== 'read' && !ctx.approved)
    throw new Error('Solo lectura requiere aprobación explícita para escribir, borrar o ejecutar.');
  if (mode === 'ask' && op !== 'read' && !ctx.approved) throw new Error('La capa nativa requiere aprobación explícita para esta acción.');
  if (mode === 'guarded' && ctx.dangerous && !ctx.approved)
    throw new Error('La capa nativa requiere aprobación para esta acción peligrosa.');
}
function assertCommandWithinScope(command, ctx = {}) {
  let mode = ctx.permission || 'guarded';
  if (mode === 'workspace') mode = 'guarded';
  if (mode === 'full') return;
  if (cmdMayEscape(command) && !ctx.externalApproved)
    throw new Error('Auric bloqueó un comando que puede salir de las carpetas autorizadas sin permiso externo explícito.');
}
function executionCwd(requested, ctx = {}) {
  let mode = ctx.permission || 'guarded';
  if (mode === 'workspace') mode = 'guarded';
  if (requested) return normalize(requested);
  if (mode === 'full') return os.homedir();
  const first = (ctx.roots || []).map(r => r?.path || r).find(Boolean);
  if (!first) throw new Error('Auric bloqueó la ejecución porque no hay una carpeta de trabajo autorizada.');
  return normalize(first);
}
function safeName(s = 'item') {
  return (
    String(s || 'item')
      .replace(/[<>:"/\\|?*\x00-\x1F]/g, '_')
      .slice(0, 120) || 'item'
  );
}
async function copyRecursive(src, dst) {
  const st = await fsp.stat(src);
  if (st.isDirectory()) {
    await fsp.mkdir(dst, { recursive: true });
    for (const e of await fsp.readdir(src)) await copyRecursive(path.join(src, e), path.join(dst, e));
  } else {
    await fsp.mkdir(path.dirname(dst), { recursive: true });
    await fsp.copyFile(src, dst);
  }
}
async function movePortable(src, dst) {
  await fsp.mkdir(path.dirname(dst), { recursive: true });
  try {
    await fsp.rename(src, dst);
  } catch {
    await copyRecursive(src, dst);
    await fsp.rm(src, { recursive: true, force: true });
  }
}
async function encodeTextPreservingFormat(target, content) {
  let text = String(content ?? ''),
    existing = null;
  try {
    existing = await fsp.readFile(target);
  } catch {}
  if (existing?.length) {
    let sample = '';
    if (existing[0] === 0xff && existing[1] === 0xfe) sample = existing.subarray(2).toString('utf16le');
    else sample = existing.toString('utf8').replace(/^\uFEFF/, '');
    const crlf = (sample.match(/\r\n/g) || []).length,
      lf = (sample.match(/(?<!\r)\n/g) || []).length;
    if (crlf > lf) text = text.replace(/\r?\n/g, '\r\n');
    else text = text.replace(/\r\n/g, '\n');
    if (existing[0] === 0xff && existing[1] === 0xfe) return Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from(text, 'utf16le')]);
    if (existing[0] === 0xef && existing[1] === 0xbb && existing[2] === 0xbf)
      return Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), Buffer.from(text, 'utf8')]);
  }
  return Buffer.from(text, 'utf8');
}
async function atomicWriteFile(target, data) {
  target = String(target);
  await fsp.mkdir(path.dirname(target), { recursive: true });
  const tmp = path.join(path.dirname(target), `.${path.basename(target)}.auric-${randomUUID()}.tmp`),
    buf = Buffer.isBuffer(data) ? data : Buffer.from(String(data ?? ''));
  let fh;
  try {
    fh = await fsp.open(tmp, 'w');
    await fh.writeFile(buf);
    await fh.sync();
    await fh.close();
    fh = null;
    try {
      await fsp.rename(tmp, target);
    } catch {
      await fsp.copyFile(tmp, target);
      await fsp.rm(tmp, { force: true });
    }
  } catch (e) {
    try {
      await fh?.close();
    } catch {}
    try {
      await fsp.rm(tmp, { force: true });
    } catch {}
    throw e;
  }
}

function findExecutable(name, roots = []) {
  const names = process.platform === 'win32' ? [`${name}.cmd`, `${name}.exe`, name] : [name];
  for (const root of roots.filter(Boolean)) {
    for (const n of names) {
      const candidates = [
        path.join(root, 'node_modules', '.bin', n),
        path.join(root, '.venv', 'Scripts', n),
        path.join(root, 'venv', 'Scripts', n)
      ];
      for (const c of candidates) if (fs.existsSync(c)) return c;
    }
  }
  try {
    const probe = spawnSync(process.platform === 'win32' ? 'where' : 'which', [name], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 2500
    });
    const line = String(probe.stdout || '')
      .split(/\r?\n/)
      .find(Boolean);
    if (line && fs.existsSync(line.trim())) return line.trim();
  } catch {}
  return '';
}
async function discoverGodotExecutables(extraRoots = []) {
  const out = [];
  const seen = new Set();
  const add = p => {
    if (!p) return;
    const abs = normalize(p);
    if (!fs.existsSync(abs) || seen.has(abs.toLowerCase())) return;
    seen.add(abs.toLowerCase());
    out.push(abs);
  };
  add(findExecutable('godot', extraRoots));
  add(findExecutable('godot4', extraRoots));
  const roots = [...extraRoots].filter(Boolean);
  for (const root of roots) {
    let entries = [];
    try {
      entries = await fsp.readdir(root, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries.slice(0, 800)) {
      if (e.isFile() && /^godot.*\.exe$/i.test(e.name)) add(path.join(root, e.name));
      if (e.isDirectory() && /^godot/i.test(e.name)) {
        let inner = [];
        try {
          inner = await fsp.readdir(path.join(root, e.name), { withFileTypes: true });
        } catch {}
        for (const x of inner) if (x.isFile() && /^godot.*\.exe$/i.test(x.name)) add(path.join(root, e.name, x.name));
      }
    }
  }
  return out.slice(0, 20);
}

function lspLanguage(file = '') {
  const ext = path.extname(file).toLowerCase();
  return (
    {
      '.ts': 'typescript',
      '.tsx': 'typescriptreact',
      '.js': 'javascript',
      '.jsx': 'javascriptreact',
      '.mjs': 'javascript',
      '.cjs': 'javascript',
      '.py': 'python',
      '.rs': 'rust',
      '.go': 'go',
      '.java': 'java',
      '.cs': 'csharp',
      '.json': 'json',
      '.css': 'css',
      '.html': 'html'
    }[ext] || ''
  );
}
function lspServer(file, root) {
  const lang = lspLanguage(file);
  let cmd = '',
    args = [];
  if (['typescript', 'typescriptreact', 'javascript', 'javascriptreact'].includes(lang)) {
    cmd = findExecutable('typescript-language-server', [root]);
    args = ['--stdio'];
  } else if (lang === 'python') {
    cmd = findExecutable('pyright-langserver', [root]);
    args = ['--stdio'];
    if (!cmd) {
      cmd = findExecutable('pylsp', [root]);
      args = [];
    }
  } else if (lang === 'rust') {
    cmd = findExecutable('rust-analyzer', [root]);
    args = [];
  } else if (lang === 'go') {
    cmd = findExecutable('gopls', [root]);
    args = [];
  } else if (lang === 'java') {
    cmd = findExecutable('jdtls', [root]);
    args = [];
  } else if (lang === 'csharp') {
    cmd = findExecutable('csharp-ls', [root]);
    args = [];
  }
  return { lang, cmd, args };
}
function frameLsp(obj) {
  const body = Buffer.from(JSON.stringify(obj), 'utf8');
  return Buffer.concat([Buffer.from(`Content-Length: ${body.length}\r\n\r\n`, 'ascii'), body]);
}
async function getLspDiagnostics(file, root) {
  file = normalize(file);
  root = normalize(root || path.dirname(file));
  const { lang, cmd, args } = lspServer(file, root);
  if (!lang)
    return { available: false, reason: `No hay adaptador LSP para ${path.extname(file) || 'este tipo de archivo'}.`, diagnostics: [] };
  if (!cmd)
    return { available: false, reason: `No se encontró un Language Server instalado para ${lang}.`, language: lang, diagnostics: [] };
  const text = await fsp.readFile(file, 'utf8'),
    uri = pathToFileURL(file).href,
    rootUri = pathToFileURL(root).href;
  return await new Promise(resolve => {
    let done = false,
      buf = Buffer.alloc(0),
      initialized = false;
    const proc = spawn(cmd, args, {
      cwd: root,
      windowsHide: true,
      shell: process.platform === 'win32' && /\.(cmd|bat)$/i.test(cmd),
      stdio: ['pipe', 'pipe', 'pipe']
    });
    const finish = value => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      try {
        proc.kill();
      } catch {}
      resolve(value);
    };
    const send = o => {
      try {
        proc.stdin.write(frameLsp(o));
      } catch {}
    };
    const timer = setTimeout(
      () => finish({ available: true, language: lang, server: path.basename(cmd), timedOut: true, diagnostics: [] }),
      9000
    );
    proc.on('error', e => finish({ available: false, reason: e.message, language: lang, diagnostics: [] }));
    proc.stdout.on('data', chunk => {
      buf = Buffer.concat([buf, chunk]);
      while (true) {
        const sep = buf.indexOf('\r\n\r\n');
        if (sep < 0) break;
        const head = buf.slice(0, sep).toString('ascii'),
          m = /Content-Length:\s*(\d+)/i.exec(head);
        if (!m) {
          buf = buf.slice(sep + 4);
          continue;
        }
        const len = Number(m[1]);
        if (buf.length < sep + 4 + len) break;
        const body = buf.slice(sep + 4, sep + 4 + len).toString('utf8');
        buf = buf.slice(sep + 4 + len);
        let msg;
        try {
          msg = JSON.parse(body);
        } catch {
          continue;
        }
        if (msg.id === 1 && !initialized) {
          initialized = true;
          send({ jsonrpc: '2.0', method: 'initialized', params: {} });
          send({ jsonrpc: '2.0', method: 'textDocument/didOpen', params: { textDocument: { uri, languageId: lang, version: 1, text } } });
        }
        if (msg.method === 'textDocument/publishDiagnostics' && msg.params?.uri === uri) {
          finish({ available: true, language: lang, server: path.basename(cmd), diagnostics: msg.params.diagnostics || [] });
          return;
        }
      }
    });
    send({
      jsonrpc: '2.0',
      id: 1,
      method: 'initialize',
      params: {
        processId: process.pid,
        rootUri,
        workspaceFolders: [{ uri: rootUri, name: path.basename(root) }],
        capabilities: { textDocument: { publishDiagnostics: { relatedInformation: true } } },
        clientInfo: { name: 'Auric Code', version: '0.17.0' }
      }
    });
  });
}

const mcpClients = new Map();
function normalizeMcpSpec(spec = {}) {
  const id = String(spec.id || '').trim();
  const command = String(spec.command || '').trim();
  const args = Array.isArray(spec.args) ? spec.args.map(x => String(x)).slice(0, 40) : [];
  const cwd = String(spec.cwd || '').trim();
  const env =
    spec.env && typeof spec.env === 'object' ? Object.fromEntries(Object.entries(spec.env).map(([k, v]) => [String(k), String(v)])) : {};
  if (!id) throw new Error('MCP requiere un id.');
  if (!command) throw new Error('MCP requiere un comando.');
  return { id, command, args, cwd, env };
}
function mcpSignature(spec, internal = null) {
  return JSON.stringify([spec.command, spec.args, spec.cwd, spec.env, internal ? ['aislado', internal.verbatim === true, internal.env] : null]);
}
function stopMcp(id) {
  const c = mcpClients.get(String(id));
  if (!c) return false;
  // En Windows un servidor puede colgar de un cmd.exe: se cierra TODO el árbol, no solo el primer proceso.
  killTree(c.proc);
  for (const x of c.pending.values()) {
    clearTimeout(x.timer);
    x.reject(new Error('Servidor MCP detenido.'));
  }
  c.pending.clear();
  mcpClients.delete(String(id));
  return true;
}
// `internal` solo lo rellena el gestor de plugins (nunca viene del renderizador): { env, verbatim }. Con él, el servidor arranca con
// un entorno mínimo y propio (no hereda nada de Auric ni del PC), sin shell y con el comando ya resuelto.
async function mcpClient(rawSpec = {}, internal = null) {
  const spec = normalizeMcpSpec(rawSpec),
    sig = mcpSignature(spec, internal),
    old = mcpClients.get(spec.id);
  if (old && old.signature === sig && old.proc && !old.proc.killed && old.proc.exitCode == null) return old;
  if (old) stopMcp(spec.id);
  let proc;
  if (internal) {
    proc = spawn(spec.command, spec.args, {
      cwd: spec.cwd || undefined,
      env: internal.env,
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
      shell: false,
      windowsVerbatimArguments: internal.verbatim === true
    });
  } else {
    let command = spec.command;
    const found = findExecutable(command, spec.cwd ? [spec.cwd] : []);
    if (found) command = found;
    const useShell = process.platform === 'win32' && /\.(cmd|bat)$/i.test(command);
    const pluginEnv = Object.fromEntries(
      Object.entries(spec.env || {}).map(([k, v]) => {
        const raw = String(v),
          m = raw.match(/^\$\{([A-Za-z_][A-Za-z0-9_]*)\}$/);
        return [k, m ? process.env[m[1]] || '' : raw];
      })
    );
    proc = spawn(command, spec.args, {
      cwd: spec.cwd || undefined,
      env: { ...process.env, ...pluginEnv },
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
      shell: useShell
    });
  }
  const client = { id: spec.id, signature: sig, proc, pending: new Map(), seq: 1, stderr: '', ready: null };
  mcpClients.set(spec.id, client);
  let buf = '';
  proc.stdout.setEncoding('utf8');
  proc.stderr.setEncoding('utf8');
  proc.stderr.on('data', d => (client.stderr = (client.stderr + String(d)).slice(-12000)));
  proc.stdout.on('data', d => {
    buf += String(d);
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line) continue;
      let msg;
      try {
        msg = JSON.parse(line);
      } catch {
        continue;
      }
      if (msg.id != null) {
        const wait = client.pending.get(String(msg.id));
        if (wait) {
          client.pending.delete(String(msg.id));
          clearTimeout(wait.timer);
          if (msg.error) wait.reject(new Error(msg.error.message || JSON.stringify(msg.error)));
          else wait.resolve(msg.result);
        }
      }
    }
  });
  proc.on('error', err => {
    for (const x of client.pending.values()) {
      clearTimeout(x.timer);
      x.reject(err);
    }
    client.pending.clear();
    // Si ni siquiera arrancó (no existe el programa…), que el siguiente intento empiece de cero en vez de reutilizar un cliente muerto.
    if (mcpClients.get(spec.id) === client) mcpClients.delete(spec.id);
  });
  proc.on('exit', code => {
    for (const x of client.pending.values()) {
      clearTimeout(x.timer);
      x.reject(new Error(`Servidor MCP cerrado (exit ${code}). ${client.stderr}`));
    }
    client.pending.clear();
    if (mcpClients.get(spec.id) === client) mcpClients.delete(spec.id);
  });
  const call = (method, params = {}, timeout = 30000) =>
    new Promise((resolve, reject) => {
      const id = String(client.seq++),
        timer = setTimeout(
          () => {
            client.pending.delete(id);
            reject(new Error(`MCP timeout en ${method}. ${client.stderr}`));
          },
          Math.max(1000, timeout)
        );
      client.pending.set(id, { resolve, reject, timer });
      try {
        proc.stdin.write(JSON.stringify({ jsonrpc: '2.0', id: Number(id), method, params }) + '\n');
      } catch (e) {
        clearTimeout(timer);
        client.pending.delete(id);
        reject(e);
      }
    });
  client.call = call;
  client.notify = (method, params = {}) => {
    proc.stdin.write(JSON.stringify({ jsonrpc: '2.0', method, params }) + '\n');
  };
  client.ready = (async () => {
    // Un servidor de plugin puede tener que descargar sus piezas la primera vez (npx, uvx…): más margen que un servidor ya instalado.
    await call(
      'initialize',
      { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'Auric Code', version: '0.17.0' } },
      internal ? 120000 : 20000
    );
    client.notify('notifications/initialized', {});
    return true;
  })();
  try {
    await client.ready;
  } catch (e) {
    // No dejar un proceso a medias: si no completó el saludo se cierra y se olvida.
    if (mcpClients.get(spec.id) === client) stopMcp(spec.id);
    throw e;
  }
  return client;
}
async function mcpListTools(spec, internal = null) {
  const c = await mcpClient(spec, internal),
    r = await c.call('tools/list', {}, 25000);
  return Array.isArray(r?.tools) ? r.tools : [];
}
async function mcpCallTool(spec, name, args = {}, internal = null) {
  const c = await mcpClient(spec, internal),
    r = await c.call('tools/call', { name: String(name || ''), arguments: args && typeof args === 'object' ? args : {} }, 60000);
  return r || {};
}
// Cierra los servidores cuyo id empieza por «prefijo» (todos los de un plugin al desinstalarlo, desactivarlo o actualizarlo).
function stopMcpPrefix(prefix) {
  const p = String(prefix || '');
  if (!p) return 0;
  let n = 0;
  for (const id of [...mcpClients.keys()]) if (id.startsWith(p)) n += stopMcp(id) ? 1 : 0;
  return n;
}

// Escanea un directorio de skills. `logosDir` (solo skills del sistema) resuelve `logo:` a una ruta relativa de la app.
async function scanSkillsDirectory(dir, source = 'global', { logosDir = '', errors = null } = {}) {
  const out = [];
  if (!dir || !fs.existsSync(dir)) return out;
  let entries = [];
  try {
    entries = await fsp.readdir(dir, { withFileTypes: true });
  } catch (err) {
    errors?.push({ folder: dir, error: String(err?.message || err) });
    return out;
  }
  for (const entry of entries) {
    let skillDir = '';
    if (entry.isDirectory()) skillDir = path.join(dir, entry.name);
    else if (entry.isFile() && /^SKILL\.md$/i.test(entry.name)) skillDir = dir;
    else continue;
    const file = path.join(skillDir, 'SKILL.md');
    if (!fs.existsSync(file)) continue;
    try {
      const parsed = parseSkillFrontmatter(await fsp.readFile(file, 'utf8'));
      const rel = path.relative(dir, skillDir) || entry.name.replace(/\.md$/i, '');
      let logo = '';
      if (parsed.logo && logosDir && /^[\w.-]+$/.test(parsed.logo) && fs.existsSync(path.join(logosDir, parsed.logo)))
        logo = `./skill-logos/${parsed.logo}`;
      out.push({
        id: safeName(parsed.id || rel.toLowerCase().replace(/[^a-z0-9_-]+/g, '-') || randomUUID()),
        name: parsed.name || rel,
        description: parsed.description || '',
        icon: parsed.icon || '',
        logo,
        logoWanted: parsed.logo || '',
        color: parsed.color || '',
        triggers: parsed.triggers || [],
        markers: parsed.markers || [],
        tags: parsed.tags || [],
        procedure: parsed.procedure || '',
        path: file,
        folder: skillDir,
        source,
        readOnly: source === 'system'
      });
    } catch (err) {
      errors?.push({ folder: skillDir, error: String(err?.message || err) });
    }
  }
  return out.sort((a, b) => String(a.name).localeCompare(String(b.name)));
}
// Une los ámbitos con prioridad workspace > global > system (mismo id = el más específico gana).
function mergeSkillScopes(system, global, workspace) {
  const map = new Map();
  for (const sk of [...system, ...global, ...workspace]) {
    const prev = map.get(sk.id);
    map.set(sk.id, prev ? { ...sk, overrides: prev.source } : sk);
  }
  return [...map.values()].sort((a, b) => String(a.name).localeCompare(String(b.name)));
}
async function scanPluginsDirectory(dir, source = 'global') {
  const out = [];
  if (!dir || !fs.existsSync(dir)) return out;
  let entries = [];
  try {
    entries = await fsp.readdir(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const entry of entries) {
    const pluginDir = entry.isDirectory() ? path.join(dir, entry.name) : dir;
    const file = entry.isFile() && /^plugin\.json$/i.test(entry.name) ? path.join(dir, entry.name) : path.join(pluginDir, 'plugin.json');
    if (!fs.existsSync(file)) continue;
    try {
      const raw = JSON.parse(await fsp.readFile(file, 'utf8'));
      const id = safeName(String(raw.id || entry.name || 'plugin'));
      const server = raw.server && typeof raw.server === 'object' ? raw.server : raw.mcp && typeof raw.mcp === 'object' ? raw.mcp : null;
      out.push({
        id,
        name: String(raw.name || id),
        description: String(raw.description || ''),
        icon: String(raw.icon || ''),
        version: String(raw.version || ''),
        path: file,
        folder: pluginDir,
        source,
        enabled: raw.enabled !== false,
        server: server
          ? {
              id: String(server.id || id),
              name: String(server.name || raw.name || id),
              command: String(server.command || ''),
              args: Array.isArray(server.args) ? server.args.map(x => String(x)) : [],
              cwd: String(server.cwd || ''),
              env: server.env && typeof server.env === 'object' ? server.env : {},
              enabled: server.enabled !== false
            }
          : null
      });
    } catch {}
  }
  return out.sort((a, b) => String(a.name).localeCompare(String(b.name)));
}
async function installPluginManifest(source, destRoot) {
  const raw = JSON.parse(await fsp.readFile(String(source), 'utf8'));
  const id = safeName(String(raw.id || raw.name || path.basename(String(source), path.extname(String(source))) || 'plugin'));
  if (!id) throw new Error('El plugin necesita un id válido.');
  const destDir = path.join(destRoot, id);
  await fsp.mkdir(destDir, { recursive: true });
  await fsp.writeFile(path.join(destDir, 'plugin.json'), JSON.stringify({ ...raw, id }, null, 2), 'utf8');
  return { id, path: path.join(destDir, 'plugin.json') };
}

// Migración 0.12 → 0.13: las skills oficiales ya NO se copian a la carpeta del usuario (se leen del sistema).
// Se eliminan las copias idénticas al original; las modificadas se conservan como skills propias.
async function migrateLegacyOfficialSkills(officialDir, globalDir) {
  const result = { removed: [], kept: [] };
  if (!fs.existsSync(officialDir) || !fs.existsSync(globalDir)) return result;
  const norm = t =>
    String(t || '')
      .replace(/\r\n/g, '\n')
      .trim();
  for (const entry of await fsp.readdir(officialDir, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    const mine = path.join(globalDir, entry.name);
    const mineFile = path.join(mine, 'SKILL.md'),
      officialFile = path.join(officialDir, entry.name, 'SKILL.md');
    if (!fs.existsSync(mineFile) || !fs.existsSync(officialFile)) continue;
    const same = norm(await fsp.readFile(mineFile, 'utf8')) === norm(await fsp.readFile(officialFile, 'utf8'));
    if (same) {
      await fsp.rm(mine, { recursive: true, force: true });
      result.removed.push(entry.name);
    } else result.kept.push(entry.name);
  }
  for (const legacy of ['auric-hub-firebase', 'paper-plugin-maintainer', 'test-and-debug-runner', 'web-ui-polish']) {
    const dir = path.join(globalDir, legacy);
    if (fs.existsSync(dir)) {
      await fsp.rm(dir, { recursive: true, force: true });
      result.removed.push(legacy);
    }
  }
  return result;
}
// Serializa una skill a SKILL.md.
function serializeSkill(spec = {}) {
  const list = v =>
    (Array.isArray(v) ? v : String(v || '').split(','))
      .map(x => String(x).trim())
      .filter(Boolean)
      .join(', ');
  const line = (k, v) => (String(v || '').trim() ? `${k}: ${String(v).replace(/\r?\n/g, ' ').trim()}\n` : '');
  const fm =
    `---\nid: ${safeName(spec.id)}\n` +
    line('name', spec.name) +
    line('description', spec.description) +
    (list(spec.triggers) ? `triggers: [${list(spec.triggers)}]\n` : '') +
    (list(spec.markers) ? `markers: [${list(spec.markers)}]\n` : '') +
    (list(spec.tags) ? `tags: [${list(spec.tags)}]\n` : '') +
    '---\n';
  return `${fm}${String(spec.procedure || '').trim()}\n`;
}
// Mata el proceso Y todos sus descendientes. En Windows `proc.kill()` solo mata el cmd.exe y deja huérfano al juego/servidor.
function killTree(proc) {
  const pid = proc?.pid;
  if (!pid) return;
  try {
    if (process.platform === 'win32') {
      execFile('taskkill', ['/PID', String(pid), '/T', '/F'], { windowsHide: true }, () => {});
    } else {
      try {
        process.kill(-pid, 'SIGKILL'); // grupo (el proceso se lanza con detached: true)
      } catch {
        proc.kill('SIGKILL');
      }
    }
  } catch {
    try {
      proc.kill();
    } catch {}
  }
}
// Ejecuta un comando con tiempo límite; al agotarse mata TODO el árbol de procesos.
function runShellCommand(command, { cwd, timeout, maxBuffer = 12 * 1024 * 1024 } = {}) {
  return new Promise(resolve => {
    const win = process.platform === 'win32';
    const proc = spawn(win ? 'cmd.exe' : '/bin/sh', win ? ['/D', '/S', '/C', String(command)] : ['-c', String(command)], {
      cwd,
      env: { ...process.env, GIT_TERMINAL_PROMPT: '0', GCM_INTERACTIVE: '0', GCM_GUI_PROMPT: '0' },
      windowsHide: true,
      detached: !win,
      stdio: ['ignore', 'pipe', 'pipe']
    });
    let out = '',
      err = '',
      timedOut = false,
      finished = false;
    const cap = (cur, d) => (cur.length > maxBuffer ? cur : cur + d.toString());
    proc.stdout.on('data', d => (out = cap(out, d)));
    proc.stderr.on('data', d => (err = cap(err, d)));
    const timer = setTimeout(() => {
      timedOut = true;
      killTree(proc);
    }, timeout);
    const done = (code, extra = '') => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      resolve({
        exitCode: timedOut ? 124 : typeof code === 'number' ? code : 1,
        stdOut: out,
        stdErr:
          (timedOut
            ? `${err}\n[Auric] Tiempo agotado (${Math.round(timeout / 1000)} s): se detuvo el comando y todos sus procesos hijos.`.trim()
            : err) + extra
      });
    };
    proc.on('close', code => done(code));
    proc.on('error', e => done(1, e.message));
  });
}
function tailLines(text = '', lines = 80) {
  const rows = String(text || '').split(/\r?\n/);
  return rows.slice(-Math.max(1, Number(lines) || 80)).join('\n');
}

function register({ app, ipcMain, BrowserWindow }) {
  const processes = new Map();
  const checkpointed = new Set();
  const trashRoot = () => path.join(app.getPath('userData'), 'trash');
  const backupRoot = () => path.join(app.getPath('userData'), 'backups');
  const globalSkillsRoot = () => path.join(app.getPath('userData'), 'skills');
  const officialSkillsRoot = () => path.join(__dirname, 'resources', 'official-skills');
  const globalPluginsRoot = () => path.join(app.getPath('userData'), 'plugins');
  const indexRoot = () => path.join(app.getPath('userData'), 'indexes');
  const indexFile = id => path.join(indexRoot(), `${safeName(id || 'workspace')}.json`);
  async function buildProjectIndex(spec = {}) {
    const id = String(spec.id || 'workspace'),
      roots = Array.isArray(spec.roots) ? spec.roots.filter(r => r && r.path) : [],
      ignored = new Set((Array.isArray(spec.ignore) ? spec.ignore : []).map(x => String(x).trim()).filter(Boolean));
    if (!roots.length) throw new Error('No hay carpetas para indexar.');
    await fsp.mkdir(indexRoot(), { recursive: true });
    let previous = { entries: [] };
    try {
      previous = JSON.parse(await fsp.readFile(indexFile(id), 'utf8'));
    } catch {}
    const prev = new Map((previous.entries || []).map(x => [String(x.path).toLowerCase(), x])),
      entries = [];
    let scanned = 0,
      reused = 0,
      skipped = 0;
    const extract = text => {
      const symbols = [],
        imports = [];
      for (const raw of String(text).split(/\r?\n/).slice(0, 12000)) {
        const line = raw.trim();
        if (!line) continue;
        if (/^(import\b|from\s+.+\s+import\b|#include\b|using\b|require\s*\(|const\s+.+?=\s*require\s*\()/i.test(line))
          imports.push(line.slice(0, 260));
        const patterns = [
          /\b(?:class|interface|enum|record|object)\s+([A-Za-z_$][\w$]*)/,
          /\b(?:function|def|fn|func)\s+([A-Za-z_$][\w$]*)\s*\(/,
          /\b(?:public|private|protected|internal|static|async|final|override|virtual|suspend|export|const|let|var)\s+(?:[A-Za-z_$][\w$<>?,.\[\] ]+\s+)?([A-Za-z_$][\w$]*)\s*\(/,
          /\b([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>/
        ];
        for (const re of patterns) {
          const m = line.match(re);
          if (m) {
            symbols.push(m[1]);
            break;
          }
        }
        if (symbols.length >= 220 && imports.length >= 160) break;
      }
      return { symbols: [...new Set(symbols)].slice(0, 220), imports: [...new Set(imports)].slice(0, 160) };
    };
    async function walk(root, dir) {
      let list;
      try {
        list = await fsp.readdir(dir, { withFileTypes: true });
      } catch {
        return;
      }
      for (const d of list) {
        if (entries.length >= 30000) return;
        if (ignored.has(d.name)) {
          skipped++;
          continue;
        }
        const full = path.join(dir, d.name);
        let st;
        try {
          st = await fsp.lstat(full);
        } catch {
          continue;
        }
        if (st.isSymbolicLink()) {
          skipped++;
          continue;
        }
        if (st.isDirectory()) {
          await walk(root, full);
          continue;
        }
        if (!st.isFile()) {
          continue;
        }
        if (st.size > 2 * 1024 * 1024) {
          skipped++;
          continue;
        }
        scanned++;
        const key = full.toLowerCase(),
          old = prev.get(key);
        if (old && Number(old.mtimeMs) === Number(st.mtimeMs) && Number(old.size) === Number(st.size)) {
          entries.push(old);
          reused++;
          continue;
        }
        let buf;
        try {
          buf = await fsp.readFile(full);
        } catch {
          continue;
        }
        if (buf.subarray(0, 65536).includes(0)) {
          skipped++;
          continue;
        }
        const text = buf.toString('utf8', 0, Math.min(buf.length, 500000)),
          meta = extract(text),
          rel = path.relative(root.path, full);
        entries.push({
          path: full,
          rel,
          rootId: root.id || '',
          rootName: root.name || path.basename(root.path),
          size: st.size,
          mtimeMs: st.mtimeMs,
          symbols: meta.symbols,
          imports: meta.imports
        });
      }
    }
    for (const root of roots) await walk(root, normalize(root.path));
    const out = {
      id,
      builtAt: new Date().toISOString(),
      roots: roots.map(r => ({ id: r.id || '', name: r.name || path.basename(r.path), path: r.path })),
      entries,
      stats: { files: entries.length, scanned, reused, skipped }
    };
    await fsp.writeFile(indexFile(id), JSON.stringify(out));
    return { builtAt: out.builtAt, ...out.stats };
  }
  async function searchProjectIndex(id, query, limit = 60) {
    let idx;
    try {
      idx = JSON.parse(await fsp.readFile(indexFile(String(id || 'workspace')), 'utf8'));
    } catch {
      throw new Error('Este workspace todavía no tiene índice. Ejecuta index_project primero.');
    }
    const terms = String(query || '')
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean);
    if (!terms.length) return [];
    const scored = [];
    for (const e of idx.entries || []) {
      const rel = String(e.rel || '').toLowerCase(),
        symbols = (e.symbols || []).join(' ').toLowerCase(),
        imports = (e.imports || []).join(' ').toLowerCase();
      let score = 0;
      for (const t of terms) {
        if (rel.includes(t)) score += 5;
        if (symbols.includes(t)) score += 8;
        if (imports.includes(t)) score += 2;
      }
      if (score)
        scored.push({
          score,
          path: e.path,
          rel: e.rel,
          rootId: e.rootId,
          rootName: e.rootName,
          symbols: (e.symbols || []).filter(x => terms.some(t => String(x).toLowerCase().includes(t))).slice(0, 20),
          imports: (e.imports || []).filter(x => terms.some(t => String(x).toLowerCase().includes(t))).slice(0, 10)
        });
    }
    return scored
      .sort((a, b) => b.score - a.score || String(a.rel).localeCompare(String(b.rel)))
      .slice(0, Math.max(1, Math.min(200, Number(limit) || 60)));
  }
  async function trashItem(target, meta = {}) {
    const src = normalize(target);
    const st = await fsp.stat(src);
    const id = randomUUID();
    const dir = path.join(trashRoot(), id),
      dest = path.join(dir, 'content');
    await fsp.mkdir(dir, { recursive: true });
    await movePortable(src, dest);
    await fsp.writeFile(
      path.join(dir, 'meta.json'),
      JSON.stringify(
        { id, originalPath: src, name: path.basename(src), deletedAt: new Date().toISOString(), isDirectory: st.isDirectory(), ...meta },
        null,
        2
      )
    );
    return id;
  }
  async function listTrash() {
    await fsp.mkdir(trashRoot(), { recursive: true });
    const out = [];
    for (const id of await fsp.readdir(trashRoot())) {
      try {
        const m = JSON.parse(await fsp.readFile(path.join(trashRoot(), id, 'meta.json'), 'utf8'));
        out.push(m);
      } catch {}
    }
    return out.sort((a, b) => String(b.deletedAt).localeCompare(String(a.deletedAt)));
  }
  async function cleanupTrash(days = 30) {
    const cut = Date.now() - Math.max(1, Number(days || 30)) * 86400000;
    for (const m of await listTrash()) {
      if (new Date(m.deletedAt).getTime() < cut) await fsp.rm(path.join(trashRoot(), m.id), { recursive: true, force: true });
    }
  }
  async function createBackup(target, meta = {}) {
    const originalPath = normalize(target),
      existed = fs.existsSync(originalPath),
      id = randomUUID(),
      dir = path.join(backupRoot(), id),
      content = path.join(dir, 'content');
    await fsp.mkdir(dir, { recursive: true });
    let isDirectory = false,
      size = 0;
    if (existed) {
      const st = await fsp.stat(originalPath);
      isDirectory = st.isDirectory();
      size = Number(st.size || 0);
      await copyRecursive(originalPath, content);
    }
    const info = {
      id,
      originalPath,
      name: path.basename(originalPath) || originalPath,
      createdAt: new Date().toISOString(),
      existed,
      isDirectory,
      size,
      sessionId: meta.sessionId || null,
      taskId: meta.taskId || null,
      action: meta.action || 'checkpoint',
      source: meta.source || 'agent',
      label: meta.label || ''
    };
    await fsp.writeFile(path.join(dir, 'meta.json'), JSON.stringify(info, null, 2), 'utf8');
    return info;
  }
  async function pruneAutoBackups(originalPath, limit = 3) {
    limit = Math.max(1, Math.min(20, Number(limit) || 3));
    const target = canonicalSync(originalPath).toLowerCase(),
      all = await listBackups();
    const auto = all
      .filter(
        x =>
          canonicalSync(x.originalPath).toLowerCase() === target &&
          ['agent', 'auto'].includes(String(x.source || 'agent')) &&
          !['pre-restore', 'manual'].includes(String(x.action || ''))
      )
      .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    for (const x of auto.slice(limit)) await fsp.rm(path.join(backupRoot(), x.id), { recursive: true, force: true });
  }
  async function checkpointVersion(target, ctx = {}, action = 'write') {
    if (ctx.backupWrites === false) return null;
    const info = await createBackup(target, { sessionId: ctx.sessionId, taskId: ctx.taskId, action, source: 'auto' });
    await pruneAutoBackups(target, ctx.backupVersions || 3);
    return info;
  }
  async function listBackups() {
    await fsp.mkdir(backupRoot(), { recursive: true });
    const out = [];
    for (const id of await fsp.readdir(backupRoot())) {
      try {
        const m = JSON.parse(await fsp.readFile(path.join(backupRoot(), id, 'meta.json'), 'utf8'));
        out.push(m);
      } catch {}
    }
    return out.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  }
  async function restoreBackup(id) {
    const dir = path.join(backupRoot(), safeName(id)),
      meta = JSON.parse(await fsp.readFile(path.join(dir, 'meta.json'), 'utf8')),
      target = normalize(meta.originalPath);
    await createBackup(target, { sessionId: meta.sessionId, taskId: `restore-${id}`, action: 'pre-restore', source: 'restore' });
    if (fs.existsSync(target)) await fsp.rm(target, { recursive: true, force: true });
    if (meta.existed) await copyRecursive(path.join(dir, 'content'), target);
    return target;
  }
  async function cleanupBackups(days = 90) {
    if (Number(days) === 0) return;
    const cut = Date.now() - Math.max(1, Number(days || 90)) * 86400000;
    for (const m of await listBackups()) {
      if (String(m.source) === 'manual' || String(m.action) === 'manual') continue;
      if (new Date(m.createdAt).getTime() < cut) await fsp.rm(path.join(backupRoot(), m.id), { recursive: true, force: true });
    }
  }

  ipcMain.handle('auric:native-special-paths', () => {
    const home = app.getPath('home'),
      candidates = {
        home,
        desktop: app.getPath('desktop'),
        documents: app.getPath('documents'),
        downloads: app.getPath('downloads'),
        pictures: app.getPath('pictures'),
        videos: app.getPath('videos'),
        music: app.getPath('music')
      };
    for (const [k, v] of Object.entries(process.env)) if (/^OneDrive/i.test(k) && v && fs.existsSync(v)) candidates[k] = v;
    return candidates;
  });
  ipcMain.handle('auric:native-find-path', async (_e, name, opts = {}) => {
    const q = String(name || '')
      .trim()
      .toLowerCase();
    if (!q) return [];
    const roots = [
      app.getPath('desktop'),
      app.getPath('documents'),
      app.getPath('downloads'),
      ...Object.entries(process.env)
        .filter(([k, v]) => /^OneDrive/i.test(k) && v && fs.existsSync(v))
        .map(([, v]) => v)
    ];
    const hits = [];
    const maxDepth = Math.min(4, Math.max(1, Number(opts.depth || 3)));
    async function walk(dir, d) {
      if (d < 0 || hits.length >= 40) return;
      let es = [];
      try {
        es = await fsp.readdir(dir, { withFileTypes: true });
      } catch {
        return;
      }
      for (const e of es) {
        if (hits.length >= 40) break;
        const p = path.join(dir, e.name),
          n = e.name.toLowerCase();
        if (n === q || n.includes(q))
          hits.push({
            path: p,
            name: e.name,
            type: e.isDirectory() ? 'DIRECTORY' : 'FILE',
            score: n === q ? 100 : n.startsWith(q) ? 80 : 60
          });
        if (e.isDirectory() && !['node_modules', '.git', 'AppData'].includes(e.name)) await walk(p, d - 1);
      }
    }
    for (const r of roots) await walk(r, maxDepth);
    return hits.sort((a, b) => b.score - a.score).slice(0, 30);
  });

  ipcMain.handle('auric:agent-read-file', async (_e, target, ctx = {}) => {
    assertAgent(ctx, 'read', [target]);
    return fsp.readFile(String(target), 'utf8');
  });
  ipcMain.handle('auric:agent-write-file', async (_e, target, content, ctx = {}) => {
    assertAgent(ctx, 'write', [target]);
    await checkpointVersion(target, ctx, 'write');
    const encoded = await encodeTextPreservingFormat(String(target), content);
    await atomicWriteFile(String(target), encoded);
    return true;
  });
  ipcMain.handle('auric:agent-write-base64', async (_e, target, data, ctx = {}) => {
    assertAgent(ctx, 'write', [target]);
    await checkpointVersion(target, ctx, 'write-binary');
    await atomicWriteFile(String(target), Buffer.from(String(data || ''), 'base64'));
    return true;
  });
  ipcMain.handle('auric:agent-mkdir', async (_e, target, ctx = {}) => {
    assertAgent(ctx, 'write', [target]);
    await fsp.mkdir(String(target), { recursive: true });
    return true;
  });
  ipcMain.handle('auric:agent-move', async (_e, from, to, ctx = {}) => {
    assertAgent(ctx, 'write', [from, to]);
    await checkpointVersion(from, ctx, 'move-source');
    await checkpointVersion(to, ctx, 'move-destination');
    await movePortable(String(from), String(to));
    return true;
  });
  ipcMain.handle('auric:agent-trash', async (_e, target, ctx = {}) => {
    assertAgent({ ...ctx, dangerous: true }, 'write', [target]);
    await checkpointVersion(target, ctx, 'delete');
    return trashItem(String(target), { source: 'agent', sessionId: ctx.sessionId || null, taskId: ctx.taskId || null });
  });
  ipcMain.handle('auric:agent-copy', async (_e, from, to, ctx = {}) => {
    assertAgent(ctx, 'read', [from]);
    assertAgent(ctx, 'write', [to]);
    await checkpointVersion(to, ctx, 'copy-destination');
    await copyRecursive(String(from), String(to));
    return true;
  });
  ipcMain.handle('auric:agent-exec', async (_e, command, options = {}, ctx = {}) => {
    const cwd = executionCwd(options.cwd, ctx);
    assertAgent({ ...ctx, dangerous: true }, 'exec', [cwd]);
    assertCommandWithinScope(command, ctx);
    return runShellCommand(String(command || ''), { cwd, timeout: Math.max(1000, Number(options.timeout || 180000)) });
  });
  // git_status / git_diff de siempre: ahora los ejecuta el mismo módulo seguro de Git (ruta completa de git.exe, sin programas del repositorio).
  const gitLegacy = async (cwd, which, ctx = {}) => {
    assertAgent(ctx, 'read', [cwd]);
    return require('./git-tools').getManager().legacyRead(cwd, which);
  };
  ipcMain.handle('auric:agent-git-status', async (_e, cwd, ctx = {}) => gitLegacy(cwd, 'status', ctx));
  ipcMain.handle('auric:agent-git-diff', async (_e, cwd, ctx = {}) => gitLegacy(cwd, 'diff', ctx));
  ipcMain.handle('auric:sqlite-query', async (_e, target, sql, params = [], ctx = {}) => {
    const dbPath = String(target || ''),
      statement = String(sql || '').trim();
    if (!dbPath || !statement) throw new Error('SQLite requiere ruta y SQL.');
    const readOnly =
      /^(?:select|pragma|explain|with\b[\s\S]*?select\b)/i.test(statement) &&
      !/(?:insert|update|delete|replace|create|drop|alter|vacuum|reindex|attach|detach)\b/i.test(statement);
    assertAgent(ctx, readOnly ? 'read' : 'write', [dbPath]);
    if (!readOnly) await checkpointVersion(dbPath, ctx, 'sqlite-write');
    let DatabaseSync;
    try {
      ({ DatabaseSync } = require('node:sqlite'));
    } catch {
      throw new Error('Este runtime de Electron no incluye node:sqlite. Usa la CLI sqlite3 mediante run_command como alternativa.');
    }
    await fsp.mkdir(path.dirname(dbPath), { recursive: true });
    const db = new DatabaseSync(dbPath);
    try {
      const prepared = db.prepare(statement),
        values = Array.isArray(params) ? params : [];
      if (readOnly) {
        const rows = prepared.all(...values);
        return { readOnly: true, rows: rows.slice(0, 1000), count: rows.length };
      }
      const result = prepared.run(...values);
      return {
        readOnly: false,
        changes: Number(result.changes || 0),
        lastInsertRowid: result.lastInsertRowid != null ? String(result.lastInsertRowid) : null
      };
    } finally {
      try {
        db.close();
      } catch {}
    }
  });

  ipcMain.handle('auric:trash-list', async () => listTrash());
  ipcMain.handle('auric:trash-restore', async (_e, id) => {
    const dir = path.join(trashRoot(), safeName(id)),
      meta = JSON.parse(await fsp.readFile(path.join(dir, 'meta.json'), 'utf8')),
      src = path.join(dir, 'content');
    let dest = meta.originalPath;
    if (fs.existsSync(dest)) {
      const ext = path.extname(dest),
        base = dest.slice(0, -ext.length);
      dest = `${base} (restaurado)${ext}`;
    }
    await movePortable(src, dest);
    await fsp.rm(dir, { recursive: true, force: true });
    return dest;
  });
  ipcMain.handle('auric:trash-delete', async (_e, id) => {
    await fsp.rm(path.join(trashRoot(), safeName(id)), { recursive: true, force: true });
    return true;
  });
  ipcMain.handle('auric:trash-empty', async () => {
    await fsp.rm(trashRoot(), { recursive: true, force: true });
    await fsp.mkdir(trashRoot(), { recursive: true });
    return true;
  });
  ipcMain.handle('auric:trash-cleanup', async (_e, days) => {
    await cleanupTrash(days);
    return true;
  });

  ipcMain.handle('auric:backup-list', async () => listBackups());
  ipcMain.handle('auric:backup-create', async (_e, target, meta = {}) => createBackup(String(target), { ...meta, source: 'manual' }));
  ipcMain.handle('auric:backup-restore', async (_e, id) => restoreBackup(String(id)));
  ipcMain.handle('auric:backup-delete', async (_e, id) => {
    await fsp.rm(path.join(backupRoot(), safeName(id)), { recursive: true, force: true });
    return true;
  });
  ipcMain.handle('auric:backup-cleanup', async (_e, days) => {
    await cleanupBackups(days);
    return true;
  });

  ipcMain.handle('auric:process-start', async (_e, command, options = {}, ctx = {}) => {
    const cwd = executionCwd(options.cwd, ctx);
    assertAgent({ ...ctx, dangerous: true }, 'exec', [cwd]);
    assertCommandWithinScope(command, ctx);
    const id = randomUUID(),
      useShell = options.shell !== false,
      env = { ...process.env, ...(options.env && typeof options.env === 'object' ? options.env : {}), GIT_TERMINAL_PROMPT: '0', GCM_INTERACTIVE: '0', GCM_GUI_PROMPT: '0' },
      backgroundMode = String(options.backgroundMode || 'background'),
      label = String(options.label || '').trim();
    const proc = useShell
      ? spawn(
          process.platform === 'win32' ? 'cmd.exe' : '/bin/sh',
          process.platform === 'win32' ? ['/D', '/S', '/C', String(command)] : ['-lc', String(command)],
          { cwd, windowsHide: true, env, detached: process.platform !== 'win32', stdio: ['pipe', 'pipe', 'pipe'] }
        )
      : spawn(String(command), Array.isArray(options.args) ? options.args.map(x => String(x)) : [], {
          cwd,
          windowsHide: true,
          detached: process.platform !== 'win32',
          env,
          stdio: ['pipe', 'pipe', 'pipe']
        });
    const info = {
      id,
      label,
      backgroundMode,
      command: String(command),
      args: Array.isArray(options.args) ? options.args.map(x => String(x)) : [],
      cwd,
      pid: proc.pid,
      startedAt: new Date().toISOString(),
      status: 'running',
      out: '',
      err: '',
      lastOutAt: '',
      lastErrAt: ''
    };
    processes.set(id, { proc, info });
    proc.stdout?.on('data', d => {
      info.out = (info.out + d.toString()).slice(-120000);
      info.lastOutAt = new Date().toISOString();
    });
    proc.stderr?.on('data', d => {
      info.err = (info.err + d.toString()).slice(-80000);
      info.lastErrAt = new Date().toISOString();
    });
    proc.on('close', code => {
      info.status = info.status === 'stopped' ? 'stopped' : 'exited';
      info.exitCode = code;
      info.closedAt = new Date().toISOString();
    });
    proc.on('error', err => {
      info.status = 'error';
      info.err = (info.err + '\n' + String(err?.message || err || '')).trim().slice(-80000);
      info.closedAt = new Date().toISOString();
    });
    return { ...info };
  });
  ipcMain.handle('auric:process-list', () => [...processes.values()].map(x => ({ ...x.info })));
  ipcMain.handle('auric:process-output', async (_e, id, lines = 80) => {
    const x = processes.get(String(id));
    if (!x) return null;
    return { ...x.info, out: tailLines(x.info.out, lines), err: tailLines(x.info.err, Math.max(20, Math.ceil(Number(lines || 80) / 2))) };
  });
  ipcMain.handle('auric:process-input', async (_e, id, input, options = {}) => {
    const x = processes.get(String(id));
    if (!x || !x.proc?.stdin) return false;
    const text = String(input ?? '') + (options && options.newline === false ? '' : '\n');
    x.proc.stdin.write(text);
    return true;
  });
  ipcMain.handle('auric:process-stop', async (_e, id) => {
    const x = processes.get(id);
    if (!x) return false;
    killTree(x.proc);
    x.info.status = 'stopped';
    x.info.closedAt = new Date().toISOString();
    return true;
  });
  ipcMain.handle('auric:godot-detect', async (_e, workspace = '') => {
    const roots = [String(workspace || ''), app.getPath('desktop'), app.getPath('downloads'), app.getPath('documents')].filter(Boolean);
    const executables = await discoverGodotExecutables(roots);
    return executables.map(p => ({ path: p, name: path.basename(p) }));
  });
  ipcMain.handle('auric:godot-start', async (_e, spec = {}, ctx = {}) => {
    const cwd = executionCwd(spec.root || spec.cwd, ctx);
    // Con perfil de datos aislado el arranque es seguro; sin aislar toca el progreso real y exige aprobación.
    assertAgent({ ...ctx, dangerous: spec.isolateUserData === false }, 'exec', [cwd]);
    const roots = [cwd, app.getPath('desktop'), app.getPath('downloads'), app.getPath('documents')],
      found = spec.executable ? String(spec.executable) : (await discoverGodotExecutables(roots))[0];
    if (!found) throw new Error('No se encontró Godot. Añádelo al PATH o indica el ejecutable.');
    const mode = String(spec.mode || 'game'),
      args = ['--path', cwd];
    if (mode === 'headless') {
      args.unshift('--headless');
      if (spec.quit !== false && !spec.script) args.push('--quit');
    }
    if (spec.script) {
      const rawScript = String(spec.script),
        scriptPath = path.isAbsolute(rawScript) ? rawScript : path.join(cwd, rawScript);
      if (!inside(scriptPath, [cwd])) throw new Error('El script de prueba de Godot debe estar dentro del workspace.');
      args.push('--script', scriptPath);
    } else if (spec.scene) args.push(String(spec.scene));
    if (mode !== 'headless') {
      const w = Math.max(320, Number(spec.width) || 960),
        h = Math.max(240, Number(spec.height) || 540);
      args.push('--windowed', '--resolution', `${w}x${h}`);
      if (spec.backgroundWindow !== false) args.push('--position', '20000,20000');
    }
    const id = randomUUID(),
      profileRoot = path.join(app.getPath('userData'), 'test-profiles', id),
      roaming = path.join(profileRoot, 'AppData', 'Roaming'),
      local = path.join(profileRoot, 'AppData', 'Local');
    const env = { ...process.env };
    if (spec.isolateUserData !== false) {
      await fsp.mkdir(roaming, { recursive: true });
      await fsp.mkdir(local, { recursive: true });
      env.APPDATA = roaming;
      env.LOCALAPPDATA = local;
      env.AURIC_TEST_PROFILE = profileRoot;
    }
    const proc = spawn(found, args, {
      cwd,
      windowsHide: mode === 'headless',
      detached: process.platform !== 'win32',
      env,
      stdio: ['pipe', 'pipe', 'pipe']
    });
    const info = {
      id,
      label: String(spec.label || `Godot ${mode}`),
      kind: 'godot',
      mode,
      command: found,
      args,
      cwd,
      pid: proc.pid,
      startedAt: new Date().toISOString(),
      status: 'running',
      out: '',
      err: '',
      profileRoot: spec.isolateUserData === false ? '' : profileRoot,
      isolateUserData: spec.isolateUserData !== false
    };
    processes.set(id, { proc, info });
    proc.stdout?.on('data', d => {
      info.out = (info.out + d.toString()).slice(-160000);
      info.lastOutAt = new Date().toISOString();
    });
    proc.stderr?.on('data', d => {
      info.err = (info.err + d.toString()).slice(-100000);
      info.lastErrAt = new Date().toISOString();
    });
    proc.on('close', code => {
      info.status = info.status === 'stopped' ? 'stopped' : 'exited';
      info.exitCode = code;
      info.closedAt = new Date().toISOString();
    });
    proc.on('error', err => {
      info.status = 'error';
      info.err = (info.err + '\n' + String(err?.message || err || '')).trim().slice(-100000);
    });
    return { ...info };
  });

  const godotSessions = new GodotSessionManager({ userDataDir: app.getPath('userData'), processes, killTree });
  godotSessions.pruneOld().catch(() => {});
  ipcMain.handle('auric:godot-session-start', async (_e, spec = {}, ctx = {}) => {
    const cwd = executionCwd(spec.root || spec.cwd, ctx);
    // Con perfil de datos aislado el arranque es seguro; sin aislar toca el progreso real y exige aprobación.
    assertAgent({ ...ctx, dangerous: spec.isolateUserData === false }, 'exec', [cwd]);
    const roots = [cwd, app.getPath('desktop'), app.getPath('downloads'), app.getPath('documents')],
      executable = spec.executable ? String(spec.executable) : (await discoverGodotExecutables(roots))[0];
    if (!executable) throw new Error('No se encontró Godot. Añádelo al PATH o indica el ejecutable.');
    let scene = '';
    if (spec.scene) {
      const raw = String(spec.scene).replace(/\\/g, '/');
      if (!raw.startsWith('res://') && (path.isAbsolute(raw) || raw.split('/').includes('..'))) {
        throw new Error('La escena debe ser res://… o una ruta relativa al proyecto.');
      }
      scene = raw.startsWith('res://') ? raw : 'res://' + raw.replace(/^\.?\//, '');
    }
    const started = await godotSessions.start({
      cwd,
      executable,
      scene,
      width: spec.width,
      height: spec.height,
      headless: spec.headless === true,
      background: spec.backgroundWindow !== false,
      mute: spec.mute === true,
      isolateUserData: spec.isolateUserData !== false,
      liveMs: spec.liveMs,
      label: spec.label
    });
    const { proc, ...rest } = started;
    return rest;
  });
  const GODOT_CMDS = new Set([
    'info',
    'wait',
    'key',
    'type',
    'action',
    'mouse',
    'screenshot',
    'tree',
    'get',
    'set',
    'call',
    'eval',
    'scene',
    'time_scale',
    'pause',
    'mute',
    'log',
    'quit'
  ]);
  ipcMain.handle('auric:godot-session-command', async (_e, id, cmd = {}) => {
    if (!GODOT_CMDS.has(String(cmd.cmd))) throw new Error('Comando de Godot no permitido: ' + String(cmd.cmd));
    return godotSessions.command(String(id), cmd);
  });
  ipcMain.handle('auric:godot-session-frame', async (_e, id, since) => godotSessions.frame(String(id), Number(since) || 0));
  ipcMain.handle('auric:godot-session-stop', async (_e, id) => godotSessions.stop(String(id)));

  // Devuelve { spec, internal }. Un servidor de plugin llega solo como referencia {plugin, server}: el comando, los argumentos y el
  // entorno los pone el gestor de plugins (tras recomprobar que sus archivos no cambiaron), NUNCA lo que mande el renderizador.
  const authorizeMcpSpec = async (spec = {}, ctx = {}) => {
    if (spec && typeof spec === 'object' && spec.pluginRef) {
      const mgr = require('./plugins').getManager();
      if (!mgr) throw new Error('Los plugins no están disponibles.');
      if (ctx?.sessionId || ctx?.permission) assertAgent({ ...ctx, dangerous: true }, 'exec', []);
      const real = await mgr.resolveMcp({ plugin: String(spec.pluginRef.plugin || ''), server: String(spec.pluginRef.server || '') }, ctx);
      return { spec: { id: real.id, command: real.command, args: real.args, cwd: real.cwd, env: {} }, internal: { env: real.env, verbatim: real.verbatim === true } };
    }
    // Un servidor propio nunca puede pedir el modo «aislado» ni usar un id reservado de plugin.
    const plain = { id: spec?.id, command: spec?.command, args: spec?.args, cwd: spec?.cwd, env: spec?.env };
    if (/\//.test(String(plain.id || ''))) throw new Error('El identificador de un servidor MCP propio no puede llevar «/» (se reserva para los plugins).');
    if (!(ctx?.sessionId || ctx?.permission)) return { spec: plain, internal: null };
    const roots = Array.isArray(ctx.roots) ? ctx.roots : [],
      fallback = String(roots[0]?.path || roots[0] || '').trim();
    const cwd = String(plain.cwd || fallback).trim();
    if (!cwd && ctx.permission !== 'full') throw new Error('MCP requiere una carpeta autorizada como cwd.');
    const next = { ...plain, ...(cwd ? { cwd } : {}) };
    assertAgent({ ...ctx, dangerous: true }, 'exec', cwd ? [cwd] : []);
    assertCommandWithinScope([next.command, ...(Array.isArray(next.args) ? next.args : [])].join(' '), ctx);
    return { spec: next, internal: null };
  };
  ipcMain.handle('auric:mcp-list-tools', async (_e, spec, ctx = {}) => {
    const a = await authorizeMcpSpec(spec, ctx);
    return mcpListTools(a.spec, a.internal);
  });
  ipcMain.handle('auric:mcp-call-tool', async (_e, spec, name, args, ctx = {}) => {
    const a = await authorizeMcpSpec(spec, ctx);
    return mcpCallTool(a.spec, name, args, a.internal);
  });
  ipcMain.handle('auric:mcp-stop', async (_e, id) => stopMcp(id));
  ipcMain.handle('auric:skills-scan', async (_e, roots = []) => {
    const globalDir = globalSkillsRoot(),
      systemDir = officialSkillsRoot(),
      logosDir = path.join(__dirname, 'resources', 'skill-logos'),
      localDirs = (Array.isArray(roots) ? roots : []).map(r => path.join(String(r), '.auric', 'skills')),
      errors = [],
      system = await scanSkillsDirectory(systemDir, 'system', { logosDir, errors }),
      globalSkills = await scanSkillsDirectory(globalDir, 'global', { errors }),
      localSkills = [];
    for (const dir of localDirs) localSkills.push(...(await scanSkillsDirectory(dir, 'workspace', { errors })));
    const merged = mergeSkillScopes(system, globalSkills, localSkills);
    // Skills de plugins instalados: ids «plugin/skill», nunca pisan a las del sistema, globales o del proyecto.
    try {
      const pm = require('./plugins').getManager();
      if (pm) {
        const fromPlugins = await pm.skillsForScan();
        errors.push(...fromPlugins.errors);
        merged.push(...fromPlugins.skills);
        merged.sort((a, b) => String(a.name).localeCompare(String(b.name)));
      }
    } catch (e) {
      errors.push({ folder: 'plugins', error: String(e?.message || e) });
    }
    return { globalDir, systemDir, localDirs, skills: merged, errors };
  });
  ipcMain.handle('auric:skills-migrate', async () => migrateLegacyOfficialSkills(officialSkillsRoot(), globalSkillsRoot()));
  ipcMain.handle('auric:skills-save', async (_e, spec = {}) => {
    const id = safeName(String(spec.id || spec.name || '').trim());
    if (!id) throw new Error('La skill necesita un nombre.');
    let base = globalSkillsRoot();
    if (spec.scope === 'workspace') {
      if (!spec.workspaceRoot) throw new Error('Falta la carpeta del proyecto.');
      base = path.join(String(spec.workspaceRoot), '.auric', 'skills');
    }
    const dir = path.join(base, id);
    if (path.relative(base, dir).startsWith('..')) throw new Error('Ruta de skill no válida.');
    await fsp.mkdir(dir, { recursive: true });
    await fsp.writeFile(path.join(dir, 'SKILL.md'), serializeSkill({ ...spec, id }), 'utf8');
    return { id, path: path.join(dir, 'SKILL.md'), folder: dir };
  });
  ipcMain.handle('auric:skills-delete', async (_e, folder) => {
    const target = path.resolve(String(folder || ''));
    const allowed = [path.resolve(globalSkillsRoot())];
    const insideGlobal = allowed.some(a => path.relative(a, target) && !path.relative(a, target).startsWith('..'));
    const isWorkspaceSkill = /[\\/]\.auric[\\/]skills[\\/][^\\/]+$/.test(target);
    if (!insideGlobal && !isWorkspaceSkill) throw new Error('Solo se pueden eliminar skills propias o del proyecto.');
    if (!fs.existsSync(path.join(target, 'SKILL.md'))) throw new Error('No es una carpeta de skill.');
    // A la Papelera de Auric (recuperable), no borrado definitivo.
    const trash = path.join(trashRoot(), 'skills', `${path.basename(target)}-${Date.now()}`);
    await fsp.mkdir(path.dirname(trash), { recursive: true });
    await fsp.rename(target, trash).catch(async () => {
      await fsp.cp(target, trash, { recursive: true });
      await fsp.rm(target, { recursive: true, force: true });
    });
    return { ok: true, trash };
  });
  ipcMain.handle('auric:skills-reveal', async (_e, folder) => {
    const target = path.resolve(String(folder || ''));
    const known = [globalSkillsRoot(), officialSkillsRoot()].map(x => path.resolve(x));
    if (!known.some(k => target === k || !path.relative(k, target).startsWith('..')) && !/[\\/]\.auric[\\/]skills/.test(target))
      throw new Error('Ruta no permitida.');
    require('electron').shell.showItemInFolder(fs.existsSync(path.join(target, 'SKILL.md')) ? path.join(target, 'SKILL.md') : target);
    return true;
  });
  ipcMain.handle('auric:plugins-scan', async (_e, roots = []) => {
    const globalDir = globalPluginsRoot(),
      localDirs = (Array.isArray(roots) ? roots : []).map(r => path.join(String(r), '.auric', 'plugins')),
      globalPlugins = await scanPluginsDirectory(globalDir, 'global'),
      localPlugins = [];
    for (const dir of localDirs) localPlugins.push(...(await scanPluginsDirectory(dir, 'workspace')));
    return { globalDir, localDirs, plugins: [...globalPlugins, ...localPlugins] };
  });
  ipcMain.handle('auric:plugins-install-manifest', async (_e, source) => installPluginManifest(String(source), globalPluginsRoot()));
  ipcMain.handle('auric:index-build', async (_e, spec) => buildProjectIndex(spec));
  ipcMain.handle('auric:index-search', async (_e, id, query, limit) => searchProjectIndex(id, query, limit));

  ipcMain.handle('auric:speak', async (_e, text, opts = {}) => {
    if (process.platform !== 'win32') return false;
    const safe = String(text || '')
      .slice(0, 12000)
      .replace(/'/g, "''");
    const rate = Math.max(-5, Math.min(5, Number(opts.rate || 0)));
    const script = `Add-Type -AssemblyName System.Speech;$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;$s.Rate=${rate};$s.Speak('${safe}');$s.Dispose()`;
    return new Promise((resolve, reject) => {
      const p = spawn('powershell.exe', ['-NoProfile', '-Sta', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true });
      p.on('error', reject);
      p.on('close', c => (c ? reject(new Error('No se pudo reproducir la voz.')) : resolve(true)));
    });
  });

  // ── Documentos (Word, Excel, PowerPoint, PDF) ─────────────────────────────────────────────────────────────────────────
  // Crear: siempre verifica releyendo el archivo y NUNCA pisa uno existente (agrega « (2)») salvo opts.replace, que el
  // renderizador solo envía tras pedir permiso. Leer/previsualizar: lectores propios, sin ejecutar nada del documento.
  const docsDeps = () => {
    let region = '';
    try {
      region = app.getLocaleCountryCode?.() || '';
    } catch {}
    let lang = 'es-ES';
    try {
      lang = (app.getLocale?.() || 'es-ES').replace('_', '-');
    } catch {}
    return { BrowserWindow, tmpDir: path.join(app.getPath('temp'), 'auric-docs'), pageSize: docs.pageSizeForRegion(region), lang: /^es/i.test(lang) ? lang : 'es-ES' };
  };
  ipcMain.handle('auric:document-generate', async (_e, type, target, spec = {}, ctx = {}, opts = {}) => {
    target = String(target || '');
    if (!target) throw new Error('Falta la ruta del documento.');
    assertAgent(ctx, 'write', [target]);
    const replace = !!(opts && opts.replace);
    if (replace) await checkpointVersion(target, ctx, 'document-generate');
    return docs.generateDocument({ format: type, target, args: spec && typeof spec === 'object' ? spec : {}, deps: docsDeps(), mode: replace ? 'replace' : 'new' });
  });
  ipcMain.handle('auric:document-probe', async (_e, target, ctx = {}) => {
    assertAgent(ctx, 'read', [target]);
    try {
      const st = await fsp.stat(String(target));
      return { exists: true, isFile: st.isFile(), size: st.size, mtime: st.mtimeMs };
    } catch (e) {
      if (e.code === 'ENOENT' || e.code === 'ENOTDIR') return { exists: false };
      throw e;
    }
  });
  ipcMain.handle('auric:document-read', async (_e, target, opts = {}, ctx = {}) => {
    assertAgent(ctx, 'read', [target]);
    return docs.readDocument(String(target), opts && typeof opts === 'object' ? opts : {});
  });
  // Lectura iniciada por la persona (adjuntos, panel de vista previa): igual de confiable que fs.readFile.
  ipcMain.handle('auric:document-read-user', async (_e, target, opts = {}) => docs.readDocument(String(target), opts && typeof opts === 'object' ? opts : {}));
  ipcMain.handle('auric:document-preview', async (_e, target) => docs.previewDocument(String(target)));

  ipcMain.handle('auric:lsp-diagnostics', async (_e, target, root, ctx = {}) => {
    assertAgent(ctx, 'read', [target]);
    return getLspDiagnostics(String(target), String(root || path.dirname(String(target))));
  });

  ipcMain.handle('auric:preview-capture', async (_e, url) => {
    const win = new BrowserWindow({
      show: false,
      width: 1280,
      height: 800,
      webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false }
    });
    await win.loadURL(String(url));
    await new Promise(r => setTimeout(r, 1200));
    const img = await win.webContents.capturePage();
    win.destroy();
    return img.toPNG().toString('base64');
  });

  ipcMain.handle('auric:generated-save', async (_e, name, data) => {
    const dir = path.join(app.getPath('userData'), 'generated');
    await fsp.mkdir(dir, { recursive: true });
    const base = safeName(name || `generated-${Date.now()}.bin`),
      ext = path.extname(base),
      stem = ext ? base.slice(0, -ext.length) : base;
    let target = path.join(dir, base),
      n = 2;
    while (fs.existsSync(target)) target = path.join(dir, `${stem}-${n++}${ext}`);
    await fsp.writeFile(target, Buffer.from(String(data || ''), 'base64'));
    return { path: target, name: path.basename(target), size: (await fsp.stat(target)).size };
  });

  app.on('before-quit', () => {
    godotSessions.stopAll();
    for (const { proc } of processes.values()) killTree(proc);
    for (const id of [...mcpClients.keys()]) stopMcp(id);
  });
}
module.exports = {
  register,
  stopMcpPrefix,
  _test: {
    mcpClient,
    stopMcp,
    mcpListTools,
    mcpCallTool,
    mcpClients,
    normalize,
    canonicalSync,
    inside,
    assertAgent,
    cmdMayEscape,
    assertCommandWithinScope,
    executionCwd,
    parseSkillFrontmatter,
    tailLines,
    scanSkillsDirectory,
    runShellCommand,
    killTree,
    mergeSkillScopes,
    migrateLegacyOfficialSkills,
    serializeSkill,
    scanPluginsDirectory
  }
};
