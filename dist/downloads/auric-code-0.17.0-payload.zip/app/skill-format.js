'use strict';
// Formato de las skills (SKILL.md con una cabecera «---» al principio). Lo comparten el escáner de skills de la app y los plugins.
// Entiende el formato de Auric (id, name, description, triggers, markers, tags…) y también el formato abierto de «Agent Skills»
// (name + description, a veces en varias líneas con `>` o `|`). Los campos que no conoce se ignoran: no conceden nada.

const unquote = s => String(s ?? '').trim().replace(/^['"]|['"]$/g, '');

// Cabecera sencilla (YAML mínimo): «clave: valor», listas «[a, b]» o con guiones, y bloques de texto «>» / «|».
function parseFrontmatterBlock(block = '') {
  const meta = {};
  const lines = String(block).split(/\r?\n/);
  let current = '';
  for (let i = 0; i < lines.length; i++) {
    const row = lines[i].replace(/\t/g, '    ');
    const head = row.match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
    if (head) {
      current = head[1].trim();
      const value = (head[2] || '').trim();
      if (!value) {
        meta[current] = [];
        continue;
      }
      // Bloque de texto en varias líneas: «>» une con espacios, «|» conserva los saltos. Termina en la primera línea sin sangría.
      const block = /^([>|])[+-]?$/.exec(value);
      if (block) {
        const body = [];
        while (i + 1 < lines.length && (/^\s+\S/.test(lines[i + 1]) || /^\s*$/.test(lines[i + 1]))) body.push(lines[++i].replace(/^\s+/, ''));
        while (body.length && !body[body.length - 1].trim()) body.pop();
        meta[current] = block[1] === '>' ? body.join(' ').replace(/\s+/g, ' ').trim() : body.join('\n').trim();
        continue;
      }
      if (value.startsWith('[') && value.endsWith(']')) {
        meta[current] = value
          .slice(1, -1)
          .split(',')
          .map(x => unquote(x))
          .filter(Boolean);
        continue;
      }
      meta[current] = unquote(value);
      continue;
    }
    const item = row.match(/^\s*-\s*(.+)$/);
    if (item && current) {
      if (!Array.isArray(meta[current])) meta[current] = meta[current] ? [meta[current]] : [];
      meta[current].push(unquote(item[1]));
    }
  }
  return meta;
}

function parseSkillFrontmatter(raw = '') {
  const text = String(raw || '').replace(/^﻿/, '');
  let body = text,
    meta = {};
  const m = text.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);
  if (m) {
    body = m[2] || '';
    meta = parseFrontmatterBlock(m[1] || '');
  }
  const arr = v =>
    Array.isArray(v)
      ? v
      : String(v || '')
          .split(',')
          .map(x => x.trim())
          .filter(Boolean);
  return {
    // `hasId`: la skill trae un «id» (o «name») propio. Si no, quien la lea decide el id (p. ej. por el nombre de su carpeta).
    hasId: Boolean(String(meta.id || meta.name || '').trim()),
    id: String(meta.id || meta.name || 'skill').trim(),
    name: String(meta.name || meta.id || 'Skill').trim(),
    description: String(meta.description || meta.summary || '').trim(),
    icon: String(meta.icon || '').trim(),
    logo: String(meta.logo || '').trim(),
    color: String(meta.color || '').trim(),
    triggers: arr(meta.triggers),
    markers: arr(meta.markers),
    tags: arr(meta.tags),
    procedure: String(body || '').trim(),
    // Campos de otros formatos que Auric no usa (se enseñan en la revisión de un plugin para que se sepa que no valen).
    ignoredFields: Object.keys(meta).filter(
      k => !['id', 'name', 'description', 'summary', 'icon', 'logo', 'color', 'triggers', 'markers', 'tags'].includes(k)
    )
  };
}

module.exports = { parseSkillFrontmatter, parseFrontmatterBlock };
