'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const git = require('./git-tools');
const core = require('./git-core');
const { assertAgent } = require('./auric-native')._test;
class TaskWorktrees {
  constructor({ dir, env = process.env }) {
    this.dir = path.resolve(dir); this.env = env; this.rows = [];
    try { this.rows = JSON.parse(fs.readFileSync(path.join(this.dir, 'worktrees.json'), 'utf8')); } catch {}
    if (!Array.isArray(this.rows)) this.rows = [];
  }
  save() { fs.mkdirSync(this.dir, { recursive: true }); fs.writeFileSync(path.join(this.dir, 'worktrees.json'), JSON.stringify(this.rows)); }
  authorized(row, ctx) {
    const roots = ctx?.roots || [];
    if (!roots.some(r => git.isInside(row.origin, r.path || r) || git.isInside(row.path, r.path || r))) throw new Error('Esta copia no pertenece a las carpetas autorizadas.');
    if (ctx.permission === 'chat') throw new Error('El modo Chat no permite acceder a copias locales.');
  }
  find(id, ctx) {
    if (!/^[a-f0-9-]{36}$/.test(String(id || ''))) throw new Error('El identificador de la copia no es válido.');
    const row = this.rows.find(r => r.id === id && git.isInside(r.path, path.join(this.dir, 'trees')) && path.basename(r.path) === id);
    if (!row) throw new Error('La copia no existe en el registro de Auric.');
    this.authorized(row, ctx); return row;
  }
  async handle(root, ctx) {
    assertAgent(ctx, 'read', [root]);
    const executable = await git.resolveGit({ avoidDirs: [root], env: this.env });
    const manager = new git.GitManager({ env: this.env });
    const found = await manager.discover(executable, root);
    if (!found) throw new Error('Esta carpeta todavía no es un repositorio Git. Guarda un primer commit antes de crear una copia por tarea.');
    assertAgent(ctx, 'read', [found.toplevel]);
    return { executable, handle: manager.openHandle({ gitPath: executable.path, cwd: root, ...found }) };
  }
  async safeRun(handle, args, options = {}) {
    const cfg = await handle.loadConfig();
    const redirect = cfg.findings.find(f => f.key === 'core.worktree' && f.level === 'danger');
    if (redirect) throw new Error('La configuración de este repositorio redirige su carpeta de trabajo. Revísala antes de crear copias.');
    const hooks = path.join(this.dir, 'empty-hooks'); fs.mkdirSync(hooks, { recursive: true });
    if (cfg.findings.some(f => f.filter && !/^[A-Za-z0-9_.-]{1,80}$/.test(f.filter))) throw new Error('El repositorio contiene un filtro con nombre no válido.');
    return handle.must(['-c', 'core.hooksPath=' + hooks, '-c', 'filter.lfs.clean=', '-c', 'filter.lfs.smudge=', '-c', 'filter.lfs.process=', '-c', 'filter.lfs.required=false', ...cfg.neutralize, ...args], { readOnly: true, ...options });
  }
  async run(spec = {}, ctx = {}) {
    const action = String(spec.action || 'list');
    if (action === 'list') return this.rows.filter(row => { try { this.authorized(row, ctx); return true; } catch { return false; } }).map(row => ({ ...row, exists: fs.existsSync(row.path) }));
    if (['create', 'remove'].includes(action) && ctx.approved !== true) throw new Error('Crear o eliminar una copia requiere confirmación explícita.');
    if (action === 'create') {
      const source = path.resolve(String(spec.root || ''));
      const { handle } = await this.handle(source, ctx);
      const head = (await this.safeRun(handle, ['rev-parse', '--verify', 'HEAD'])).stdout.trim();
      const id = crypto.randomUUID(), destination = path.join(this.dir, 'trees', id), branch = 'auric/task-' + id.slice(0, 12);
      if (!git.isInside(destination, this.dir)) throw new Error('La ruta de la copia no es válida.');
      fs.mkdirSync(path.dirname(destination), { recursive: true });
      await this.safeRun(handle, ['worktree', 'add', '-b', branch, '--', destination, head], { timeoutMs: 120000 });
      const row = { id, name: String(spec.name || 'Tarea').slice(0, 120), origin: handle.toplevel, path: destination, branch, base: head, createdAt: new Date().toISOString() };
      this.rows.push(row); this.save();
      return { ...row, note: 'Copia del último commit. Los cambios sin commit de la carpeta original no se copiaron. Conserva esos archivos en su carpeta original.' };
    }
    const row = this.find(spec.id, ctx);
    const roots = [...(ctx.roots || []), { path: row.path }];
    const { handle } = await this.handle(row.path, { ...ctx, roots });
    if (action === 'inspect') {
      const [status, diff, commits] = await Promise.all([
        this.safeRun(handle, ['status', '--short']),
        this.safeRun(handle, ['diff', '--no-ext-diff', '--no-textconv', '--stat', row.base, '--']),
        this.safeRun(handle, ['log', '--oneline', row.base + '..HEAD'])
      ]);
      return { ...row, status: status.stdout, diff: diff.stdout, commits: commits.stdout };
    }
    if (action === 'remove') {
      const status = (await this.safeRun(handle, ['status', '--porcelain'])).stdout;
      if (status.trim()) throw new Error('Esta copia tiene cambios sin guardar. Revísalos y guárdalos antes de eliminarla; Auric no la forzará.');
      const { handle: source } = await this.handle(row.origin, { ...ctx, roots: [...roots, { path: row.origin }] });
      await this.safeRun(source, ['worktree', 'remove', '--', row.path]);
      this.rows = this.rows.filter(r => r.id !== row.id); this.save();
      return { removed: true, branch: row.branch, note: 'Se eliminó la carpeta de la copia. Su rama y sus commits se conservan.' };
    }
    throw new Error('Acción desconocida. Usa create, list, inspect o remove.');
  }
}
function register({ app, ipcMain }) {
  const manager = new TaskWorktrees({ dir: path.join(app.getPath('userData'), 'task-worktrees') });
  ipcMain.handle('auric:task-worktrees', async (_event, spec, ctx) => { try { return { ok: true, value: await manager.run(spec, ctx) }; } catch (error) { return { ok: false, error: String(error.message), code: error.code || '' }; } });
  return manager;
}
module.exports = { TaskWorktrees, register };
