'use strict';
// ZIP seguro (lectura, extracción y escritura) sin dependencias. Sirve para plugins (.zip descargados de GitHub),
// documentos de Office (docx/xlsx/pptx son ZIP) y paquetes. Defensas: rutas con "..", rutas absolutas o con unidad,
// enlaces simbólicos, entradas cifradas, ZIP64, bombas de descompresión (límite de bytes y de ratio), CRC, nombres duplicados.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const zlib = require('zlib');

const DEFAULT_LIMITS = {
  maxEntries: 5000,
  maxEntryBytes: 64 * 1024 * 1024,
  maxTotalBytes: 256 * 1024 * 1024,
  maxRatio: 200, // descomprimido / comprimido (por entrada, cuando la entrada pesa > 1 MB)
  maxNameLength: 400
};

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  if (typeof zlib.crc32 === 'function') return zlib.crc32(buf) >>> 0;
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function zipError(message, code = 'ZIP_INVALID') {
  const e = new Error(message);
  e.code = code;
  return e;
}

// Normaliza un nombre de entrada; devuelve '' si es peligroso.
function safeEntryName(raw, maxLen = DEFAULT_LIMITS.maxNameLength) {
  let n = String(raw || '').replace(/\\/g, '/');
  if (!n || n.length > maxLen || n.includes('\0')) return '';
  if (/^[a-zA-Z]:/.test(n) || n.startsWith('/') || n.startsWith('//')) return '';
  const parts = n.split('/');
  for (const p of parts) if (p === '..') return '';
  n = parts.filter((p, i) => p !== '.' && (p !== '' || i === parts.length - 1)).join('/');
  if (/[\u0000-\u001f]/.test(n)) return '';
  // Windows: nombres con ":" (flujos alternativos de datos), nombres reservados, espacios o puntos finales
  if (/:/.test(n)) return '';
  if (parts.some(p => /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i.test(p))) return '';
  if (parts.some(p => p && /[. ]$/.test(p) && p !== '.' && p !== '..')) return '';
  // Letras invisibles o que cambian el sentido de lectura (esconden o disfrazan el nombre real al mostrarlo).
  if (/[­؜᠎​-‏‪-‮⁠-⁤⁦-⁩﻿]|[\u{e0000}-\u{e007f}]/u.test(n)) return '';
  // Windows: «nombres cortos» 8.3 (PROGRA~1): son otro nombre de una carpeta o archivo que ya existe y permitirían escribir «por la puerta de atrás».
  if (parts.some(p => /^[^~]{1,6}~\d{1,6}(\.[^.]*)?$/.test(p))) return '';
  return n;
}

function readZip(buf, userLimits = {}) {
  const limits = { ...DEFAULT_LIMITS, ...userLimits };
  if (!Buffer.isBuffer(buf)) buf = Buffer.from(buf);
  if (buf.length < 22) throw zipError('El archivo no es un ZIP válido (demasiado pequeño).');
  // Registro de fin de directorio central (EOCD): se busca desde el final (puede haber comentario).
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65535); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      const commentLen = buf.readUInt16LE(i + 20);
      if (i + 22 + commentLen === buf.length) {
        eocd = i;
        break;
      }
      if (eocd < 0) eocd = i;
    }
  }
  if (eocd < 0) throw zipError('El archivo no es un ZIP válido (no se encontró el directorio central).');
  const total = buf.readUInt16LE(eocd + 10);
  const cdSize = buf.readUInt32LE(eocd + 12);
  const cdOffset = buf.readUInt32LE(eocd + 16);
  if (total === 0xffff || cdSize === 0xffffffff || cdOffset === 0xffffffff)
    throw zipError('Los ZIP de formato ZIP64 (más de 4 GB) no están soportados.', 'ZIP_UNSUPPORTED');
  if (total > limits.maxEntries) throw zipError(`El ZIP tiene demasiados archivos (${total}; máximo ${limits.maxEntries}).`, 'ZIP_LIMIT');
  if (cdOffset + cdSize > buf.length) throw zipError('El ZIP está dañado (directorio central fuera de rango).');
  const entries = [];
  const seen = new Set();
  let p = cdOffset,
    declaredTotal = 0;
  for (let i = 0; i < total; i++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw zipError('El ZIP está dañado (entrada del directorio ilegible).');
    const flags = buf.readUInt16LE(p + 8);
    const method = buf.readUInt16LE(p + 10);
    const crc = buf.readUInt32LE(p + 16);
    const csize = buf.readUInt32LE(p + 20);
    const usize = buf.readUInt32LE(p + 24);
    const nlen = buf.readUInt16LE(p + 28);
    const elen = buf.readUInt16LE(p + 30);
    const clen = buf.readUInt16LE(p + 32);
    const ext = buf.readUInt32LE(p + 38);
    const off = buf.readUInt32LE(p + 42);
    const rawName = buf.toString(flags & 0x800 ? 'utf8' : 'latin1', p + 46, p + 46 + nlen);
    p += 46 + nlen + elen + clen;
    const mode = (ext >>> 16) & 0xffff;
    const isDir = rawName.endsWith('/') || rawName.endsWith('\\');
    const isSymlink = (mode & 0o170000) === 0o120000;
    const name = safeEntryName(rawName, limits.maxNameLength);
    declaredTotal += usize;
    const entry = {
      rawName,
      name,
      unsafe: !name,
      isDir,
      isSymlink,
      encrypted: !!(flags & 1),
      method,
      crc,
      size: usize,
      compressedSize: csize,
      offset: off,
      mode
    };
    const key = name.toLowerCase();
    if (name && seen.has(key)) entry.duplicate = true;
    if (name) seen.add(key);
    entries.push(entry);
  }
  if (declaredTotal > limits.maxTotalBytes)
    throw zipError(`El ZIP descomprimido pesaría demasiado (${Math.round(declaredTotal / 1048576)} MB).`, 'ZIP_LIMIT');

  function read(entry) {
    if (entry.unsafe) throw zipError(`Nombre de archivo peligroso en el ZIP: ${entry.rawName}`, 'ZIP_UNSAFE');
    if (entry.encrypted) throw zipError(`El archivo ${entry.name} está cifrado: no se puede leer.`, 'ZIP_UNSUPPORTED');
    if (entry.isDir) return Buffer.alloc(0);
    if (entry.size > limits.maxEntryBytes) throw zipError(`El archivo ${entry.name} es demasiado grande dentro del ZIP.`, 'ZIP_LIMIT');
    if (entry.size > 1024 * 1024 && entry.compressedSize > 0 && entry.size / entry.compressedSize > limits.maxRatio)
      throw zipError(`El archivo ${entry.name} se descomprime a un tamaño desproporcionado (posible bomba de compresión).`, 'ZIP_BOMB');
    const o = entry.offset;
    if (o + 30 > buf.length || buf.readUInt32LE(o) !== 0x04034b50) throw zipError(`El ZIP está dañado (cabecera local de ${entry.name}).`);
    const nlen = buf.readUInt16LE(o + 26),
      elen = buf.readUInt16LE(o + 28);
    const start = o + 30 + nlen + elen,
      end = start + entry.compressedSize;
    if (end > buf.length) throw zipError(`El ZIP está dañado (datos de ${entry.name} incompletos).`);
    const raw = buf.subarray(start, end);
    let data;
    if (entry.method === 0) data = Buffer.from(raw);
    else if (entry.method === 8) {
      try {
        data = zlib.inflateRawSync(raw, { maxOutputLength: Math.min(limits.maxEntryBytes, Math.max(entry.size, 1) + 1024) });
      } catch (e) {
        throw zipError(
          `No se pudo descomprimir ${entry.name}: ${e.code === 'ERR_BUFFER_TOO_LARGE' ? 'tamaño mayor al declarado' : e.message}`,
          'ZIP_BOMB'
        );
      }
    } else throw zipError(`Método de compresión no soportado en ${entry.name} (${entry.method}).`, 'ZIP_UNSUPPORTED');
    if (data.length !== entry.size) throw zipError(`El tamaño de ${entry.name} no coincide con el declarado.`);
    if (crc32(data) !== entry.crc) throw zipError(`El archivo ${entry.name} está dañado (CRC incorrecto).`);
    return data;
  }
  const byName = new Map(entries.filter(e => e.name).map(e => [e.name, e]));
  return {
    entries,
    limits,
    has: n => byName.has(n),
    find: n => byName.get(n) || null,
    read,
    readByName: n => {
      const e = byName.get(n);
      if (!e) throw zipError(`El ZIP no contiene ${n}.`, 'ZIP_MISSING');
      return read(e);
    },
    readText: n =>
      read(
        byName.get(n) ||
          (() => {
            throw zipError(`El ZIP no contiene ${n}.`, 'ZIP_MISSING');
          })()
      )
        .toString('utf8')
        .replace(/^﻿/, '')
  };
}

// Revisión previa: lista los problemas sin extraer nada.
function inspectZip(buf, userLimits = {}) {
  const zip = readZip(buf, userLimits);
  const problems = [];
  for (const e of zip.entries) {
    if (e.unsafe) problems.push({ entry: e.rawName, problem: 'ruta peligrosa (sale de la carpeta o es absoluta)' });
    else if (e.isSymlink) problems.push({ entry: e.name, problem: 'enlace simbólico' });
    else if (e.encrypted) problems.push({ entry: e.name, problem: 'archivo cifrado' });
    else if (e.duplicate) problems.push({ entry: e.name, problem: 'nombre duplicado' });
  }
  return { zip, problems };
}

// Extrae a `destDir` (debe existir o se crea). Rechaza TODO el ZIP si alguna entrada es peligrosa: no se extrae a medias.
async function extractZip(buf, destDir, userLimits = {}) {
  const { zip, problems } = inspectZip(buf, userLimits);
  if (problems.length) throw zipError(`ZIP rechazado: ${problems[0].entry} (${problems[0].problem}).`, 'ZIP_UNSAFE');
  await fsp.mkdir(destDir, { recursive: true });
  const root = await fsp.realpath(destDir);
  const written = [];
  let total = 0;
  for (const e of zip.entries) {
    const target = path.resolve(root, e.name);
    if (target !== root && !target.startsWith(root + path.sep))
      throw zipError(`ZIP rechazado: ${e.rawName} sale de la carpeta de destino.`, 'ZIP_UNSAFE');
    if (e.isDir) {
      await fsp.mkdir(target, { recursive: true });
      continue;
    }
    const data = zip.read(e);
    total += data.length;
    if (total > zip.limits.maxTotalBytes) throw zipError('El ZIP descomprimido pesa demasiado.', 'ZIP_LIMIT');
    await fsp.mkdir(path.dirname(target), { recursive: true });
    // el directorio padre real tampoco puede salir de la raíz (enlaces creados antes)
    const parentReal = await fsp.realpath(path.dirname(target));
    if (parentReal !== root && !parentReal.startsWith(root + path.sep))
      throw zipError(`ZIP rechazado: ${e.rawName} sale de la carpeta de destino.`, 'ZIP_UNSAFE');
    await fsp.writeFile(target, data, { flag: 'wx' });
    written.push(e.name);
  }
  return { files: written, totalBytes: total };
}

// ── Escritura ─────────────────────────────────────────────────────────────────────────────────
function u16(n) {
  const b = Buffer.alloc(2);
  b.writeUInt16LE(n & 0xffff);
  return b;
}
function u32(n) {
  const b = Buffer.alloc(4);
  b.writeUInt32LE(n >>> 0);
  return b;
}
// entries: [[nombre, Buffer|string], ...]  (nombres terminados en "/" = carpeta). deflate: comprime cuando compensa.
function writeZip(entries, { deflate = true, date = new Date() } = {}) {
  const locals = [],
    centrals = [];
  let offset = 0;
  const dosTime = ((date.getHours() << 11) | (date.getMinutes() << 5) | (date.getSeconds() >> 1)) & 0xffff;
  const dosDate = ((Math.max(0, date.getFullYear() - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate()) & 0xffff;
  for (const [rawName, data0] of entries) {
    const name = String(rawName).replace(/\\/g, '/');
    if (!safeEntryName(name)) throw zipError(`Nombre de entrada no permitido: ${name}`, 'ZIP_UNSAFE');
    const data = Buffer.isBuffer(data0) ? data0 : Buffer.from(String(data0 ?? ''), 'utf8');
    const nb = Buffer.from(name, 'utf8');
    const crc = crc32(data);
    let method = 0,
      body = data;
    if (deflate && data.length > 64) {
      const z = zlib.deflateRawSync(data, { level: 6 });
      if (z.length < data.length) {
        method = 8;
        body = z;
      }
    }
    const local = Buffer.concat([
      u32(0x04034b50),
      u16(20),
      u16(0x800),
      u16(method),
      u16(dosTime),
      u16(dosDate),
      u32(crc),
      u32(body.length),
      u32(data.length),
      u16(nb.length),
      u16(0),
      nb,
      body
    ]);
    locals.push(local);
    centrals.push(
      Buffer.concat([
        u32(0x02014b50),
        u16(20),
        u16(20),
        u16(0x800),
        u16(method),
        u16(dosTime),
        u16(dosDate),
        u32(crc),
        u32(body.length),
        u32(data.length),
        u16(nb.length),
        u16(0),
        u16(0),
        u16(0),
        u16(0),
        u32(name.endsWith('/') ? 0x10 : 0),
        u32(offset),
        nb
      ])
    );
    offset += local.length;
  }
  const cd = Buffer.concat(centrals);
  return Buffer.concat([
    ...locals,
    cd,
    u32(0x06054b50),
    u16(0),
    u16(0),
    u16(entries.length),
    u16(entries.length),
    u32(cd.length),
    u32(offset),
    u16(0)
  ]);
}

module.exports = { readZip, inspectZip, extractZip, writeZip, safeEntryName, crc32, DEFAULT_LIMITS };
