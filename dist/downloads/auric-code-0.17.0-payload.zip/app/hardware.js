// Detección del equipo para "Mi PC": memoria, procesador, tarjeta gráfica (con su memoria) y espacio libre en disco.
// Solo LEE información del sistema. No instala nada ni escribe archivos. Todo lo que ejecuta (nvidia-smi, PowerShell)
// es de solo lectura y se puede sustituir en las pruebas mediante `run`.
const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');
const { execFile } = require('node:child_process');

const GB = 1024 ** 3;
const round1 = n => Math.round(n * 10) / 10;

function defaultRun(file, args, { timeoutMs = 6000 } = {}) {
  return new Promise(resolve => {
    try {
      execFile(file, args, { timeout: timeoutMs, windowsHide: true, maxBuffer: 1024 * 1024 }, (err, stdout) => {
        resolve(err ? { ok: false, stdout: String(stdout || ''), error: err } : { ok: true, stdout: String(stdout || '') });
      });
    } catch (error) {
      resolve({ ok: false, stdout: '', error });
    }
  });
}

function vendorOf(name = '') {
  const n = String(name).toLowerCase();
  if (/nvidia|geforce|quadro|tesla|rtx|gtx/.test(n)) return 'nvidia';
  if (/amd|radeon|ati\b|vega/.test(n)) return 'amd';
  if (/intel|iris|uhd|arc\b/.test(n)) return 'intel';
  return 'otro';
}

// Gráficos integrados o genéricos: comparten la memoria del equipo y Ollama no los acelera.
function isIntegrated(name = '', vramGB = 0) {
  const n = String(name).toLowerCase();
  if (/microsoft basic|basic render|remote display|virtual|vmware|parallels|hyper-v|citrix/.test(n)) return true;
  if (/intel/.test(n) && !/\barc\b.*\b(a[3-9]\d{2}|b\d{3})\b/.test(n)) return true;
  if (/radeon\(tm\)\s+graphics|radeon graphics|vega \d+ graphics|radeon vega|radeon 6\d0m|radeon 780m|radeon 890m/.test(n)) return true;
  return vramGB > 0 && vramGB <= 1;
}

// "sí": Ollama la usa con normalidad · "depende": solo algunas tarjetas AMD funcionan · "no": integrada/desconocida.
function accelerationOf(vendor, integrated) {
  if (integrated) return 'no';
  if (vendor === 'nvidia') return 'sí';
  if (vendor === 'amd') return 'depende';
  if (vendor === 'intel') return 'depende';
  return 'no';
}

function parseNvidiaSmi(text) {
  const out = [];
  for (const raw of String(text || '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    const parts = line.split(',').map(x => x.trim());
    if (parts.length < 2) continue;
    const total = Number(parts[1]),
      free = Number(parts[2]);
    if (!Number.isFinite(total) || total <= 0) continue;
    out.push({
      name: parts[0],
      vendor: 'nvidia',
      vramGB: round1(total / 1024),
      freeVramGB: Number.isFinite(free) ? round1(free / 1024) : null,
      driver: parts[3] || '',
      integrated: false,
      accel: 'sí',
      source: 'nvidia-smi'
    });
  }
  return out;
}

function parseRegistryGpus(text) {
  let data;
  try {
    data = JSON.parse(String(text || '').trim() || '[]');
  } catch {
    return [];
  }
  const rows = Array.isArray(data) ? data : data && typeof data === 'object' ? [data] : [];
  const out = [];
  for (const r of rows) {
    const name = String(r?.name || r?.DriverDesc || '').trim();
    if (!name) continue;
    let bytes = Number(r?.vram ?? r?.['HardwareInformation.qwMemorySize'] ?? r?.AdapterRAM ?? 0);
    // El registro a veces guarda el valor como lista de bytes (REG_BINARY) en lugar de número.
    if (Array.isArray(r?.vram)) bytes = r.vram.reduce((acc, b, i) => acc + Number(b || 0) * 256 ** i, 0);
    if (!Number.isFinite(bytes) || bytes < 0) bytes = 0;
    const vramGB = round1(bytes / GB),
      vendor = vendorOf(name),
      integrated = isIntegrated(name, vramGB);
    out.push({
      name,
      vendor,
      vramGB,
      freeVramGB: null,
      driver: String(r?.driver || ''),
      integrated,
      accel: accelerationOf(vendor, integrated),
      source: 'windows'
    });
  }
  return out;
}

const WINDOWS_GPU_SCRIPT = [
  "$ErrorActionPreference='SilentlyContinue'",
  "$cls='HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0*'",
  '$rows=@(Get-ItemProperty $cls | Where-Object { $_.DriverDesc } | ForEach-Object { [pscustomobject]@{ name=$_.DriverDesc; vram=$_."HardwareInformation.qwMemorySize"; driver=$_.DriverVersion } })',
  'if(-not $rows -or $rows.Count -eq 0){ $rows=@(Get-CimInstance Win32_VideoController | ForEach-Object { [pscustomobject]@{ name=$_.Name; vram=$_.AdapterRAM; driver=$_.DriverVersion } }) }',
  '$rows | ConvertTo-Json -Compress -Depth 3'
].join(';');

async function detectGpus({ platform, run, env }) {
  const gpus = [];
  const smiCandidates =
    platform === 'win32'
      ? [
          'nvidia-smi',
          path.join(env.SystemRoot || 'C:\\Windows', 'System32', 'nvidia-smi.exe'),
          path.join(env.ProgramFiles || 'C:\\Program Files', 'NVIDIA Corporation', 'NVSMI', 'nvidia-smi.exe')
        ]
      : ['nvidia-smi'];
  for (const exe of smiCandidates) {
    const r = await run(exe, ['--query-gpu=name,memory.total,memory.free,driver_version', '--format=csv,noheader,nounits']);
    if (r.ok) {
      gpus.push(...parseNvidiaSmi(r.stdout));
      if (gpus.length) break;
    }
  }
  if (platform === 'win32') {
    const r = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', WINDOWS_GPU_SCRIPT], {
      timeoutMs: 10000
    });
    if (r.ok) {
      for (const g of parseRegistryGpus(r.stdout)) {
        // Si nvidia-smi ya la describió (misma tarjeta) no se duplica.
        const dup = gpus.some(x => x.vendor === g.vendor && (x.name === g.name || (x.vendor === 'nvidia' && g.vendor === 'nvidia')));
        if (!dup) gpus.push(g);
      }
    }
  }
  return gpus;
}

async function freeDiskGB(dir) {
  try {
    let probe = dir;
    while (probe && !fs.existsSync(probe)) {
      const parent = path.dirname(probe);
      if (parent === probe) break;
      probe = parent;
    }
    const st = await fs.promises.statfs(probe);
    return round1((Number(st.bavail) * Number(st.bsize)) / GB);
  } catch {
    return null;
  }
}

function ollamaModelsDir(env = process.env, home = os.homedir()) {
  return env.OLLAMA_MODELS ? String(env.OLLAMA_MODELS) : path.join(home, '.ollama', 'models');
}

// Devuelve una descripción del equipo lista para mostrar y para calcular recomendaciones.
async function detectHardware({ platform = process.platform, run = defaultRun, env = process.env, modelsDir } = {}) {
  const cpus = os.cpus() || [];
  const gpus = await detectGpus({ platform, run, env });
  const usable = gpus.filter(g => g.accel !== 'no' && g.vramGB > 0);
  const best = usable.slice().sort((a, b) => b.vramGB - a.vramGB)[0] || null;
  const notes = [];
  if (!gpus.length) notes.push('No se detectó tarjeta gráfica: los modelos usarán el procesador y la memoria RAM.');
  else if (!usable.length) notes.push('Tu tarjeta gráfica es integrada: Ollama usará el procesador y la memoria RAM.');
  if (best && best.accel === 'depende')
    notes.push('Tu tarjeta no es NVIDIA: Ollama solo la acelera en algunos modelos de tarjeta. Si no la usa, irá más lento.');
  return {
    platform,
    arch: os.arch(),
    system: `${os.type()} ${os.release()}`,
    ramGB: round1(os.totalmem() / GB),
    freeRamGB: round1(os.freemem() / GB),
    cpu: {
      model: String(cpus[0]?.model || 'Procesador desconocido')
        .replace(/\s+/g, ' ')
        .trim(),
      threads: cpus.length || 1
    },
    gpus,
    bestGpu: best,
    vramGB: best ? best.vramGB : 0,
    diskFreeGB: await freeDiskGB(modelsDir || ollamaModelsDir(env)),
    modelsDir: modelsDir || ollamaModelsDir(env),
    notes
  };
}

module.exports = {
  detectHardware,
  parseNvidiaSmi,
  parseRegistryGpus,
  vendorOf,
  isIntegrated,
  accelerationOf,
  ollamaModelsDir,
  freeDiskGB,
  defaultRun
};
