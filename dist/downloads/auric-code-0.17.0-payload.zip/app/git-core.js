'use strict';
// Git: piezas puras (sin ejecutar nada). Validación de lo que escribe la IA, lectura de lo que devuelve Git,
// detección de archivos delicados, avisos de configuración peligrosa y las reglas de cuándo se pregunta.
// Todo lo que sale de aquí es texto o datos: el que ejecuta Git es git-tools.js, y siempre con argumentos ya validados.
const nodePath = require('path');

const MAX_PATHS = 1000;
const MAX_PATH_LEN = 1024;
const MAX_MESSAGE = 20000;

function fail(code, message, extra = {}) {
  return Object.assign(new Error(message), { code }, extra);
}

// ── Validación de argumentos ─────────────────────────────────────────────────────────────────────
const NAME_CHARS = /^[\p{L}\p{N}][\p{L}\p{N}._\/+#@=,-]*$/u;
// Nombre de rama. Nunca empieza por «-» (no puede colarse como opción de Git), no usa «..», «@{», «//», etc.
function validateBranchName(raw, label = 'La rama') {
  const name = String(raw ?? '').trim();
  if (!name) throw fail('BAD_ARG', `Falta el nombre de la rama.`);
  if (name.length > 200) throw fail('BAD_ARG', `${label} tiene un nombre demasiado largo.`);
  if (!NAME_CHARS.test(name) || /\.\.|\/\/|\/\.|\.lock(\/|$)|@\{|\/$|\.$|^@$|^(HEAD|refs)(\/|$)/i.test(name))
    throw fail(
      'BAD_ARG',
      `${label} «${name.slice(0, 60)}» no es un nombre válido. Usa letras, números, guiones, puntos o barras, sin espacios.`
    );
  return name;
}

// Una revisión: rama, etiqueta, huella (hash), HEAD~2, origin/main, @{u}… Nunca empieza por «-».
const REV_CHARS = /^[\p{L}\p{N}_.\/+#=,@~^{}-]{1,200}$/u;
const REV_SPECIAL = /^(?:@|[^{}@]*)(?:@\{(?:u|upstream|push|\d{1,4})\})?(?:\^\{commit\})?$/u;
function validateRevision(raw, label = 'La revisión') {
  const rev = String(raw ?? '').trim();
  if (!rev) throw fail('BAD_ARG', `Falta ${label.toLowerCase()}.`);
  if (
    rev.startsWith('-') ||
    rev.startsWith('.') ||
    rev.startsWith('/') ||
    !REV_CHARS.test(rev) ||
    /\/\/|\.lock\b|\.\.|^\^/.test(rev) ||
    !REV_SPECIAL.test(rev)
  )
    throw fail(
      'BAD_ARG',
      `${label} «${rev.slice(0, 60)}» no es válida. Usa el nombre de una rama, una etiqueta, un código de commit o HEAD~1.`
    );
  return rev;
}
// «A..B» o «A...B» (para log y diff): cada lado se valida por separado.
function validateRange(raw) {
  const text = String(raw ?? '').trim();
  const m = /^(.*?)(\.\.\.?)(.*)$/.exec(text);
  if (!m) return validateRevision(text);
  const left = m[1] ? validateRevision(m[1]) : '',
    right = m[3] ? validateRevision(m[3]) : '';
  if (!left && !right) throw fail('BAD_ARG', 'El rango de revisiones está vacío.');
  return `${left}${m[2]}${right}`;
}

function validateRemoteName(raw) {
  const name = String(raw ?? '').trim();
  if (!name) throw fail('BAD_ARG', 'Falta el nombre del servidor remoto (por ejemplo «origin»).');
  if (!/^[A-Za-z0-9][A-Za-z0-9._\/-]{0,63}$/.test(name) || /\.\.|\/\/|\.lock$/.test(name))
    throw fail(
      'BAD_ARG',
      `«${name.slice(0, 60)}» no es un nombre de servidor remoto válido. Usa el nombre (como «origin»), nunca una dirección.`
    );
  return name;
}

function validateStashRef(raw) {
  const ref = String(raw ?? 'stash@{0}').trim() || 'stash@{0}';
  if (!/^stash@\{\d{1,3}\}$/.test(ref)) throw fail('BAD_ARG', 'La referencia de guardado temporal debe ser como stash@{0}.');
  return ref;
}

function validateMessage(raw, { required = true, label = 'El mensaje' } = {}) {
  let msg = String(raw ?? '')
    .replace(/\r\n?/g, '\n')
    .replace(/[ \t]+$/gm, '')
    .trim();
  if (!msg) {
    if (required) throw fail('BAD_ARG', `${label} no puede estar vacío.`);
    return '';
  }
  if (msg.includes('\0')) throw fail('BAD_ARG', `${label} contiene caracteres no permitidos.`);
  if (msg.length > MAX_MESSAGE) throw fail('BAD_ARG', `${label} es demasiado largo (máximo ${MAX_MESSAGE} caracteres).`);
  return msg;
}

// Quita las firmas de IA que algunos modelos añaden al final de un commit («Co-Authored-By: Claude…», «Generated with…», 🤖).
// Los commits de Auric tienen que leerse como trabajo de la persona. Los co-autores humanos se respetan.
const AI_NAME =
  /(claude|anthropic|chat-?gpt|\bgpt[-\s\d]|openai|codex|gemini|bard|copilot|cursor|aider|devin|windsurf|auric|\bllm\b|\bai\b|\bia\b|assistant|asistente|noreply@anthropic|\bbot\b|🤖)/i;
const ATTRIBUTION_LINE =
  /^\s*(?:[-*>]\s*)?(?:co-?authored-?by|generated[- ](?:by|with)|created[- ](?:by|with)|made[- ](?:by|with)|written[- ](?:by|with)|assisted[- ]by|authored[- ]by|signed-?off-?by|reviewed-?by|claude-session|generado (?:por|con)|creado (?:por|con)|hecho con|escrito (?:por|con))\b[^\n]*$/i;
function stripAiAttribution(raw) {
  const lines = String(raw ?? '')
    .replace(/\r\n?/g, '\n')
    .split('\n');
  const kept = lines.filter(line => {
    if (/🤖/.test(line)) return false;
    if (ATTRIBUTION_LINE.test(line) && AI_NAME.test(line)) return false;
    if (/^\s*https?:\/\/claude\.(?:ai|com)\/\S*\s*$/i.test(line)) return false;
    return true;
  });
  return kept
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function validateIdentity(raw) {
  const name = String(raw?.name ?? '').trim(),
    email = String(raw?.email ?? '').trim();
  if (!/^[^\n\r<>\0]{1,100}$/.test(name)) throw fail('BAD_ARG', 'Escribe tu nombre (hasta 100 letras, sin < ni >).');
  if (!/^[^\s<>@,;]{1,100}@[^\s<>@,;]{1,100}$/.test(email) || email.length > 200)
    throw fail('BAD_ARG', 'Escribe un correo válido, como nombre@sitio.com.');
  return { name, email };
}

// Rutas de archivos: siempre relativas a la raíz del repositorio, sin salirse de ella y sin tocar la carpeta .git.
function validateRelPaths(list, { repoRoot, pathLib = nodePath, caseInsensitive = pathLib === nodePath.win32 } = {}) {
  const arr = Array.isArray(list) ? list : list == null || list === '' ? [] : [list];
  if (arr.length > MAX_PATHS) throw fail('BAD_ARG', `Demasiados archivos a la vez (máximo ${MAX_PATHS}).`);
  const out = [];
  const seen = new Set();
  for (const raw of arr) {
    if (typeof raw !== 'string' || !raw.length) throw fail('BAD_ARG', 'Una de las rutas está vacía o no es texto.');
    if (raw.length > MAX_PATH_LEN) throw fail('BAD_ARG', 'Una ruta es demasiado larga.');
    if (/[\x00-\x1f]/.test(raw)) throw fail('BAD_ARG', 'Una ruta contiene caracteres de control.');
    let rel;
    const isWin = pathLib === nodePath.win32;
    const text = isWin ? raw.replace(/\\/g, '/') : raw;
    if (pathLib.isAbsolute(raw) || (isWin && /^[A-Za-z]:/.test(raw))) {
      if (!repoRoot) throw fail('BAD_ARG', 'No se puede usar una ruta absoluta aquí.');
      const r = pathLib.relative(repoRoot, raw);
      if (!r || r === '') rel = '.';
      else if (r.startsWith('..') || pathLib.isAbsolute(r))
        throw fail('OUTSIDE_REPO', `La ruta «${raw.slice(0, 120)}» está fuera del repositorio.`);
      else rel = r.split(pathLib.sep).join('/');
    } else {
      rel = nodePath.posix.normalize(text);
    }
    if (rel === '..' || rel.startsWith('../')) throw fail('OUTSIDE_REPO', `La ruta «${raw.slice(0, 120)}» está fuera del repositorio.`);
    if (rel.startsWith('/')) throw fail('OUTSIDE_REPO', `La ruta «${raw.slice(0, 120)}» no es relativa al repositorio.`);
    rel = rel.replace(/^\.\//, '').replace(/\/+$/, '') || '.';
    for (const seg of rel.split('/')) {
      if (/^\.git[. ]*$/i.test(seg) || /^git~\d+$/i.test(seg)) throw fail('BAD_ARG', 'Auric no toca la carpeta interna .git de Git.');
      if (isWin && /[<>:"|?*]/.test(seg)) throw fail('BAD_ARG', `«${seg.slice(0, 40)}» no es un nombre de archivo válido en Windows.`);
    }
    const key = caseInsensitive ? rel.toLowerCase() : rel;
    if (!seen.has(key)) {
      seen.add(key);
      out.push(rel);
    }
  }
  return out;
}

// Rutas listas para usar como pathspec: «.» tal cual; las que llevan comodines (* ? [ \\) o empiezan por «:» se marcan como literales.
function literalPathspecs(paths) {
  return (paths || []).map(p => (p === '.' || !/[*?[\\]|^:/.test(p) ? p : `:(literal)${p}`));
}

// ── Lectura de lo que devuelve Git ───────────────────────────────────────────────────────────────
const STATUS_WORD = {
  M: 'modificado',
  A: 'nuevo',
  D: 'borrado',
  R: 'renombrado',
  C: 'copiado',
  T: 'cambio de tipo',
  U: 'en conflicto',
  '?': 'sin seguimiento'
};
function statusWord(letter) {
  return STATUS_WORD[letter] || letter;
}
// `git status --porcelain=v2 --branch -z`
function parseStatusV2(text) {
  const out = {
    branch: { oid: '', head: '', upstream: '', ahead: 0, behind: 0, hasAB: false },
    staged: [],
    unstaged: [],
    untracked: [],
    conflicts: [],
    ignored: []
  };
  const parts = String(text || '').split('\0');
  for (let i = 0; i < parts.length; i++) {
    const line = parts[i];
    if (!line) continue;
    if (line.startsWith('# ')) {
      const [key, ...rest] = line.slice(2).split(' ');
      const val = rest.join(' ');
      if (key === 'branch.oid') out.branch.oid = val === '(initial)' ? '' : val;
      else if (key === 'branch.head') out.branch.head = val === '(detached)' ? '' : val;
      else if (key === 'branch.upstream') out.branch.upstream = val;
      else if (key === 'branch.ab') {
        const m = /^\+(\d+) -(\d+)$/.exec(val);
        if (m) {
          out.branch.ahead = Number(m[1]);
          out.branch.behind = Number(m[2]);
          out.branch.hasAB = true;
        }
      }
      continue;
    }
    const kind = line[0];
    if (kind === '1') {
      const m = /^1 (.)(.) \S+ \S+ \S+ \S+ \S+ \S+ ([\s\S]*)$/.exec(line);
      if (!m) continue;
      if (m[1] !== '.') out.staged.push({ path: m[3], status: m[1] });
      if (m[2] !== '.') out.unstaged.push({ path: m[3], status: m[2] });
    } else if (kind === '2') {
      const m = /^2 (.)(.) \S+ \S+ \S+ \S+ \S+ \S+ \S+ ([\s\S]*)$/.exec(line);
      const orig = parts[++i] || '';
      if (!m) continue;
      if (m[1] !== '.') out.staged.push({ path: m[3], status: m[1], from: orig });
      if (m[2] !== '.') out.unstaged.push({ path: m[3], status: m[2], from: orig });
    } else if (kind === 'u') {
      const m = /^u (..) \S+ \S+ \S+ \S+ \S+ \S+ \S+ \S+ ([\s\S]*)$/.exec(line);
      if (m) out.conflicts.push({ path: m[2], status: 'U', xy: m[1] });
    } else if (kind === '?') out.untracked.push(line.slice(2));
    else if (kind === '!') out.ignored.push(line.slice(2));
  }
  return out;
}

// `git diff --numstat -z`: «añadidas<TAB>quitadas<TAB>ruta\0» y, si es un renombrado, «añadidas<TAB>quitadas<TAB>\0origen\0destino\0».
function parseNumstat(text) {
  const parts = String(text || '').split('\0');
  const rows = [];
  for (let i = 0; i < parts.length; i++) {
    const rec = parts[i];
    if (!rec) continue;
    const m = /^(\d+|-)\t(\d+|-)\t([\s\S]*)$/.exec(rec);
    if (!m) continue;
    const binary = m[1] === '-' || m[2] === '-';
    let file = m[3],
      from = '';
    if (file === '') {
      from = parts[++i] || '';
      file = parts[++i] || '';
    }
    rows.push({ path: file, from, added: binary ? 0 : Number(m[1]), deleted: binary ? 0 : Number(m[2]), binary });
  }
  return rows;
}

// `git diff --raw -z --no-abbrev`: «:modo modo hash hash estado\0ruta\0» (renombrados llevan dos rutas)
function parseRawDiff(text) {
  const parts = String(text || '').split('\0');
  const rows = [];
  for (let i = 0; i < parts.length; i++) {
    const head = parts[i];
    const m = /^:(\d+) (\d+) ([0-9a-f]+) ([0-9a-f]+) ([A-Z])(\d*)$/.exec(head || '');
    if (!m) continue;
    const letter = m[5];
    let file = parts[++i] || '',
      from = '';
    if (letter === 'R' || letter === 'C') {
      from = file;
      file = parts[++i] || '';
    }
    rows.push({ path: file, from, status: letter, oldMode: m[1], newMode: m[2], oldId: m[3], newId: m[4] });
  }
  return rows;
}

// Registros del formato `--format=%H%x00%h%x00%an%x00%ae%x00%ct%x00%s%x00%D%x1e`
function parseLog(text) {
  return String(text || '')
    .split('\x1e')
    .map(s => s.replace(/^\n+/, ''))
    .filter(s => s.trim())
    .map(rec => {
      const [hash, short, author, email, ct, subject, refs] = rec.split('\0');
      return {
        hash: hash || '',
        short: short || '',
        author: author || '',
        email: email || '',
        date: Number(ct) ? new Date(Number(ct) * 1000).toISOString() : '',
        subject: subject || '',
        refs: (refs || '').trim()
      };
    });
}

// `git config --list --show-origin --show-scope -z`: «ámbito\0origen\0clave\nvalor\0»
function parseConfigList(text) {
  const parts = String(text || '').split('\0');
  const rows = [];
  for (let i = 0; i + 2 < parts.length + 1; i += 3) {
    const scope = parts[i],
      origin = parts[i + 1],
      kv = parts[i + 2];
    if (scope === undefined || kv === undefined) break;
    const nl = kv.indexOf('\n');
    const key = nl < 0 ? kv : kv.slice(0, nl);
    const value = nl < 0 ? '' : kv.slice(nl + 1);
    if (!key) continue;
    rows.push({ scope, origin, key: key.toLowerCase(), raw: key, value });
  }
  return rows;
}

// ── Servidores remotos ───────────────────────────────────────────────────────────────────────────
// Convierte la dirección de un remoto en algo que se pueda enseñar sin filtrar claves.
function describeRemoteUrl(url) {
  const raw = String(url || '').trim();
  const info = { raw: '', display: '', host: '', scheme: '', secure: false, local: false, helper: false, hadCredentials: false, path: '' };
  if (!raw) return info;
  let m;
  if ((m = /^([A-Za-z][A-Za-z0-9+.-]*)::/.exec(raw)) && !/^[A-Za-z]:\\/.test(raw)) {
    info.scheme = m[1].toLowerCase();
    info.helper = true;
    info.display = `${info.scheme}::…`;
    return info;
  }
  if ((m = /^(https?|ssh|git|ftps?):\/\/([^/?#]*)(.*)$/i.exec(raw))) {
    info.scheme = m[1].toLowerCase();
    let auth = m[2];
    const at = auth.lastIndexOf('@');
    let user = '';
    if (at >= 0) {
      user = auth.slice(0, at);
      auth = auth.slice(at + 1);
    }
    const hostPort = auth;
    info.host = hostPort
      .replace(/^\[|\](?=:|$)/g, '')
      .replace(/:\d+$/, '')
      .toLowerCase();
    info.path = m[3].replace(/^\/+/, '');
    // Usuario sin clave (ssh://git@…) es normal; usuario:clave o token en la dirección no se muestra jamás.
    info.hadCredentials = user.includes(':') || (info.scheme !== 'ssh' && !!user);
    const shownUser = info.scheme === 'ssh' && user && !user.includes(':') ? `${user}@` : info.hadCredentials ? '***@' : '';
    info.display = `${info.scheme}://${shownUser}${hostPort}${m[3]}`;
    info.secure = info.scheme === 'https' || info.scheme === 'ssh';
    return info;
  }
  if (/^file:\/\//i.test(raw)) {
    info.scheme = 'file';
    info.local = true;
    info.display = raw.replace(/^file:\/\//i, 'file://');
    info.path = raw.replace(/^file:\/\//i, '');
    info.secure = true;
    return info;
  }
  if ((m = /^(?:([^@/\\:\s]+)@)?([^/\\:\s]+):(?!\/\/)(.*)$/.exec(raw)) && !/^[A-Za-z]:[\\/]/.test(raw)) {
    info.scheme = 'ssh';
    info.host = m[2].toLowerCase();
    info.path = m[3];
    info.display = `${m[1] ? `${m[1]}@` : ''}${m[2]}:${m[3]}`;
    info.secure = true;
    return info;
  }
  info.scheme = 'path';
  info.local = true;
  info.secure = true;
  info.path = raw;
  info.display = raw;
  return info;
}
function maskUrls(text) {
  return String(text || '').replace(/\b([a-z][a-z0-9+.-]*:\/\/)([^\s/@:]+(?::[^\s/@]*)?)@/gi, '$1***@');
}

// ── Archivos delicados ───────────────────────────────────────────────────────────────────────────
const SENSITIVE_NAME = [
  [
    /^\.env(\.(?!example$|sample$|template$|dist$|defaults?$)[^/]*)?$/i,
    'archivo de variables de entorno (.env): suele tener claves y contraseñas'
  ],
  [/\.(pem|key|p12|pfx|ppk|jks|keystore|kdbx|asc)$/i, 'archivo de claves o certificados'],
  [/^id_(rsa|dsa|ecdsa|ed25519)(?!.*\.pub$).*$/i, 'clave privada SSH'],
  [/^(credentials?|secrets?)([._-].*)?$/i, 'archivo de credenciales o secretos'],
  [/^\.(npmrc|pypirc|netrc|git-credentials|htpasswd|dockercfg)$/i, 'archivo de acceso a servicios'],
  [/^_netrc$/i, 'archivo de acceso a servicios'],
  [/(service[-_]?account|firebase[-_]?adminsdk|client[-_]?secret)[^/]*\.json$/i, 'clave de cuenta de servicio'],
  [/^terraform\.tfstate(\.backup)?$/i, 'estado de Terraform (puede guardar secretos)'],
  [/\.tfvars$/i, 'variables de Terraform (pueden guardar secretos)'],
  [/^auth\.json$/i, 'archivo de autenticación']
];
function sensitiveReason(filePath) {
  const p = String(filePath || '').replace(/\\/g, '/');
  const base = p.split('/').pop() || '';
  if (/(^|\/)\.(aws|ssh|gnupg)\//i.test(p)) return 'carpeta de claves del sistema (.aws, .ssh o .gnupg)';
  if (/(^|\/)\.docker\/config\.json$/i.test(p)) return 'configuración de Docker con claves de acceso';
  for (const [re, why] of SENSITIVE_NAME) if (re.test(base)) return why;
  return '';
}
function detectSensitiveFiles(paths) {
  const out = [];
  for (const p of paths || []) {
    const why = sensitiveReason(typeof p === 'string' ? p : p.path);
    if (why) out.push({ path: typeof p === 'string' ? p : p.path, reason: why });
  }
  return out;
}

const SECRET_PATTERNS = [
  [/-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY(?: BLOCK)?-----/, 'una clave privada', 'danger'],
  [/\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/, 'una clave de acceso de AWS', 'danger'],
  [/\bgh[pousr]_[A-Za-z0-9]{30,}\b|\bgithub_pat_[A-Za-z0-9_]{20,}\b/, 'un token de GitHub', 'danger'],
  [/\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{24,}\b/, 'una clave de API (sk-…)', 'danger'],
  [/\bAIza[0-9A-Za-z_-]{35}\b/, 'una clave de Google', 'danger'],
  [/\bxox[baprs]-[A-Za-z0-9-]{10,}\b/, 'un token de Slack', 'danger'],
  [/\b[a-z][a-z0-9+.-]{1,12}:\/\/[^\s/:@'"]{1,60}:[^\s/@'"]{3,80}@[^\s'"]{3,}/i, 'una dirección con usuario y contraseña', 'danger'],
  [
    /\b(?:password|passwd|pwd|secret|token|api[_-]?key|client[_-]?secret)\b["']?\s*[:=]\s*["'][^"'\s]{8,}["']/i,
    'una posible contraseña o clave escrita en el código',
    'warn'
  ]
];
// Busca claves en las líneas AÑADIDAS de un diff. Nunca devuelve el texto del secreto.
function scanDiffForSecrets(diff, { maxFindings = 50 } = {}) {
  const findings = [];
  let file = '';
  const seen = new Set();
  for (const line of String(diff || '').split('\n')) {
    if (line.startsWith('+++ ')) {
      file = line.slice(4).replace(/^b\//, '').replace(/^"|"$/g, '');
      continue;
    }
    if (!line.startsWith('+') || line.startsWith('+++')) continue;
    const text = line.slice(1, 4000);
    for (const [re, what, level] of SECRET_PATTERNS) {
      if (re.test(text)) {
        const key = `${file}|${what}`;
        if (!seen.has(key)) {
          seen.add(key);
          findings.push({ file, what, level });
        }
        break;
      }
    }
    if (findings.length >= maxFindings) break;
  }
  return findings;
}

// ── Configuración del repositorio que ejecuta programas ──────────────────────────────────────────
const LOCAL_SCOPES = new Set(['local', 'worktree']);
// Programas de filtro conocidos y legítimos (Git LFS, git-crypt): solo si el valor es exactamente «git-lfs …» sin caracteres de shell.
const KNOWN_FILTER_RE = /^\s*git[- ](?:lfs|crypt)(?:\s+[\w%.=-]+)*\s*$/i;
// Devuelve lo que la configuración PROPIA del repositorio (no la del usuario) haría ejecutar o desviar.
function riskyConfigFindings(entries) {
  const out = [];
  for (const e of entries || []) {
    if (!LOCAL_SCOPES.has(e.scope)) continue;
    const key = e.key,
      value = String(e.value || '');
    const add = (level, text, extra = {}) => out.push({ key, value: value.slice(0, 200), scope: e.scope, level, text, ...extra });
    if (key === 'core.fsmonitor') {
      if (!/^(false|no|off|0)$/i.test(value))
        add('info', 'Pide ejecutar un programa para vigilar cambios. Auric lo desactiva.', { neutralized: true });
    } else if (key === 'core.sshcommand' || key === 'core.gitproxy')
      add('danger', 'Cambia el programa que usa Git para conectarse: se ejecutaría al subir o bajar.');
    else if (key === 'core.hookspath') add('danger', 'Usa programas automáticos (hooks) de otra carpeta.');
    else if (
      key === 'core.askpass' ||
      key === 'core.editor' ||
      key === 'core.pager' ||
      key === 'sequence.editor' ||
      key === 'diff.external'
    )
      add('info', 'Auric lo desactiva en las pruebas y consultas.', { neutralized: true });
    else if (key === 'gpg.program' || /^gpg\.[^.]+\.program$/.test(key))
      add('danger', 'Cambia el programa de firmas: se ejecutaría al guardar un commit firmado.');
    else if (key === 'credential.helper' || /^credential\..+\.helper$/.test(key))
      add(
        value.trim().startsWith('!') || /[\\/]/.test(value) ? 'danger' : 'warn',
        'Define cómo se piden las contraseñas: podría ejecutar un programa al subir o bajar.'
      );
    else if (/^filter\..+\.(clean|smudge|process)$/.test(key)) {
      if (!KNOWN_FILTER_RE.test(value))
        add('danger', 'Ejecuta un programa sobre los archivos al guardarlos o cambiar de rama.', {
          filter: /^filter\.(.+)\.(?:clean|smudge|process)$/.exec(e.raw || e.key)?.[1] || ''
        });
    } else if (/^merge\..+\.driver$/.test(key)) add('danger', 'Ejecuta un programa propio al fusionar ramas.');
    else if (/^diff\..+\.(textconv|command)$/.test(key))
      add('info', 'Auric no ejecuta conversores propios al mostrar cambios.', { neutralized: true });
    else if (key === 'include.path' || /^includeif\..+\.path$/.test(key)) add('warn', 'Incluye otro archivo de configuración.');
    else if (/^url\..+\.(pushinsteadof|insteadof)$/.test(key))
      add('warn', 'Cambia a dónde apunta una dirección: Auric muestra la dirección real antes de subir o bajar.');
    else if (key === 'http.proxy' || /^remote\..+\.proxy$/.test(key) || key === 'https.proxy')
      add('warn', 'Envía las conexiones de Git por un proxy definido en este repositorio.');
    else if (key === 'http.sslverify' && /^(false|no|off|0)$/i.test(value))
      add('warn', 'Desactiva la comprobación del certificado de seguridad del servidor.');
    else if (key === 'http.sslcainfo' || key === 'http.sslcapath') add('warn', 'Cambia los certificados en los que confía Git.');
    else if (/^protocol\..+\.allow$/.test(key) && /^always$/i.test(value)) add('warn', 'Permite protocolos que Git bloquea por seguridad.');
    else if (key === 'core.worktree') add('danger', 'Apunta a otra carpeta de trabajo distinta de la del repositorio.');
    else if (key === 'core.attributesfile') add('warn', 'Usa un archivo de atributos propio.');
    else if (key === 'core.bare' && /^true$/i.test(value)) add('info', 'El repositorio es «desnudo» (sin carpeta de trabajo).');
  }
  return out;
}

// Para las CONSULTAS (status, diff…): apaga los filtros peligrosos del repositorio. Si no, Git los ejecutaría solo por comparar archivos.
function filterNeutralizers(findings) {
  const names = [...new Set((findings || []).filter(f => f.filter && f.level === 'danger').map(f => f.filter))];
  const args = [];
  for (const n of names) {
    if (!/^[A-Za-z0-9_.-]{1,80}$/.test(n)) continue;
    for (const k of ['clean', 'smudge', 'process']) args.push('-c', `filter.${n}.${k}=`);
    args.push('-c', `filter.${n}.required=false`);
  }
  return args;
}

// ── Programas automáticos (hooks) ────────────────────────────────────────────────────────────────
const HOOKS_BY_OP = {
  commit: ['pre-commit', 'prepare-commit-msg', 'commit-msg', 'post-commit', 'post-index-change', 'reference-transaction'],
  merge: [
    'pre-merge-commit',
    'prepare-commit-msg',
    'commit-msg',
    'post-merge',
    'post-commit',
    'post-index-change',
    'reference-transaction'
  ],
  pull: ['pre-merge-commit', 'post-merge', 'post-checkout', 'post-index-change', 'reference-transaction'],
  push: ['pre-push', 'reference-transaction'],
  switch: ['post-checkout', 'post-index-change', 'reference-transaction'],
  stash: ['post-index-change', 'reference-transaction'],
  reset: ['post-index-change', 'reference-transaction'],
  discard: ['post-index-change'],
  add: ['post-index-change'],
  branch: ['reference-transaction'],
  fetch: ['reference-transaction'],
  init: [],
  backup_restore: ['post-index-change', 'reference-transaction']
};
function relevantHooks(opFamily, activeHooks) {
  const wanted = new Set(HOOKS_BY_OP[opFamily] || []);
  return (activeHooks || []).filter(h => wanted.has(h.name));
}

// ── Cuándo se pregunta ───────────────────────────────────────────────────────────────────────────
// kind: read | stage | branch | fetch | tree | commit | push | destructive
// Devuelve { ask, always }: ask = hay que enseñar una ventana; always = ni «completo» ni ninguna concesión lo saltan.
function confirmPolicy(kind, permission) {
  if (kind === 'read') return { ask: false, always: false };
  if (kind === 'push' || kind === 'destructive') return { ask: true, always: true };
  const lenient = permission === 'full';
  const guarded = permission === 'guarded' || permission === 'workspace';
  if (kind === 'stage' || kind === 'branch' || kind === 'fetch') return { ask: !(lenient || guarded), always: false };
  if (kind === 'tree' || kind === 'commit') return { ask: !lenient, always: false };
  return { ask: true, always: true };
}

// ── Textos que la persona lee ────────────────────────────────────────────────────────────────────
const OPERATION_TEXT = {
  merge: 'una fusión de ramas sin terminar',
  'cherry-pick': 'un cherry-pick sin terminar',
  revert: 'una reversión sin terminar',
  rebase: 'un rebase sin terminar',
  bisect: 'una búsqueda binaria (bisect) en curso'
};

module.exports = {
  fail,
  validateBranchName,
  validateRevision,
  validateRange,
  validateRemoteName,
  validateStashRef,
  validateMessage,
  stripAiAttribution,
  validateIdentity,
  validateRelPaths,
  literalPathspecs,
  parseStatusV2,
  parseNumstat,
  parseRawDiff,
  parseLog,
  parseConfigList,
  statusWord,
  describeRemoteUrl,
  maskUrls,
  sensitiveReason,
  detectSensitiveFiles,
  scanDiffForSecrets,
  riskyConfigFindings,
  filterNeutralizers,
  relevantHooks,
  HOOKS_BY_OP,
  confirmPolicy,
  OPERATION_TEXT,
  MAX_PATHS
};
