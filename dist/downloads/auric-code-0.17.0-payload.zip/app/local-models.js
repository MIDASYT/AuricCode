// Lista de modelos de Mi PC y motor de recomendación. Funciones puras: no hablan con Ollama ni con Electron.
// La lista que se entrega con la app es editable (se pueden añadir, ocultar y restaurar modelos) y la app la
// comprueba contra el registro de Ollama desde el PC de la persona (ver local-ai.js → verifyCatalog).
const fs = require('node:fs');
const path = require('node:path');

const GIB = 1024 ** 3;
const GB = 1e9;
const CTX_STEPS = [4096, 8192, 16384, 32768, 65536, 131072];
// Velocidades EFECTIVAS (lo que se consigue de verdad, no el máximo teórico) en GB/s para leer los pesos del modelo.
const BW_GPU_NVIDIA = 150;
const BW_GPU_OTHER = 60;
const BW_CPU = 22;
const SYSTEM_PROMPT_TOKENS = 3000; // pregunta típica de un agente con herramientas (modo compacto)

const NAME_RE = /^[a-z0-9][a-z0-9._-]{0,60}(?:\/[a-z0-9][a-z0-9._-]{0,60}){0,2}:[A-Za-z0-9][A-Za-z0-9._-]{0,60}$/;
const NAME_NO_TAG_RE = /^[a-z0-9][a-z0-9._-]{0,60}(?:\/[a-z0-9][a-z0-9._-]{0,60}){0,2}$/;

// Acepta "qwen3" o "qwen3:8b" y devuelve siempre "nombre:etiqueta". El nombre va en minúsculas; la etiqueta conserva
// sus mayúsculas (hay etiquetas como "8b-instruct-q4_K_M"). Texto inválido → ''.
function normalizeModelName(raw) {
  let s = String(raw || '')
    .trim()
    .replace(/^ollama\s+(?:run|pull)\s+/i, '');
  if (!s || /\s/.test(s) || s.length > 200) return '';
  const i = s.lastIndexOf(':');
  let repo = (i > 0 ? s.slice(0, i) : s).toLowerCase();
  const tag = i > 0 ? s.slice(i + 1) : 'latest';
  repo = repo.replace(/^(?:registry\.ollama\.ai\/)?library\//, '');
  const full = `${repo}:${tag}`;
  return NAME_RE.test(full) ? full : '';
}

const num = (v, min, max, dflt) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : dflt;
};

// Memoria de contexto por token (MB) cuando no se conoce la arquitectura: aproximación por tamaño.
function estimateKv(paramsB) {
  const p = Number(paramsB) || 8;
  return Math.round(Math.min(0.5, Math.max(0.03, 0.016 * p)) * 1000) / 1000;
}

function normalizeEntry(raw, { custom = false } = {}) {
  if (!raw || typeof raw !== 'object') return null;
  const id = normalizeModelName(raw.id);
  if (!id) return null;
  const sizeGB = num(raw.sizeGB, 0.05, 2000, 0);
  if (!sizeGB) return null;
  const paramsB = num(raw.paramsB, 0.05, 3000, 0) || Math.round(sizeGB * 1.6 * 10) / 10;
  return {
    id,
    name: String(raw.name || id).slice(0, 60),
    family: String(raw.family || id.split(':')[0]).slice(0, 40),
    paramsB,
    activeB: num(raw.activeB, 0.05, paramsB, paramsB),
    sizeGB,
    ctxMax: Math.round(num(raw.ctxMax, 2048, 4194304, 8192)),
    kvMBPerToken: num(raw.kvMBPerToken, 0.005, 4, 0) || estimateKv(paramsB),
    tools: raw.tools === true,
    coding: raw.coding === true,
    thinking: raw.thinking === true,
    vision: raw.vision === true,
    note: String(raw.note || '').slice(0, 200),
    custom: custom || raw.custom === true
  };
}

function loadShipped(file) {
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  return {
    reviewed: String(data.reviewed || ''),
    verified: data.verified === true,
    source: String(data.source || ''),
    models: (Array.isArray(data.models) ? data.models : []).map(m => normalizeEntry(m)).filter(Boolean)
  };
}

// Une la lista de fábrica con los cambios de la persona: modelos añadidos, ocultos y valores corregidos por la comprobación.
function mergeCatalog(shipped, user = {}) {
  const hidden = new Set((Array.isArray(user.hidden) ? user.hidden : []).map(normalizeModelName).filter(Boolean));
  const map = new Map();
  for (const m of shipped.models) map.set(m.id, { ...m });
  for (const raw of Array.isArray(user.custom) ? user.custom : []) {
    const e = normalizeEntry(raw, { custom: true });
    if (e) map.set(e.id, { ...(map.get(e.id) || {}), ...e, custom: !shipped.models.some(s => s.id === e.id) });
  }
  const checks = user.checks && typeof user.checks === 'object' ? user.checks : {};
  const out = [];
  for (const m of map.values()) {
    const c = checks[m.id];
    const merged = { ...m, hidden: hidden.has(m.id), check: null };
    if (c && typeof c === 'object') {
      merged.check = {
        exists: c.exists !== false,
        checkedAt: Number(c.checkedAt) || 0,
        sizeGB: Number(c.sizeGB) || 0,
        tools: typeof c.tools === 'boolean' ? c.tools : null,
        vision: typeof c.vision === 'boolean' ? c.vision : null,
        error: String(c.error || '').slice(0, 160)
      };
      if (c.exists !== false && c.sizeGB > 0) merged.sizeGB = Math.round(c.sizeGB * 100) / 100;
      if (typeof c.tools === 'boolean') merged.tools = c.tools;
      if (typeof c.vision === 'boolean') merged.vision = c.vision;
    }
    out.push(merged);
  }
  return { reviewed: shipped.reviewed, verified: shipped.verified, source: shipped.source, models: out };
}

// ── Cálculo de memoria y velocidad ──────────────────────────────────────────────────────────────
function memoryBudget(hw) {
  const ram = Number(hw?.ramGB) || 0;
  const reserve = Math.max(3, ram * 0.25); // Windows y tus otros programas
  const g = hw?.bestGpu && hw.bestGpu.accel !== 'no' ? hw.bestGpu : null;
  return {
    cpuGB: Math.max(0, ram - reserve),
    gpuGB: g ? Math.max(0, Number(g.vramGB) - 0.6) : 0, // reserva para la pantalla y el controlador
    gpu: g
  };
}

function weightsGiB(entry) {
  return (entry.sizeGB * GB) / GIB;
}
function needGiB(entry, ctx) {
  return weightsGiB(entry) * 1.03 + (entry.kvMBPerToken * ctx) / 1024 + 0.5;
}

function placementOf(entry, ctx, budget) {
  const need = needGiB(entry, ctx);
  if (budget.gpuGB >= need) return { placement: 'gpu', gpuFrac: 1, need };
  if (budget.gpuGB >= 1 && need <= budget.gpuGB + budget.cpuGB)
    return { placement: 'mixto', gpuFrac: Math.min(1, budget.gpuGB / need), need };
  if (need <= budget.cpuGB) return { placement: 'cpu', gpuFrac: 0, need };
  return { placement: 'no-cabe', gpuFrac: 0, need };
}

// Velocidad estimada de escritura (tokens por segundo) y tiempo de la primera respuesta (segundos).
function speedOf(entry, place, budget) {
  const active = Math.min(entry.activeB, entry.paramsB);
  const readGB = weightsGiB(entry) * (active / entry.paramsB);
  const bwGpu = budget.gpu && budget.gpu.vendor === 'nvidia' ? BW_GPU_NVIDIA : BW_GPU_OTHER;
  const f = place.gpuFrac;
  const sec = (f * readGB) / bwGpu + ((1 - f) * readGB) / BW_CPU;
  const tps = sec > 0 ? 1 / sec : 0;
  // Lectura del texto de entrada: mucho más lenta en procesador que en tarjeta gráfica.
  const prefillCpu = 250 / Math.max(1, active);
  const prefillGpu = (budget.gpu && budget.gpu.vendor === 'nvidia' ? 3000 : 900) / Math.max(1, active);
  const prefill = f >= 1 ? prefillGpu : f > 0 ? 1 / (f / prefillGpu + (1 - f) / prefillCpu) : prefillCpu;
  return { tps, prefillTps: prefill, firstReplySec: SYSTEM_PROMPT_TOKENS / prefill + 200 / Math.max(0.1, tps) };
}

function fitsAt(entry, ctx, budget) {
  return placementOf(entry, ctx, budget).placement !== 'no-cabe';
}

// Mayor contexto que cabe en memoria (0 si ni siquiera 4096 caben).
function pickContext(entry, hw, { cap } = {}) {
  const budget = memoryBudget(hw);
  const gpuComfort = budget.gpuGB >= weightsGiB(entry) * 1.1;
  const hardCap = Math.min(entry.ctxMax || 8192, cap || (gpuComfort ? 32768 : 16384));
  let best = 0;
  for (const c of CTX_STEPS) {
    if (c > hardCap) break;
    if (fitsAt(entry, c, budget)) best = c;
  }
  if (!best && entry.ctxMax && entry.ctxMax < CTX_STEPS[0] && fitsAt(entry, entry.ctxMax, budget)) best = entry.ctxMax;
  return best;
}

const LEVELS = {
  fluido: { id: 'fluido', label: 'Va fluido', order: 0 },
  lento: { id: 'lento', label: 'Va lento', order: 1 },
  no: { id: 'no', label: 'No recomendado', order: 2 }
};
const fmtGB = n => (Math.round(n * 10) / 10).toString().replace('.', ',');
const wordsPerSec = tps => Math.max(0.1, Math.round(tps * 0.65 * 10) / 10);
const fmtWps = tps => String(wordsPerSec(tps)).replace('.', ',');

// Valora un modelo para un equipo: nivel, motivo en español, contexto sugerido y avisos.
function assess(entry, hw) {
  const budget = memoryBudget(hw);
  const numCtx = pickContext(entry, hw);
  const warnings = [];
  const ctx = numCtx || 4096;
  const place = placementOf(entry, ctx, budget);
  const base = { id: entry.id, numCtx, placement: place.placement, needGB: Math.round(place.need * 10) / 10 };
  const availableGB = Math.round((budget.gpuGB + budget.cpuGB) * 10) / 10;
  if (place.placement === 'no-cabe' || !numCtx) {
    return {
      ...base,
      level: 'no',
      label: LEVELS.no.label,
      reason: `Necesita unos ${fmtGB(place.need)} GB y tu equipo puede dedicar unos ${fmtGB(availableGB)} GB a los modelos.`,
      tps: 0,
      wordsPerSec: 0,
      firstReplySec: 0,
      warnings
    };
  }
  const sp = speedOf(entry, place, budget);
  let level = 'no';
  if (sp.tps >= 10 && sp.firstReplySec <= 45) level = 'fluido';
  else if (sp.tps >= 3 && sp.firstReplySec <= 240) level = 'lento';
  const where =
    place.placement === 'gpu'
      ? 'Cabe entera en la memoria de tu tarjeta gráfica.'
      : place.placement === 'mixto'
        ? 'Una parte va en la tarjeta gráfica y el resto en la memoria RAM.'
        : 'Usa el procesador y la memoria RAM.';
  let reason;
  if (level === 'fluido') reason = `${where} Unas ${fmtWps(sp.tps)} palabras por segundo.`;
  else if (level === 'lento')
    reason = `${where} Unas ${fmtWps(sp.tps)} palabras por segundo; la primera respuesta puede tardar ${Math.round(sp.firstReplySec)} s.`;
  else
    reason = `${where} Iría a unas ${fmtWps(sp.tps)} palabras por segundo (primera respuesta ~${Math.round(sp.firstReplySec)} s): demasiado lento para trabajar.`;
  if (numCtx < 8192)
    warnings.push(`Con la memoria de tu equipo el contexto queda corto (${numCtx} tokens): las tareas largas pueden perder el hilo.`);
  if (budget.gpu && budget.gpu.accel === 'depende') warnings.push('Tu tarjeta no es NVIDIA: la velocidad real puede ser menor.');
  return {
    ...base,
    level,
    label: LEVELS[level].label,
    reason,
    tps: Math.round(sp.tps * 10) / 10,
    wordsPerSec: wordsPerSec(sp.tps),
    firstReplySec: Math.round(sp.firstReplySec),
    warnings
  };
}

function agentGrade(entry) {
  if (!entry.tools) return { id: 'no', label: 'Sin herramientas' };
  if (entry.paramsB >= 14) return { id: 'bueno', label: 'Herramientas: buenas' };
  if (entry.paramsB >= 7) return { id: 'justo', label: 'Herramientas: aceptables' };
  return { id: 'basico', label: 'Herramientas: básicas' };
}

// Capacidad aproximada: en los modelos que activan solo una parte de sus parámetros (MoE) pesa un poco más que lo activo.
const effectiveB = e => (e.activeB >= e.paramsB ? e.paramsB : (e.activeB + e.paramsB) / 2.5);

// Ordena por nivel y, dentro de cada nivel, prioriza los que sirven con herramientas y los más capaces.
// `pick`: lo mejor que va fluido con holgura de memoria. `pickCapable`: lo más capaz aunque vaya lento.
function recommendAll(entries, hw) {
  const budget = memoryBudget(hw);
  const total = budget.gpuGB + budget.cpuGB;
  const rows = entries
    .filter(e => !e.hidden)
    .map(e => {
      const a =
        e.check?.exists === false
          ? {
              id: e.id,
              level: 'no',
              label: 'No disponible',
              reason: 'El registro de Ollama ya no ofrece este modelo.',
              numCtx: 0,
              placement: 'no-cabe',
              needGB: 0,
              tps: 0,
              wordsPerSec: 0,
              firstReplySec: 0,
              warnings: [],
              unavailable: true
            }
          : assess(e, hw);
      return {
        ...e,
        grade: agentGrade(e),
        assessment: {
          ...a,
          headroom: total > 0 && a.needGB ? Math.round((a.needGB / total) * 100) / 100 : 0,
          // Parte de la memoria útil que ocupa SOLO el modelo (sin la memoria de conversación, que se ajusta sola).
          weightShare: total > 0 ? Math.round(((weightsGiB(e) * 1.03) / total) * 100) / 100 : 0
        }
      };
    });
  const score = r => (r.tools ? 1000 : 0) + (r.coding ? 50 : 0) + effectiveB(r) * 5;
  rows.sort((a, b) => {
    const la = LEVELS[a.assessment.level].order,
      lb = LEVELS[b.assessment.level].order;
    if (la !== lb) return la - lb;
    if (a.assessment.level === 'no') return a.sizeGB - b.sizeGB;
    return score(b) - score(a);
  });
  const usable = rows.filter(r => r.tools && !r.assessment.unavailable && r.assessment.level !== 'no');
  // «Recomendado para ti» solo sale de los que sobran con holgura: el modelo no debe ocupar más de ~60 % de la memoria útil,
  // para que el equipo siga usable mientras trabaja (Windows, el navegador y Auric también necesitan memoria).
  const comfy = usable.filter(
    r =>
      r.assessment.level === 'fluido' && r.assessment.weightShare <= 0.6 && r.assessment.headroom <= 0.85 && r.assessment.wordsPerSec >= 8
  );
  const best = list =>
    list.slice().sort((a, b) => (b.assessment.numCtx >= 16384) - (a.assessment.numCtx >= 16384) || effectiveB(b) - effectiveB(a))[0];
  const pick = best(comfy) || best(usable.filter(r => r.assessment.level === 'fluido')) || best(usable);
  const capable = usable
    .filter(r => r.assessment.wordsPerSec >= 3 && r.assessment.firstReplySec <= 150)
    .sort((a, b) => effectiveB(b) - effectiveB(a) || b.assessment.numCtx - a.assessment.numCtx)[0];
  return { rows, pick: pick ? pick.id : '', pickCapable: capable && capable.id !== pick?.id ? capable.id : '' };
}

// Contexto que se debe pedir a Ollama para un modelo YA instalado, con los datos reales de /api/show.
function contextForInstalled({ info, hw, requested }) {
  const sizeGB = Number(info?.sizeBytes) > 0 ? info.sizeBytes / GB : 0;
  const entry = normalizeEntry({
    id: info?.name || 'x:latest',
    sizeGB: sizeGB || 1,
    paramsB: info?.paramsB || 0,
    ctxMax: info?.contextLength || 8192,
    kvMBPerToken: info?.kvBytesPerToken ? info.kvBytesPerToken / (1024 * 1024) : 0,
    tools: info?.tools
  });
  if (!entry) return { numCtx: 4096, reason: 'sin datos' };
  const auto = pickContext(entry, hw);
  const asked = Number(requested);
  if (Number.isFinite(asked) && asked >= 2048) {
    const limited = Math.min(asked, entry.ctxMax || asked);
    const fits = fitsAt(entry, limited, memoryBudget(hw));
    return { numCtx: limited, reason: fits ? 'elegido por ti' : 'elegido por ti (puede no caber en memoria)', fits, auto };
  }
  return {
    numCtx: auto || 4096,
    reason: auto ? 'ajustado a la memoria de tu equipo' : 'poca memoria: contexto mínimo',
    fits: !!auto,
    auto
  };
}

module.exports = {
  CTX_STEPS,
  NAME_RE,
  normalizeModelName,
  normalizeEntry,
  loadShipped,
  mergeCatalog,
  memoryBudget,
  needGiB,
  weightsGiB,
  placementOf,
  speedOf,
  pickContext,
  assess,
  agentGrade,
  recommendAll,
  contextForInstalled,
  estimateKv,
  LEVELS
};
