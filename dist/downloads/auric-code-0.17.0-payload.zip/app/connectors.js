'use strict';
// Conectores reales de Auric Code: cliente MCP (Streamable HTTP) + OAuth 2.1 (PKCE, DCR, refresh) en el proceso principal.
// Los secretos viven cifrados con safeStorage (DPAPI en Windows) y NUNCA se envían al renderer.
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');

const PROTOCOL_VERSION = '2025-06-18';
const CLIENT_INFO = { name: 'Auric Code', version: '0.17.0' };
const GOOGLE_AUTH = 'https://accounts.google.com/o/oauth2/v2/auth';
const GOOGLE_TOKEN = 'https://oauth2.googleapis.com/token';
const GOOGLE_REDIRECT_PORT = 53682;

const b64url = buf => Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const sha256 = s => crypto.createHash('sha256').update(s).digest();
const sleep = ms => new Promise(r => setTimeout(r, ms));
const nowSec = () => Math.floor(Date.now() / 1000);

class ConnectorError extends Error {
  constructor(message, code = 'ERROR', extra = {}) {
    super(message);
    this.code = code;
    Object.assign(this, extra);
  }
}

function googleDef(id, name, description, host, scopes, hint) {
  return {
    id,
    name,
    category: 'Google',
    description,
    url: `https://${host}.googleapis.com/mcp/v1`,
    auth: 'oauth-client',
    verified: id === 'gmail',
    google: true,
    scopes,
    fields: [
      { key: 'clientId', label: 'Client ID de Google Cloud', secret: false },
      { key: 'clientSecret', label: 'Client secret (si tu cliente lo tiene)', secret: true, optional: true }
    ],
    setup: {
      title: 'Configuración única: crea un acceso OAuth en Google Cloud (gratis)',
      steps: [
        'Entra a console.cloud.google.com y crea un proyecto (o usa uno existente).',
        `Activa la API correspondiente y el servidor MCP de Workspace (Developer Preview): ${hint}`,
        'Pantalla de consentimiento OAuth: tipo "Externo", añade tu correo como usuario de prueba.',
        'Credenciales → Crear credenciales → ID de cliente OAuth → tipo "Aplicación de escritorio" (o "Aplicación web" con la URI de redirección exacta de abajo).',
        'Copia el Client ID (y el secret si lo muestra) y pégalos aquí.'
      ],
      redirectUri: `http://127.0.0.1:${GOOGLE_REDIRECT_PORT}/callback`,
      notes: [
        'Google puede mostrar "Google no ha verificado esta aplicación": pulsa "Avanzado" y continúa. Mientras el cliente OAuth esté en modo de prueba, el permiso se renueva cada 7 días.',
        'Solo se pide lectura y creación de borradores/eventos según el conector; Auric siempre te pide confirmación antes de enviar o borrar.'
      ]
    }
  };
}

// Con un cliente OAuth incluido en la app, conectar Google es: Conectar → elegir cuenta → aceptar permisos.
function bundledGoogleDef(d) {
  return {
    ...d,
    fields: [],
    bundled: true,
    setup: {
      title: 'Conecta tu cuenta de Google',
      steps: [
        'Se abrirá Google en tu navegador.',
        'Elige tu cuenta y marca los permisos que Auric solicita.',
        'Vuelve aquí: la conexión se completa sola.'
      ],
      notes: [
        'Google puede mostrar "Google no ha verificado esta aplicación" mientras Auric completa la verificación de Google (un proceso de pago). Pulsa "Avanzado" → "Ir a Auric Code" para continuar; solo se conceden los permisos que ves en la lista.',
        'Si tu cuenta no está autorizada todavía, pide acceso al administrador de Auric (el modo de prueba de Google solo admite cuentas añadidas de antemano).',
        'Auric siempre te pide confirmación antes de enviar o borrar.'
      ]
    }
  };
}

const BUILTIN = [
  googleDef(
    'gmail',
    'Gmail',
    'Lee y busca correos, y crea borradores para que tú los revises y envíes.',
    'gmailmcp',
    ['https://www.googleapis.com/auth/gmail.readonly', 'https://www.googleapis.com/auth/gmail.compose'],
    'Gmail API + Gmail MCP'
  ),
  googleDef(
    'google-calendar',
    'Google Calendar',
    'Consulta tu agenda y crea eventos.',
    'calendarmcp',
    ['https://www.googleapis.com/auth/calendar.events', 'https://www.googleapis.com/auth/calendar.readonly'],
    'Google Calendar API + Calendar MCP'
  ),
  googleDef(
    'google-drive',
    'Google Drive',
    'Busca y lee archivos de tu Drive.',
    'drivemcp',
    ['https://www.googleapis.com/auth/drive.readonly'],
    'Google Drive API + Drive MCP'
  ),
  {
    id: 'github',
    name: 'GitHub',
    category: 'Código',
    description: 'Issues, pull requests, código y flujos de GitHub desde el chat.',
    url: 'https://api.githubcopilot.com/mcp/',
    auth: 'token',
    verified: false,
    fields: [{ key: 'token', label: 'Token de acceso personal', secret: true }],
    setup: {
      title: 'Crea un token con los permisos mínimos',
      steps: [
        'Pulsa "Crear token en GitHub": se abre la página con el nombre y los permisos ya rellenados (repositorios y datos de perfil).',
        'Baja y pulsa "Generate token", copia el token (empieza por ghp_).',
        'Pégalo aquí. Se guarda cifrado en tu equipo y puedes revocarlo cuando quieras desde GitHub.'
      ],
      links: [{ label: 'Crear token en GitHub', url: 'https://github.com/settings/tokens/new?description=Auric%20Code&scopes=repo,read:user' }]
    }
  },
  {
    id: 'supabase',
    name: 'Supabase',
    category: 'Datos',
    description: 'Proyectos, tablas, migraciones y logs de Supabase.',
    url: 'https://mcp.supabase.com/mcp',
    auth: 'oauth-dcr',
    verified: true,
    fields: [],
    setup: { title: 'Inicio de sesión en el navegador', steps: ['Se abrirá Supabase para que autorices a Auric Code.'] }
  },
  {
    id: 'notion',
    name: 'Notion',
    category: 'Productividad',
    description: 'Busca y edita páginas y bases de datos de Notion.',
    url: 'https://mcp.notion.com/mcp',
    auth: 'oauth-dcr',
    verified: false,
    fields: [],
    setup: { title: 'Inicio de sesión en el navegador', steps: ['Se abrirá Notion para que autorices a Auric Code.'] }
  },
  {
    id: 'linear',
    name: 'Linear',
    category: 'Productividad',
    description: 'Issues, proyectos y ciclos de Linear.',
    url: 'https://mcp.linear.app/mcp',
    auth: 'oauth-dcr',
    verified: false,
    fields: [],
    setup: { title: 'Inicio de sesión en el navegador', steps: ['Se abrirá Linear para que autorices a Auric Code.'] }
  }
];

function slug(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 32);
}
function assertMcpUrl(raw) {
  let u;
  try {
    u = new URL(String(raw || '').trim());
  } catch {
    throw new ConnectorError('La URL del servidor MCP no es válida.', 'BAD_URL');
  }
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname);
  if (u.protocol !== 'https:' && !(u.protocol === 'http:' && local))
    throw new ConnectorError('Solo se permiten servidores https:// (o http://localhost).', 'BAD_URL');
  if (u.username || u.password) throw new ConnectorError('La URL no debe contener usuario ni contraseña.', 'BAD_URL');
  return u.toString();
}
function redact(s) {
  return String(s || '').replace(
    /(access_token|refresh_token|client_secret|code_verifier|Bearer)[=": ]+[A-Za-z0-9._~+/-]{8,}/gi,
    '$1=[redacted]'
  );
}

class ConnectorManager {
  constructor({ dir, safeStorage, logosDir = '', openExternal, log = () => {}, fetchImpl = null, callbackTimeoutMs = 5 * 60 * 1000, bundledGoogle = null } = {}) {
    if (!dir) throw new Error('ConnectorManager requiere dir');
    this.dir = dir;
    this.safe = safeStorage;
    this.logosDir = logosDir;
    // Cliente OAuth de Google incluido en la app (opcional): con él el usuario solo pulsa «Conectar».
    this.bundledGoogle = bundledGoogle && String(bundledGoogle.clientId || '').trim() ? { clientId: String(bundledGoogle.clientId).trim(), clientSecret: String(bundledGoogle.clientSecret || '').trim() } : null;
    this.openExternal = openExternal || (async () => {});
    this.log = log;
    this.fetch = fetchImpl || ((...a) => fetch(...a));
    this.callbackTimeoutMs = callbackTimeoutMs;
    this.cfgFile = path.join(dir, 'connectors.json');
    this.secFile = path.join(dir, 'connectors.secrets');
    this.cfg = this._readCfg();
    this.secrets = null; // carga perezosa
    this.memSecrets = {}; // respaldo en memoria si no hay cifrado disponible
    this.sessions = new Map(); // id -> { sessionId, initialized }
    this.toolCache = new Map(); // id -> { at, tools }
    this.pending = new Map(); // id -> { server, reject }
  }

  // ── Persistencia ────────────────────────────────────────────────────────────────────────────
  _readCfg() {
    try {
      const j = JSON.parse(fs.readFileSync(this.cfgFile, 'utf8'));
      return { custom: Array.isArray(j.custom) ? j.custom : [], state: j.state && typeof j.state === 'object' ? j.state : {} };
    } catch {
      return { custom: [], state: {} };
    }
  }
  _writeCfg() {
    fs.mkdirSync(this.dir, { recursive: true });
    const tmp = `${this.cfgFile}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.cfg, null, 2));
    fs.renameSync(tmp, this.cfgFile);
  }
  _encOk() {
    try {
      return !!this.safe?.isEncryptionAvailable?.();
    } catch {
      return false;
    }
  }
  _loadSecrets() {
    if (this.secrets) return this.secrets;
    this.secrets = {};
    try {
      const raw = fs.readFileSync(this.secFile);
      if (this._encOk()) this.secrets = JSON.parse(this.safe.decryptString(raw));
    } catch {}
    return this.secrets;
  }
  _saveSecrets() {
    const data = this._loadSecrets();
    if (!this._encOk()) {
      this.memSecrets = { ...data };
      return false;
    }
    fs.mkdirSync(this.dir, { recursive: true });
    const tmp = `${this.secFile}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, this.safe.encryptString(JSON.stringify(data)));
    fs.renameSync(tmp, this.secFile);
    return true;
  }
  _sec(id) {
    return this._loadSecrets()[id] || {};
  }
  _setSec(id, patch) {
    const all = this._loadSecrets();
    all[id] = { ...(all[id] || {}), ...patch };
    return this._saveSecrets();
  }
  _clearSec(id) {
    const all = this._loadSecrets();
    delete all[id];
    this._saveSecrets();
  }

  // ── Catálogo ────────────────────────────────────────────────────────────────────────────────
  _def(id) {
    const b = BUILTIN.find(x => x.id === id);
    if (b) return b.google && this.bundledGoogle ? bundledGoogleDef(b) : b;
    const c = this.cfg.custom.find(x => x.id === id);
    if (c)
      return {
        id: c.id,
        name: c.name,
        category: 'Personalizado',
        description: c.description || 'Servidor MCP personalizado.',
        url: c.url,
        auth: c.token ? 'token' : c.auth || 'oauth-dcr',
        custom: true,
        verified: false,
        fields: c.auth === 'token' ? [{ key: 'token', label: 'Token (Bearer)', secret: true, optional: true }] : [],
        setup: { title: 'Servidor MCP personalizado', steps: ['Auric intentará iniciar sesión por OAuth si el servidor lo pide.'] }
      };
    throw new ConnectorError(`Conector desconocido: ${id}`, 'UNKNOWN');
  }
  _logo(id) {
    if (!this.logosDir) return '';
    for (const ext of ['png', 'svg', 'webp']) {
      const f = path.join(this.logosDir, `${id}.${ext}`);
      if (fs.existsSync(f)) return `./connector-logos/${id}.${ext}`;
    }
    return '';
  }
  catalog() {
    const defs = [...BUILTIN.map(b => this._def(b.id)), ...this.cfg.custom.map(c => this._def(c.id))];
    return defs.map(d => {
      const st = this.cfg.state[d.id] || {};
      const sec = this._sec(d.id);
      const connected = !!st.connected && !!(sec.accessToken || sec.token || d.auth === 'none');
      return {
        id: d.id,
        name: d.name,
        category: d.category,
        description: d.description,
        url: d.url,
        auth: d.auth,
        verified: !!d.verified,
        bundled: !!d.bundled,
        custom: !!d.custom,
        fields: d.fields || [],
        setup: d.setup || null,
        logo: this._logo(d.id),
        connected,
        needsAuth: !!st.needsAuth,
        error: st.error || '',
        connectedAt: st.connectedAt || '',
        toolCount: st.toolCount || 0,
        scopes: d.scopes || [],
        persistentSecrets: this._encOk()
      };
    });
  }
  _state(id, patch) {
    this.cfg.state[id] = { ...(this.cfg.state[id] || {}), ...patch };
    this._writeCfg();
  }

  async addCustom({ name, url, token = '', description = '' } = {}) {
    const clean = assertMcpUrl(url);
    const base = slug(name) || slug(new URL(clean).hostname) || 'servidor';
    let id = `custom-${base}`,
      n = 2;
    while (this.cfg.custom.some(x => x.id === id)) id = `custom-${base}-${n++}`;
    this.cfg.custom.push({
      id,
      name: String(name || base).slice(0, 60),
      url: clean,
      description: String(description || '').slice(0, 200),
      auth: token ? 'token' : 'oauth-dcr'
    });
    this._writeCfg();
    if (token) this._setSec(id, { token: String(token) });
    return this.connect(id, token ? { token } : {});
  }
  async removeCustom(id) {
    await this.disconnect(id).catch(() => {});
    this.cfg.custom = this.cfg.custom.filter(x => x.id !== id);
    delete this.cfg.state[id];
    this._writeCfg();
    return true;
  }

  // ── Conexión ────────────────────────────────────────────────────────────────────────────────
  async connect(id, input = {}) {
    const def = this._def(id);
    this.sessions.delete(id);
    this.toolCache.delete(id);
    try {
      if (def.auth === 'token') {
        const token = String(input.token || this._sec(id).token || '').trim();
        if (!token && !def.fields.every(f => f.optional)) throw new ConnectorError('Falta el token.', 'MISSING_FIELD');
        if (token) this._setSec(id, { token });
      } else if (def.auth === 'oauth-client') {
        const clientId = String(input.clientId || this._sec(id).clientId || this.bundledGoogle?.clientId || '').trim();
        const clientSecret = String(input.clientSecret ?? this._sec(id).clientSecret ?? this.bundledGoogle?.clientSecret ?? '').trim();
        if (!clientId) throw new ConnectorError('Falta el Client ID de Google Cloud.', 'MISSING_FIELD');
        const tokens = await this._oauthFlow(def, { clientId, clientSecret });
        this._setSec(id, { clientId, clientSecret, ...tokens });
      } else if (def.auth === 'oauth-dcr') {
        const tokens = await this._oauthFlow(def, {});
        this._setSec(id, tokens);
      }
      // Validación real: initialize + tools/list
      const tools = await this.listTools(id, true);
      this._state(id, { connected: true, needsAuth: false, error: '', connectedAt: new Date().toISOString(), toolCount: tools.length });
      return { id, connected: true, toolCount: tools.length, persistentSecrets: this._encOk() };
    } catch (err) {
      this._state(id, { connected: false, error: redact(err.message).slice(0, 400) });
      throw err;
    }
  }
  cancelPending(id) {
    const p = this.pending.get(id);
    if (!p) return false;
    p.reject(new ConnectorError('Conexión cancelada.', 'CANCELLED'));
    return true;
  }
  async disconnect(id) {
    this.cancelPending(id);
    this.sessions.delete(id);
    this.toolCache.delete(id);
    const def = this._def(id);
    if (def.auth.startsWith('oauth')) this._clearSec(id);
    else this._clearSec(id);
    this._state(id, { connected: false, needsAuth: false, error: '', toolCount: 0 });
    return true;
  }

  // ── OAuth ───────────────────────────────────────────────────────────────────────────────────
  async _json(url, init = {}) {
    const res = await this.fetch(url, { ...init, headers: { Accept: 'application/json', ...(init.headers || {}) } });
    const text = await res.text();
    let body = null;
    try {
      body = JSON.parse(text);
    } catch {}
    return { res, text, body };
  }
  async _discover(def) {
    const mcp = new URL(def.url);
    let prm = null;
    // 1) cabecera WWW-Authenticate
    try {
      const probe = await this.fetch(def.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json, text/event-stream' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: 0,
          method: 'initialize',
          params: { protocolVersion: PROTOCOL_VERSION, capabilities: {}, clientInfo: CLIENT_INFO }
        })
      });
      const www = probe.headers.get('www-authenticate') || '';
      const m = www.match(/resource_metadata="([^"]+)"/i);
      if (m) prm = (await this._json(m[1])).body;
      try {
        await probe.arrayBuffer();
      } catch {}
    } catch {}
    // 2) well-known (RFC 9728), con y sin path
    if (!prm) {
      for (const u of [
        `${mcp.origin}/.well-known/oauth-protected-resource${mcp.pathname.replace(/\/$/, '')}`,
        `${mcp.origin}/.well-known/oauth-protected-resource`
      ]) {
        const r = await this._json(u).catch(() => null);
        if (r?.res.ok && r.body?.authorization_servers) {
          prm = r.body;
          break;
        }
      }
    }
    const issuer = prm?.authorization_servers?.[0] || mcp.origin;
    const iu = new URL(issuer);
    const candidates = [
      `${iu.origin}/.well-known/oauth-authorization-server${iu.pathname.replace(/\/$/, '')}`,
      `${iu.origin}/.well-known/oauth-authorization-server`,
      `${iu.origin}/.well-known/openid-configuration${iu.pathname.replace(/\/$/, '')}`,
      `${iu.origin}/.well-known/openid-configuration`
    ];
    for (const u of candidates) {
      const r = await this._json(u).catch(() => null);
      if (r?.res.ok && r.body?.authorization_endpoint && r.body?.token_endpoint) return { as: r.body, resource: prm?.resource || def.url };
    }
    throw new ConnectorError('No se pudo descubrir el servidor de autorización OAuth de este conector.', 'OAUTH_DISCOVERY');
  }
  async _register(as, redirectUri) {
    if (!as.registration_endpoint)
      throw new ConnectorError('Este servicio no permite registro automático de clientes (DCR).', 'OAUTH_NO_DCR');
    const r = await this._json(as.registration_endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client_name: 'Auric Code',
        redirect_uris: [redirectUri],
        grant_types: ['authorization_code', 'refresh_token'],
        response_types: ['code'],
        token_endpoint_auth_method: 'none'
      })
    });
    if (!r.res.ok || !r.body?.client_id) throw new ConnectorError(`El registro del cliente OAuth falló (${r.res.status}).`, 'OAUTH_DCR');
    return { clientId: r.body.client_id, clientSecret: r.body.client_secret || '' };
  }
  // Abre el receptor loopback. Devuelve { port, code } : `port` ya está escuchando, `code` resuelve con el código OAuth.
  async _listenForCode(id, port, expectedState) {
    let finish;
    const code = new Promise((resolve, reject) => {
      let done = false,
        server = null;
      const timer = setTimeout(
        () => finish(new ConnectorError('Se agotó el tiempo para autorizar (5 min).', 'OAUTH_TIMEOUT')),
        this.callbackTimeoutMs
      );
      finish = (err, value) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        this.pending.delete(id);
        try {
          server?.close();
          server?.closeAllConnections?.();
        } catch {}
        err ? reject(err) : resolve(value);
      };
      server = http.createServer((req, res) => {
        const u = new URL(req.url, 'http://127.0.0.1');
        if (u.pathname !== '/callback') {
          res.statusCode = 404;
          return res.end();
        }
        const c = u.searchParams.get('code'),
          st = u.searchParams.get('state'),
          err = u.searchParams.get('error');
        res.setHeader('content-type', 'text/html; charset=utf-8');
        const page = (t, m) =>
          `<!doctype html><meta charset="utf-8"><title>Auric Code</title><body style="font-family:system-ui;background:#0b0e13;color:#e8ecf2;display:grid;place-items:center;height:100vh;margin:0"><div style="text-align:center"><h2>${t}</h2><p>${m}</p></div>`;
        if (err || !c || st !== expectedState) {
          res.statusCode = 400;
          res.end(page('No se pudo conectar', 'Puedes cerrar esta pestaña y volver a Auric Code.'));
          return finish(
            new ConnectorError(err ? `El servicio rechazó la autorización: ${err}` : 'Respuesta OAuth inválida (state).', 'OAUTH_DENIED')
          );
        }
        res.end(page('Conectado', 'Ya puedes cerrar esta pestaña y volver a Auric Code.'));
        finish(null, c);
      });
      this._pendingServer = server;
      server.on('error', e =>
        finish(
          new ConnectorError(
            e.code === 'EADDRINUSE'
              ? `El puerto ${port} está ocupado; cierra otras conexiones en curso e inténtalo de nuevo.`
              : `No se pudo abrir el receptor local: ${e.message}`,
            'OAUTH_PORT'
          )
        )
      );
      this.pending.set(id, { reject: e => finish(e) });
    });
    code.catch(() => {});
    const server = this._pendingServer;
    await new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(port, '127.0.0.1', resolve);
    }).catch(async e => {
      this.pending
        .get(id)
        ?.reject(
          new ConnectorError(
            e.code === 'EADDRINUSE'
              ? `El puerto ${port} está ocupado; cierra otras conexiones en curso e inténtalo de nuevo.`
              : String(e.message),
            'OAUTH_PORT'
          )
        );
      await code;
    });
    return { port: server.address().port, code };
  }
  async _oauthFlow(def, client) {
    const id = def.id;
    this.cancelPending(id);
    let as, resource, clientId, clientSecret;
    const fixedPort = def.google ? GOOGLE_REDIRECT_PORT : 0;
    if (def.google) {
      as = { authorization_endpoint: GOOGLE_AUTH, token_endpoint: GOOGLE_TOKEN };
      resource = '';
      clientId = client.clientId;
      clientSecret = client.clientSecret || '';
    } else {
      ({ as, resource } = await this._discover(def));
    }
    const verifier = b64url(crypto.randomBytes(48)),
      challenge = b64url(sha256(verifier)),
      state = b64url(crypto.randomBytes(18));
    // Se abre primero el receptor para conocer el puerto real (DCR necesita la redirect_uri exacta).
    const { port, code: codePromise } = await this._listenForCode(id, fixedPort, state);
    const redirectUri = `http://127.0.0.1:${port}/callback`;
    try {
      if (!def.google) ({ clientId, clientSecret } = await this._register(as, redirectUri));
      const q = new URLSearchParams({
        response_type: 'code',
        client_id: clientId,
        redirect_uri: redirectUri,
        code_challenge: challenge,
        code_challenge_method: 'S256',
        state
      });
      if (def.scopes?.length) q.set('scope', def.scopes.join(' '));
      if (def.google) {
        q.set('access_type', 'offline');
        q.set('prompt', 'consent');
      } else if (resource) q.set('resource', resource);
      const authUrl = `${as.authorization_endpoint}${as.authorization_endpoint.includes('?') ? '&' : '?'}${q}`;
      await this.openExternal(authUrl);
      const code = await codePromise;
      const form = new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: redirectUri,
        client_id: clientId,
        code_verifier: verifier
      });
      if (clientSecret) form.set('client_secret', clientSecret);
      if (!def.google && resource) form.set('resource', resource);
      const tok = await this._tokenRequest(as.token_endpoint, form);
      return { ...tok, clientId, clientSecret, tokenEndpoint: as.token_endpoint, resource: resource || '' };
    } catch (err) {
      this.cancelPending(id);
      throw err;
    }
  }
  async _tokenRequest(endpoint, form) {
    const r = await this._json(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form.toString()
    });
    if (!r.res.ok || !r.body?.access_token) {
      const detail = r.body?.error_description || r.body?.error || r.text.slice(0, 200);
      throw new ConnectorError(
        `El intercambio de tokens falló (${r.res.status}): ${redact(detail)}`,
        r.body?.error === 'invalid_grant' ? 'OAUTH_INVALID_GRANT' : 'OAUTH_TOKEN'
      );
    }
    return {
      accessToken: r.body.access_token,
      refreshToken: r.body.refresh_token || '',
      expiresAt: r.body.expires_in ? nowSec() + Number(r.body.expires_in) - 30 : 0
    };
  }
  async _refresh(id) {
    const s = this._sec(id);
    if (!s.refreshToken || !s.tokenEndpoint) return false;
    const form = new URLSearchParams({ grant_type: 'refresh_token', refresh_token: s.refreshToken, client_id: s.clientId || '' });
    if (s.clientSecret) form.set('client_secret', s.clientSecret);
    if (s.resource) form.set('resource', s.resource);
    try {
      const tok = await this._tokenRequest(s.tokenEndpoint, form);
      this._setSec(id, { accessToken: tok.accessToken, expiresAt: tok.expiresAt, refreshToken: tok.refreshToken || s.refreshToken });
      return true;
    } catch (e) {
      if (e.code === 'OAUTH_INVALID_GRANT') this._state(id, { needsAuth: true, error: 'La sesión caducó; vuelve a conectar.' });
      return false;
    }
  }

  // ── MCP (Streamable HTTP) ───────────────────────────────────────────────────────────────────
  _authHeader(id) {
    const s = this._sec(id);
    const t = s.accessToken || s.token;
    return t ? { Authorization: `Bearer ${t}` } : {};
  }
  async _post(id, def, payload, { retryAuth = true, retrySession = true } = {}) {
    const sess = this.sessions.get(id) || {};
    const s = this._sec(id);
    if (s.accessToken && s.expiresAt && s.expiresAt < nowSec() && s.refreshToken) await this._refresh(id);
    const headers = {
      'Content-Type': 'application/json',
      Accept: 'application/json, text/event-stream',
      'MCP-Protocol-Version': PROTOCOL_VERSION,
      ...this._authHeader(id)
    };
    if (sess.sessionId) headers['Mcp-Session-Id'] = sess.sessionId;
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 60000);
    let res;
    try {
      res = await this.fetch(def.url, { method: 'POST', headers, body: JSON.stringify(payload), signal: ctl.signal });
    } catch (e) {
      clearTimeout(timer);
      throw new ConnectorError(
        e.name === 'AbortError' ? 'El servidor MCP no respondió a tiempo.' : `No se pudo conectar con ${def.name}: ${e.message}`,
        'NETWORK'
      );
    }
    try {
      if (res.status === 401 || res.status === 403) {
        if (retryAuth && res.status === 401 && (await this._refresh(id)))
          return await this._post(id, def, payload, { retryAuth: false, retrySession });
        this._state(id, { needsAuth: true });
        throw new ConnectorError(`${def.name} rechazó la sesión. Vuelve a conectar el servicio.`, 'AUTH_REQUIRED');
      }
      if (res.status === 404 && sess.sessionId && retrySession && payload.method !== 'initialize') {
        this.sessions.delete(id);
        await this._initialize(id, def);
        return await this._post(id, def, payload, { retryAuth, retrySession: false });
      }
      if (res.status === 202 || res.status === 204) return { notification: true, res };
      if (!res.ok) {
        const text = (await res.text()).slice(0, 400);
        throw new ConnectorError(`${def.name} respondió HTTP ${res.status}: ${redact(text)}`, res.status === 429 ? 'RATE_LIMIT' : 'HTTP');
      }
      const sid = res.headers.get('mcp-session-id');
      if (sid) this.sessions.set(id, { ...(this.sessions.get(id) || {}), sessionId: sid });
      const type = (res.headers.get('content-type') || '').toLowerCase();
      const text = await res.text();
      if (type.includes('text/event-stream')) {
        let found = null;
        for (const block of text.split(/\r?\n\r?\n/)) {
          const data = block
            .split(/\r?\n/)
            .filter(l => l.startsWith('data:'))
            .map(l => l.slice(5).trimStart())
            .join('\n');
          if (!data) continue;
          try {
            const m = JSON.parse(data);
            if (m.id === payload.id && (m.result !== undefined || m.error)) found = m;
          } catch {}
        }
        if (!found) throw new ConnectorError('Respuesta SSE sin resultado.', 'PROTOCOL');
        return found;
      }
      try {
        return JSON.parse(text);
      } catch {
        throw new ConnectorError('Respuesta no válida del servidor MCP.', 'PROTOCOL');
      }
    } finally {
      clearTimeout(timer);
    }
  }
  async _initialize(id, def) {
    this.sessions.set(id, {});
    const init = await this._post(
      id,
      def,
      {
        jsonrpc: '2.0',
        id: 1,
        method: 'initialize',
        params: { protocolVersion: PROTOCOL_VERSION, capabilities: {}, clientInfo: CLIENT_INFO }
      },
      { retrySession: false }
    );
    if (init.error) throw new ConnectorError(`initialize falló: ${init.error.message}`, 'PROTOCOL');
    await this._post(id, def, { jsonrpc: '2.0', method: 'notifications/initialized' }, { retrySession: false }).catch(() => {});
    this.sessions.set(id, { ...(this.sessions.get(id) || {}), initialized: true, server: init.result?.serverInfo || null });
    return init.result;
  }
  async _rpc(id, method, params) {
    const def = this._def(id);
    if (!this.sessions.get(id)?.initialized) await this._initialize(id, def);
    const r = await this._post(id, def, { jsonrpc: '2.0', id: Date.now() % 1e9, method, params });
    if (r.error) throw new ConnectorError(`${method}: ${r.error.message || 'error MCP'}`, 'MCP_ERROR', { mcpCode: r.error.code });
    return r.result;
  }
  async listTools(id, force = false) {
    const hit = this.toolCache.get(id);
    if (!force && hit && Date.now() - hit.at < 5 * 60 * 1000) return hit.tools;
    const tools = [];
    let cursor;
    for (let i = 0; i < 20; i++) {
      const r = await this._rpc(id, 'tools/list', cursor ? { cursor } : {});
      for (const t of r.tools || [])
        tools.push({
          name: String(t.name),
          description: String(t.description || '').slice(0, 600),
          inputSchema: t.inputSchema || { type: 'object', properties: {} },
          annotations: t.annotations || {}
        });
      cursor = r.nextCursor;
      if (!cursor) break;
    }
    this.toolCache.set(id, { at: Date.now(), tools });
    if (this.cfg.state[id]) this._state(id, { toolCount: tools.length });
    return tools;
  }
  async health(id) {
    const t0 = Date.now();
    try {
      const tools = await this.listTools(id, true);
      this._state(id, { connected: true, needsAuth: false, error: '', toolCount: tools.length });
      return { ok: true, ms: Date.now() - t0, toolCount: tools.length };
    } catch (e) {
      this._state(id, { error: redact(e.message).slice(0, 300) });
      return { ok: false, ms: Date.now() - t0, error: e.message, code: e.code };
    }
  }
  async callTool(id, name, args = {}) {
    if (!this.cfg.state[id]?.connected) throw new ConnectorError('El conector no está conectado.', 'NOT_CONNECTED');
    const tools = await this.listTools(id);
    if (!tools.some(t => t.name === name)) throw new ConnectorError(`El conector no tiene la herramienta "${name}".`, 'UNKNOWN_TOOL');
    const r = await this._rpc(id, 'tools/call', { name, arguments: args && typeof args === 'object' ? args : {} });
    const text = (r.content || [])
      .map(c =>
        c.type === 'text'
          ? c.text
          : c.type === 'resource'
            ? c.resource?.text || `[recurso ${c.resource?.uri || ''}]`
            : `[${c.type || 'contenido'} no textual]`
      )
      .join('\n');
    return { isError: !!r.isError, text: text.slice(0, 60000), structured: r.structuredContent || null };
  }
}

module.exports = {
  ConnectorManager,
  ConnectorError,
  BUILTIN_CONNECTORS: BUILTIN,
  GOOGLE_REDIRECT_PORT,
  _test: { assertMcpUrl, redact, b64url }
};
