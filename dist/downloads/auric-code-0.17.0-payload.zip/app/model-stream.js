'use strict';
// Respuestas de los modelos "por partes" (streaming SSE).
//
// Por qué existe: una respuesta larga tarda en generarse. Si se espera TODA de golpe (sin streaming), cualquier servidor o puerta
// intermedia que se canse de esperar corta la conexión (NVIDIA responde 504 pasados ~5 minutos sin datos, otras puertas cortan antes),
// y la persona ve «el modelo se cortó con un error» aunque el modelo iba bien. Con streaming llegan datos todo el rato, así que:
//   · el tiempo máximo es «tiempo SIN recibir nada» (no el tiempo total de la respuesta);
//   · si la conexión se cae a mitad, lo que ya llegó se conserva (texto parcial) y Auric puede continuar desde ahí;
//   · se distingue «terminó bien» de «se cortó» (un flujo sin marca de fin NUNCA se da por bueno);
//   · cada servicio explica su error con su nombre.
//
// Este módulo no toca la interfaz: lee el flujo SSE, lo junta en el MISMO JSON que habría devuelto la llamada sin streaming (así el resto
// de la app no cambia) y devuelve además cómo terminó. Es puro y se prueba con servidores falsos que se portan mal a propósito.

const MAX_EVENT_BYTES = 24 * 1024 * 1024; // un evento SSE suelto jamás debería pasar de esto
const MAX_BODY_BYTES = 96 * 1024 * 1024; // tope de todo lo que se lee de una respuesta
const ERROR_BODY_BYTES = 1024 * 1024; // de un error HTTP solo hace falta el principio

const tryJson = text => {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
};
const str = v => (typeof v === 'string' ? v : v == null ? '' : String(v));
const asArray = v => (Array.isArray(v) ? v : v == null ? [] : [v]);

// ── Lector SSE ────────────────────────────────────────────────────────────────────────────────────────────────
// Sigue la especificación: líneas separadas por \n, \r\n o \r; una línea vacía cierra el evento; las que empiezan por «:» son comentarios
// (los servidores las usan para mantener viva la conexión: cuentan como actividad aunque no traigan datos).
class SseParser {
  constructor(onEvent) {
    this.onEvent = onEvent;
    this.decoder = new TextDecoder('utf-8');
    this.buf = '';
    this.event = '';
    this.data = [];
    this.sawField = false;
    this.skipLf = false; // «\r» acaba de cerrar una línea: si llega «\n» justo después, es parte del mismo salto
    this.eventBytes = 0;
  }
  push(chunk) {
    this.consume(typeof chunk === 'string' ? chunk : this.decoder.decode(chunk, { stream: true }));
  }
  end() {
    this.consume(this.decoder.decode());
    if (this.buf) this.line(this.buf);
    this.buf = '';
    this.dispatch();
  }
  consume(text) {
    if (!text) return;
    let s = this.buf + text;
    this.buf = '';
    if (this.skipLf) {
      if (s[0] === '\n') s = s.slice(1);
      this.skipLf = false;
    }
    let start = 0;
    for (let i = 0; i < s.length; i++) {
      const ch = s.charCodeAt(i);
      if (ch !== 10 && ch !== 13) continue;
      this.line(s.slice(start, i));
      if (ch === 13) {
        if (s.charCodeAt(i + 1) === 10) i++;
        else if (i + 1 >= s.length) this.skipLf = true;
      }
      start = i + 1;
    }
    this.buf = s.slice(start);
    if (this.buf.length > MAX_EVENT_BYTES) throw new Error('STREAM_TOO_LARGE: un evento del servidor es demasiado grande.');
  }
  line(l) {
    if (l === '') return this.dispatch();
    if (l[0] === ':') return; // comentario / latido
    const i = l.indexOf(':');
    const field = i < 0 ? l : l.slice(0, i);
    let value = i < 0 ? '' : l.slice(i + 1);
    if (value[0] === ' ') value = value.slice(1);
    if (field === 'data') {
      this.data.push(value);
      this.sawField = true;
      this.eventBytes += value.length;
      if (this.eventBytes > MAX_EVENT_BYTES) throw new Error('STREAM_TOO_LARGE: un evento del servidor es demasiado grande.');
    } else if (field === 'event') {
      this.event = value;
      this.sawField = true;
    }
  }
  dispatch() {
    if (this.sawField && (this.data.length || this.event)) this.onEvent({ event: this.event || 'message', data: this.data.join('\n') });
    this.event = '';
    this.data = [];
    this.sawField = false;
    this.eventBytes = 0;
  }
}

// ── Errores que llegan DENTRO del flujo ────────────────────────────────────────────────────────────────────────
// Se convierten al estado HTTP equivalente para que la app los clasifique igual que un error normal (saturado, cuota, clave…).
const STATUS_BY_NAME = {
  overloaded_error: 529,
  overloaded: 529,
  engine_overloaded: 503,
  model_overloaded: 503,
  unavailable: 503,
  service_unavailable: 503,
  server_is_overloaded: 503,
  rate_limit_error: 429,
  rate_limit_exceeded: 429,
  rate_limited: 429,
  resource_exhausted: 429,
  insufficient_quota: 429,
  quota_exceeded: 429,
  too_many_requests: 429,
  authentication_error: 401,
  unauthenticated: 401,
  invalid_api_key: 401,
  permission_error: 403,
  permission_denied: 403,
  not_found_error: 404,
  not_found: 404,
  invalid_request_error: 400,
  invalid_argument: 400,
  bad_request: 400,
  request_too_large: 413,
  deadline_exceeded: 504,
  timeout: 504,
  gateway_timeout: 504,
  api_error: 500,
  server_error: 500,
  internal: 500,
  internal_error: 500
};
function errorInfo(raw, whole = {}) {
  const e = raw && typeof raw === 'object' ? raw : { message: str(raw) };
  // El nombre del error puede venir en «status» (Google), «type» (OpenAI, Anthropic) o «code»; el valor «error» solo dice que es un error.
  const names = [e.status, e.type, e.code].map(x => str(x).toLowerCase()).filter(x => x && x !== 'error');
  const name = names.find(x => STATUS_BY_NAME[x]) || names[0] || '';
  const num = Number(e.code ?? e.status ?? whole.status ?? whole.code);
  const status = STATUS_BY_NAME[name] || (Number.isInteger(num) && num >= 400 && num <= 599 ? num : 0) || 502;
  return { message: str(e.message || e.error || whole.message || 'El servidor devolvió un error durante la respuesta.').slice(0, 1500), name, status, raw: e };
}

// ── Agregadores: juntan los trozos y reconstruyen el JSON de la respuesta completa ─────────────────────────────
// Cada uno devuelve { push(evt), finish(), stats() }.
//   finish() → { json, terminal, error, hasContent }
//     json      el mismo cuerpo que habría devuelto el servicio sin streaming (con lo recibido hasta el momento)
//     terminal  el servidor dijo que terminó (marca de fin / motivo de fin)
//     error     error recibido dentro del flujo, si lo hubo
//   stats() → { chars, thoughtChars, toolCalls }

// Chat Completions (OpenAI y casi todos los demás: NVIDIA, Groq, OpenRouter, DeepSeek, Mistral, Kimi, Hugging Face…)
function openAiChatAggregator() {
  const st = { id: '', model: '', created: 0, content: '', reasoningContent: '', reasoning: '', details: [], calls: [], finish: '', usage: null, terminal: false, error: null };
  const callAt = (tc, pos) => {
    // Lo normal es «index»; algunos servicios lo omiten: se reconoce la llamada por su id o, si no, por la última abierta.
    if (Number.isInteger(tc.index)) {
      // Dos llamadas con el mismo «index» pero ids distintos son dos llamadas (algunos servicios se equivocan con el index).
      let c = st.calls.find(x => x.index === tc.index && (!tc.id || !x.id || x.id === tc.id));
      if (!c) st.calls.push((c = { index: tc.index, id: '', name: '', args: '' }));
      return c;
    }
    if (tc.id) {
      let c = st.calls.find(x => x.id === tc.id);
      if (!c) st.calls.push((c = { index: st.calls.length, id: tc.id, name: '', args: '' }));
      return c;
    }
    if (st.calls.length) return st.calls[st.calls.length - 1];
    st.calls.push({ index: pos, id: '', name: '', args: '' });
    return st.calls[0];
  };
  const text = v =>
    typeof v === 'string'
      ? v
      : Array.isArray(v)
        ? v.map(text).join('')
        : v && typeof v === 'object'
          ? str(v.text ?? v.content ?? '')
          : '';
  return {
    push({ data }) {
      if (data === '[DONE]') {
        st.terminal = true;
        return;
      }
      const j = tryJson(data);
      if (!j || typeof j !== 'object') return;
      if (j.error) {
        st.error = errorInfo(j.error, j);
        return;
      }
      if (j.id) st.id = j.id;
      if (j.model) st.model = j.model;
      if (j.created) st.created = j.created;
      if (j.usage) st.usage = j.usage;
      const ch = j.choices?.[0];
      if (!ch) return;
      const d = ch.delta || ch.message || {};
      if (d.content != null) st.content += text(d.content);
      if (typeof d.reasoning_content === 'string') st.reasoningContent += d.reasoning_content;
      if (typeof d.reasoning === 'string') st.reasoning += d.reasoning;
      if (Array.isArray(d.reasoning_details)) st.details.push(...d.reasoning_details);
      asArray(d.tool_calls).forEach((tc, pos) => {
        if (!tc || typeof tc !== 'object') return;
        const c = callAt(tc, pos);
        if (tc.id) c.id = tc.id;
        const fn = tc.function || {};
        if (fn.name) c.name = c.name && c.name !== fn.name ? c.name + fn.name : fn.name; // el nombre casi siempre llega entero, de una vez
        if (fn.arguments != null) c.args += typeof fn.arguments === 'string' ? fn.arguments : JSON.stringify(fn.arguments);
      });
      if (d.function_call && typeof d.function_call === 'object') {
        const c = st.calls[0] || (st.calls.push({ index: 0, id: '', name: '', args: '' }), st.calls[0]);
        if (d.function_call.name) c.name = d.function_call.name;
        if (d.function_call.arguments != null) c.args += str(d.function_call.arguments);
      }
      if (ch.finish_reason) {
        st.finish = ch.finish_reason;
        st.terminal = true;
      }
    },
    finish() {
      const calls = st.calls.filter(c => c.name);
      const message = { role: 'assistant', content: st.content || (calls.length ? null : '') };
      if (st.reasoningContent) message.reasoning_content = st.reasoningContent;
      if (st.reasoning) message.reasoning = st.reasoning;
      if (st.details.length) message.reasoning_details = st.details;
      if (calls.length)
        message.tool_calls = calls.map((c, i) => ({ id: c.id || `call_${i + 1}`, type: 'function', function: { name: c.name, arguments: c.args } }));
      const json = { id: st.id || undefined, object: 'chat.completion', created: st.created || undefined, model: st.model || undefined, choices: [{ index: 0, message, finish_reason: st.finish || null }] };
      if (st.usage) json.usage = st.usage;
      return { json, terminal: st.terminal, error: st.error, hasContent: !!(st.content || calls.length) };
    },
    stats: () => ({ chars: st.content.length, thoughtChars: st.reasoningContent.length + st.reasoning.length, reasoningPreview: (st.reasoningContent || st.reasoning).slice(-64000), toolCalls: st.calls.length })
  };
}

// Google Gemini (streamGenerateContent con alt=sse): cada evento es una respuesta parcial completa con sus «parts».
function geminiAggregator() {
  const st = { parts: [], finish: '', usage: null, modelVersion: '', responseId: '', promptFeedback: null, safety: null, terminal: false, error: null, chars: 0, thought: 0, calls: 0 };
  return {
    push({ data }) {
      const j = tryJson(data);
      if (!j || typeof j !== 'object') return;
      if (j.error) {
        st.error = errorInfo(j.error, j);
        return;
      }
      if (j.usageMetadata) st.usage = j.usageMetadata;
      if (j.modelVersion) st.modelVersion = j.modelVersion;
      if (j.responseId) st.responseId = j.responseId;
      if (j.promptFeedback) {
        st.promptFeedback = j.promptFeedback;
        if (j.promptFeedback.blockReason && !j.candidates?.length) st.terminal = true; // pedido bloqueado: no vendrá nada más
      }
      const cand = j.candidates?.[0];
      if (!cand) return;
      for (const part of asArray(cand.content?.parts)) {
        if (!part || typeof part !== 'object') continue;
        const last = st.parts[st.parts.length - 1];
        const plain = typeof part.text === 'string' && !part.functionCall && !part.inlineData;
        if (plain && last && typeof last.text === 'string' && !last.functionCall && !!last.thought === !!part.thought) {
          last.text += part.text;
          if (part.thoughtSignature) last.thoughtSignature = part.thoughtSignature;
        } else st.parts.push({ ...part });
        if (plain) part.thought ? (st.thought += part.text.length) : (st.chars += part.text.length);
        if (part.functionCall) st.calls++;
      }
      if (cand.safetyRatings) st.safety = cand.safetyRatings;
      if (cand.finishReason && cand.finishReason !== 'FINISH_REASON_UNSPECIFIED') {
        st.finish = cand.finishReason;
        st.terminal = true;
      }
    },
    finish() {
      const cand = { content: { role: 'model', parts: st.parts }, finishReason: st.finish || undefined, index: 0 };
      if (st.safety) cand.safetyRatings = st.safety;
      const json = { candidates: st.parts.length || st.finish ? [cand] : [] };
      if (st.usage) json.usageMetadata = st.usage;
      if (st.modelVersion) json.modelVersion = st.modelVersion;
      if (st.responseId) json.responseId = st.responseId;
      if (st.promptFeedback) json.promptFeedback = st.promptFeedback;
      return { json, terminal: st.terminal, error: st.error, hasContent: st.parts.some(p => (typeof p.text === 'string' && p.text && !p.thought) || p.functionCall) };
    },
    stats: () => ({ chars: st.chars, thoughtChars: st.thought, reasoningPreview: st.parts.filter(p => p.thought && typeof p.text === 'string').map(p => p.text).join('\n').slice(-64000), toolCalls: st.calls })
  };
}

// Anthropic Claude (/messages con stream:true): message_start, content_block_*, message_delta, message_stop.
function anthropicAggregator() {
  const st = { message: null, blocks: [], stop: '', usage: null, terminal: false, error: null, chars: 0, thought: 0 };
  const block = i => st.blocks[i] || (st.blocks[i] = { type: 'text', text: '' });
  return {
    push({ event, data }) {
      const j = tryJson(data);
      if (!j || typeof j !== 'object') return;
      const type = j.type || event;
      if (type === 'error' || event === 'error') {
        st.error = errorInfo(j.error || j, j);
        return;
      }
      if (type === 'message_start') {
        st.message = j.message || {};
        if (j.message?.usage) st.usage = { ...j.message.usage };
      } else if (type === 'content_block_start') {
        const b = { ...(j.content_block || {}) };
        if (b.type === 'tool_use' || b.type === 'server_tool_use') b._json = '';
        if (b.type === 'text' && b.text == null) b.text = '';
        if (b.type === 'thinking' && b.thinking == null) b.thinking = '';
        st.blocks[j.index ?? st.blocks.length] = b;
      } else if (type === 'content_block_delta') {
        const b = block(j.index ?? Math.max(0, st.blocks.length - 1)),
          d = j.delta || {};
        if (d.type === 'text_delta') {
          b.text = (b.text || '') + str(d.text);
          st.chars += str(d.text).length;
        } else if (d.type === 'input_json_delta') b._json = (b._json || '') + str(d.partial_json);
        else if (d.type === 'thinking_delta') {
          b.thinking = (b.thinking || '') + str(d.thinking);
          st.thought += str(d.thinking).length;
        } else if (d.type === 'signature_delta') b.signature = str(d.signature);
      } else if (type === 'message_delta') {
        if (j.delta?.stop_reason) {
          st.stop = j.delta.stop_reason;
          st.terminal = true;
        }
        if (j.usage) st.usage = { ...(st.usage || {}), ...j.usage };
      } else if (type === 'message_stop') st.terminal = true;
    },
    finish() {
      const content = st.blocks.filter(Boolean).map(b => {
        if (b.type === 'tool_use' || b.type === 'server_tool_use') {
          const { _json, ...rest } = b;
          return { ...rest, input: _json ? tryJson(_json) || { _incomplete: _json } : rest.input || {} };
        }
        const { _json, ...rest } = b;
        return rest;
      });
      const json = { ...(st.message || {}), type: 'message', role: 'assistant', content, stop_reason: st.stop || null };
      if (st.usage) json.usage = st.usage;
      return { json, terminal: st.terminal, error: st.error, hasContent: content.some(b => (b.type === 'text' && b.text) || b.type === 'tool_use') };
    },
    stats: () => ({ chars: st.chars, thoughtChars: st.thought, reasoningPreview: st.blocks.filter(b => b?.type === 'thinking').map(b => b.thinking || '').join('\n').slice(-64000), toolCalls: st.blocks.filter(b => b?.type === 'tool_use').length })
  };
}

// OpenAI Responses (/responses con stream:true): el último evento trae la respuesta completa; si el flujo se corta, se rehace con lo recibido.
function openAiResponsesAggregator() {
  const st = { final: null, items: new Map(), text: '', terminal: false, error: null, chars: 0, calls: 0, status: '' };
  return {
    push({ event, data }) {
      const j = tryJson(data);
      if (!j || typeof j !== 'object') return;
      const type = j.type || event;
      if (type === 'error' || (type === 'response.failed' && !j.response?.output?.length)) {
        const e = type === 'error' ? j : j.response?.error || j;
        st.error = errorInfo(e, j);
        if (type === 'response.failed') st.terminal = true;
        return;
      }
      if (type === 'response.output_text.delta') {
        st.text += str(j.delta);
        st.chars += str(j.delta).length;
      } else if (type === 'response.output_item.added' || type === 'response.output_item.done') {
        if (j.item) st.items.set(j.output_index ?? j.item.id ?? st.items.size, j.item);
        if (type === 'response.output_item.done' && j.item?.type === 'function_call') st.calls++;
      } else if (type === 'response.function_call_arguments.delta') {
        const it = st.items.get(j.output_index);
        if (it) it.arguments = str(it.arguments) + str(j.delta);
      } else if (type === 'response.completed' || type === 'response.incomplete' || type === 'response.failed') {
        st.final = j.response || null;
        st.status = j.response?.status || (type === 'response.completed' ? 'completed' : type === 'response.incomplete' ? 'incomplete' : 'failed');
        st.terminal = true;
      }
    },
    finish() {
      let json = st.final;
      if (!json) json = { object: 'response', status: 'incomplete', output: [...st.items.values()], output_text: st.text || undefined };
      const hasText = !!(json.output_text || asArray(json.output).some(o => asArray(o?.content).some(c => c?.text)) || st.text);
      return { json, terminal: st.terminal, error: st.error, hasContent: hasText || asArray(json.output).some(o => o?.type === 'function_call') };
    },
    stats: () => ({ chars: st.chars, thoughtChars: 0, toolCalls: st.calls })
  };
}

// Cohere v2 (/chat con stream:true): message-start, content-delta, tool-call-*, message-end.
function cohereAggregator() {
  const st = { id: '', text: '', plan: '', calls: [], finish: '', usage: null, terminal: false, error: null };
  return {
    push({ event, data }) {
      const j = tryJson(data);
      if (!j || typeof j !== 'object') return;
      const type = j.type || event;
      if (type === 'error') {
        st.error = errorInfo(j.error || j, j);
        return;
      }
      const msg = j.delta?.message || {};
      if (type === 'message-start') st.id = j.id || st.id;
      else if (type === 'content-delta') st.text += str(msg.content?.text);
      else if (type === 'tool-plan-delta') st.plan += str(msg.tool_plan);
      else if (type === 'tool-call-start') {
        const tc = msg.tool_calls || {};
        st.calls[j.index ?? st.calls.length] = { id: tc.id || '', type: 'function', function: { name: tc.function?.name || '', arguments: str(tc.function?.arguments) } };
      } else if (type === 'tool-call-delta') {
        const c = st.calls[j.index ?? st.calls.length - 1];
        if (c) c.function.arguments += str(msg.tool_calls?.function?.arguments);
      } else if (type === 'message-end') {
        st.finish = j.delta?.finish_reason || 'COMPLETE';
        if (j.delta?.usage) st.usage = j.delta.usage;
        st.terminal = true;
      }
    },
    finish() {
      const calls = st.calls.filter(c => c?.function?.name);
      const message = { role: 'assistant', content: st.text ? [{ type: 'text', text: st.text }] : [] };
      if (st.plan) message.tool_plan = st.plan;
      if (calls.length) message.tool_calls = calls;
      return { json: { id: st.id || undefined, message, finish_reason: st.finish || null, usage: st.usage || undefined }, terminal: st.terminal, error: st.error, hasContent: !!(st.text || calls.length) };
    },
    stats: () => ({ chars: st.text.length, thoughtChars: st.plan.length, reasoningPreview: st.plan.slice(-64000), toolCalls: st.calls.filter(Boolean).length })
  };
}

// Relay de Auric Free con ?keepalive=1: una respuesta lenta llega como SSE con latidos («: …») y, al final, «event: result» con { status, body }.
// El cuerpo es EXACTAMENTE el JSON que el relay habría devuelto sin latidos y el estado es el HTTP que habría tenido (200, 429, 503…).
function relayAggregator() {
  let result = null;
  return {
    push({ event, data }) {
      if (event !== 'result') return;
      const j = tryJson(data);
      if (j && typeof j === 'object') result = j;
    },
    finish() {
      if (!result) return { json: {}, terminal: false, error: null, hasContent: false };
      const status = Number(result.status);
      return { json: result.body ?? {}, status: Number.isInteger(status) && status >= 100 && status <= 599 ? status : 200, terminal: true, error: null, hasContent: true };
    },
    stats: () => ({ chars: 0, thoughtChars: 0, toolCalls: 0 })
  };
}

const AGGREGATORS = {
  'openai-chat': openAiChatAggregator,
  gemini: geminiAggregator,
  anthropic: anthropicAggregator,
  'openai-responses': openAiResponsesAggregator,
  cohere: cohereAggregator,
  'auric-relay': relayAggregator
};
const createAggregator = kind => (AGGREGATORS[kind] ? AGGREGATORS[kind]() : null);

// ── Petición con tiempo máximo SIN datos ───────────────────────────────────────────────────────────────────────
const flattenHeaders = h => {
  const out = {};
  try {
    for (const [k, v] of h.entries()) out[String(k).toLowerCase()] = String(v);
  } catch {}
  return out;
};
const looksSse = (contentType, firstBytes) => /text\/event-stream/i.test(contentType) || (!/json|html|xml/i.test(contentType) && /^\s*(?:data:|event:|:)/.test(firstBytes));

// Devuelve:
//   { statusCode, headers, body, streamed, incomplete, incompleteDetail, stats }
//   · streamed       true si era SSE y se juntó en un solo JSON (body es ese JSON)
//   · incomplete     '' si terminó bien; si no, por qué se cortó: 'idle' (se quedó callado), 'connection' (se cayó la conexión),
//                    'no-terminal' (el flujo acabó sin marca de fin), 'provider-error' (el servicio mandó un error a mitad), 'total' (tope de seguridad)
//   · si NO llegó nada útil y hubo un error dentro del flujo, se devuelve como un error HTTP normal (statusCode 4xx/5xx)
// Lanza (como la llamada normal): ABORTED (la persona pulsó Detener), ETIMEDOUT (no llegó nada en idleMs), NETWORK (no se pudo conectar).
async function streamRequest({
  url,
  method = 'POST',
  headers = {},
  body,
  kind = 'openai-chat',
  idleMs = 180000,
  totalMs = 45 * 60 * 1000,
  signal = null,
  fetchImpl = globalThis.fetch,
  onProgress = null,
  progressEveryMs = 400,
  now = () => Date.now()
} = {}) {
  const ctl = new AbortController();
  const why = { idle: false, total: false, outer: false };
  if (signal) {
    if (signal.aborted) {
      why.outer = true;
      ctl.abort();
    } else
      signal.addEventListener(
        'abort',
        () => {
          why.outer = true;
          ctl.abort();
        },
        { once: true }
      );
  }
  let idleTimer = null;
  const touch = () => {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      why.idle = true;
      ctl.abort();
    }, Math.max(50, idleMs));
  };
  const totalTimer = setTimeout(() => {
    why.total = true;
    ctl.abort();
  }, Math.max(100, totalMs));
  const cleanup = () => {
    clearTimeout(idleTimer);
    clearTimeout(totalTimer);
  };
  const t0 = now();
  const secs = Math.round(idleMs / 1000);
  const typed = err => {
    if (why.outer) return new Error('ABORTED: petición cancelada.');
    if (why.idle) return Object.assign(new Error(`ETIMEDOUT: el servidor no envió nada durante ${secs} s.`), { code: 'ETIMEDOUT' });
    if (why.total) return Object.assign(new Error('ETIMEDOUT: la respuesta superó el tiempo máximo permitido.'), { code: 'ETIMEDOUT' });
    if (err && /^(STREAM_TOO_LARGE)/.test(String(err.message))) return err;
    const cause = err?.cause?.code || err?.cause?.message || err?.code || '';
    return new Error(`NETWORK: fetch failed ${cause ? `(${cause}) ` : ''}${err?.message || err}`);
  };

  touch();
  let res;
  try {
    res = await fetchImpl(url, { method, headers, body: body ?? undefined, signal: ctl.signal, redirect: 'follow' });
  } catch (err) {
    cleanup();
    throw typed(err);
  }
  const ttfbMs = now() - t0;
  const resHeaders = flattenHeaders(res.headers);
  const contentType = resHeaders['content-type'] || '';
  const reader = res.body?.getReader ? res.body.getReader() : null;
  const decoder = new TextDecoder('utf-8');
  let bytes = 0;
  const readAllText = async limit => {
    let out = '';
    if (!reader) return await res.text();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      touch();
      bytes += value.length;
      if (bytes > MAX_BODY_BYTES) throw new Error('La respuesta supera el tamaño permitido.');
      if (out.length < limit) out += decoder.decode(value, { stream: true });
    }
    return out + decoder.decode();
  };
  try {
    // Errores HTTP: se devuelve el cuerpo tal cual (la app los clasifica por estado y texto).
    if (res.status >= 400) {
      const text = await readAllText(ERROR_BODY_BYTES);
      cleanup();
      return { statusCode: res.status, headers: resHeaders, body: text, streamed: false, incomplete: '', stats: { ttfbMs, durationMs: now() - t0, bytes } };
    }
    const agg = createAggregator(kind);
    // Lo que no es SSE (el servicio ignoró «stream», o es un simulacro que responde JSON) se devuelve como siempre.
    let first = null;
    if (reader && agg && !/json|html|xml/i.test(contentType) && !/text\/event-stream/i.test(contentType)) {
      // Tipo desconocido: se mira el principio para decidir.
      const r = await reader.read();
      touch();
      first = r.done ? null : r.value;
      const peek = first ? decoder.decode(first, { stream: true }) : '';
      if (!looksSse(contentType, peek)) {
        let text = peek;
        if (first) bytes += first.length;
        text += await readAllText(MAX_BODY_BYTES);
        cleanup();
        return { statusCode: res.status, headers: resHeaders, body: text, streamed: false, incomplete: '', stats: { ttfbMs, durationMs: now() - t0, bytes } };
      }
    } else if (!agg || !reader || !/text\/event-stream/i.test(contentType)) {
      const text = await readAllText(MAX_BODY_BYTES);
      cleanup();
      return { statusCode: res.status, headers: resHeaders, body: text, streamed: false, incomplete: '', stats: { ttfbMs, durationMs: now() - t0, bytes } };
    }

    // SSE
    let lastProgress = 0,
      events = 0,
      readError = null;
    const emit = force => {
      if (!onProgress) return;
      const t = now();
      if (!force && t - lastProgress < progressEveryMs) return;
      lastProgress = t;
      try {
        onProgress({ ...agg.stats(), elapsedMs: t - t0, ttfbMs, bytes });
      } catch {}
    };
    const parser = new SseParser(evt => {
      events++;
      try {
        agg.push(evt);
      } catch {}
    });
    try {
      if (first) {
        bytes += first.length;
        parser.push(first);
        emit(false);
      }
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        touch();
        bytes += value.length;
        if (bytes > MAX_BODY_BYTES) throw new Error('STREAM_TOO_LARGE: la respuesta es demasiado grande.');
        parser.push(value);
        emit(false);
      }
      parser.end();
    } catch (err) {
      readError = err;
      try {
        parser.end();
      } catch {}
    }
    cleanup();
    if (why.outer) throw new Error('ABORTED: petición cancelada.');
    emit(true);
    const fin = agg.finish();
    const stats = { ...agg.stats(), events, ttfbMs, durationMs: now() - t0, bytes };
    // Una conexión que no trajo NI UN evento: no hay nada que conservar. Se trata como un fallo de red / de espera (la app reintenta).
    if (!events && !fin.hasContent) {
      if (why.idle || why.total || readError) throw typed(readError);
      throw new Error('NETWORK: el servidor cerró la conexión sin enviar nada.');
    }
    let incomplete = '',
      detail = '';
    if (why.idle) {
      incomplete = 'idle';
      detail = `El servidor dejó de enviar datos durante ${secs} s.`;
    } else if (why.total) {
      incomplete = 'total';
      detail = 'La respuesta superó el tiempo máximo permitido.';
    } else if (fin.error && !fin.terminal) {
      incomplete = 'provider-error';
      detail = fin.error.message;
    } else if (readError) {
      incomplete = 'connection';
      detail = String(readError?.cause?.code || readError?.cause?.message || readError?.message || readError);
    } else if (!fin.terminal) {
      incomplete = 'no-terminal';
      detail = 'El flujo terminó sin la marca de fin del servidor.';
    }
    // Error dentro del flujo y nada útil recibido → se presenta como el error HTTP que es (así lo tratan igual los reintentos y los mensajes).
    if (fin.error && !fin.hasContent) {
      return {
        statusCode: fin.error.status || 502,
        headers: resHeaders,
        body: JSON.stringify({ error: { message: fin.error.message, type: fin.error.name || 'stream_error', code: fin.error.status || 502 } }),
        streamed: true,
        incomplete: '',
        stats
      };
    }
    return { statusCode: fin.status || res.status, headers: resHeaders, body: JSON.stringify(fin.json), streamed: true, incomplete, incompleteDetail: detail, errorInfo: fin.error ? { message: fin.error.message, status: fin.error.status, name: fin.error.name } : undefined, stats };
  } catch (err) {
    cleanup();
    if (why.outer) throw new Error('ABORTED: petición cancelada.');
    throw typed(err);
  }
}

module.exports = { SseParser, createAggregator, streamRequest, errorInfo, STATUS_BY_NAME, MAX_BODY_BYTES };
