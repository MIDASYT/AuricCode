'use strict';
// Plugins de Auric Code — parte PURA (sin disco ni red, para poder probarla con `node --test`).
// Un plugin es una carpeta (o un ZIP, o un repositorio de GitHub) que trae skills, instrucciones, servidores MCP y/o conectores.
// Aquí se lee el manifiesto (`auric-plugin.json`) y los formatos ajenos más comunes, y se arma el «modelo» del plugin:
// lo único que el resto de la app conoce. La revisión de seguridad (qué pide) está en plugins-review.js.
const crypto = require('crypto');
const { parseSkillFrontmatter } = require('./skill-format');

const SCHEMA = 'auric-plugin/1';
const MANIFEST_FILE = 'auric-plugin.json';
const LIMITS = {
  maxFiles: 1500,
  maxTotalBytes: 25 * 1024 * 1024,
  maxFileBytes: 8 * 1024 * 1024,
  maxSkills: 60,
  maxSkillBytes: 64 * 1024,
  maxInstructionsBytes: 16 * 1024,
  maxMcp: 8,
  maxConnectors: 8,
  maxArgs: 40,
  maxArgLength: 1000
};
const PLUGIN_ID_RE = /^[a-z0-9][a-z0-9-]{1,46}[a-z0-9]$/;
const SUB_ID_RE = /^[a-z0-9][a-z0-9_-]{0,38}$/;
const ENV_NAME_RE = /^[A-Za-z_][A-Za-z0-9_]{0,63}$/;
// Herramientas que un plugin puede declarar que necesita (se comprueba si están instaladas).
const KNOWN_TOOLS = ['node', 'npx', 'npm', 'pnpm', 'python', 'python3', 'pip', 'uv', 'uvx', 'git', 'docker', 'java', 'dotnet', 'go', 'cargo'];

class PluginError extends Error {
  constructor(message, code = 'PLUGIN_INVALID') {
    super(message);
    this.code = code;
  }
}

// ── Utilidades ─────────────────────────────────────────────────────────────────────────────────
const slug = (s, max = 48) =>
  String(s ?? '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, max)
    .replace(/-+$/, '');
const str = (v, max) => (typeof v === 'string' ? v.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, max) : '');
const sha256 = buf => crypto.createHash('sha256').update(buf).digest('hex');
const textOf = buf => Buffer.from(buf).toString('utf8').replace(/^﻿/, '');
const isObj = v => !!v && typeof v === 'object' && !Array.isArray(v);

// Ruta relativa segura dentro del paquete ('' si es peligrosa o inválida).
function cleanRel(p) {
  let s = String(p ?? '').replace(/\\/g, '/').trim();
  s = s.replace(/^(\.\/)+/, '');
  if (!s || s.length > 300 || /[\u0000-\u001f]/.test(s)) return '';
  if (s.startsWith('/') || /^[a-zA-Z]:/.test(s)) return '';
  const parts = s.split('/').filter(x => x !== '' && x !== '.');
  if (!parts.length || parts.some(x => x === '..')) return '';
  // Nombres que Windows no admite o trata de forma especial (CON, NUL, «archivo.», «a:b» = flujo oculto de datos…).
  if (parts.some(x => /[:<>"|?*]/.test(x) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i.test(x) || /[. ]$/.test(x))) return '';
  return parts.join('/');
}

// Quita la carpeta única que envuelve el paquete (los ZIP de GitHub vienen como «usuario-repo-1a2b3c/…») y la basura de sistema.
function normalizeFiles(input, { stripWrapper = true } = {}) {
  const out = new Map();
  for (const [raw, buf] of input instanceof Map ? input : new Map(Object.entries(input || {}))) {
    const rel = cleanRel(raw);
    if (!rel) throw new PluginError(`El paquete trae una ruta no permitida: ${String(raw).slice(0, 120)}`, 'PLUGIN_UNSAFE_PATH');
    if (/^__MACOSX\//i.test(rel) || /(^|\/)(\.DS_Store|Thumbs\.db|desktop\.ini)$/i.test(rel)) continue;
    if (/(^|\/)\.git\//.test(rel)) continue;
    out.set(rel, Buffer.isBuffer(buf) ? buf : Buffer.from(buf));
  }
  // Windows y macOS no distinguen mayúsculas: «A.md» y «a.md» serían el mismo archivo.
  const lower = new Map();
  for (const k of out.keys()) {
    const l = k.toLowerCase();
    if (lower.has(l)) throw new PluginError(`El paquete trae dos archivos con el mismo nombre salvo mayúsculas (${lower.get(l)} y ${k}); en Windows serían el mismo.`, 'PLUGIN_DUPLICATE_PATH');
    lower.set(l, k);
  }
  const names = [...out.keys()];
  if (stripWrapper && names.length && names.every(n => n.includes('/'))) {
    const first = names[0].split('/')[0];
    if (names.every(n => n.split('/')[0] === first)) {
      const stripped = new Map();
      for (const [n, b] of out) stripped.set(n.slice(first.length + 1), b);
      return { files: stripped, root: first };
    }
  }
  return { files: out, root: '' };
}

function checkLimits(files) {
  if (files.size > LIMITS.maxFiles) throw new PluginError(`El paquete tiene demasiados archivos (${files.size}; máximo ${LIMITS.maxFiles}).`, 'PLUGIN_LIMIT');
  let total = 0;
  for (const [name, buf] of files) {
    if (buf.length > LIMITS.maxFileBytes) throw new PluginError(`El archivo ${name} es demasiado grande (máximo ${LIMITS.maxFileBytes / 1048576} MB).`, 'PLUGIN_LIMIT');
    total += buf.length;
  }
  if (total > LIMITS.maxTotalBytes) throw new PluginError(`El paquete pesa demasiado (${Math.round(total / 1048576)} MB; máximo ${LIMITS.maxTotalBytes / 1048576} MB).`, 'PLUGIN_LIMIT');
  return total;
}

const EXT_BINARY = new Set(['exe', 'dll', 'msi', 'msix', 'com', 'scr', 'lnk', 'node', 'so', 'dylib', 'jar', 'sys', 'ocx', 'cpl', 'bin', 'appimage']);
const EXT_SCRIPT = new Set(['bat', 'cmd', 'ps1', 'psm1', 'vbs', 'vbe', 'wsf', 'js', 'mjs', 'cjs', 'py', 'sh', 'rb', 'pl', 'php']);
function fileKind(rel) {
  const name = rel.split('/').pop().toLowerCase();
  const ext = name.includes('.') ? name.split('.').pop() : '';
  if (EXT_BINARY.has(ext)) return 'binary';
  if (EXT_SCRIPT.has(ext)) return 'script';
  if (/^\.env(\.|$)/.test(name) || /\.(pem|key|pfx|p12|kdbx)$/.test(name) || /^(id_rsa|id_ed25519|credentials\.json|secrets?\.(json|ya?ml))$/.test(name)) return 'secret';
  return 'data';
}

// Resumen de archivos con huella (se guarda al instalar y se vuelve a comprobar para detectar cambios).
function fileTable(files) {
  return [...files.entries()]
    .sort((a, b) => (a[0] < b[0] ? -1 : 1))
    .map(([path, buf]) => ({ path, size: buf.length, sha256: sha256(buf), kind: fileKind(path) }));
}
function treeDigest(table) {
  const h = crypto.createHash('sha256');
  for (const f of table) h.update(`${f.path}\0${f.sha256}\n`);
  return h.digest('hex');
}

// ── Versiones ───────────────────────────────────────────────────────────────────────────────────
const SEMVER_RE = /^(\d{1,6})\.(\d{1,6})\.(\d{1,6})(?:[-+][0-9A-Za-z.+-]{1,40})?$/;
function parseVersion(v) {
  const m = SEMVER_RE.exec(String(v ?? '').trim().replace(/^v/i, ''));
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
}
function compareVersions(a, b) {
  const x = parseVersion(a),
    y = parseVersion(b);
  if (!x || !y) return 0;
  for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
  return 0;
}
// «>=0.15.0», «^0.15.0», «~0.15.0», «0.15.0», «>0.14», «<1.0.0». Devuelve null si no se entiende el rango.
function satisfies(range, version) {
  const r = String(range ?? '').trim();
  if (!r) return true;
  const have = parseVersion(version);
  if (!have) return true;
  const m = /^(>=|<=|>|<|\^|~|=)?\s*v?(\d{1,6})(?:\.(\d{1,6}))?(?:\.(\d{1,6}))?$/.exec(r);
  if (!m) return null;
  const want = [Number(m[2]), Number(m[3] ?? 0), Number(m[4] ?? 0)];
  const cmp = compareVersions(have.join('.'), want.join('.'));
  switch (m[1] || '=') {
    case '>=':
      return cmp >= 0;
    case '>':
      return cmp > 0;
    case '<=':
      return cmp <= 0;
    case '<':
      return cmp < 0;
    case '^':
      return cmp >= 0 && (want[0] > 0 ? have[0] === want[0] : have[0] === 0 && have[1] === want[1]);
    case '~':
      return cmp >= 0 && have[0] === want[0] && have[1] === want[1];
    default:
      return cmp === 0;
  }
}

// ── Manifiesto ──────────────────────────────────────────────────────────────────────────────────
function parseJsonFile(buf, name) {
  try {
    const v = JSON.parse(textOf(buf));
    if (!isObj(v)) throw new Error('no es un objeto');
    return v;
  } catch (e) {
    throw new PluginError(`${name} no es un JSON válido (${String(e.message).slice(0, 120)}).`, 'PLUGIN_BAD_MANIFEST');
  }
}

function httpsUrl(v) {
  try {
    const u = new URL(String(v));
    return u.protocol === 'https:' && !u.username && !u.password ? u : null;
  } catch {
    return null;
  }
}

// Convierte los datos de «quién lo hizo / dónde» a texto simple.
function authorText(a) {
  if (typeof a === 'string') return str(a, 80);
  if (isObj(a)) return str(a.name, 80);
  return '';
}

function normalizeMeta(raw, hint, report) {
  const idGiven = str(raw.id, 80);
  let id = slug(idGiven || raw.name || hint.name || '');
  if (idGiven && idGiven !== slug(idGiven)) report.warnings.push(`El id «${idGiven}» se ajustó a «${id}» (solo letras minúsculas, números y guiones).`);
  if (id.length < 3) id = (id + '-plugin').replace(/^-+/, '').padEnd(3, 'x');
  if (!PLUGIN_ID_RE.test(id)) report.errors.push(`El id del plugin no es válido: usa entre 3 y 48 letras minúsculas, números o guiones (recibido: «${idGiven || id}»).`);
  const name = str(raw.name, 80) || str(hint.name, 80) || id;
  let version = str(raw.version, 40).replace(/^v/i, '');
  if (!version) {
    version = str(hint.version, 40).replace(/^v/i, '') || '0.0.0';
    report.warnings.push('El plugin no indica su versión.');
  } else if (!parseVersion(version)) {
    report.warnings.push(`La versión «${version}» no tiene el formato 1.2.3; se usará 0.0.0.`);
    version = '0.0.0';
  }
  const description = str(raw.description, 400) || str(hint.description, 400);
  const homepageUrl = raw.homepage ? httpsUrl(raw.homepage) : null;
  if (raw.homepage && !homepageUrl) report.warnings.push('La página del plugin no es una dirección https válida y se ignoró.');
  const requires = { auric: '', tools: [] };
  if (isObj(raw.requires)) {
    requires.auric = str(raw.requires.auric, 40);
    if (requires.auric && satisfies(requires.auric, '1.0.0') === null) {
      report.warnings.push(`No se entendió la versión de Auric que pide («${requires.auric}»); se ignora.`);
      requires.auric = '';
    }
    for (const t of Array.isArray(raw.requires.tools) ? raw.requires.tools.slice(0, 10) : []) {
      const tool = str(t, 20).toLowerCase();
      if (KNOWN_TOOLS.includes(tool) && !requires.tools.includes(tool)) requires.tools.push(tool);
      else if (tool) report.warnings.push(`La herramienta «${tool}» que pide el plugin no está en la lista que Auric sabe comprobar.`);
    }
  }
  const perm = { declared: false, network: [], env: [], runs: [], files: '', notes: '' };
  if (isObj(raw.permissions)) {
    perm.declared = true;
    perm.network = (Array.isArray(raw.permissions.network) ? raw.permissions.network : []).map(x => str(x, 120).toLowerCase()).filter(Boolean).slice(0, 20);
    perm.env = (Array.isArray(raw.permissions.env) ? raw.permissions.env : []).map(x => str(x, 64)).filter(Boolean).slice(0, 20);
    perm.runs = (Array.isArray(raw.permissions.runs) ? raw.permissions.runs : []).map(x => str(x, 160)).filter(Boolean).slice(0, 20);
    perm.files = ['none', 'workspace', 'any'].includes(raw.permissions.files) ? raw.permissions.files : '';
    perm.notes = str(raw.permissions.notes, 400);
  }
  return {
    id,
    name,
    version,
    description,
    author: authorText(raw.author),
    homepage: homepageUrl ? homepageUrl.href : '',
    license: str(raw.license, 60),
    requires,
    permissions: perm
  };
}

// ── Piezas: skills, instrucciones, MCP, conectores ──────────────────────────────────────────────
const STOPWORDS = new Set(
  (
    'skill skills use using the and for with tool tools helper guide plugin pack best practices work workflow ' +
    'para con las los una uno del que por guia guía ayuda como cómo uso usar herramienta herramientas'
  ).split(' ')
);
// Para skills de otros formatos que no traen palabras clave: se usa el nombre (y las etiquetas) para decidir cuándo aplican.
function deriveTriggers(skill) {
  const out = [];
  const add = w => {
    const t = String(w || '').toLowerCase().trim();
    if (t.length >= 3 && t.length <= 40 && !STOPWORDS.has(t) && !out.includes(t)) out.push(t);
  };
  const name = String(skill.name || '').toLowerCase().trim();
  if (name && name.split(/\s+/).length <= 4) add(name);
  for (const part of slug(skill.name).split('-')) add(part);
  for (const part of slug(skill.id).split('-')) add(part);
  for (const t of skill.tags || []) add(t);
  return out.slice(0, 8);
}

function describeFrom(text) {
  const line = String(text || '')
    .split(/\r?\n/)
    .map(l => l.replace(/^#+\s*/, '').trim())
    .find(Boolean);
  return str(line || '', 160);
}

function collectSkills(files, explicitDirs, report, hint = {}) {
  const found = [];
  const pushDir = dir => {
    const file = dir ? `${dir}/SKILL.md` : 'SKILL.md';
    const key = [...files.keys()].find(k => k.toLowerCase() === file.toLowerCase());
    if (!key) return false;
    found.push({ dir, file: key });
    return true;
  };
  if (Array.isArray(explicitDirs)) {
    for (const d of explicitDirs.slice(0, LIMITS.maxSkills)) {
      const dir = cleanRel(d);
      if (!dir && String(d).trim() !== '.' && String(d).trim() !== './') throw new PluginError(`Ruta no permitida en «skills» del manifiesto: ${String(d).slice(0, 80)}`, 'PLUGIN_UNSAFE_PATH');
      if (!pushDir(dir)) throw new PluginError(`El manifiesto lista la skill «${d}» pero no existe ${dir ? dir + '/' : ''}SKILL.md.`, 'PLUGIN_BAD_MANIFEST');
    }
  } else {
    const seen = new Set();
    for (const key of files.keys()) {
      const m = /^(?:(.+)\/)?SKILL\.md$/i.exec(key);
      if (!m) continue;
      const dir = m[1] || '';
      if (dir.split('/').length > 3 || /(^|\/)(node_modules|test|tests|fixtures|examples?|templates?)(\/|$)/i.test(dir)) continue;
      if (!seen.has(dir)) {
        seen.add(dir);
        found.push({ dir, file: key });
      }
    }
    found.sort((a, b) => (a.file < b.file ? -1 : 1));
    if (found.length > LIMITS.maxSkills) {
      report.warnings.push(`El paquete tiene ${found.length} skills; se usarán las primeras ${LIMITS.maxSkills}.`);
      found.length = LIMITS.maxSkills;
    }
  }
  const skills = [];
  const used = new Set();
  for (const { dir, file } of found) {
    const buf = files.get(file);
    if (buf.length > LIMITS.maxSkillBytes) throw new PluginError(`La skill de ${dir || 'la raíz'} es demasiado larga (${Math.round(buf.length / 1024)} KB; máximo ${LIMITS.maxSkillBytes / 1024} KB).`, 'PLUGIN_LIMIT');
    const parsed = parseSkillFrontmatter(textOf(buf));
    const base = dir ? dir.split('/').pop() : slug(hint.name) || 'skill';
    let id = slug(parsed.hasId ? parsed.id : base) || slug(base) || 'skill';
    for (let n = 2; used.has(id); n++) id = `${slug(parsed.hasId ? parsed.id : base).slice(0, 44)}-${n}`;
    used.add(id);
    const name = str(parsed.name, 80) && parsed.name !== 'Skill' ? str(parsed.name, 80) : id;
    const description = str(parsed.description, 300) || describeFrom(parsed.procedure);
    const skill = {
      id,
      name,
      description,
      triggers: parsed.triggers.map(x => str(x, 60)).filter(Boolean).slice(0, 20),
      markers: parsed.markers.map(x => str(x, 120)).filter(Boolean).slice(0, 20),
      tags: parsed.tags.map(x => str(x, 40)).filter(Boolean).slice(0, 12),
      dir,
      file,
      chars: parsed.procedure.length,
      sha256: sha256(buf),
      derived: false,
      ignoredFields: parsed.ignoredFields || []
    };
    if (!skill.triggers.length && !skill.markers.length) {
      skill.triggers = deriveTriggers(skill);
      skill.derived = skill.triggers.length > 0;
    }
    skills.push(skill);
  }
  return skills;
}

function readInstructions(files, rel, report) {
  if (rel == null || rel === '') return null;
  const file = cleanRel(rel);
  if (!file) throw new PluginError(`Ruta no permitida en «instructions» del manifiesto: ${String(rel).slice(0, 80)}`, 'PLUGIN_UNSAFE_PATH');
  if (!/\.(md|txt)$/i.test(file)) throw new PluginError('Las instrucciones del plugin deben ser un archivo .md o .txt.', 'PLUGIN_BAD_MANIFEST');
  const key = [...files.keys()].find(k => k.toLowerCase() === file.toLowerCase());
  if (!key) throw new PluginError(`El manifiesto indica el archivo de instrucciones «${file}», pero no existe en el paquete.`, 'PLUGIN_BAD_MANIFEST');
  const buf = files.get(key);
  if (buf.length > LIMITS.maxInstructionsBytes) throw new PluginError(`Las instrucciones son demasiado largas (${Math.round(buf.length / 1024)} KB; máximo ${LIMITS.maxInstructionsBytes / 1024} KB).`, 'PLUGIN_LIMIT');
  const text = textOf(buf).trim();
  if (!text) {
    report.warnings.push('El archivo de instrucciones está vacío y se ignoró.');
    return null;
  }
  return { file: key, chars: text.length, sha256: sha256(buf) };
}

function cleanArgs(v, report, ctx) {
  const out = [];
  for (const a of Array.isArray(v) ? v.slice(0, LIMITS.maxArgs) : []) {
    const s = typeof a === 'string' || typeof a === 'number' ? String(a) : '';
    if (s.length > LIMITS.maxArgLength || /[\u0000\r\n]/.test(s)) {
      report.errors.push(`${ctx}: un argumento tiene saltos de línea, caracteres de control o es demasiado largo.`);
      continue;
    }
    out.push(s);
  }
  if (Array.isArray(v) && v.length > LIMITS.maxArgs) report.warnings.push(`${ctx}: se ignoraron los argumentos después del número ${LIMITS.maxArgs}.`);
  return out;
}
function cleanEnv(v, report, ctx) {
  const out = {};
  if (!isObj(v)) return out;
  for (const [k, val] of Object.entries(v).slice(0, 30)) {
    if (!ENV_NAME_RE.test(k)) {
      report.errors.push(`${ctx}: el nombre de variable «${String(k).slice(0, 30)}» no es válido.`);
      continue;
    }
    const s = typeof val === 'string' || typeof val === 'number' || typeof val === 'boolean' ? String(val) : '';
    if (s.length > 500 || /[\u0000\r\n]/.test(s)) {
      report.errors.push(`${ctx}: el valor de ${k} es inválido o demasiado largo.`);
      continue;
    }
    out[k] = s;
  }
  return out;
}

function cleanMcpList(list, report) {
  const out = [];
  const ids = new Set();
  for (const raw of Array.isArray(list) ? list.slice(0, LIMITS.maxMcp) : []) {
    if (!isObj(raw)) continue;
    const label = `Servidor MCP «${str(raw.id || raw.name, 40) || '?'}»`;
    const id = slug(raw.id || raw.name || '', 39).replace(/-/g, '-');
    if (!SUB_ID_RE.test(id)) {
      report.errors.push(`${label}: necesita un id (letras minúsculas, números, guiones).`);
      continue;
    }
    if (ids.has(id)) {
      report.errors.push(`${label}: el id «${id}» está repetido.`);
      continue;
    }
    const command = str(raw.command, 260);
    if (!command || /[\u0000\r\n]/.test(command)) {
      report.errors.push(`${label}: falta el comando que lo ejecuta.`);
      continue;
    }
    ids.add(id);
    out.push({
      id,
      name: str(raw.name, 80) || id,
      description: str(raw.description, 300),
      command,
      args: cleanArgs(raw.args, report, label),
      env: cleanEnv(raw.env, report, label),
      // Por defecto el servidor trabaja en la carpeta de datos del plugin; solo usa la de tu proyecto si lo pide con "cwd": "workspace".
      cwd: raw.cwd === 'workspace' ? 'workspace' : 'plugin'
    });
  }
  if (Array.isArray(list) && list.length > LIMITS.maxMcp) report.warnings.push(`Se ignoraron los servidores MCP después del número ${LIMITS.maxMcp}.`);
  return out;
}

function cleanConnectors(list, report) {
  const out = [];
  const ids = new Set();
  for (const raw of Array.isArray(list) ? list.slice(0, LIMITS.maxConnectors) : []) {
    if (!isObj(raw)) continue;
    const label = `Conector «${str(raw.id || raw.name, 40) || '?'}»`;
    const id = slug(raw.id || raw.name || '', 39);
    if (!SUB_ID_RE.test(id)) {
      report.errors.push(`${label}: necesita un id (letras minúsculas, números, guiones).`);
      continue;
    }
    if (ids.has(id)) {
      report.errors.push(`${label}: el id «${id}» está repetido.`);
      continue;
    }
    const ref = slug(raw.ref || '', 40);
    let url = '';
    if (raw.url != null && raw.url !== '') {
      const u = httpsUrl(raw.url);
      if (!u) {
        report.errors.push(`${label}: la dirección debe ser https y sin usuario ni clave (recibido: «${str(String(raw.url), 80)}»).`);
        continue;
      }
      url = u.href;
    }
    if (!url && !ref) {
      report.errors.push(`${label}: indica «url» (servidor MCP remoto) o «ref» (un conector que Auric ya trae).`);
      continue;
    }
    ids.add(id);
    out.push({
      id,
      name: str(raw.name, 80) || id,
      description: str(raw.description, 300),
      url,
      ref: url ? '' : ref,
      auth: ['oauth', 'token', 'none'].includes(raw.auth) ? raw.auth : 'oauth'
    });
  }
  return out;
}

// ── Otros formatos ──────────────────────────────────────────────────────────────────────────────
// Reemplaza la variable de raíz que usan otros formatos por la de Auric.
const fixRoot = s => String(s).replace(/\$\{(?:CLAUDE_PLUGIN_ROOT|PLUGIN_ROOT)\}/g, '${PLUGIN_DIR}');

// `.mcp.json` / `mcpServers`: servidores por comando (MCP local) y servidores remotos (conectores).
function fromMcpServersObject(obj, report) {
  const list = [];
  const conns = [];
  const entries = isObj(obj) ? Object.entries(obj.mcpServers && isObj(obj.mcpServers) ? obj.mcpServers : obj) : [];
  for (const [key, v] of entries.slice(0, 40)) {
    if (!isObj(v)) continue;
    if (typeof v.url === 'string' || ['http', 'sse', 'streamable-http'].includes(String(v.type || '').toLowerCase())) {
      conns.push({ id: key, name: key, url: v.url, auth: isObj(v.headers) && Object.keys(v.headers).length ? 'token' : 'oauth' });
      continue;
    }
    list.push({
      id: key,
      name: key,
      command: typeof v.command === 'string' ? fixRoot(v.command) : '',
      args: (Array.isArray(v.args) ? v.args : []).map(a => fixRoot(a)),
      env: isObj(v.env) ? Object.fromEntries(Object.entries(v.env).map(([k, x]) => [k, fixRoot(x)])) : {},
      cwd: 'workspace'
    });
  }
  return { mcp: cleanMcpList(list, report), connectors: cleanConnectors(conns, report) };
}

function describeIgnored(files) {
  const out = [];
  const has = re => [...files.keys()].filter(k => re.test(k));
  const cmds = has(/^commands\/.+\.md$/i);
  if (cmds.length) out.push({ what: `Comandos (${cmds.length})`, why: 'Auric no usa los comandos de otros programas.' });
  const agents = has(/^agents\/.+\.md$/i);
  if (agents.length) out.push({ what: `Agentes (${agents.length})`, why: 'Auric no usa los agentes de otros programas.' });
  const hooks = has(/^hooks\/|^\.claude\/hooks/i);
  if (hooks.length) out.push({ what: 'Hooks (programas que se ejecutan solos)', why: 'Auric NO ejecuta hooks: se ignoran.' });
  return out;
}

// ── Modelo ──────────────────────────────────────────────────────────────────────────────────────
/**
 * Arma el modelo del plugin a partir de los archivos del paquete (Map ruta → Buffer).
 * hint: { name, version, description } — nombre del ZIP / repositorio, por si el paquete no trae manifiesto.
 */
function prepareModel(input, hint = {}) {
  // hint.stripWrapper === false: quien cargó el paquete (ZIP, GitHub, carpeta) ya dejó la raíz en su sitio; recortar otra vez
  // escondería la estructura real (p. ej. «plugins/uno» pasaría a «uno» y el usuario no sabría qué carpeta pedir).
  const { files, root } = normalizeFiles(input, { stripWrapper: hint.stripWrapper !== false });
  if (!files.size) throw new PluginError('El paquete está vacío.', 'PLUGIN_EMPTY');
  const bytes = checkLimits(files);
  const report = { errors: [], warnings: [] };
  const keyOf = name => [...files.keys()].find(k => k.toLowerCase() === name.toLowerCase());
  const own = keyOf(MANIFEST_FILE);
  const claude = keyOf('.claude-plugin/plugin.json');
  const legacy = keyOf('plugin.json');
  let origin = '';
  let raw = {};
  let skillDirs = null;
  let instructionsRel = '';
  let mcp = [];
  let connectors = [];

  if (own) {
    origin = 'auric';
    raw = parseJsonFile(files.get(own), MANIFEST_FILE);
    if (raw.schema != null && raw.schema !== SCHEMA) {
      const s = str(String(raw.schema), 40);
      throw new PluginError(
        /^auric-plugin\//.test(s) ? `Este plugin usa un formato más nuevo («${s}») que el que entiende esta versión de Auric (${SCHEMA}). Actualiza Auric Code.` : `El formato «${s}» no es un plugin de Auric (se esperaba «${SCHEMA}»).`,
        'PLUGIN_SCHEMA'
      );
    }
    if (raw.schema == null) report.warnings.push(`El manifiesto no indica «schema»; se asume ${SCHEMA}.`);
    if (raw.skills != null && !Array.isArray(raw.skills)) report.errors.push('«skills» debe ser una lista de carpetas.');
    skillDirs = Array.isArray(raw.skills) ? raw.skills : null;
    instructionsRel = raw.instructions;
    mcp = cleanMcpList(raw.mcp, report);
    connectors = cleanConnectors(raw.connectors, report);
    const known = new Set(['schema', 'id', 'name', 'version', 'description', 'author', 'homepage', 'license', 'requires', 'permissions', 'skills', 'instructions', 'mcp', 'connectors', 'icon']);
    const extra = Object.keys(raw).filter(k => !known.has(k));
    if (extra.length) report.warnings.push(`El manifiesto trae campos que Auric no usa: ${extra.slice(0, 8).join(', ')}.`);
  } else if (claude) {
    origin = 'claude';
    raw = parseJsonFile(files.get(claude), '.claude-plugin/plugin.json');
    const mcpFile = keyOf('.mcp.json');
    const fromFile = mcpFile ? fromMcpServersObject(parseJsonFile(files.get(mcpFile), '.mcp.json'), report) : { mcp: [], connectors: [] };
    const inline = isObj(raw.mcpServers) ? fromMcpServersObject({ mcpServers: raw.mcpServers }, report) : { mcp: [], connectors: [] };
    mcp = [...fromFile.mcp, ...inline.mcp].slice(0, LIMITS.maxMcp);
    connectors = [...fromFile.connectors, ...inline.connectors].slice(0, LIMITS.maxConnectors);
    if (typeof raw.skills === 'string' || Array.isArray(raw.skills)) skillDirs = (Array.isArray(raw.skills) ? raw.skills : [raw.skills]).map(s => String(s).replace(/\/+$/, ''));
    report.warnings.push('Es un paquete en otro formato: Auric usó sus skills y servidores; el resto se ignora.');
  } else if (legacy) {
    origin = 'legacy';
    raw = parseJsonFile(files.get(legacy), 'plugin.json');
    const server = isObj(raw.server) ? raw.server : isObj(raw.mcp) ? raw.mcp : null;
    if (server) {
      mcp = cleanMcpList([{ id: server.id || raw.id || raw.name || 'servidor', name: server.name || raw.name, command: server.command, args: server.args, env: server.env, cwd: 'workspace' }], report);
      if (server.cwd) report.warnings.push('El «cwd» fijo del plugin.json antiguo no se usa: el servidor arranca en la carpeta del proyecto.');
    }
    report.warnings.push('Es un plugin.json del formato antiguo de Auric (un solo servidor MCP).');
  } else {
    // Un repositorio con varios plugins cada uno en su carpeta: no se adivina, se pide elegir uno.
    const nested = [...files.keys()].filter(k => /\/auric-plugin\.json$/i.test(k) || /(^|\/)\.claude-plugin\/plugin\.json$/i.test(k)).map(k => k.replace(/\/(auric-plugin\.json|\.claude-plugin\/plugin\.json)$/i, '').replace(/^\.claude-plugin\/plugin\.json$/i, ''));
    const folders = [...new Set(nested.filter(Boolean))];
    if (folders.length) {
      folders.sort();
      const e = new PluginError(`Este paquete no tiene un plugin en su raíz: trae ${folders.length === 1 ? 'uno dentro de una carpeta' : 'varios, cada uno en su carpeta'} (${folders.slice(0, 5).join(', ')}${folders.length > 5 ? '…' : ''}).`, 'PLUGIN_MULTIPLE');
      e.folders = folders.slice(0, 50);
      throw e;
    }
    const skillFiles = [...files.keys()].filter(k => /(^|\/)SKILL\.md$/i.test(k));
    if (!skillFiles.length) throw new PluginError('No parece un plugin: falta auric-plugin.json y no hay ninguna skill (SKILL.md).', 'PLUGIN_NOT_A_PLUGIN');
    origin = 'skills-only';
    report.warnings.push('El paquete no trae manifiesto: Auric lo trató como un conjunto de skills.');
  }

  const manifest = normalizeMeta(raw, { name: hint.name || root, version: hint.version, description: hint.description }, report);
  const skills = collectSkills(files, skillDirs, report, { name: manifest.name });
  const instructions = readInstructions(files, instructionsRel, report);
  if (origin === 'auric' && raw.icon) {
    const icon = cleanRel(raw.icon);
    const key = icon && keyOf(icon);
    if (key && /\.(png|svg|jpe?g|webp)$/i.test(key) && files.get(key).length <= 256 * 1024) manifest.icon = key;
    else report.warnings.push('El icono del plugin no es una imagen válida de menos de 256 KB y se ignoró.');
  }
  if (!skills.length && !instructions && !mcp.length && !connectors.length)
    report.errors.push('El plugin no aporta nada: no tiene skills, instrucciones, servidores MCP ni conectores.');
  if (report.errors.length) throw new PluginError(report.errors.slice(0, 6).join('\n'), 'PLUGIN_INVALID');

  const table = fileTable(files);
  const model = {
    origin,
    manifest,
    skills,
    instructions,
    mcp,
    connectors,
    files: table,
    treeSha256: treeDigest(table),
    stats: { files: table.length, bytes },
    ignored: describeIgnored(files),
    notes: report.warnings
  };
  // `files` (rutas ya normalizadas) es lo que se revisa Y lo que se instala: así lo revisado y lo instalado son los mismos bytes.
  return { model, files };
}
const buildModel = (input, hint = {}) => prepareModel(input, hint).model;

// ── Cambios entre dos versiones (actualizaciones) ───────────────────────────────────────────────
const mcpLine = m => [m.command, ...(m.args || [])].join(' ');
function diffModels(prev, next) {
  const by = (a, k = 'id') => new Map((a || []).map(x => [x[k], x]));
  const out = { from: prev?.manifest?.version || '', to: next.manifest.version, added: [], removed: [], changed: [] };
  const cmp = (kind, label, a, b, same) => {
    const A = by(a),
      B = by(b);
    for (const [id, x] of B) {
      if (!A.has(id)) out.added.push({ kind, id, label: label(x) });
      else if (!same(A.get(id), x)) out.changed.push({ kind, id, label: label(x), before: label(A.get(id)) });
    }
    for (const [id, x] of A) if (!B.has(id)) out.removed.push({ kind, id, label: label(x) });
  };
  cmp('mcp', mcpLine, prev?.components?.mcp ?? prev?.mcp, next.mcp, (a, b) => mcpLine(a) === mcpLine(b) && JSON.stringify(a.env) === JSON.stringify(b.env));
  cmp('connector', x => x.url || `(${x.ref})`, prev?.components?.connectors ?? prev?.connectors, next.connectors, (a, b) => (a.url || a.ref) === (b.url || b.ref));
  cmp('skill', x => x.name, prev?.components?.skills ?? prev?.skills, next.skills, (a, b) => JSON.stringify(a.triggers) === JSON.stringify(b.triggers) && a.chars === b.chars && (a.sha256 || '') === (b.sha256 || ''));
  const pi = prev?.components?.instructions ?? prev?.instructions,
    ni = next.instructions;
  if (!pi && ni) out.added.push({ kind: 'instructions', id: 'instructions', label: 'Instrucciones para el modelo' });
  else if (pi && !ni) out.removed.push({ kind: 'instructions', id: 'instructions', label: 'Instrucciones para el modelo' });
  else if (pi && ni && (pi.sha256 || '') !== (ni.sha256 || '')) out.changed.push({ kind: 'instructions', id: 'instructions', label: 'Instrucciones para el modelo', before: '' });
  return out;
}

// ── Variables que se pueden usar en los comandos de un servidor MCP ─────────────────────────────
// ${PLUGIN_DIR}: carpeta del plugin · ${PLUGIN_DATA}: carpeta propia para guardar datos · ${WORKSPACE}: carpeta del proyecto ·
// ${AURIC_NODE}: el motor de JavaScript de Auric (no hace falta instalar Node.js).
const PLACEHOLDER_RE = /\$\{(PLUGIN_DIR|PLUGIN_DATA|WORKSPACE|AURIC_NODE)\}/g;
function usesPlaceholder(text, name) {
  return new RegExp(`\\$\\{${name}\\}`).test(String(text));
}
function expandPlaceholders(text, vars) {
  return String(text).replace(PLACEHOLDER_RE, (_, k) => {
    if (vars[k] == null || vars[k] === '') throw new PluginError(k === 'WORKSPACE' ? 'Este servidor necesita una carpeta de proyecto abierta (${WORKSPACE}).' : `No se pudo resolver \${${k}}.`, 'PLUGIN_VARIABLE');
    return vars[k];
  });
}

// ── GitHub ──────────────────────────────────────────────────────────────────────────────────────
// «usuario/repo», «usuario/repo@rama», «github:usuario/repo», https://github.com/usuario/repo[/tree/rama[/carpeta]]
function parseGithubInput(text) {
  const raw = String(text ?? '').trim();
  if (!raw || raw.length > 300) throw new PluginError('Escribe el repositorio como «usuario/repo» o pega su dirección de GitHub.', 'GITHUB_INPUT');
  let owner = '',
    repo = '',
    ref = '',
    subdir = '';
  const urlLike = /^(?:https?:\/\/)?(?:www\.)?github\.com\/([^/\s]+)\/([^/\s#?]+)(?:\/tree\/([^/\s#?]+)(?:\/([^\s#?]+))?)?\/?(?:[?#].*)?$/i.exec(raw);
  if (urlLike) {
    if (/^http:\/\//i.test(raw)) throw new PluginError('La dirección de GitHub debe ser https.', 'GITHUB_INPUT');
    [, owner, repo, ref = '', subdir = ''] = urlLike;
  } else {
    const short = /^(?:github:)?([A-Za-z0-9](?:[A-Za-z0-9-]{0,38}))\/([A-Za-z0-9._-]{1,100})(?:@([^\s@]{1,100}))?$/.exec(raw);
    if (!short) throw new PluginError('No se entendió la dirección. Usa «usuario/repo» o una dirección de github.com.', 'GITHUB_INPUT');
    [, owner, repo, ref = ''] = short;
  }
  repo = repo.replace(/\.git$/i, '');
  if (!/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/.test(owner) || !/^[A-Za-z0-9._-]{1,100}$/.test(repo) || repo === '.' || repo === '..')
    throw new PluginError('El nombre del usuario o del repositorio no es válido.', 'GITHUB_INPUT');
  if (ref && (!/^[A-Za-z0-9._\/-]{1,100}$/.test(ref) || ref.includes('..') || ref.startsWith('/') || ref.endsWith('/')))
    throw new PluginError('La rama o etiqueta no es válida.', 'GITHUB_INPUT');
  const sub = cleanRel(subdir);
  if (subdir && !sub) throw new PluginError('La carpeta indicada dentro del repositorio no es válida.', 'GITHUB_INPUT');
  return { owner, repo, ref, subdir: sub };
}

module.exports = {
  SCHEMA,
  MANIFEST_FILE,
  LIMITS,
  KNOWN_TOOLS,
  PLUGIN_ID_RE,
  PluginError,
  slug,
  str,
  sha256,
  textOf,
  cleanRel,
  normalizeFiles,
  checkLimits,
  fileKind,
  fileTable,
  treeDigest,
  parseVersion,
  compareVersions,
  satisfies,
  deriveTriggers,
  prepareModel,
  buildModel,
  diffModels,
  expandPlaceholders,
  usesPlaceholder,
  parseGithubInput,
  httpsUrl,
  fromMcpServersObject,
  cleanMcpList,
  cleanConnectors,
  mcpLine
};
