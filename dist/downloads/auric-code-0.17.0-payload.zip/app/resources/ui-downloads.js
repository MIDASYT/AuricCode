// Descargas e instalaciones con permiso: ventanas de confirmación, bandeja de progreso y registro.
// Módulo de interfaz. Toda la seguridad real (https, direcciones públicas, tamaño, firma del archivo, SHA-256,
// carpeta propia, registro) vive en el proceso principal (downloads.js). Aquí solo se muestra lo que ya se
// comprobó y se pregunta a la persona. Todo texto que viene de fuera (direcciones, nombres, avisos) se escapa.
let C = null;
let unsubscribers = [];
let downloadsDirNorm = '';
let dialogChain = Promise.resolve();
const cards = new Map(); // id de descarga -> estado de su tarjeta en la bandeja

const nf = new Intl.NumberFormat('es', { maximumFractionDigits: 1 });
export const fmtBytes = n => {
  n = Number(n);
  if (!Number.isFinite(n) || n < 0) return '—';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i++;
  }
  return `${i === 0 || n >= 100 ? Math.round(n) : nf.format(n)} ${units[i]}`;
};
export const fmtSpeed = bps => (bps > 0 ? `${fmtBytes(bps)}/s` : '');
export const fmtEta = sec => {
  if (!Number.isFinite(sec) || sec <= 0) return '';
  if (sec < 60) return 'menos de 1 min';
  if (sec < 3600) return `unos ${Math.round(sec / 60)} min`;
  return `unas ${nf.format(sec / 3600)} h`;
};
export const fmtDate = iso => {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : d.toLocaleString('es', { dateStyle: 'short', timeStyle: 'short' });
};
const e = s => C.esc(s);

// ── Arranque ──────────────────────────────────────────────────────────────────────────────────────────────
export function initDownloadsUi(ctx) {
  C = ctx;
  for (const off of unsubscribers) {
    try {
      off();
    } catch {}
  }
  unsubscribers = [C.D.on('download-progress', onProgress), C.D.on('download-done', onDone)];
  C.D.downloads
    .dir()
    .then(r => {
      if (r?.ok) downloadsDirNorm = normPath(r.value);
    })
    .catch(() => {});
}

const normPath = p =>
  String(p || '')
    .toLowerCase()
    .replace(/\\/g, '/')
    .replace(/\/+/g, '/')
    .replace(/\/$/, '');

// Un comando que abre o ejecuta un archivo de la carpeta de descargas de Auric se rechaza: para instalar un
// programa existe install_app, que pide un permiso aparte y enseña el comando exacto (también en modo completo).
export function commandRunsDownloadedFile(command) {
  const c = normPath(command);
  if (!c) return false;
  const inFolder = /downloads\/auric(\/|"|'|\s|$)/.test(c) || (downloadsDirNorm && c.includes(downloadsDirNorm));
  if (!inFolder) return false;
  return /\.(exe|msi|msix|bat|cmd|com|scr|ps1|vbs|wsf|jar|lnk)\b/.test(c) || /\b(msiexec|start-process|invoke-item|explorer)\b/.test(c);
}

// ── Utilidades ────────────────────────────────────────────────────────────────────────────────────────────
async function call(fn) {
  let r;
  try {
    r = await fn();
  } catch (err) {
    throw new Error(String(err?.message || err));
  }
  if (!r?.ok) {
    const err = new Error(r?.error || 'No se pudo completar la acción.');
    err.code = r?.code || '';
    throw err;
  }
  return r.value;
}
// Todas las ventanas donde la persona decide (descargas, Git, navegador y permisos de la app) salen DE A UNA y en orden: si dos
// tareas piden permiso a la vez, la segunda espera su turno en vez de taparse o perderse.
export const queued = fn => {
  const run = dialogChain.then(fn, fn);
  dialogChain = run.catch(() => {});
  return run;
};
const stoppedFn = session => () => !!(session && C.isStopped?.(session));
const live = (session, text, detail = '') => {
  if (session) C.setLive?.(session, text, detail);
};

// El dominio con la parte registrada en negrita: así se ve a simple vista que «ollama.com.otro.test» pertenece a «otro.test».
export function hostHtml(host, registrable) {
  const h = String(host || ''),
    reg = String(registrable || '');
  if (reg && h.endsWith(reg) && h.length > reg.length)
    return `<span class="dl-host"><span class="dl-sub">${e(h.slice(0, h.length - reg.length))}</span><b>${e(reg)}</b></span>`;
  return `<span class="dl-host"><b>${e(h)}</b></span>`;
}
export const row = (label, html, cls = '') => `<div class="dl-row ${cls}"><dt>${e(label)}</dt><dd>${html}</dd></div>`;
const NOTE_ICON = { info: 'i', warn: '!', danger: '!', block: '×', ok: '✓' };
export const note = (level, text) =>
  `<li class="dl-note ${e(level)}"><span class="dl-note-ico" aria-hidden="true">${NOTE_ICON[level] || 'i'}</span><span>${e(text)}</span></li>`;
// Motivos concretos por los que un enlace no es de riesgo bajo (en vez de un aviso vago).
export function riskReasons(plan) {
  const out = [];
  if (plan.kind === 'installer') out.push('es un instalador: al ejecutarlo podrá cambiar tu equipo');
  if (plan.kind === 'script') out.push('es un script');
  if (plan.crossDomain) out.push('el enlace pasa por otro sitio');
  if (!plan.knownSite) out.push('el sitio no está en la lista de sitios conocidos de Auric');
  if (plan.size == null) out.push('el sitio no dice cuánto pesa');
  return out;
}
const RISK = {
  low: ['low', 'Riesgo bajo', 'No se encontró nada raro. Aun así, comprueba que sea lo que esperas.'],
  medium: ['medium', 'Revisa antes de continuar', 'Hay detalles que conviene mirar con calma antes de aceptar.'],
  high: ['high', 'Riesgo alto', 'Auric encontró señales de peligro. Lo normal es cancelar.'],
  blocked: ['blocked', 'Bloqueado por Auric', 'Auric no permite descargar este archivo.']
};

// Ventana propia (no es modal nativo de Windows). Devuelve 'ok' | 'cancel' | 'stopped'.
// Opcional: validate(layer) activa o apaga el botón «ok» mientras la persona escribe; collect(layer) recoge lo escrito al aceptar
// (entonces devuelve { answer, values }). La usan también las ventanas de Git.
export function showDialog({ html, cls = '', labelId, stopped, focus = '[data-dl-answer="cancel"]', collect = null, validate = null }) {
  return new Promise(resolve => {
    // Si la tarea ya se detuvo mientras esperaba su turno, no se enseña la ventana.
    if (stopped?.()) return resolve(collect ? { answer: 'stopped', values: null } : 'stopped');
    const layer = document.createElement('div');
    layer.className = 'dl-overlay';
    layer.innerHTML = `<div class="dl-dialog ${cls}" role="dialog" aria-modal="true" aria-labelledby="${labelId}" data-dl="dialog">${html}</div>`;
    let finished = false;
    const finish = answer => {
      if (finished) return;
      finished = true;
      let values = null;
      if (collect && answer === 'ok') {
        try {
          values = collect(layer);
        } catch {
          values = null;
        }
      }
      clearInterval(timer);
      document.removeEventListener('keydown', onKey, true);
      layer.remove();
      resolve(collect ? { answer, values } : answer);
    };
    const onKey = ev => {
      if (ev.key === 'Escape') {
        ev.stopPropagation();
        ev.preventDefault();
        finish('cancel');
      } else if (ev.key === 'Tab') {
        const items = [...layer.querySelectorAll('button:not([disabled]), input:not([disabled]), textarea:not([disabled]), summary, a[href], [tabindex="0"]')].filter(
          x => x.offsetParent !== null
        );
        if (!items.length) return;
        const first = items[0],
          last = items[items.length - 1];
        if (ev.shiftKey && document.activeElement === first) {
          ev.preventDefault();
          last.focus();
        } else if (!ev.shiftKey && document.activeElement === last) {
          ev.preventDefault();
          first.focus();
        }
      }
    };
    const timer = setInterval(() => {
      if (stopped?.()) finish('stopped');
    }, 250);
    layer.addEventListener('mousedown', ev => {
      if (ev.target === layer) finish('cancel');
    });
    layer.addEventListener('click', ev => {
      const b = ev.target.closest('[data-dl-answer]');
      if (b && !b.disabled) finish(b.dataset.dlAnswer);
    });
    const ack = layer.querySelector('[data-dl="ack"]');
    if (ack)
      ack.addEventListener('change', () => {
        const ok = layer.querySelector('[data-dl-answer="ok"]');
        if (ok) ok.disabled = !ack.checked;
      });
    if (validate) {
      const apply = () => {
        const ok = layer.querySelector('[data-dl-answer="ok"]');
        if (!ok) return;
        let good = false;
        try {
          good = !!validate(layer);
        } catch {}
        ok.disabled = !good;
      };
      layer.addEventListener('input', apply);
      layer.addEventListener('change', apply);
      apply();
    }
    document.addEventListener('keydown', onKey, true);
    document.body.append(layer);
    // Si algo quita la ventana de la pantalla sin que la persona responda, cuenta como un "no" (la cola nunca se queda atascada).
    const gone = new MutationObserver(() => {
      if (!layer.isConnected) {
        gone.disconnect();
        finish('cancel');
      }
    });
    gone.observe(document.body, { childList: true });
    setTimeout(() => layer.querySelector(focus)?.focus(), 0);
  });
}

// ── Ventana 1: ¿descargar este archivo? ───────────────────────────────────────────────────────────────────
export function downloadDialogHtml(plan, { origin = 'ia' } = {}) {
  const risk = [...(RISK[plan.risk] || RISK.medium)];
  const blocked = plan.status === 'blocked' || plan.risk === 'blocked';
  if (plan.risk === 'medium') {
    const why = riskReasons(plan);
    if (why.length) risk[2] = `${why.join('; ').replace(/^./, c => c.toUpperCase())}.`;
  }
  const lead = blocked
    ? origin === 'ia'
      ? 'La IA intentó descargar este archivo, pero Auric lo detuvo. No se descargó nada.'
      : 'Auric detuvo esta descarga. No se descargó nada.'
    : `${origin === 'ia' ? 'La IA quiere descargar un archivo de internet a tu PC.' : 'Vas a descargar un archivo de internet a tu PC.'} Nada se baja hasta que lo aceptes: Auric solo miró el enlace.`;
  const chain = (plan.redirects || []).length
    ? row(
        'Redirecciones',
        `<ol class="dl-chain">${plan.redirects.map(h => `<li>${hostHtml(safeHost(h.to), '')} <small>(HTTP ${e(h.status)})</small></li>`).join('')}</ol>`
      )
    : '';
  const requestedLine =
    plan.crossHost || (plan.redirects || []).length
      ? row('Enlace pedido', `<code class="dl-code">${e(String(plan.requestedUrl).slice(0, 400))}</code>`)
      : '';
  const checks = [];
  checks.push(note('ok', 'Conexión segura (https), sin usuario ni clave en la dirección.'));
  checks.push(note('ok', 'La dirección apunta a internet; no a tu red ni a tu propio equipo.'));
  if (plan.signatureOk) checks.push(note('ok', `El contenido real del archivo coincide con su tipo: ${plan.detectedText}.`));
  if (plan.size != null && !blocked) checks.push(note('ok', `Tamaño dentro del límite (${plan.maxText}).`));
  const warnings = (plan.warnings || []).map(w => note(w.level, w.text)).join('');
  const hash = plan.sha256Expected
    ? `<code class="dl-code dl-hash">${e(plan.sha256Expected)}</code><small class="dl-sub-note">Publicada por ${plan.sha256SourceKnown ? `${e(plan.sha256SourceKnown)} (${e(plan.sha256Source)})` : e(plan.sha256Source || 'el sitio')}. Auric la comparará al terminar y borrará el archivo si no coincide.</small>`
    : `<span class="dl-muted">No hay una suma publicada con la que comparar. Auric calculará la del archivo y te la mostrará al terminar.</span>`;
  const purpose = plan.purpose
    ? row(origin === 'ia' ? 'Motivo (según la IA)' : 'Motivo', `<span class="dl-purpose">${e(plan.purpose)}</span>`)
    : '';
  const needsAck = plan.risk === 'high' && !blocked;
  const buttons = blocked
    ? `<button class="primary-btn" data-dl-answer="cancel" data-dl="close">Cerrar</button>`
    : `${needsAck ? `<label class="dl-ack"><input type="checkbox" data-dl="ack"> Entiendo los avisos en rojo y quiero continuar</label>` : ''}<span class="dl-spacer"></span><button class="secondary-btn" data-dl-answer="cancel" data-dl="cancel">Cancelar</button><button class="primary-btn ${plan.risk === 'high' ? 'is-danger' : ''}" data-dl-answer="ok" data-dl="ok" ${needsAck ? 'disabled' : ''}>${plan.risk === 'high' ? 'Descargar de todos modos' : 'Descargar'}</button>`;
  return `<div class="dl-head"><span class="dl-head-ico ${blocked ? 'is-blocked' : ''}">${C.icon(blocked ? 'shield' : 'download', 22)}</span><div><span class="eyebrow">${blocked ? 'DESCARGA BLOQUEADA' : 'PERMISO PARA DESCARGAR'}</span><h3 id="dlTitle">${blocked ? 'Auric no puede descargar este archivo' : 'Auric quiere descargar un archivo'}</h3><p class="dl-lead">${e(lead)}</p></div></div>
<div class="dl-body">
  <div class="dl-risk ${e(risk[0])}" data-dl="risk" data-risk="${e(plan.risk)}"><b>${e(risk[1])}</b><span>${e(risk[2])}</span></div>
  <dl class="dl-rows">
    ${row('Sitio', `${hostHtml(plan.finalHost, plan.registrableDomain)}${plan.knownSite ? ` <span class="cx-pill ok">Sitio conocido: ${e(plan.knownSite)}</span>` : ''}`, 'is-host')}
    ${plan.githubRepo ? row('Repositorio en GitHub', `<b>${e(plan.githubRepo)}</b>`) : ''}
    ${requestedLine}${chain}
    ${row('Archivo', `<b>${e(plan.name)}</b> <span class="dl-muted">· ${e(plan.typeLabel)}</span>`)}
    ${row('Tamaño', `<b>${e(plan.sizeText)}</b>${plan.size == null ? ' <span class="dl-muted">(el sitio no lo dice)</span>' : ''}`)}
    ${blocked ? '' : row('Se guardará en', `<code class="dl-code">${e(plan.savePath)}</code>`)}
    ${blocked ? '' : row('Suma SHA-256', hash)}
    ${purpose}
  </dl>
  ${warnings ? `<h4 class="dl-sec">Avisos</h4><ul class="dl-notes" data-dl="warnings">${warnings}</ul>` : ''}
  ${blocked ? '' : `<h4 class="dl-sec">Lo que Auric comprobó</h4><ul class="dl-notes is-checks">${checks.join('')}</ul><p class="dl-fine">Son comprobaciones técnicas del enlace y del archivo: no garantizan que el programa sea de fiar.</p>`}
  ${blocked ? '' : `<p class="dl-foot-note">El archivo se guarda en una carpeta propia de Auric y <b>no se abre ni se ejecuta</b>. Si es un instalador, más adelante se te pedirá otro permiso, aparte, para ejecutarlo.</p>`}
</div>
<div class="dl-actions">${buttons}</div>`;
}
function safeHost(u) {
  try {
    return new URL(u).hostname;
  } catch {
    return String(u || '');
  }
}
function confirmDownload(plan, opts = {}) {
  return showDialog({
    html: downloadDialogHtml(plan, opts),
    labelId: 'dlTitle',
    cls: plan.risk === 'high' || plan.risk === 'blocked' ? 'is-danger' : '',
    stopped: opts.stopped,
    focus: plan.status === 'blocked' ? '[data-dl="close"]' : '[data-dl-answer="cancel"]'
  });
}

// ── Ventana 2: ¿ejecutar este instalador? (permiso aparte) ─────────────────────────────────────────────────
const SIGNATURE_TEXT = {
  Valid: 'Firma digital válida',
  NotSigned: 'Sin firma digital',
  unavailable: 'No se pudo comprobar la firma en este sistema'
};
export function runDialogHtml(run) {
  const sig = run.signature || {},
    sigText = SIGNATURE_TEXT[sig.status] || `Firma no válida (${sig.status || 'desconocida'})`;
  const sigCls = sig.status === 'Valid' ? 'ok' : sig.status === 'unavailable' ? 'muted' : 'bad';
  const warnings = (run.warnings || []).map(w => note(w.level, w.text)).join('');
  const risky = (run.warnings || []).some(w => w.level === 'danger');
  return `<div class="dl-head"><span class="dl-head-ico is-run">${C.icon('terminal', 22)}</span><div><span class="eyebrow">PERMISO PARA EJECUTAR · APARTE DE LA DESCARGA</span><h3 id="dlTitle">Auric quiere abrir un programa en tu PC</h3><p class="dl-lead">Descargar un archivo y ejecutarlo son cosas distintas: un instalador puede cambiar tu sistema. Revisa el comando exacto.</p></div></div>
<div class="dl-body">
  <dl class="dl-rows">
    ${row('Programa', `<b>${e(run.name)}</b>`)}
    ${row('Ubicación', `<code class="dl-code">${e(run.path)}</code>`)}
    ${row('Tamaño', `<b>${e(run.sizeText)}</b>`)}
    ${row('Descargado de', `${hostHtml(run.sourceHost, '')}${run.downloadedAt ? ` <span class="dl-muted">· ${e(fmtDate(run.downloadedAt))}</span>` : ''}`)}
    ${row('Suma SHA-256', `<code class="dl-code dl-hash">${e(run.sha256)}</code><small class="dl-sub-note">Auric comprobó que el archivo sigue siendo el mismo que descargó, y lo volverá a comprobar justo antes de abrirlo.</small>`)}
    ${row('Firma digital', `<span class="dl-sig ${sigCls}" data-dl="signature">${e(sigText)}</span>${sig.subject ? `<small class="dl-sub-note">${e(sig.subject)}</small>` : ''}`)}
  </dl>
  <h4 class="dl-sec">Comando exacto que se ejecutará</h4>
  <pre class="dl-cmd" data-dl="command">${e(run.command)}</pre>
  ${warnings ? `<ul class="dl-notes" data-dl="warnings">${warnings}</ul>` : ''}
  <p class="dl-foot-note">Se abre con su ventana normal, sin opciones silenciosas y sin permisos de administrador: verás cada paso. Si Windows pide permiso de administrador, lo verás tú en pantalla.</p>
</div>
<div class="dl-actions"><span class="dl-spacer"></span><button class="secondary-btn" data-dl-answer="cancel" data-dl="cancel">Cancelar</button><button class="primary-btn ${risky ? 'is-danger' : ''}" data-dl-answer="ok" data-dl="ok">Ejecutar instalador</button></div>`;
}
function confirmRun(run, opts = {}) {
  return showDialog({ html: runDialogHtml(run), labelId: 'dlTitle', cls: 'is-run', stopped: opts.stopped });
}

// ── Bandeja de progreso (no bloquea el resto de la app) ──────────────────────────────────────────────────
function tray() {
  let t = document.getElementById('dlTray');
  if (!t) {
    t = document.createElement('div');
    t.id = 'dlTray';
    t.className = 'dl-tray';
    t.setAttribute('aria-live', 'polite');
    t.addEventListener('click', onTrayClick);
    document.body.append(t);
  }
  return t;
}
function onTrayClick(ev) {
  const b = ev.target.closest('[data-dl-act]');
  if (!b) return;
  const card = b.closest('.dl-card');
  const id = card?.dataset.id;
  const st = cards.get(id);
  if (!st) return;
  if (b.dataset.dlAct === 'cancel') C.D.downloads.cancel(id).catch(() => {});
  else if (b.dataset.dlAct === 'close') removeCard(id);
  else if (b.dataset.dlAct === 'show' && st.downloadId) C.D.downloads.show(st.downloadId).catch(() => {});
}
function removeCard(id) {
  const st = cards.get(id);
  if (st?.timer) clearTimeout(st.timer);
  cards.delete(id);
  document.querySelector(`.dl-card[data-id="${CSS.escape(id)}"]`)?.remove();
  const t = document.getElementById('dlTray');
  if (t && !t.children.length) t.remove();
}
function cardHtml(st) {
  const pct = st.total ? Math.min(100, Math.round((st.received / st.total) * 100)) : null;
  const bar =
    st.status === 'downloading'
      ? `<div class="dl-bar ${pct == null ? 'is-indeterminate' : ''}"><i style="width:${pct ?? 40}%"></i></div>`
      : `<div class="dl-bar ${st.status === 'done' ? 'is-ok' : 'is-bad'}"><i style="width:100%"></i></div>`;
  let line = '';
  let actions = '';
  if (st.status === 'downloading') {
    const eta = st.total && st.speed > 0 ? fmtEta((st.total - st.received) / st.speed) : '';
    line = `<span>${e(fmtBytes(st.received))}${st.total ? ` de ${e(fmtBytes(st.total))} · ${pct} %` : ' descargados'}</span><span>${e([fmtSpeed(st.speed), eta ? `quedan ${eta}` : ''].filter(Boolean).join(' · '))}</span>`;
    actions = `<button class="secondary-btn compact-btn" data-dl-act="cancel">Cancelar</button>`;
  } else if (st.status === 'done') {
    line = `<span>Descargado · ${e(st.sizeText || '')}</span><span>${st.hashStatus === 'match' ? 'SHA-256 verificado' : 'SHA-256 calculado'}</span>`;
    actions = `<button class="secondary-btn compact-btn" data-dl-act="show">Mostrar en la carpeta</button><button class="secondary-btn compact-btn" data-dl-act="close">Cerrar</button>`;
  } else {
    line = `<span class="dl-err">${e(st.message || (st.status === 'cancelled' ? 'Descarga cancelada.' : 'La descarga falló.'))}</span>`;
    actions = `<button class="secondary-btn compact-btn" data-dl-act="close">Cerrar</button>`;
  }
  return `<div class="dl-card-head"><span class="dl-card-ico">${C.icon('download', 15)}</span><b class="dl-card-name" title="${e(st.name)}">${e(st.name)}</b><button class="dl-x" data-dl-act="close" aria-label="Cerrar" ${st.status === 'downloading' ? 'hidden' : ''}>${C.icon('close', 13)}</button></div>${bar}<div class="dl-card-line">${line}</div><div class="dl-card-actions">${actions}</div>`;
}
function paintCard(st) {
  const t = tray();
  let el = t.querySelector(`.dl-card[data-id="${CSS.escape(st.id)}"]`);
  if (!el) {
    el = document.createElement('div');
    el.dataset.id = st.id;
    t.append(el);
  }
  el.className = `dl-card is-${st.status}`;
  el.innerHTML = cardHtml(st);
}
function addCard(plan) {
  const st = { id: plan.id, name: plan.name, received: 0, total: plan.size, speed: 0, status: 'downloading' };
  cards.set(plan.id, st);
  paintCard(st);
  return st;
}
function onProgress(p) {
  const st = cards.get(p?.id);
  if (!st || st.status !== 'downloading') return;
  Object.assign(st, { received: Number(p.received) || 0, total: p.total ?? st.total, speed: Number(p.speed) || 0 });
  paintCard(st);
}
function onDone(p) {
  const st = cards.get(p?.id);
  if (!st) return;
  if (p.ok)
    Object.assign(st, {
      status: 'done',
      sizeText: p.sizeText,
      hashStatus: p.hashStatus,
      downloadId: p.id,
      received: p.size,
      total: p.size
    });
  else Object.assign(st, { status: p.cancelled ? 'cancelled' : 'error', message: p.error });
  paintCard(st);
  if (st.status === 'done') st.timer = setTimeout(() => removeCard(st.id), 30000);
}

// ── Descargar (con permiso) ───────────────────────────────────────────────────────────────────────────────
const REJECTED = 'Descarga rechazada por el usuario.';
const STOPPED = 'Tarea detenida por el usuario.';
function downloadSpec(args = {}) {
  const url = String(args.url || '').trim();
  if (!url) throw new Error('Falta la dirección (url) del archivo.');
  const mb = Math.max(50, Math.min(20480, Number(C.state.settings.downloadMaxMB) || 2048));
  return {
    url,
    name: String(args.name || '').slice(0, 200),
    purpose: String(args.purpose || args.reason || '').slice(0, 300),
    sha256: String(args.sha256 || '').trim(),
    checksumUrl: String(args.checksum_url || args.checksumUrl || '').trim(),
    maxBytes: mb * 1024 * 1024
  };
}
// Devuelve el resultado de la descarga o lanza un Error con un mensaje claro (la persona dijo que no, se canceló, falló una comprobación…).
export async function downloadFile(args, { session = null, origin = 'ia' } = {}) {
  const spec = downloadSpec(args);
  live(session, 'Comprobando el enlace de descarga…', safeHost(spec.url));
  const plan = await call(() => C.D.downloads.prepare(spec, { permission: session?.permission || '' }));
  live(session, 'Esperando tu permiso para descargar…', plan.name);
  const answer = await queued(() => confirmDownload(plan, { origin, stopped: stoppedFn(session) }));
  if (plan.status === 'blocked') {
    // La persona vio por qué se bloqueó; la IA también debe saberlo para buscar otra fuente en vez de insistir.
    const why = (plan.warnings || []).filter(w => w.level === 'block').map(w => w.text);
    throw new Error(`Auric bloqueó la descarga por seguridad: ${why.join(' ') || 'no cumple las comprobaciones.'}`);
  }
  if (answer !== 'ok') {
    await C.D.downloads.cancel(plan.id).catch(() => {});
    throw new Error(answer === 'stopped' ? STOPPED : REJECTED);
  }
  await call(() => C.D.downloads.approve(plan.id));
  addCard(plan);
  live(session, `Descargando ${plan.name}…`, plan.sizeText);
  const stop = stoppedFn(session);
  const watch = setInterval(() => {
    if (stop()) C.D.downloads.cancel(plan.id).catch(() => {});
  }, 250);
  const unsubscribe = C.D.on('download-progress', p => {
    if (p?.id === plan.id && p.total)
      live(session, `Descargando ${plan.name}…`, `${Math.round((p.received / p.total) * 100)} % · ${fmtSpeed(p.speed)}`);
  });
  try {
    const result = await call(() => C.D.downloads.start(plan.id));
    return { ...result, plan };
  } catch (err) {
    if (err.code === 'CANCELLED') throw new Error(stop() ? STOPPED : 'Descarga cancelada por el usuario.');
    throw err;
  } finally {
    clearInterval(watch);
    try {
      unsubscribe?.();
    } catch {}
  }
}
export function describeDownload(r) {
  const hash =
    r.hashStatus === 'match'
      ? `coincide con la suma publicada por ${r.hashSource}`
      : 'no había una suma publicada con la que comparar; la persona la vio en pantalla';
  return [
    'Descarga completada.',
    `Archivo: ${r.path}`,
    `Tamaño: ${r.sizeText}`,
    `SHA-256: ${r.sha256} (${hash})`,
    `Descargado de: ${r.host}`,
    `ID de descarga: ${r.id}`,
    'Nada se ha abierto ni ejecutado.' +
      (r.canRunLater
        ? ' Si hay que instalarlo, usa install_app con este ID de descarga: pide un permiso aparte a la persona y le enseña el comando exacto.'
        : '')
  ].join('\n');
}
export async function downloadFileTool(session, args = {}) {
  return describeDownload(await downloadFile(args, { session, origin: 'ia' }));
}

// ── Ejecutar un instalador descargado (permiso aparte) ─────────────────────────────────────────────────────
export async function runInstaller(target, { session = null } = {}) {
  live(session, 'Preparando la instalación…', '');
  const plan = await call(() =>
    C.D.run.prepare(
      { downloadId: target.downloadId || '', path: target.path || '', args: Array.isArray(target.args) ? target.args : [] },
      { permission: session?.permission || '' }
    )
  );
  live(session, 'Esperando tu permiso para ejecutar el instalador…', plan.name);
  const answer = await queued(() => confirmRun(plan, { stopped: stoppedFn(session) }));
  if (answer !== 'ok') throw new Error(answer === 'stopped' ? STOPPED : 'Ejecución rechazada por el usuario.');
  await call(() => C.D.run.approve(plan.id));
  live(session, `Abriendo ${plan.name}…`, plan.command);
  const out = await call(() => C.D.run.start(plan.id));
  return { ...out, plan };
}
export function describeRun(r) {
  const quick = r.exited
    ? r.exitCode === 0 || r.exitCode == null
      ? 'El programa terminó enseguida (puede ser normal si solo lanza otro proceso).'
      : `El programa terminó enseguida con el código ${r.exitCode}: puede que haya fallado.`
    : 'El asistente del instalador está abierto en la pantalla de la persona; Auric no puede ver cuándo termina.';
  return [
    `Se inició el instalador «${r.plan.name}».`,
    `Comando: ${r.command}`,
    quick,
    'Pídele a la persona que te avise cuando termine y comprueba el resultado con un comando inocuo (por ejemplo, la versión del programa).'
  ].join('\n');
}
export async function installAppTool(session, args = {}) {
  let downloadId = String(args.download_id || args.downloadId || '').trim();
  const filePath = String(args.path || '').trim();
  if (!downloadId && !filePath) {
    if (!String(args.url || '').trim())
      throw new Error('install_app necesita el ID de una descarga (download_id), la ruta de un archivo descargado o una dirección (url).');
    // Una sola petición del modelo, dos permisos distintos: primero descargar, después ejecutar.
    downloadId = (await downloadFile(args, { session, origin: 'ia' })).id;
  }
  const out = await runInstaller({ downloadId, path: filePath, args: args.args }, { session });
  return describeRun(out);
}

// Flujo iniciado por la persona desde Ajustes (por ejemplo, «Instalar Ollama»): mismas ventanas, mismos permisos.
export async function installProgram(spec) {
  try {
    const got = await downloadFile(spec, { origin: 'user' });
    if (!got.canRunLater) return { ok: true, downloaded: true, path: got.path };
    const out = await runInstaller({ downloadId: got.id });
    return { ok: true, started: true, exited: !!out.exited, exitCode: out.exitCode, path: got.path };
  } catch (err) {
    if (err?.message === REJECTED || err?.message === 'Ejecución rechazada por el usuario.' || err?.message === STOPPED)
      return { ok: false, cancelled: true };
    throw err;
  }
}

// ── Ajustes: carpeta, límite y registro ────────────────────────────────────────────────────────────────
const EVENT_TEXT = {
  prepared: 'Enlace revisado',
  approved: 'Descarga confirmada por ti',
  started: 'Descarga iniciada',
  done: 'Descarga terminada',
  failed: 'Descarga fallida',
  cancelled: 'Descarga cancelada',
  'run-prepared': 'Instalador preparado (esperando tu permiso)',
  'run-approved': 'Ejecución confirmada por ti',
  'run-started': 'Instalador ejecutado',
  'run-failed': 'No se pudo ejecutar el instalador',
  deleted: 'Archivo eliminado'
};
function logDetail(r) {
  const parts = [];
  if (r.name) parts.push(`<b>${e(r.name)}</b>`);
  if (r.host) parts.push(e(r.host));
  if (r.size != null && Number.isFinite(Number(r.size))) parts.push(e(fmtBytes(r.size)));
  if (r.command) parts.push(`<code class="dl-code">${e(String(r.command).slice(0, 300))}</code>`);
  if (r.file && !r.command) parts.push(`<code class="dl-code">${e(r.file)}</code>`);
  if (r.reason) parts.push(`<span class="dl-err">${e(String(r.reason).slice(0, 240))}</span>`);
  if (r.sha256) parts.push(`<span class="dl-muted" title="${e(r.sha256)}">SHA-256 ${e(String(r.sha256).slice(0, 12))}…</span>`);
  if (!parts.length && r.url) parts.push(e(String(r.url).slice(0, 200)));
  return parts.join(' · ');
}
export async function renderDownloadsSettings(host) {
  host.innerHTML = `<h4>Descargas</h4><p class="desc">Cargando…</p>`;
  let dir = '',
    rows = [],
    problem = '';
  try {
    dir = await call(() => C.D.downloads.dir());
  } catch (err) {
    problem = err.message;
  }
  try {
    rows = await call(() => C.D.downloads.log(200));
  } catch (err) {
    problem = problem || err.message;
  }
  const maxMb = Math.max(50, Math.min(20480, Number(C.state.settings.downloadMaxMB) || 2048));
  const tableRows = rows
    .map(
      r =>
        `<tr data-event="${e(r.event)}"><td class="dl-when">${e(fmtDate(r.ts))}</td><td>${e(EVENT_TEXT[r.event] || r.event)}</td><td class="dl-what">${logDetail(r)}</td><td class="dl-row-actions">${r.event === 'done' ? `<button class="secondary-btn compact-btn" data-dl-log="show" data-id="${e(r.id)}">Mostrar</button><button class="secondary-btn compact-btn" data-dl-log="delete" data-id="${e(r.id)}" data-name="${e(r.name || '')}">Eliminar</button>` : ''}</td></tr>`
    )
    .join('');
  host.innerHTML = `<h4>Descargas e instalaciones</h4>
<p class="desc">Auric solo descarga o instala cuando tú lo aceptas, también en modo <b>Completo</b>. Antes de aceptar ves la dirección real, el tamaño, el nombre y el tipo de archivo. Descargar y ejecutar son dos permisos distintos, y todo queda anotado aquí abajo.</p>
${problem ? `<div class="cx-banner">No se pudo leer parte de la información: ${e(problem)}</div>` : ''}
<div class="form-grid">
  <div class="form-field full"><label>Carpeta de descargas de Auric</label><div class="dl-folder"><code class="dl-code" data-dl="folder">${e(dir || '—')}</code><button class="secondary-btn compact-btn" id="dlOpenFolder" ${dir ? '' : 'disabled'}>Abrir carpeta</button></div><div class="form-help">Todo lo que Auric descarga va aquí, nunca a tus proyectos. Un archivo nunca reemplaza a otro con el mismo nombre.</div></div>
  <div class="form-field"><label>Tamaño máximo por descarga (MB)</label><input id="dlMaxMb" type="number" min="50" max="20480" step="50" value="${maxMb}"><div class="form-help">Por seguridad, Auric corta cualquier descarga que pase de este tamaño.</div></div>
</div>
<div class="modal-actions" style="border:0;padding:6px 0 14px"><span style="flex:1"></span><button id="dlSave" class="primary-btn">Guardar</button></div>
<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">Registro de descargas y ejecuciones</div><button class="secondary-btn compact-btn" id="dlReload">Actualizar</button></div>
${rows.length ? `<div class="dl-log-wrap"><table class="dl-log" data-dl="log"><thead><tr><th>Cuándo</th><th>Qué pasó</th><th>Detalle</th><th></th></tr></thead><tbody>${tableRows}</tbody></table></div>` : `<p class="lm-text" data-dl="log-empty">Todavía no hay descargas ni ejecuciones.</p>`}
</div>`;
  const q = sel => host.querySelector(sel);
  q('#dlOpenFolder')?.addEventListener('click', () => C.D.openPath(dir).catch(() => {}));
  q('#dlReload').onclick = () => renderDownloadsSettings(host);
  q('#dlSave').onclick = async () => {
    C.state.settings.downloadMaxMB = Math.max(50, Math.min(20480, Number(q('#dlMaxMb').value) || 2048));
    await C.saveState();
    C.toast('Descargas', 'Límite guardado', 'success');
  };
  host.onclick = async ev => {
    const b = ev.target.closest('[data-dl-log]');
    if (!b || !host.contains(b)) return;
    try {
      if (b.dataset.dlLog === 'show') await call(() => C.D.downloads.show(b.dataset.id));
      else if (b.dataset.dlLog === 'delete') {
        const sure = await C.appConfirm({
          title: 'Eliminar archivo descargado',
          message: `¿Mover «${b.dataset.name || 'este archivo'}» a la Papelera?`,
          buttons: ['Cancelar', 'Mover a la Papelera'],
          defaultId: 0,
          cancelId: 0,
          type: 'warning'
        });
        if (sure !== 1) return;
        await call(() => C.D.downloads.remove(b.dataset.id));
        await renderDownloadsSettings(host);
      }
    } catch (err) {
      C.toast('Descargas', err.message, 'error', 6000);
    }
  };
}
