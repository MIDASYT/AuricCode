// Recuperación de respuestas de modelos: largo máximo de cada respuesta, respuestas que se cortan (por límite de largo o porque la conexión
// se cayó), cómo continuarlas sin repetir, y mensajes claros por servicio cuando algo falla.
// Son funciones puras (sin pantalla ni red) para poder probarlas una por una; app.js las usa en la llamada al modelo.

// ── Largo máximo de la respuesta ───────────────────────────────────────────────────────────────────────────────
export const OUTPUT_HARD_MAX = 65536;
export const OUTPUT_CHOICES = [
  ['auto', 'Automático (recomendado)'],
  ['4096', 'Corto · unas 3.000 palabras'],
  ['8192', 'Medio · unas 6.000 palabras'],
  ['16384', 'Largo · unas 12.000 palabras'],
  ['32768', 'Muy largo · unas 24.000 palabras'],
  ['65536', 'Máximo · unas 48.000 palabras'],
  ['provider', 'Dejar el límite que ponga el proveedor']
];
export const limitKey = (providerId, model) => `${providerId}::${model}`;
const positive = n => (Number(n) > 0 && Number.isFinite(Number(n)) ? Math.floor(Number(n)) : 0);

// Qué límite de salida mandar a un modelo. value 0 = no mandar ninguno (el proveedor decide).
//   setting  'auto' | 'provider' | número (lo que eligió la persona en Ajustes)
//   learned  lo que Auric aprendió de este modelo: { explicit, cap, never }
//   record   ficha del modelo (puede traer maxOutputTokens, p. ej. outputTokenLimit de Google)
// «Automático» no cambia nada hasta que hace falta: solo se manda un límite explícito a Google (donde es seguro, porque la ficha dice el máximo
// del modelo), a Claude (que lo exige) y a los modelos que ya se cortaron por largo una vez (se aprende y se guarda).
export function resolveOutputLimit({ providerId, kind, model, record = null, setting = 'auto', learned = {} } = {}) {
  const L = (learned && learned[limitKey(providerId, model)]) || {};
  const caps = [positive(record?.maxOutputTokens), positive(L.cap)].filter(Boolean);
  const cap = caps.length ? Math.min(...caps) : 0;
  const within = n => (cap ? Math.min(n, cap) : n);
  if (L.never) return { value: 0, source: 'rejected', cap };
  if (setting === 'provider') return { value: 0, source: 'provider', cap };
  const chosen = positive(setting);
  if (chosen) return { value: within(Math.min(chosen, OUTPUT_HARD_MAX)), source: 'user', cap };
  if (positive(L.explicit)) return { value: within(Math.min(positive(L.explicit), OUTPUT_HARD_MAX)), source: 'learned', cap };
  if (kind === 'anthropic') return { value: within(16384), source: 'default', cap };
  if (kind === 'gemini' && positive(record?.maxOutputTokens))
    return { value: Math.min(positive(record.maxOutputTokens), OUTPUT_HARD_MAX), source: 'model', cap };
  return { value: 0, source: 'provider', cap };
}

// Cuánto subir el límite cuando una respuesta se corta por largo. 0 = ya no se puede subir más (solo queda continuar la respuesta).
export function escalateOutputLimit(requested, { cap = 0 } = {}) {
  const top = cap > 0 ? Math.min(cap, OUTPUT_HARD_MAX) : OUTPUT_HARD_MAX;
  const from = positive(requested);
  const next = Math.min(from < 16384 ? 16384 : from * 2, top);
  return next > from ? next : 0;
}

// Algunos servicios rechazan un límite demasiado grande y dicen cuál es el máximo en el mensaje. Devuelve ese máximo (o 0 si no se entiende).
const LIMIT_PATTERNS = [
  /valid range of max_tokens is \[\s*\d+\s*,\s*(\d{3,7})\s*\]/i,
  /max_tokens:\s*\d+\s*>\s*(\d{3,7})/i,
  />\s*(\d{3,7}),?\s*which is the maximum/i,
  /(?:supports?|allows?|accepts?) (?:at most|up to|a maximum of|no more than)\s*`?(\d{3,7})/i,
  /(?:must be|should be|needs to be)\s*(?:less than or equal to|<=|at most|no more than|lower than or equal to)\s*`?(\d{3,7})/i,
  /(?:at most|no more than|up to|a maximum of|maximum (?:value )?(?:of|is|allowed is|allowed)?)\s*`?(\d{3,7})\s*(?:completion |output )?tokens?/i,
  /max(?:imum)?(?:_| )?(?:output|completion)?(?:_| )?tokens?[^.\d]{0,60}?(?:<=|≤|is|of|limit|max(?:imum)?)\s*`?(\d{3,7})/i,
  /(?:limit|limited) (?:of|to|is)\s*`?(\d{3,7})\s*(?:completion |output )?tokens?/i
];
export function parseOutputLimitError(message, requested) {
  const text = String(message || '');
  const asked = positive(requested) || Infinity;
  for (const re of LIMIT_PATTERNS) {
    const m = re.exec(text);
    const n = m ? positive(m[1]) : 0;
    if (n >= 256 && n < asked) return n;
  }
  return 0;
}
// ¿El error dice que el problema es el límite de salida que se mandó?
export const isOutputLimitError = e => {
  const msg = String(e?.message || '');
  return (
    [400, 413, 422].includes(Number(e?.status || 0)) &&
    /max_tokens|max_completion_tokens|max_output_tokens|maxOutputTokens|output tokens|completion tokens/i.test(msg)
  );
};
// Rebaja el límite pedido cuando el servicio lo rechazó: si el mensaje dice el máximo se usa ese; si no, se baja por escalones.
// 0 = ya no se manda ningún límite (lo decide el proveedor).
export function lowerOutputLimit(requested, message) {
  const said = parseOutputLimitError(message, requested);
  if (said) return said;
  const r = positive(requested);
  if (r > 8192) return 8192;
  if (r > 4096) return 4096;
  if (r > 2048) return 2048;
  return 0;
}
// Los modelos de razonamiento de OpenAI y algunos compatibles piden max_completion_tokens en lugar de max_tokens.
export const wantsCompletionTokens = message => {
  const m = String(message || '');
  return /max_completion_tokens/i.test(m) && /unsupported|not supported|use |instead|deprecated|invalid/i.test(m);
};
// ¿El servicio rechazó la petición POR pedir la respuesta por partes? (se vuelve a pedir de golpe y, si así funciona, se recuerda)
export function looksLikeStreamRejection(e) {
  const status = Number(e?.status || 0);
  const msg = `${e?.message || ''}\n${e?.responseText || ''}`;
  if ([404, 405, 406, 415, 501].includes(status)) return true;
  return [400, 422].includes(status) && /stream|event-stream|\bsse\b|text\/event/i.test(msg);
}

// ── Respuesta por partes: cuándo se desactiva ─────────────────────────────────────────────────────────────────
// Solo se recuerda que un proveedor «no admite respuesta por partes» cuando fue rechazada Y la misma petición de golpe funcionó.
// Caduca a los 7 días para que un fallo pasajero no deje la función apagada para siempre.
export const STREAM_OFF_DAYS = 7;
export function streamDisabled(streamOff, providerId, now = Date.now()) {
  const x = streamOff && typeof streamOff === 'object' ? streamOff[providerId] : null;
  if (!x) return false;
  return now - (Number(x.at) || 0) < STREAM_OFF_DAYS * 86400000;
}

// ── Cómo terminó la respuesta ──────────────────────────────────────────────────────────────────────────────────
const LENGTH_RE =
  /^(length|max_tokens|max_output_tokens|max_completion_tokens|model_length|token_limit|max_tokens_reached|finish_reason_length)$/i;
const BLOCKED_RE =
  /^(content_filter|safety|recitation|blocklist|prohibited_content|spii|image_safety|image_prohibited_content|refusal|language)$/i;
const MALFORMED_RE = /^(malformed_function_call|unexpected_tool_call|too_many_tool_calls)$/i;
export function isLengthFinish(finishReason, raw) {
  const f = String(finishReason || '').trim();
  if (LENGTH_RE.test(f)) return true;
  // OpenAI Responses: «incomplete» por tamaño
  return /^incomplete$/i.test(f) && /max_output_tokens|max_tokens|length/i.test(String(raw?.incomplete_details?.reason || ''));
}
export const isBlockedFinish = finishReason => BLOCKED_RE.test(String(finishReason || '').trim());
export const isMalformedFinish = finishReason => MALFORMED_RE.test(String(finishReason || '').trim());
// '' = terminó bien · 'length' = llegó al límite de largo · 'cut' = el flujo se cortó (silencio, conexión caída, sin marca de fin, error a mitad)
export function truncationKind(result) {
  if (!result) return '';
  if (result.stream?.incomplete) return 'cut';
  return isLengthFinish(result.finishReason, result.raw) ? 'length' : '';
}

// ── Continuar una respuesta cortada ───────────────────────────────────────────────────────────────────────────
export const MAX_CONTINUATIONS = 6;
export const CONTINUE_PROMPT =
  'Your previous reply was cut off before it finished (output length limit or a dropped connection). Continue EXACTLY from where it stopped: ' +
  'no preamble, do not repeat anything you already wrote, same language and same format (if you were inside a code block or a JSON object, keep going inside it).';
export const SMALLER_PIECES_PROMPT =
  'Your previous reply was cut off by the output length limit while you were writing a tool call, so that call was discarded and NOT executed. ' +
  'Do the same work in smaller pieces: shorter file contents (write big files in several parts, e.g. create the file with the first part and append the rest with apply_patch), and fewer parallel calls. Then continue.';

// Une la continuación al texto anterior. Los modelos suelen repetir las últimas palabras: si el principio de lo nuevo ya estaba al final de lo anterior
// (12 caracteres o más), no se duplica.
export function mergeContinuation(previous, next) {
  const a = String(previous || ''),
    b = String(next || '');
  if (!b) return a;
  const max = Math.min(240, a.length, b.length);
  for (let n = max; n >= 12; n--) if (a.endsWith(b.slice(0, n))) return a + b.slice(n);
  return a + b;
}

// ── El bucle de recuperación ─────────────────────────────────────────────────────────────────────────────────
// Recibe una función `call` que hace UNA llamada al modelo y devuelve el resultado normalizado ({ text, toolCalls, finishReason, stream… }).
// Decide qué hacer cuando la respuesta no llegó entera: continuarla, subir el límite, rehacer una acción cortada en trozos más pequeños,
// pedirla de golpe si el flujo no se entiende, etc. Nunca ejecuta una acción cortada y nunca tira lo ya escrito.
export class RecoveryError extends Error {
  constructor(code, message, extra = {}) {
    super(message);
    this.code = code;
    Object.assign(this, extra);
  }
}
export const MALFORMED_PROMPT =
  'Your last tool call was malformed and could not be executed. Retry it with valid JSON arguments that match the tool schema.';
const DROPPED_NOTE =
  '\n\n[Auric: the last tool call was cut off by the output length limit and was NOT executed. Redo it in smaller pieces.]';
const NORMAL_STOP_RE = /^(stop|end_turn|completed|complete|tool_calls|tool_use|function_call|eos|end|finished)$/i;
export const isNormalStop = f => NORMAL_STOP_RE.test(String(f || '').trim());
const isAbort = e => /^ABORTED:/.test(String(e?.message || ''));
export const partialNote = reason =>
  `\n\nLa respuesta se cortó y no se pudo terminar${reason ? ` (${reason})` : ''}. Escribe «continúa» y sigo desde aquí.`;
const shortReason = e =>
  String(e?.message || e || '')
    .replace(/\s+/g, ' ')
    .slice(0, 140);

export async function recoverCall({
  call,
  messages,
  limit = { value: 0, source: 'provider', cap: 0 },
  learn = () => {},
  status = () => {},
  isTransient = () => false,
  sleep = ms => new Promise(r => setTimeout(r, ms)),
  shouldStop = () => false,
  maxContinuations = MAX_CONTINUATIONS
} = {}) {
  const n = { continuations: 0, smaller: 0, malformed: 0, empty: 0, contErrors: 0 };
  let override = 0,
    noStream = false,
    streamUnusable = false,
    working = messages,
    acc = '',
    accReasoning = '',
    last = null;
  const requested = () => override || positive(limit.value);
  // El límite que eligió la persona en Ajustes se respeta siempre: solo se sube el que Auric puso o aprendió.
  const raise = () => {
    if (limit.source === 'user') return 0;
    const next = escalateOutputLimit(requested(), { cap: limit.cap });
    if (next) {
      override = next;
      learn({ type: 'raise', value: next, source: limit.source });
    }
    return next;
  };
  const partial = reason => ({
    ...(last || { toolCalls: [], reasoningDetails: null, usage: null, raw: null, stream: null }),
    text: acc + partialNote(reason),
    reasoningContent: accReasoning,
    toolCalls: [],
    finishReason: last?.finishReason || 'length',
    truncated: true,
    continued: n.continuations
  });

  for (let turn = 0; turn < 40; turn++) {
    if (shouldStop()) throw new Error('ABORTED: petición cancelada.');
    let r;
    try {
      r = await call(working, { override, noStream });
    } catch (e) {
      if (isAbort(e) || shouldStop()) throw e;
      if (!acc) throw e;
      // Ya hay texto escrito: una continuación que falla no lo tira. Si el fallo es pasajero se reintenta unas veces; si no, se entrega lo escrito con un aviso.
      if (isTransient(e) && n.contErrors < 3) {
        n.contErrors++;
        status('Reconectando para seguir la respuesta…', `intento ${n.contErrors} de 3`);
        await sleep(1500 * n.contErrors);
        continue;
      }
      return partial(shortReason(e));
    }
    last = r;
    const f = String(r.finishReason || ''),
      kind = truncationKind(r),
      calls = Array.isArray(r.toolCalls) ? r.toolCalls : [];
    let text = String(r.text || '');
    if (acc) {
      // Si el modelo, en vez de continuar, volvió a empezar desde el principio, se queda con lo más largo en lugar de duplicar.
      if (acc.length > 80 && text.length > 80 && text.slice(0, 60) === acc.slice(0, 60)) text = text.length >= acc.length ? text : acc;
      else text = mergeContinuation(acc, text);
    }
    const reasoning = accReasoning + String(r.reasoningContent || ''),
      hasText = !!text.trim(),
      done = extra => ({ ...r, reasoningContent: reasoning, continued: n.continuations, ...extra });

    // 1) Llegó por partes pero sin nada aprovechable y sin marca de fin (un formato que no entendemos): se pide de golpe.
    if (r.stream?.incomplete === 'no-terminal' && !hasText && !calls.length && !noStream) {
      noStream = true;
      streamUnusable = true;
      status('Pidiendo la respuesta de otra forma…', 'el servicio no mandó la respuesta por partes como se esperaba');
      continue;
    }
    if (streamUnusable && noStream && (hasText || calls.length)) {
      streamUnusable = false;
      learn({ type: 'stream-unusable' });
    }

    // 2) Sin texto ni acciones.
    if (!hasText && !calls.length) {
      const detail = String(r.raw?.promptFeedback?.blockReason || f || '');
      if (isBlockedFinish(f) || r.raw?.promptFeedback?.blockReason)
        throw new RecoveryError('BLOCKED', `Respuesta bloqueada por el proveedor (${detail}).`, { detail });
      if (kind === 'cut')
        throw new RecoveryError('STREAM_CUT', 'La respuesta se cortó antes de que llegara nada útil.', { detail: r.stream?.detail || '' });
      if (kind === 'length') {
        learn({ type: 'length-hit', requested: requested(), source: limit.source });
        if (raise()) {
          status('Subiendo el largo de la respuesta…', 'el modelo gastó todo su límite pensando');
          continue;
        }
        throw new RecoveryError(
          'LENGTH_EXHAUSTED',
          'El modelo agotó su límite de largo antes de escribir la respuesta (gastó todo pensando).'
        );
      }
      if (isMalformedFinish(f)) {
        if (n.malformed < 2) {
          n.malformed++;
          status('Corrigiendo una llamada mal formada…', `intento ${n.malformed} de 2`);
          working = [...messages, { role: 'user', content: MALFORMED_PROMPT }];
          continue;
        }
        throw new RecoveryError('EMPTY_RESPONSE', 'El modelo no logró formar una llamada válida.', { detail: f });
      }
      if (!isNormalStop(f)) {
        if (n.empty < 1) {
          n.empty++;
          status('El modelo respondió vacío…', 'reintentando');
          continue;
        }
        throw new RecoveryError('EMPTY_RESPONSE', 'El modelo respondió vacío.', { detail: f });
      }
      // Parada normal sin texto: se devuelve tal cual, como siempre.
      return done({ text });
    }

    // 3) Una acción cortada a la mitad NUNCA se ejecuta.
    const bad = calls.filter(c => c?.argsInvalid),
      good = calls.filter(c => !c?.argsInvalid);
    if (kind && bad.length) {
      if (kind === 'length') learn({ type: 'length-hit', requested: requested(), source: limit.source });
      if (good.length) return done({ text: text + DROPPED_NOTE, toolCalls: good });
      if (n.smaller < 2) {
        n.smaller++;
        raise();
        status('Rehaciendo la acción en trozos más pequeños…', 'la anterior se cortó por el largo');
        working = [
          ...messages,
          ...(hasText ? [{ role: 'assistant', content: text }] : []),
          { role: 'user', content: SMALLER_PIECES_PROMPT }
        ];
        acc = '';
        accReasoning = '';
        continue;
      }
      throw new RecoveryError('LENGTH_EXHAUSTED', 'Una acción larga se cortó varias veces seguidas por el límite de largo.');
    }

    // 4) Texto cortado: se continúa desde donde quedó.
    if (kind && !calls.length) {
      if (kind === 'length') learn({ type: 'length-hit', requested: requested(), source: limit.source });
      if (n.continuations >= maxContinuations) {
        acc = text;
        return partial('llegó al máximo de continuaciones');
      }
      n.continuations++;
      if (kind === 'length') raise();
      acc = text;
      accReasoning = reasoning;
      working = [...messages, { role: 'assistant', content: text }, { role: 'user', content: CONTINUE_PROMPT }];
      status('Continuando la respuesta…', `parte ${n.continuations + 1} · lo escrito hasta ahora se conserva`);
      continue;
    }

    // 5) Respuesta completa.
    return done({ text });
  }
  throw new RecoveryError('EMPTY_RESPONSE', 'Demasiados reintentos seguidos sin una respuesta completa.');
}

// ── Qué enseñar mientras llega la respuesta ───────────────────────────────────────────────────────────────────
export function describeStreamProgress(name, stats = {}) {
  const secs = Math.max(0, Math.round((Number(stats.elapsedMs) || 0) / 1000));
  const words = Math.round((Number(stats.chars) || 0) / 5.5);
  if (Number(stats.chars) > 0) return { text: `${name} está escribiendo…`, detail: `${secs} s · ≈${words.toLocaleString('es')} palabras` };
  if (Number(stats.toolCalls) > 0) return { text: `${name} está preparando una acción…`, detail: `${secs} s` };
  if (Number(stats.thoughtChars) > 0)
    return {
      text: `${name} está razonando…`,
      detail: `${secs} s · ≈${Math.round(stats.thoughtChars / 5.5).toLocaleString('es')} palabras de razonamiento`
    };
  return { text: `Esperando a ${name}…`, detail: `${secs} s` };
}

// ── Mensajes claros por servicio ──────────────────────────────────────────────────────────────────────────────
// Devuelve el texto en español para la persona, o '' si el error no es de los que sabemos explicar (entonces se muestra tal cual).
const retryDelaySeconds = text => {
  const m = /retryDelay"?\s*[:=]\s*"?(\d+(?:\.\d+)?)s|retry (?:in|after)\s*(\d+(?:\.\d+)?)\s*s/i.exec(String(text || ''));
  const n = m ? Number(m[1] || m[2]) : 0;
  return n > 0 ? Math.ceil(n) : 0;
};
const KEY_SAFE = name =>
  `Tu key no se ha filtrado ni se ha usado en otro sitio: Auric la guarda cifrada solo en este equipo y únicamente la envía a ${name}.`;
export function explainProviderError(p, e) {
  if (!e) return '';
  const name = p?.name || p?.id || 'el proveedor';
  const status = Number(e.status || 0) || Number(String(e.message || '').match(/HTTP\s+(\d{3})/i)?.[1] || 0);
  const msg = String(e.message || '');
  const body = `${msg}\n${e.responseText || ''}`;
  const code = String(e.code || '');
  const crowd = /overload|high demand|UNAVAILABLE|busy|capacity|temporar|try again later|too many requests|saturad/i.test(body);

  if (code === 'STREAM_CUT')
    return `${name} cortó la conexión a mitad de la respuesta${e.detail ? ` (${e.detail})` : ''}. Auric conservó lo que había llegado y lo reintenta; si se repite, prueba otro modelo o configura un respaldo.`;
  if (code === 'EMPTY_RESPONSE')
    return `${name} respondió vacío. A veces pasa cuando el modelo gasta todo su límite pensando o el servicio está saturado. Auric lo reintenta.`;
  if (code === 'BLOCKED')
    return `${name} bloqueó la respuesta con sus filtros de seguridad${e.detail ? ` (motivo: ${e.detail})` : ''}. Reformula el pedido o prueba otro modelo.`;
  if (code === 'LENGTH_EXHAUSTED')
    return `La respuesta de ${name} llegó al límite de largo varias veces seguidas. Pide el trabajo por partes más pequeñas o sube «Largo máximo de cada respuesta» en Ajustes → Agente.`;
  if (/^ETIMEDOUT:/.test(msg) || code === 'ETIMEDOUT')
    return `${name} no envió ningún dato durante el tiempo máximo y Auric dejó de esperar. Suele pasar cuando el servicio está saturado (en hora punta los modelos gratuitos hacen cola). Prueba de nuevo, elige otro modelo o sube «Tiempo máximo sin respuesta» en Ajustes → Agente.`;
  if (/^NETWORK:/.test(msg)) {
    const why = /ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ECONNRESET|UND_ERR|terminated|socket|fetch failed|cerró la conexión/i.test(msg) ? '' : '';
    return `No se pudo mantener la conexión con ${name}${why} (sin internet, un cortafuegos o proxy, o el servicio tuvo una caída). Auric reintenta solo; si no vuelve, revisa tu conexión.`;
  }
  if (!status) return '';
  if (p?.id === 'cerebras' && status === 402) return 'Cerebras indica que esta cuenta necesita saldo o un plan (402). El uso gratuito pertenece a cuentas Personal cuando está disponible; comprueba si tu clave está vinculada a una cuenta Team.';
  if (status === 400)
    return `${name} rechazó la petición (error 400). Suele significar que el modelo elegido no admite alguna opción de esta tarea; prueba otro modelo o menos razonamiento.`;
  if (status === 401)
    return `${name} no aceptó la API key (error 401). Lo más habitual es una key mal copiada, caducada, revocada o de otro proveedor. Revísala o crea una nueva en la web de ${name}. ${KEY_SAFE(name)}`;
  if (status === 402)
    return `${name} indica que la cuenta no tiene saldo o plan de pago activo (error 402). Revisa tu facturación en ${name}. ${KEY_SAFE(name)}`;
  if (status === 403)
    return `${name} denegó el acceso (error 403). La key es válida pero puede no tener permiso para este modelo, región o función, o la cuenta necesita activar pagos. ${KEY_SAFE(name)}`;
  if (status === 404)
    return `${name} no encontró el modelo o la ruta pedida (error 404). Puede que el modelo ya no exista o no esté habilitado para tu cuenta; elige otro modelo.`;
  if (status === 413)
    return `${name} dice que la conversación es demasiado grande para este modelo (error 413). Empieza un chat nuevo o usa «compactar», o elige un modelo con más memoria.`;
  if (status === 429) {
    const wait = retryDelaySeconds(body);
    if (/PerDay|per day|daily|diari/i.test(body))
      return `Se acabó la cuota DIARIA gratuita de ${name} para este modelo (error 429). No es un problema de tu key: se renueva más tarde (la de Google, a medianoche hora del Pacífico). Elige otro modelo o añade un respaldo.`;
    if (/PerMinute|per minute|per second|too many requests|rate.?limit|tokens per minute|requests per minute/i.test(body))
      return `Pediste demasiado rápido y ${name} limitó el ritmo (error 429)${wait ? `: espera unos ${wait} s` : ''}. No es un problema de tu key; Auric reintenta solo.`;
    return `${name} aplicó un límite de uso o cuota (error 429)${wait ? `; vuelve a intentar en unos ${wait} s` : ''}. No es un problema de tu key: espera un poco o cambia de modelo.`;
  }
  if (status === 408 || status === 504 || status === 522 || status === 524)
    return `El servidor de ${name} (o la puerta que tiene delante) cortó la conexión porque la respuesta tardó demasiado (error ${status}). No es un problema de tu key. Auric ahora recibe las respuestas por partes para evitarlo; si sigue pasando, el modelo está saturado: prueba otro o configura un respaldo.`;
  if (status >= 500 && (crowd || status === 503 || status === 529))
    return `${name} está saturado en este momento (error ${status}): mucha gente usa el modelo a la vez, algo habitual en hora punta con los modelos gratuitos. No es un problema de tu key. Auric reintenta solo y, si configuraste un respaldo, cambia a él.`;
  if (status >= 500)
    return `${name} tuvo un fallo de su lado (error ${status}). No es un problema de tu key; Auric reintentará o puedes elegir otro modelo.`;
  return '';
}
