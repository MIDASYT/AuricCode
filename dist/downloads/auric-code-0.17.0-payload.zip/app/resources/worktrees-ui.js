export async function renderWorktrees(host, C) {
  const { D, esc, currentSession, sessionRoots, nativeAgentContext, appConfirm } = C;
  const session = currentSession();
  host.innerHTML = '<h4>Copias por tarea</h4><p class="desc">Cada tarea puede trabajar en su propia copia de Git. La carpeta original conserva sus cambios. Las copias parten del último commit.</p>';
  if (!session || !sessionRoots(session).length) { host.insertAdjacentHTML('beforeend', '<p>Abre un proyecto para crear una copia.</p>'); return; }
  const ctx = nativeAgentContext(session);
  const load = await D.worktrees({ action: 'list' }, ctx);
  if (!load.ok) { host.append(Object.assign(document.createElement('p'), { textContent: load.error })); return; }
  host.insertAdjacentHTML('beforeend', '<button class="primary-btn" id="createTaskCopy">Crear copia para una tarea</button><div id="copyResult" aria-live="polite"></div><div id="taskCopyRows">' + load.value.map(row => '<div class="settings-section"><b>' + esc(row.name) + '</b><p>' + esc(row.branch) + '</p><small>' + esc(row.path) + '</small><div class="inline-actions"><button class="secondary-btn" data-copy-open="' + esc(row.id) + '">Trabajar aquí</button><button class="secondary-btn" data-copy-inspect="' + esc(row.id) + '">Revisar</button><button class="secondary-btn" data-copy-merge="' + esc(row.id) + '">Integrar commits</button><button class="secondary-btn" data-copy-remove="' + esc(row.id) + '">Eliminar copia</button></div></div>').join('') + '</div>');
  const result = host.querySelector('#copyResult');
  const invoke = async (spec, approved = false) => { const r = await D.worktrees(spec, { ...ctx, approved }); if (!r.ok) throw new Error(r.error); return r.value; };
  const showError = error => result.textContent = error.message;
  host.querySelector('#createTaskCopy').onclick = async () => { try {
    const root = sessionRoots(session)[0];
    const yes = await appConfirm({ title: 'Crear una copia de trabajo', message: 'Se creará una rama y una copia del último commit de ' + (root.name || root.path) + '.', detail: 'Los cambios sin commit se quedan en su carpeta original. No se subirá nada a Internet.', buttons: ['Cancelar', 'Crear copia'] });
    if (yes !== 1) return;
    await invoke({ action: 'create', root: root.path, name: session.title || 'Tarea' }, true); await renderWorktrees(host, C);
  } catch (error) { showError(error); } };
  for (const button of host.querySelectorAll('[data-copy-open]')) button.onclick = () => C.openCopy(load.value.find(r => r.id === button.dataset.copyOpen));
  for (const button of host.querySelectorAll('[data-copy-inspect]')) button.onclick = async () => { try { const row = await invoke({ action: 'inspect', id: button.dataset.copyInspect }); result.textContent = [row.status, row.diff, row.commits, 'Los archivos nuevos sin commit aparecen en el estado; revisa su contenido antes de integrar.'].join('\n'); } catch (error) { showError(error); } };
  for (const button of host.querySelectorAll('[data-copy-merge]')) button.onclick = async () => { try { const row = load.value.find(r => r.id === button.dataset.copyMerge); await C.mergeCopy(row, result); } catch (error) { showError(error); } };
  for (const button of host.querySelectorAll('[data-copy-remove]')) button.onclick = async () => { try {
    const row = load.value.find(r => r.id === button.dataset.copyRemove);
    if (sessionRoots(session).some(root => root.path === row.path)) throw new Error('Cambia a la carpeta original antes de eliminar la copia activa.');
    const yes = await appConfirm({ title: 'Eliminar copia de trabajo', message: row.name, detail: 'Se eliminará solo esta carpeta de copia. Si hay cambios sin guardar, Auric se detendrá. La rama y sus commits se conservan.', buttons: ['Cancelar', 'Eliminar copia'] });
    if (yes !== 1) return; await invoke({ action: 'remove', id: row.id }, true); await renderWorktrees(host, C);
  } catch (error) { showError(error); } };
}
