export const providers = {
  auric: {
    id: 'auric',
    name: 'Auric',
    logo: 'auric-dragon.png',
    tier: 'free',
    kind: 'auric',
    virtual: true,
    note: 'Modelo incluido con Auric Code. No requiere API key ni configuración.'
  },
  local: {
    id: 'local',
    name: 'Mi PC',
    logo: 'local-pc.svg',
    tier: 'free',
    kind: 'ollama',
    auth: 'none',
    virtual: true,
    base: 'http://127.0.0.1:11434',
    note: 'Modelos que se ejecutan en tu propio equipo con Ollama. Gratis, privados y sin internet, pero más lentos y menos fiables que los modelos en la nube.',
    docsUrl: 'https://ollama.com/library'
  },
  gemini: {
    id: 'gemini',
    name: 'Google Gemini AI',
    logo: 'gemini.svg',
    tier: 'mixed',
    kind: 'gemini',
    note: 'Catálogo en vivo de Google. Auric Code clasifica cada modelo por separado cuando puede verificarlo.',
    base: 'https://generativelanguage.googleapis.com/v1beta',
    models: '/models?pageSize=1000',
    keyUrl: 'https://aistudio.google.com/app/apikey',
    docsUrl: 'https://ai.google.dev/gemini-api/docs',
    pricingUrl: 'https://ai.google.dev/gemini-api/docs/pricing'
  },
  openai: {
    id: 'openai',
    name: 'OpenAI / ChatGPT',
    logo: 'openai.png',
    tier: 'paid',
    kind: 'openai',
    note: 'API de OpenAI. Se factura por separado de ChatGPT.',
    base: 'https://api.openai.com/v1',
    models: '/models',
    chat: '/responses',
    keyUrl: 'https://platform.openai.com/api-keys',
    docsUrl: 'https://platform.openai.com/docs',
    pricingUrl: 'https://openai.com/api/pricing/'
  },
  anthropic: {
    id: 'anthropic',
    name: 'Anthropic Claude',
    logo: 'anthropic.png',
    tier: 'paid',
    kind: 'anthropic',
    note: 'Claude API. El razonamiento disponible depende del modelo.',
    base: 'https://api.anthropic.com/v1',
    models: '/models?limit=1000',
    chat: '/messages',
    keyUrl: 'https://console.anthropic.com/settings/keys',
    docsUrl: 'https://docs.anthropic.com/',
    pricingUrl: 'https://www.anthropic.com/pricing'
  },
  perplexity: {
    id: 'perplexity',
    name: 'Perplexity AI',
    logo: 'perplexity.jpeg',
    tier: 'paid',
    kind: 'openai',
    note: 'Sonar API con acceso web propio según el modelo.',
    base: 'https://api.perplexity.ai',
    models: '/models',
    modelsAlt: ['/v1/models'],
    chat: '/chat/completions',
    chatAlt: ['/v1/sonar'],
    keyUrl: 'https://www.perplexity.ai/settings/api',
    docsUrl: 'https://docs.perplexity.ai/',
    pricingUrl: 'https://docs.perplexity.ai/getting-started/pricing'
  },
  minimax: {
    id: 'minimax',
    name: 'MiniMax AI',
    logo: 'minimax.jpeg',
    tier: 'paid',
    kind: 'openai',
    note: 'API de pago por uso. Auric Code consulta el catálogo disponible para tu cuenta; un HTTP 402 indica saldo insuficiente.',
    base: 'https://api.minimax.io/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://platform.minimax.io/',
    docsUrl: 'https://platform.minimax.io/docs',
    pricingUrl: 'https://platform.minimax.io/'
  },
  grok: {
    id: 'grok',
    name: 'xAI Grok',
    logo: 'grok.png',
    tier: 'paid',
    kind: 'openai',
    note: 'xAI expone catálogo y precios por modelo mediante /v1/models.',
    base: 'https://api.x.ai/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://console.x.ai/',
    docsUrl: 'https://docs.x.ai/',
    pricingUrl: 'https://docs.x.ai/developers/models'
  },
  deepseek: {
    id: 'deepseek',
    name: 'DeepSeek AI',
    logo: 'deepseek.png',
    tier: 'paid',
    kind: 'openai',
    note: 'API compatible con OpenAI. El razonamiento depende del modelo.',
    base: 'https://api.deepseek.com/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://platform.deepseek.com/api_keys',
    docsUrl: 'https://api-docs.deepseek.com/',
    pricingUrl: 'https://api-docs.deepseek.com/quick_start/pricing'
  },
  kimi: {
    id: 'kimi',
    name: 'Kimi Moonshot',
    logo: 'kimi.jpeg',
    tier: 'mixed',
    kind: 'openai',
    note: 'Moonshot/Kimi. Auric Code consulta los modelos de la cuenta.',
    base: 'https://api.moonshot.ai/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://platform.moonshot.ai/console/api-keys',
    docsUrl: 'https://platform.moonshot.ai/docs',
    pricingUrl: 'https://platform.moonshot.ai/docs/pricing'
  },
  cohere: {
    id: 'cohere',
    name: 'Cohere Command',
    logo: 'cohere.svg',
    tier: 'mixed',
    kind: 'cohere',
    note: 'Command models mediante la API nativa de Cohere.',
    base: 'https://api.cohere.com/v2',
    modelsUrl: 'https://api.cohere.com/v1/models?endpoint=chat&page_size=1000',
    chat: '/chat',
    keyUrl: 'https://dashboard.cohere.com/api-keys',
    docsUrl: 'https://docs.cohere.com/',
    pricingUrl: 'https://cohere.com/pricing'
  },
  qwen: {
    id: 'qwen',
    name: 'Qwen AI',
    logo: 'qwen.png',
    tier: 'mixed',
    kind: 'openai',
    note: 'Model Studio / DashScope compatible con OpenAI.',
    base: 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://dashscope.console.aliyun.com/apiKey',
    docsUrl: 'https://www.alibabacloud.com/help/en/model-studio/',
    pricingUrl: 'https://www.alibabacloud.com/help/en/model-studio/model-pricing'
  },
  meta: {
    id: 'meta',
    name: 'Meta Model API',
    logo: 'meta.png',
    tier: 'mixed',
    kind: 'openai',
    note: 'Meta Model API oficial para Muse Spark. Compatible con Chat Completions y tool calling.',
    base: 'https://api.meta.ai/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://dev.meta.ai/',
    docsUrl: 'https://dev.meta.ai/docs/overview',
    pricingUrl: 'https://dev.meta.ai/products/meta-model-api'
  },
  groq: {
    id: 'groq',
    name: 'Groq Cloud',
    logo: 'groq.svg',
    tier: 'mixed',
    kind: 'openai',
    note: 'Inferencia muy rápida. La disponibilidad y los límites dependen de cada modelo/cuenta.',
    base: 'https://api.groq.com/openai/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://console.groq.com/keys',
    docsUrl: 'https://console.groq.com/docs',
    pricingUrl: 'https://groq.com/pricing'
  },
  openrouter: {
    id: 'openrouter',
    name: 'OpenRouter Gateway',
    logo: 'openrouter.svg',
    tier: 'mixed',
    kind: 'openai',
    note: 'Catálogo amplio. Las variantes :free y los precios cero se detectan automáticamente.',
    base: 'https://openrouter.ai/api/v1',
    models: '/models',
    chat: '/chat/completions',
    headers: { 'HTTP-Referer': 'https://auric-hub.web.app', 'X-OpenRouter-Title': 'Auric Code' },
    keyUrl: 'https://openrouter.ai/settings/keys',
    docsUrl: 'https://openrouter.ai/docs',
    pricingUrl: 'https://openrouter.ai/models'
  },
  huggingface: {
    id: 'huggingface',
    name: 'HuggingFace Hub',
    logo: 'huggingface.svg',
    tier: 'mixed',
    kind: 'openai',
    note: 'Inference Providers de Hugging Face. Créditos y precio dependen del proveedor/modelo.',
    base: 'https://router.huggingface.co/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://huggingface.co/settings/tokens',
    docsUrl: 'https://huggingface.co/docs/inference-providers/',
    pricingUrl: 'https://huggingface.co/docs/inference-providers/pricing'
  },
  nvidia: {
    id: 'nvidia',
    name: 'NVIDIA NIM',
    logo: 'nvidia.webp',
    tier: 'mixed',
    kind: 'openai',
    note: 'NVIDIA NIM / build.nvidia.com con tu propia API key. Auric consulta el catálogo de tu cuenta; no forma parte de Auric Free.',
    base: 'https://integrate.api.nvidia.com/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://build.nvidia.com/settings/api-keys',
    docsUrl: 'https://docs.nvidia.com/nim/large-language-models/latest/api-reference.html',
    pricingUrl: 'https://build.nvidia.com/'
  },
  cloudflare: {
    id: 'cloudflare',
    name: 'Cloudflare Workers AI',
    logo: 'cloudflare.png',
    tier: 'mixed',
    kind: 'openai',
    note: 'Workers AI con tu propio Account ID + API Token restringido. En Auric Free usa el binding AI del relay, sin exponer una key de tu cuenta.',
    base: 'https://api.cloudflare.com/client/v4/accounts',
    models: '/ai/models/search',
    chat: '/chat/completions',
    keyUrl: 'https://dash.cloudflare.com/profile/api-tokens',
    docsUrl: 'https://developers.cloudflare.com/workers-ai/',
    pricingUrl: 'https://developers.cloudflare.com/workers-ai/platform/pricing/'
  },
  vercel: {
    id: 'vercel',
    name: 'Vercel AI Gateway',
    logo: 'vercel.svg',
    tier: 'mixed',
    kind: 'openai',
    note: 'AI Gateway compatible con OpenAI usando tu propia key. Crea la key en Dashboard → AI Gateway → API Keys. No forma parte de Auric Free.',
    base: 'https://ai-gateway.vercel.sh/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://vercel.com/dashboard',
    docsUrl: 'https://vercel.com/docs/ai-gateway',
    pricingUrl: 'https://vercel.com/ai-gateway'
  },
  mistral: {
    id: 'mistral',
    name: 'Mistral AI',
    logo: 'mistral.png',
    tier: 'mixed',
    kind: 'openai',
    note: 'API oficial de Mistral con tu propia clave de Studio. También puede aparecer en Auric Free cuando el relay tenga cuentas Mistral configuradas.',
    base: 'https://api.mistral.ai/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://console.mistral.ai/',
    docsUrl: 'https://docs.mistral.ai/',
    pricingUrl: 'https://mistral.ai/products/la-plateforme'
  },
  cerebras: {
    id: 'cerebras',
    name: 'Cerebras',
    logo: 'cerebras.svg',
    tier: 'mixed',
    kind: 'openai',
    byok: true,
    note: 'Inferencia rápida con tu propia clave. Cerebras ofrece uso gratuito en cuentas Personal según disponibilidad; las cuentas Team requieren saldo o plan. Revisa el tipo de cuenta al crear la clave.',
    base: 'https://api.cerebras.ai/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://cloud.cerebras.ai/',
    docsUrl: 'https://inference-docs.cerebras.ai/',
    pricingUrl: 'https://www.cerebras.ai/pricing'
  },
  sambanova: {
    id: 'sambanova',
    name: 'SambaNova Cloud',
    logo: 'sambanova.png',
    tier: 'mixed',
    kind: 'openai',
    byok: true,
    note: 'Endpoint compatible con OpenAI usando tu propia API key de SambaCloud.',
    base: 'https://api.sambanova.ai/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://cloud.sambanova.ai/dashboard',
    docsUrl: 'https://docs.sambanova.ai/',
    pricingUrl: 'https://sambanova.ai/products/sambacloud'
  },
  siliconflow: {
    id: 'siliconflow',
    name: 'SiliconFlow',
    logo: 'siliconflow.svg',
    tier: 'mixed',
    kind: 'openai',
    byok: true,
    note: 'API compatible con OpenAI. Auric Code usa únicamente tu propia key.',
    base: 'https://api.siliconflow.com/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://cloud.siliconflow.com/account/ak',
    docsUrl: 'https://docs.siliconflow.com/',
    pricingUrl: 'https://siliconflow.com/pricing'
  },
  hetzner: {
    id: 'hetzner',
    name: 'Hetzner Inference',
    logo: 'hetzner.svg',
    tier: 'mixed',
    kind: 'openai',
    byok: true,
    note: 'Inference API experimental compatible con OpenAI. Puede cambiar o dejar de estar disponible; usa tu propio token.',
    base: 'https://inference.hetzner.com/api/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://experiments.hetzner.com/',
    docsUrl: 'https://community.hetzner.com/',
    pricingUrl: 'https://www.hetzner.com/'
  },
  ovh: {
    id: 'ovh',
    name: 'OVHcloud AI Endpoints',
    logo: 'ovh.svg',
    tier: 'mixed',
    kind: 'openai',
    byok: true,
    note: 'AI Endpoints compatible con OpenAI. Las claves autenticadas se administran desde tu proyecto Public Cloud.',
    base: 'https://oai.endpoints.kepler.ai.cloud.ovh.net/v1',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://www.ovh.com/manager/',
    docsUrl: 'https://docs.ovhcloud.com/en/public-cloud-ai-endpoints/',
    pricingUrl: 'https://www.ovhcloud.com/public-cloud/ai-endpoints/'
  },
  zai: {
    id: 'zai',
    name: 'Z.AI / GLM',
    logo: 'zai.png',
    tier: 'mixed',
    kind: 'openai',
    byok: true,
    note: 'GLM mediante la API general oficial de Z.AI con tu propia key. El Coding Plan no se usa dentro de Auric Code.',
    base: 'https://api.z.ai/api/paas/v4',
    models: '/models',
    chat: '/chat/completions',
    keyUrl: 'https://z.ai/manage-apikey/apikey-list',
    docsUrl: 'https://docs.z.ai/',
    pricingUrl: 'https://z.ai/subscribe'
  }
};

// Mismo conjunto visual/proveedores de Auric Control, más Auric y Z.AI/GLM.
export const providerOrder = [
  'auric',
  'local',
  'gemini',
  'openai',
  'anthropic',
  'perplexity',
  'minimax',
  'grok',
  'deepseek',
  'kimi',
  'cohere',
  'qwen',
  'meta',
  'groq',
  'openrouter',
  'huggingface',
  'cloudflare',
  'vercel',
  'nvidia',
  'mistral',
  'cerebras',
  'sambanova',
  'siliconflow',
  'hetzner',
  'ovh',
  'zai'
];

export function providerBadge(provider) {
  if (provider.id === 'auric') return { text: 'Incluido', cls: 'free' };
  if (provider.id === 'local') return { text: 'En tu PC', cls: 'free' };
  if (provider.byok) return { text: 'Tu propia clave', cls: 'unknown' };
  return provider.tier === 'free'
    ? { text: 'Cuota gratis', cls: 'free' }
    : provider.tier === 'paid'
      ? { text: 'Pago', cls: 'paid' }
      : { text: 'Mixto', cls: 'unknown' };
}

// Catálogo conocido: se usa solo para clasificar, no para limitar qué modelos aparecen.
const geminiFree = new Set([
  'gemini-2.5-pro',
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite',
  'gemini-2.5-flash-native-audio-preview-12-2025',
  'gemini-2.5-flash-preview-tts',
  'gemini-3-flash-preview',
  'gemini-3.1-flash-lite',
  'gemini-3.1-flash-live-preview',
  'gemini-3.5-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.5-live-translate-preview',
  'gemini-3.5-transcribe-live',
  'gemini-3.5-transcribe',
  'gemini-3.6-flash',
  'gemini-3.7-flash',
  'gemini-3.8-flash',
  'gemini-3.8-flash-tts',
  'gemini-3.8-flash-lite-tts',
  'gemini-3.8-live',
  'gemini-3.8-live-extended-thinking'
]);
const geminiPaid = [
  /gemini-3\.1-pro-preview/i,
  /gemini-omni/i,
  /gemini-3\.1-flash(?:-lite)?-image/i,
  /gemini-3-pro-image/i,
  /gemini-2\.5-pro-preview-tts/i,
  /gemini-2\.5-flash-image/i,
  /nano[-_ ]?banana/i
];
const groqFree = new Set([
  'openai/gpt-oss-120b',
  'openai/gpt-oss-20b',
  'openai/gpt-oss-safeguard-20b',
  'qwen/qwen3.8-27b',
  'whisper-large-v3',
  'whisper-large-v3-turbo',
  'canopylabs/orpheus-v1-english',
  'canopylabs/orpheus-arabic-saudi'
]);
const groqEnterprise = new Set([]);
const qwenInitialQuota = [
  /^qwen-turbo(?:$|-)/i,
  /^qwen3\.7-plus(?:$|-)/i,
  /^qwq-plus(?:$|-)/i,
  /^qvq-max(?:$|-)/i,
  /^qwen3-vl-(?:plus|flash)(?:$|-)/i,
  /^qwen3\.5-(?:omni|livetranslate)-.*(?:$|-)/i
];

const cloudflarePaidRequired = [
  /@cf\/moonshotai\/kimi-k2\.(?:6|7-code)/i,
  /@cf\/(?:zai-org|z-ai)\/glm-5\.(?:2|3)(?:-flash)?/i,
  /@cf\/deepseek-ai\/deepseek-v4-(?:flash-0731|pro-0813)/i
];

export function modelTier(provider, model) {
  const id = String(typeof model === 'string' ? model : model?.id || model?.name || '').toLowerCase();
  const raw = typeof model === 'object' && model ? model : {};
  if (provider.id === 'auric' || provider.id === 'local') return 'free';
  if (provider.id === 'openrouter') {
    const pricing = raw.pricing || {};
    const p = Number(pricing.prompt ?? NaN),
      c = Number(pricing.completion ?? NaN);
    if (id.endsWith(':free') || (!Number.isNaN(p) && p === 0 && !Number.isNaN(c) && c === 0)) return 'free';
    return 'paid';
  }
  if (provider.id === 'grok') {
    const prompt = Number(raw.prompt_text_token_price ?? NaN),
      completion = Number(raw.completion_text_token_price ?? NaN);
    if (!Number.isNaN(prompt) && prompt === 0 && !Number.isNaN(completion) && completion === 0) return 'free-tier';
    if (!Number.isNaN(prompt) || !Number.isNaN(completion)) return 'paid';
    return 'unknown';
  }
  if (provider.id === 'gemini') {
    if (geminiPaid.some(re => re.test(id))) return 'paid';
    // Only exact aliases and numeric/date snapshots inherit the verified free tier.
    for (const family of geminiFree) {
      if (
        id === family ||
        new RegExp('^' + family.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '-(?:\\d{3}|\\d{4}-\\d{2}-\\d{2})$', 'i').test(id)
      )
        return 'free-tier';
    }
    return 'unknown';
  }
  if (provider.id === 'nvidia') return 'free-tier';
  if (provider.id === 'minimax') return 'paid';
  if (provider.id === 'huggingface') return 'credits';
  if (provider.id === 'cloudflare') {
    if (cloudflarePaidRequired.some(re => re.test(id))) return 'paid';
    return 'free-quota';
  }
  if (provider.id === 'groq') {
    if (groqFree.has(id)) return 'free-tier';
    if (groqEnterprise.has(id) || /minimax/i.test(id)) return 'paid';
    return 'unknown';
  }
  if (provider.id === 'qwen') {
    if (qwenInitialQuota.some(re => re.test(id))) return 'free-quota';
    return 'unknown';
  }
  if (provider.id === 'cohere') return 'trial';
  if (provider.tier === 'free') return 'free-tier';
  if (provider.tier === 'mixed') return 'unknown';
  return 'paid';
}

export function modelTierLabel(tier) {
  return (
    {
      free: 'Cuota gratis',
      'free-tier': 'Cuota gratis',
      'free-quota': 'Créditos',
      trial: 'Trial',
      credits: 'Créditos',
      paid: 'Pago',
      unknown: 'Desconocido',
      blocked: 'No disponible',
      unavailable: 'No disponible'
    }[tier] || 'Desconocido'
  );
}

export function modelCapabilities(provider, model) {
  const raw = typeof model === 'object' && model ? model : {};
  const id = String(typeof model === 'string' ? model : raw.id || raw.name || '').toLowerCase();
  const arr = v => (Array.isArray(v) ? v.map(x => String(x).toLowerCase()) : []);
  const inMods = arr(raw.inputModalities || raw.input_modalities || raw.supportedInputModalities || raw.supported_input_modalities);
  const outMods = arr(raw.outputModalities || raw.output_modalities || raw.supportedOutputModalities || raw.supported_output_modalities);
  const capObj = raw.capabilities && !Array.isArray(raw.capabilities) && typeof raw.capabilities === 'object' ? raw.capabilities : {};
  const capFlags = Object.entries(capObj)
    .filter(([, v]) => v === true)
    .map(([k]) => String(k).toLowerCase());
  const caps = new Set(
    [...(Array.isArray(raw.capabilities) ? raw.capabilities : []), ...capFlags, ...inMods, ...outMods].map(x => String(x).toLowerCase())
  );
  const has = x => caps.has(x) || inMods.includes(x) || outMods.includes(x);
  let kind = 'chat';
  // Prefer explicit catalog metadata. Names are only a conservative fallback for APIs that do not expose modalities.
  if (/embedding/.test(id)) kind = 'embedding';
  else if (/transcrib|whisper|speech-to-text/.test(id)) kind = 'transcription';
  else if (/(^|[-_/])live($|[-_/])|native-audio|robotics-er-.*streaming/.test(id)) kind = 'voice';
  else if (outMods.includes('video') || /(^|[-_/])veo([-.\/_]|$)/.test(id)) kind = 'video';
  else if (/lyria|music[-_ ]?generation/.test(id) || (outMods.includes('audio') && /music/.test(id))) kind = 'music';
  else if (outMods.includes('audio') || /tts|text-to-speech|speech-generation/.test(id)) kind = 'speech';
  else if (
    (outMods.includes('image') && !outMods.includes('text')) ||
    /imagen|nano[-_ ]?banana|image[-_ ]generation|flash[-_ ]image/.test(id)
  )
    kind = 'image';
  return {
    kind,
    vision:
      inMods.includes('image') ||
      has('vision') ||
      capObj.vision === true ||
      (!inMods.length && /gemini|gpt|claude|qwen|llama|kimi-k3|glm-5[.-]3-flash|muse-glimmer/.test(id)),
    audioIn: inMods.includes('audio') || kind === 'voice' || kind === 'transcription',
    videoIn: inMods.includes('video') || (!inMods.length && provider?.id === 'gemini' && kind === 'chat'),
    imageOut: kind === 'image' || outMods.includes('image') || has('image_generation'),
    audioOut: ['speech', 'voice', 'music'].includes(kind) || outMods.includes('audio') || has('audio_generation'),
    videoOut: kind === 'video' || outMods.includes('video') || has('video_generation'),
    realtime: kind === 'voice' || has('realtime'),
    tools:
      raw.supportedGenerationMethods || raw.supportedActions || raw.tools || (capObj.function_calling === true ? ['function_calling'] : [])
  };
}
