// Continuity and evidence are local. No extra inference request is needed.
const array = value => Array.isArray(value) ? value : [];
const text = value => typeof value === 'string' ? value : String(value ?? '');
const size = message => text(message.content).length + JSON.stringify(message.toolCalls || []).length;

export function checkpointPayloadMessage(message = {}) {
  const out = { role: message.role, content: text(message.content) };
  for (const key of ['toolCallId', 'name', 'sourceMessageId', 'reasoningContent', 'reasoningDetails', 'mentionNotes', 'pageNote'])
    if (message[key] != null) out[key] = message[key];
  if (message.toolCalls?.length) out.toolCalls = message.toolCalls;
  if (message.attachments?.length) out.attachments = message.attachments.map(({ id, path, name, mime, size }) => ({ id, path, name, mime, size })).filter(a => a.path);
  return out;
}

// An assistant call and all its replies form one unit. Never send a reply without
// its call, or a partially executed batch which the provider would reject.
export function completeToolGroups(messages = []) {
  const result = [];
  for (let i = 0; i < messages.length; i++) {
    const message = messages[i];
    if (message.role === 'tool') continue;
    if (!message.toolCalls?.length) { result.push(message); continue; }
    const needed = new Set(message.toolCalls.map(c => c.id).filter(Boolean));
    const replies = [];
    let j = i + 1;
    while (j < messages.length && messages[j].role === 'tool') {
      if (needed.has(messages[j].toolCallId)) replies.push(messages[j]);
      j++;
    }
    if (needed.size && [...needed].every(id => replies.some(reply => reply.toolCallId === id))) result.push(message, ...replies);
    else if (text(message.content).trim()) result.push({ role: 'assistant', content: message.content, reasoningContent: message.reasoningContent || '' });
    i = j - 1;
  }
  return result;
}

export function checkpointTail(messages, maxChars = 220000) {
  const safe = completeToolGroups(messages.filter(m => m.role !== 'system'));
  let start = safe.length, used = 0;
  while (start > 0) {
    const next = size(safe[start - 1]);
    if (used && used + next > maxChars) break;
    used += next;
    start--;
  }
  return completeToolGroups(safe.slice(start)).map(checkpointPayloadMessage);
}

export function restoreCheckpointMessages(visible, checkpoint) {
  if (!checkpoint?.messages?.length) return visible;
  const ids = new Set(visible.map(m => m.sourceMessageId).filter(Boolean));
  const pending = checkpoint.messages.filter(m => {
    if (m.sourceMessageId) return !ids.has(m.sourceMessageId);
    // Compatibility with checkpoints created before source IDs were recorded.
    return m.role === 'tool' || m.toolCalls?.length || !visible.some(v => v.role === m.role && text(v.content) === text(m.content));
  });
  return [...visible, ...completeToolGroups(pending).map(checkpointPayloadMessage)];
}

const isHumanMessage = m => m.role === 'user' && !/^(?:TOOL RESULTS\b|INTERNAL PROTOCOL REPAIR:|Visual evidence captured by )/.test(text(m.content));
export function compactAgentMessages(messages, { threshold = 120000, taskPrompt = '', plan = [], changes = [], local = false } = {}) {
  if (messages.reduce((n, m) => n + size(m), 0) <= threshold) return messages;
  const systems = messages.filter(m => m.role === 'system');
  const body = messages.filter(m => m.role !== 'system');
  // Preserve the actual current request and recent human corrections, including
  // the middle and end of long messages. Tool output never becomes instructions.
  const human = body.filter(isHumanMessage);
  const instructions = [...new Set([taskPrompt, ...human.slice(-8).map(m => text(m.content))].filter(Boolean))];
  const instructionText = instructions.join('\n\n');
  const facts = {
    originalRequest: taskPrompt,
    userMessages: instructions,
    plan: array(plan).map(p => ({ title: p.title, status: p.status })),
    changedFiles: array(changes).slice(-60),
    omittedToolMessages: 0
  };
  const budget = Math.max(local ? 2000 : 8000, threshold - systems.reduce((n, m) => n + size(m), 0) - instructionText.length - 2500);
  let used = 0, start = body.length;
  while (start > 0) {
    const n = size(body[start - 1]);
    if (used + n > budget) break;
    used += n;
    start--;
  }
  const recent = completeToolGroups(body.slice(start));
  facts.omittedToolMessages = body.slice(0, start).filter(m => !isHumanMessage(m)).length;
  const missingInstructions = instructions.filter(instruction => !recent.some(m => m.role === 'user' && text(m.content).includes(instruction)));
  // Do not truncate human text silently. With an exceptionally large request,
  // the caller receives a visible warning and can choose a larger context.
  const summary = {
    role: 'user',
    content: `LOCAL TASK RECORD (earlier user requests and local state; no new task).\n${JSON.stringify({ ...facts, userMessages: missingInstructions })}`
  };
  return [...systems, summary, ...recent];
}

const MUTATIONS = new Set(['write_file', 'apply_patch', 'write_path', 'make_dir', 'move_path', 'copy_path', 'delete_path', 'generate_document', 'run_command', 'start_process']);
export function recordVerification(session, { tool, args = {}, result = '', ok = true, at = Date.now() }) {
  const record = session.verification ||= { checks: [], lastChangeAt: 0 };
  if (ok && MUTATIONS.has(tool)) { record.lastChangeAt = at; record.revision = (record.revision || 0) + 1; }
  const command = text(args.command || '');
  const isCheck = tool === 'run_tests' || tool === 'lsp_diagnostics' || (tool === 'run_command' && /(?:\b(?:test|tests|check|lint|build|pytest|cargo test|go test)\b|--test)/i.test(command));
  if (!isCheck) return record;
  const output = text(result);
  const exit = output.match(/\bexit=(-?\d+)\b/);
  const unavailable = /no disponible|no se detect|not found|no se encontr/i.test(output);
  const passed = ok && !unavailable && (exit ? Number(exit[1]) === 0 : tool === 'lsp_diagnostics' && !/\bERROR\b/.test(output));
  record.checks.push({ tool, command, at, revision: record.revision || 0, passed, exitCode: exit ? Number(exit[1]) : null, detail: output.slice(-1200) });
  record.checks = record.checks.slice(-30);
  return record;
}

export function verificationSummary(session) {
  const record = session.verification || { checks: [], lastChangeAt: 0 };
  const checks = array(record.checks).filter(c => c.at >= record.lastChangeAt && (c.revision || 0) === (record.revision || 0));
  if (checks.some(c => !c.passed)) return { phase: 'warning', text: 'Tarea terminada · revisar comprobaciones', detail: 'Hay comprobaciones fallidas o no disponibles.', status: 'failed' };
  if (checks.some(c => c.passed)) return { phase: 'success', text: 'Tarea terminada · comprobaciones aprobadas', detail: `${checks.length} comprobación(es) después del último cambio.`, status: 'passed' };
  if (record.lastChangeAt) return { phase: 'warning', text: 'Tarea terminada · pendiente de comprobar', detail: 'No hay una comprobación aprobada después del último cambio.', status: 'unchecked' };
  return { phase: 'success', text: 'Tarea terminada', detail: 'Consulta completada.', status: 'none' };
}
