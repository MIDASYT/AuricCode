// Mi PC: panel de ajustes para usar modelos de IA que se ejecutan en el propio equipo con Ollama.
// Módulo de interfaz: no guarda nada sensible. Toda la lógica pesada (detección del equipo, descargas, chat)
// vive en el proceso principal (local-ai.js). Todo texto que viene de fuera se escapa antes de pintarlo.
let C = null;
let view = null; // última respuesta de D.local.catalog
let loading = false;
let loadError = '';
let showAllRows = false;
let hostEl = null;
let verify = null; // {done, total} mientras se comprueba la lista
let starting = false;
let installing = false;
let focusBound = false;
let advancedOpen = false;
let unsubscribers = [];
const pulls = new Map(); // nombre -> progreso de descarga
const pullErrors = new Map(); // nombre -> último error de descarga
const tests = new Map(); // nombre -> {state: 'running'|'ok'|'error', text}
let statusCache = { state: 'unknown', version: '', at: 0 };

const DEFAULT_LOCAL = { numCtx: 'auto', keepAlive: '10m', autoStart: true, host: '', measured: {} };
export const LOCAL_DEFAULTS = DEFAULT_LOCAL;

const nf = new Intl.NumberFormat('es', { maximumFractionDigits: 1 });
const fmt = n => (Number.isFinite(Number(n)) ? nf.format(Number(n)) : '—');
const fmtGB = n => `${fmt(n)} GB`;
const fmtSpeed = bps => (bps >= 1048576 ? `${fmt(bps / 1048576)} MB/s` : bps > 0 ? `${fmt(bps / 1024)} KB/s` : '');
const fmtEta = sec => {
  if (!Number.isFinite(sec) || sec == null) return '';
  if (sec < 60) return 'menos de 1 min';
  if (sec < 3600) return `unos ${Math.round(sec / 60)} min`;
  return `unas ${fmt(sec / 3600)} h`;
};
const pill = (cls, text, title = '') => `<span class="cx-pill ${cls}" ${title ? `title="${C.esc(title)}"` : ''}>${C.esc(text)}</span>`;

export function initLocalUi(ctx) {
  C = ctx;
  for (const off of unsubscribers) {
    try {
      off();
    } catch {}
  }
  unsubscribers = [
    C.D.on('local-pull-progress', onPullProgress),
    C.D.on('local-pull-done', onPullDone),
    C.D.on('local-verify-progress', p => {
      verify = p && p.total ? p : null;
      paintVerify();
    })
  ];
  // Quien instala o enciende Ollama por su cuenta vuelve a Auric: el panel se actualiza solo al recuperar el foco.
  if (!focusBound && typeof window !== 'undefined') {
    focusBound = true;
    window.addEventListener('focus', () => {
      if (!connected() || loading || view?.status?.state === 'running') return;
      load({ quiet: true });
    });
  }
}

export function localSettings() {
  const s = C.state.settings;
  if (!s.local || typeof s.local !== 'object') s.local = {};
  for (const [k, v] of Object.entries(DEFAULT_LOCAL)) if (!(k in s.local)) s.local[k] = k === 'measured' ? {} : v;
  if (!s.local.measured || typeof s.local.measured !== 'object') s.local.measured = {};
  return s.local;
}
const hostArg = () => localSettings().host || '';

// ── Estado de Ollama visible fuera del panel (lista de proveedores, selector) ─────────────────────────
export function localStatusCache() {
  return statusCache;
}
export async function refreshLocalStatus() {
  try {
    const r = await C.D.local.status(hostArg());
    if (r?.ok) statusCache = { ...r.status, at: Date.now() };
  } catch {}
  return statusCache;
}
export function localProviderLine(modelCount = 0) {
  const st = statusCache.state;
  if (st === 'running')
    return modelCount ? `${modelCount} modelo${modelCount === 1 ? '' : 's'} en tu equipo` : 'Listo · sin modelos todavía';
  if (st === 'installed') return 'Ollama apagado';
  if (st === 'missing') return 'Hay que instalar Ollama';
  if (st === 'error') return 'Revisar Ollama';
  return 'En tu equipo';
}

// ── Carga ────────────────────────────────────────────────────────────────────────────────────────────
async function load({ quiet = false } = {}) {
  if (loading) return;
  loading = true;
  if (!quiet) paint();
  try {
    const r = await C.D.local.catalog(hostArg());
    if (!r?.ok) {
      loadError = r?.error?.message || 'No se pudo leer el estado de Mi PC.';
      view = null;
    } else {
      view = r.view;
      loadError = '';
      statusCache = { ...r.view.status, at: Date.now() };
    }
  } catch (e) {
    loadError = String(e?.message || e);
    view = null;
  }
  loading = false;
  paint();
}

export async function renderLocalPanel(host) {
  hostEl = host;
  paint();
  await load({ quiet: !!view });
}

function connected() {
  return !!(hostEl && hostEl.isConnected);
}

// ── Eventos de descarga ────────────────────────────────────────────────────────────────────────────────
function onPullProgress(d) {
  if (!d?.name) return;
  const cur = pulls.get(d.name) || { startedAt: Date.now() };
  pulls.set(d.name, { ...cur, ...d });
  paintPull(d.name);
}
async function onPullDone(d) {
  const name = String(d?.name || '');
  pulls.delete(name);
  if (d?.ok) {
    pullErrors.delete(name);
    C.toast('Modelo descargado', name, 'success');
  } else if (d?.cancelled) {
    pullErrors.delete(name);
    C.toast('Descarga cancelada', 'Lo ya descargado se conserva: si vuelves a pulsar Descargar, continúa donde se quedó.', 'info', 5200);
  } else {
    const msg = d?.error?.message || 'La descarga falló.';
    pullErrors.set(name, msg);
    C.toast('No se pudo descargar', msg, 'error', 8000);
  }
  await load({ quiet: true });
  try {
    await C.afterModelsChanged?.();
  } catch {}
}

function paintPull(name) {
  if (!connected()) return;
  const box = hostEl.querySelector(`[data-pull="${CSS.escape(name)}"]`);
  if (!box) return paint();
  const p = pulls.get(name) || {};
  const pct = Math.max(0, Math.min(100, Number(p.pct) || 0));
  const bar = box.querySelector('[data-pull-bar]');
  const text = box.querySelector('[data-pull-text]');
  if (bar) {
    bar.style.width = `${pct}%`;
    bar.parentElement?.setAttribute('aria-valuenow', String(Math.round(pct)));
  }
  if (text) text.textContent = pullText(p);
}
function pullText(p) {
  const pct = Number(p.pct) || 0;
  const parts = [];
  if (p.total) parts.push(`${fmt(pct)} % · ${fmtGB(p.completed / 1e9)} de ${fmtGB(p.total / 1e9)}`);
  else parts.push(p.status ? statusText(p.status) : 'Conectando…');
  const sp = fmtSpeed(p.speedBps);
  if (sp) parts.push(sp);
  const eta = p.etaSec != null ? fmtEta(p.etaSec) : '';
  if (eta) parts.push(`quedan ${eta}`);
  return parts.join(' · ');
}
function statusText(s) {
  const t = String(s || '').toLowerCase();
  if (t.startsWith('pulling manifest')) return 'Consultando el modelo…';
  if (t.startsWith('verifying')) return 'Comprobando que el archivo está completo…';
  if (t.startsWith('writing')) return 'Guardando…';
  if (t.startsWith('removing')) return 'Limpiando…';
  if (t.startsWith('success')) return 'Listo';
  return 'Descargando…';
}
function paintVerify() {
  if (!connected()) return;
  const el = hostEl.querySelector('[data-verify-text]');
  if (el) el.textContent = verify ? `Comprobando ${verify.done} de ${verify.total}…` : '';
}

// ── Pintado ──────────────────────────────────────────────────────────────────────────────────────────────
function statePill() {
  const st = view?.status?.state || statusCache.state;
  if (st === 'running') return pill('ok', 'Funcionando');
  if (st === 'installed') return pill('warn', 'Apagado');
  if (st === 'missing') return pill('', 'Sin instalar');
  if (st === 'error') return pill('warn', 'Con un problema');
  return pill('', loading ? 'Comprobando…' : 'Sin comprobar');
}

function ollamaCard() {
  const st = view?.status;
  if (!st) {
    return `<div class="lm-card"><div class="lm-card-title">Ollama</div><p class="lm-text">${
      loadError ? C.esc(loadError) : 'Comprobando si Ollama está en tu equipo…'
    }</p>${loadError ? '<div class="lm-actions-row"><button class="secondary-btn compact-btn" data-lm="reload">Reintentar</button></div>' : ''}</div>`;
  }
  if (st.state === 'running')
    return `<div class="lm-card"><div class="lm-card-title">Ollama ${pill('ok', `versión ${st.version || '—'}`)}</div><p class="lm-text">Ollama está funcionando. Los modelos se ejecutan solo en tu equipo: lo que escribes aquí no sale a internet.</p></div>`;
  if (st.state === 'installed')
    return `<div class="lm-card"><div class="lm-card-title">Ollama</div><p class="lm-text">Ollama está instalado pero apagado. Auric puede encenderlo por ti cuando uses un modelo de Mi PC.</p><div class="lm-actions-row"><button class="primary-btn compact-btn" data-lm="start" ${starting ? 'disabled' : ''}>${starting ? 'Iniciando…' : 'Iniciar Ollama'}</button><button class="secondary-btn compact-btn" data-lm="reload">Volver a comprobar</button></div></div>`;
  if (st.state === 'error')
    return `<div class="lm-card is-warn"><div class="lm-card-title">Ollama</div><p class="lm-text">${C.esc(st.message || 'Hay algo en la dirección de Ollama que no responde como Ollama.')}</p><div class="lm-actions-row"><button class="secondary-btn compact-btn" data-lm="reload">Volver a comprobar</button></div></div>`;
  return `<div class="lm-card"><div class="lm-card-title">Ollama</div><p class="lm-text">Mi PC necesita <b>Ollama</b>, un programa gratuito que ejecuta modelos de IA en tu equipo. Solo hay que instalarlo una vez. Auric lo descarga del repositorio oficial de Ollama (github.com/ollama/ollama), comprueba su suma de verificación, te enseña la dirección y el tamaño antes de bajarlo y te pide permiso aparte para ejecutar el instalador.</p><div class="lm-actions-row"><button class="primary-btn compact-btn" data-lm="install" ${installing ? 'disabled' : ''}>${installing ? 'Preparando…' : 'Instalar Ollama'}</button><button class="secondary-btn compact-btn" data-lm="open-ollama">Abrir ollama.com</button><button class="secondary-btn compact-btn" data-lm="reload" title="Si ya lo instalaste por tu cuenta, comprueba otra vez">Volver a comprobar</button></div></div>`;
}

function hardwareCard() {
  const h = view?.hardware;
  if (!h) return '';
  const gpu = h.bestGpu || (h.gpus || [])[0];
  const accel = !gpu
    ? ''
    : gpu.accel === 'sí'
      ? ' · Ollama la usa'
      : gpu.accel === 'depende'
        ? ' · puede que Ollama no la use'
        : ' · es integrada: se usa la memoria RAM';
  const rows = [
    ['Memoria RAM', `${fmtGB(h.ramGB)} <small>(libres ahora: ${fmtGB(h.freeRamGB)})</small>`],
    [
      'Tarjeta gráfica',
      gpu ? `${C.esc(gpu.name)}${gpu.vramGB ? ` · ${fmtGB(gpu.vramGB)}` : ''}<small>${C.esc(accel)}</small>` : 'No se detectó ninguna'
    ],
    ['Procesador', `${C.esc(h.cpu?.model || '—')} <small>(${h.cpu?.threads || '?'} hilos)</small>`],
    ['Espacio en disco', h.diskFreeGB == null ? '—' : `${fmtGB(h.diskFreeGB)} libres`]
  ];
  const notes = (h.notes || []).map(n => `<p class="lm-note-line">${C.esc(n)}</p>`).join('');
  return `<div class="lm-card"><div class="lm-card-title">Tu equipo</div><dl class="lm-hw">${rows.map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('')}</dl>${notes}</div>`;
}

function levelPill(a) {
  if (a.unavailable) return pill('off', 'No disponible', 'La biblioteca de Ollama ya no lo ofrece.');
  if (a.level === 'fluido') return pill('ok', 'Va fluido');
  if (a.level === 'lento') return pill('warn', 'Va lento');
  return pill('bad', 'No recomendado');
}

function isActive(name) {
  const cfg = C.activeConfig?.() || {};
  return cfg.provider === 'local' && String(cfg.model || '').toLowerCase() === String(name || '').toLowerCase();
}

function rowActions(r) {
  const name = r.id;
  const p = pulls.get(name);
  if (p)
    return `<div class="lm-pull" data-pull="${C.esc(name)}"><div class="lm-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(Number(p.pct) || 0)}"><i data-pull-bar style="width:${Math.max(0, Math.min(100, Number(p.pct) || 0))}%"></i></div><div class="lm-pull-row"><span data-pull-text>${C.esc(pullText(p))}</span><button class="secondary-btn compact-btn" data-lm="cancel" data-name="${C.esc(name)}">Cancelar</button></div></div>`;
  const parts = [];
  if (r.installed) {
    const real = r.installedInfo?.name || name;
    const active = isActive(real);
    parts.push(
      active ? pill('accent', 'En uso') : `<button class="primary-btn compact-btn" data-lm="use" data-name="${C.esc(real)}">Usar</button>`
    );
    parts.push(`<button class="secondary-btn compact-btn" data-lm="test" data-name="${C.esc(real)}">Probar</button>`);
    parts.push(
      `<button class="secondary-btn compact-btn" data-lm="delete" data-name="${C.esc(real)}" data-size="${r.installedInfo?.sizeGB || r.sizeGB}">Borrar</button>`
    );
  } else if (!r.assessment.unavailable) {
    const label = r.assessment.level === 'no' ? 'Descargar igualmente' : `Descargar ${fmtGB(r.sizeGB)}`;
    parts.push(
      `<button class="${r.assessment.level === 'no' ? 'secondary-btn' : 'primary-btn'} compact-btn" data-lm="pull" data-name="${C.esc(name)}" data-size="${r.sizeGB}" data-level="${C.esc(r.assessment.level)}">${C.esc(label)}</button>`
    );
  }
  if (!r.installed)
    parts.push(
      r.custom
        ? `<button class="secondary-btn compact-btn" data-lm="remove-custom" data-name="${C.esc(name)}" title="Quitar de la lista">Quitar</button>`
        : `<button class="secondary-btn compact-btn" data-lm="hide" data-name="${C.esc(name)}" title="No volver a mostrar este modelo">Ocultar</button>`
    );
  return `<div class="lm-actions-row">${parts.join('')}</div>`;
}

function testLine(name) {
  const t = tests.get(name);
  if (!t) return '';
  return `<p class="lm-test ${t.state}" data-test="${C.esc(name)}">${t.state === 'running' ? '<span class="lm-spin" aria-hidden="true"></span>' : ''}${C.esc(t.text)}</p>`;
}

function modelRow(r, { pickId, capableId }) {
  const a = r.assessment;
  const tags = [];
  tags.push(
    r.tools
      ? `<span class="lm-tag ok" title="Puede usar las herramientas de Auric (leer archivos, buscar…)">${C.esc(r.grade?.label || 'Herramientas')}</span>`
      : '<span class="lm-tag" title="Solo conversa: no puede leer ni cambiar archivos por sí solo">Solo conversación</span>'
  );
  if (r.coding) tags.push('<span class="lm-tag">Código</span>');
  if (r.thinking) tags.push('<span class="lm-tag">Razona</span>');
  if (r.vision) tags.push('<span class="lm-tag">Entiende imágenes</span>');
  if (r.custom) tags.push('<span class="lm-tag">Añadido por ti</span>');
  const star =
    r.id === pickId
      ? pill('accent', 'Recomendado para ti')
      : r.id === capableId
        ? pill('accent', 'Más capaz (más lento)', 'Es el más capaz que tu equipo puede mover, aunque tarde más en responder.')
        : '';
  const measured = localSettings().measured?.[r.installedInfo?.name || r.id];
  const warns = (a.warnings || []).map(w => `<p class="lm-warn">${C.esc(w)}</p>`).join('');
  const err = pullErrors.get(r.id) ? `<p class="lm-warn">${C.esc(pullErrors.get(r.id))}</p>` : '';
  const ctxInfo = a.numCtx ? ` · contexto ${fmt(a.numCtx / 1024)}K` : '';
  return `<article class="lm-row ${r.installed ? 'is-installed' : ''} ${a.level === 'no' ? 'is-no' : ''}" data-model-row="${C.esc(r.id)}">
    <div class="lm-main">
      <div class="lm-title"><b>${C.esc(r.name || r.id)}</b><span class="lm-size">${fmtGB(r.sizeGB)}</span>${levelPill(a)}${star}${r.installed ? pill('ok', 'Descargado') : ''}</div>
      <div class="lm-tags">${tags.join('')}</div>
      ${r.note ? `<p class="lm-note">${C.esc(r.note)}</p>` : ''}
      <p class="lm-reason">${C.esc(a.reason)}${a.unavailable ? '' : C.esc(ctxInfo)}</p>
      ${measured ? `<p class="lm-measured">Medido en tu equipo: unas ${fmt(measured.tps * 0.65)} palabras por segundo.</p>` : ''}
      ${warns}${err}${testLine(r.installedInfo?.name || r.id)}
    </div>
    <div class="lm-side ${pulls.has(r.id) ? 'is-pulling' : ''}">${rowActions(r)}</div>
  </article>`;
}

function listSection() {
  if (!view) return '';
  const rows = view.rows || [];
  const hiddenByLevel = rows.filter(r => r.assessment.level === 'no' && !r.installed && !pulls.has(r.id));
  const visible = showAllRows ? rows : rows.filter(r => !(r.assessment.level === 'no' && !r.installed && !pulls.has(r.id)));
  const reviewed = view.reviewed ? `revisada el ${C.esc(view.reviewed)}` : '';
  const verifiedText = view.verified
    ? 'La lista está comprobada con la biblioteca de Ollama.'
    : `Lista ${reviewed}. No está comprobada en vivo: pulsa «Comprobar disponibilidad» para confirmar que cada modelo existe y ajustar su tamaño real.`;
  const pick = rows.find(r => r.id === view.pick);
  const capable = rows.find(r => r.id === (view.pickCapable || ''));
  const banner = pick
    ? `<div class="lm-banner">Para tu equipo te recomiendo <b>${C.esc(pick.name)}</b> (${fmtGB(pick.sizeGB)}). ${
        capable ? `Si no te importa esperar más, <b>${C.esc(capable.name)}</b> es más capaz.` : ''
      }</div>`
    : `<div class="lm-banner is-warn">Tu equipo es justo para modelos de IA locales. Los más pequeños funcionarán, pero con limitaciones y más lentos de lo que estás acostumbrado.</div>`;
  const body = visible.length
    ? visible.map(r => modelRow(r, { pickId: view.pick, capableId: view.pickCapable })).join('')
    : '<div class="sidebar-empty">No hay modelos en la lista. Pulsa «Restaurar lista» o añade uno por su nombre.</div>';
  const toggle = hiddenByLevel.length
    ? `<button class="lm-link" data-lm="toggle-all">${showAllRows ? 'Ocultar los no recomendados' : `Mostrar también los no recomendados (${hiddenByLevel.length})`}</button>`
    : '';
  return `<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">Modelos para tu equipo</div><div class="lm-actions-row"><span class="lm-verify" data-verify-text>${verify ? `Comprobando ${verify.done} de ${verify.total}…` : ''}</span><button class="secondary-btn compact-btn" data-lm="verify" ${verify ? 'disabled' : ''}>Comprobar disponibilidad</button></div></div>
    ${banner}
    <div class="lm-list">${body}</div>
    <div class="lm-foot">${toggle}<span class="lm-fine">${verifiedText}</span></div>
    <div class="lm-add"><input id="lmAddName" placeholder="Añadir otro modelo por su nombre, por ejemplo qwen3:8b" autocomplete="off" spellcheck="false"><button class="secondary-btn compact-btn" data-lm="add">Añadir</button><button class="secondary-btn compact-btn" data-lm="restore" title="Vuelve a la lista original">Restaurar lista</button><button class="secondary-btn compact-btn" data-lm="library">Ver la biblioteca de Ollama</button></div>
  </div>`;
}

function extraInstalledSection() {
  const extra = view?.extraInstalled || [];
  if (!extra.length) return '';
  return `<div class="lm-card"><div class="lm-card-title">Otros modelos que ya tienes en Ollama</div><div class="lm-list">${extra
    .map(
      m =>
        `<article class="lm-row is-installed"><div class="lm-main"><div class="lm-title"><b>${C.esc(m.name)}</b><span class="lm-size">${fmtGB(m.sizeGB)}</span>${m.paramSize ? `<span class="lm-tag">${C.esc(m.paramSize)}</span>` : ''}${m.loaded ? pill('ok', 'En memoria') : ''}</div>${testLine(m.name)}</div><div class="lm-side"><div class="lm-actions-row">${
          isActive(m.name)
            ? pill('accent', 'En uso')
            : `<button class="primary-btn compact-btn" data-lm="use" data-name="${C.esc(m.name)}">Usar</button>`
        }<button class="secondary-btn compact-btn" data-lm="test" data-name="${C.esc(m.name)}">Probar</button><button class="secondary-btn compact-btn" data-lm="delete" data-name="${C.esc(m.name)}" data-size="${m.sizeGB}">Borrar</button></div></div></article>`
    )
    .join('')}</div></div>`;
}

function advancedSection() {
  const s = localSettings();
  const ctxOpts = [
    ['auto', 'Automática (según la memoria de tu equipo)'],
    ['4096', '4 096 (poca memoria)'],
    ['8192', '8 192'],
    ['16384', '16 384'],
    ['32768', '32 768'],
    ['65536', '65 536 (mucha memoria)']
  ];
  const keepOpts = [
    ['5m', '5 minutos'],
    ['10m', '10 minutos'],
    ['30m', '30 minutos'],
    ['1h', '1 hora'],
    ['-1', 'Hasta que cierre Ollama']
  ];
  const used = (view?.installed || []).reduce((n, m) => n + (m.sizeGB || 0), 0);
  const count = (view?.installed || []).length;
  return `<details class="lm-card lm-advanced" ${advancedOpen ? 'open' : ''}><summary>Ajustes avanzados</summary>
    <div class="form-grid">
      <div class="form-field"><label for="lmCtx">Memoria de conversación (contexto)</label><select id="lmCtx">${ctxOpts.map(([v, l]) => `<option value="${v}" ${String(s.numCtx) === v ? 'selected' : ''}>${C.esc(l)}</option>`).join('')}</select><div class="form-help">Más contexto recuerda más, pero gasta más memoria. En «Automática» Auric calcula lo que cabe en tu equipo.</div></div>
      <div class="form-field"><label for="lmKeep">Mantener el modelo cargado</label><select id="lmKeep">${keepOpts.map(([v, l]) => `<option value="${v}" ${String(s.keepAlive) === v ? 'selected' : ''}>${C.esc(l)}</option>`).join('')}</select><div class="form-help">Mientras está cargado responde sin esperar, pero ocupa memoria.</div></div>
      <div class="form-field full"><label class="lm-check"><input type="checkbox" id="lmAuto" ${s.autoStart !== false ? 'checked' : ''}> Encender Ollama automáticamente cuando use un modelo de Mi PC</label></div>
      <div class="form-field full"><label for="lmHost">Dirección de Ollama</label><div class="key-row"><input id="lmHost" value="${C.esc(s.host || '')}" placeholder="http://127.0.0.1:11434 (por defecto)" spellcheck="false"><button class="secondary-btn compact-btn" data-lm="save-host">Guardar</button></div><div class="form-help">Solo se aceptan direcciones de este mismo equipo (127.0.0.1 o localhost). Auric nunca envía tus chats a otro ordenador.</div></div>
      <div class="form-field full"><label>Espacio que ocupan los modelos</label><div class="lm-text">${count ? `${count} modelo${count === 1 ? '' : 's'} · ${fmtGB(used)} en ${C.esc(view?.hardware?.modelsDir || 'la carpeta de Ollama')}` : 'Todavía no hay modelos descargados.'}</div></div>
    </div></details>`;
}

function reliabilityNote() {
  return `<div class="lm-card is-note"><div class="lm-text"><b>Antes de empezar:</b> los modelos de tu PC son gratis y privados, pero más lentos y se equivocan más que los de la nube, sobre todo cuando tienen que usar herramientas. Por eso Auric los deja por defecto en <b>Solo lectura</b> (o en <b>Chat</b> si el modelo no sabe usar herramientas) y te avisa antes de darles más permisos.</div></div>`;
}

function paint() {
  if (!connected()) return;
  const p = C.provider('local');
  const scroll = hostEl.closest('.settings-content, #settingsContent, .modal-body')?.scrollTop;
  hostEl.innerHTML = `<div class="provider-detail lm-panel"><div class="provider-head">${C.providerVisual(p)}<div class="provider-head-copy"><h5>Mi PC</h5><p>${C.esc(p.note || '')}</p></div>${statePill()}</div>${reliabilityNote()}${ollamaCard()}${hardwareCard()}${listSection()}${extraInstalledSection()}${advancedSection()}</div>`;
  if (scroll != null) {
    const sc = hostEl.closest('.settings-content, #settingsContent, .modal-body');
    if (sc) sc.scrollTop = scroll;
  }
  bind();
}

// ── Acciones ──────────────────────────────────────────────────────────────────────────────────────────────
function bind() {
  hostEl.onclick = async ev => {
    const el = ev.target.closest('[data-lm]');
    if (!el || !hostEl.contains(el) || el.disabled) return;
    const act = el.dataset.lm;
    const name = el.dataset.name || '';
    try {
      if (act === 'reload') await load();
      else if (act === 'start') await startOllama();
      else if (act === 'install') await installOllama();
      else if (act === 'open-ollama') await C.D.openExternal('https://ollama.com/download');
      else if (act === 'library') await C.D.local.openLibrary();
      else if (act === 'toggle-all') {
        showAllRows = !showAllRows;
        paint();
      } else if (act === 'pull') await startPull(name, Number(el.dataset.size), el.dataset.level);
      else if (act === 'cancel') await C.D.local.cancelPull(hostArg(), name);
      else if (act === 'use') await useModel(name);
      else if (act === 'test') await testModel(name);
      else if (act === 'delete') await deleteModel(name, Number(el.dataset.size));
      else if (act === 'hide') await editList({ action: 'hide', id: name });
      else if (act === 'remove-custom') await editList({ action: 'remove-custom', id: name });
      else if (act === 'restore') await restoreList();
      else if (act === 'add') await addModel();
      else if (act === 'verify') await verifyList();
      else if (act === 'save-host') await saveHost();
    } catch (e) {
      C.toast('Mi PC', String(e?.message || e), 'error', 6500);
    }
  };
  const s = localSettings();
  const adv = hostEl.querySelector('.lm-advanced');
  if (adv) adv.ontoggle = () => (advancedOpen = adv.open);
  const ctx = hostEl.querySelector('#lmCtx');
  if (ctx)
    ctx.onchange = async () => {
      s.numCtx = ctx.value === 'auto' ? 'auto' : Number(ctx.value);
      await C.saveState();
    };
  const keep = hostEl.querySelector('#lmKeep');
  if (keep)
    keep.onchange = async () => {
      s.keepAlive = keep.value;
      await C.saveState();
    };
  const auto = hostEl.querySelector('#lmAuto');
  if (auto)
    auto.onchange = async () => {
      s.autoStart = !!auto.checked;
      await C.saveState();
    };
  const add = hostEl.querySelector('#lmAddName');
  if (add)
    add.onkeydown = e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        addModel().catch(err => C.toast('Mi PC', String(err?.message || err), 'error', 6500));
      }
    };
}

async function startOllama() {
  starting = true;
  paint();
  try {
    const r = await C.D.local.start(hostArg());
    if (!r?.ok)
      C.toast('No se pudo iniciar Ollama', r?.error?.message || 'Ábrelo desde el menú Inicio y vuelve a intentarlo.', 'error', 7000);
  } finally {
    starting = false;
    await load({ quiet: true });
    await C.afterModelsChanged?.();
  }
}

async function installOllama() {
  installing = true;
  paint();
  try {
    if (C.installOllama) await C.installOllama();
    else await C.D.openExternal('https://ollama.com/download');
  } finally {
    installing = false;
    await load({ quiet: true });
  }
}

async function ensureRunning() {
  const st = view?.status?.state || statusCache.state;
  if (st === 'running') return true;
  if (st === 'installed') {
    const r = await C.D.local.start(hostArg());
    if (!r?.ok) {
      C.toast('No se pudo iniciar Ollama', r?.error?.message || 'Ábrelo desde el menú Inicio.', 'error', 7000);
      return false;
    }
    return true;
  }
  C.toast('Falta Ollama', 'Primero instala Ollama con el botón de arriba.', 'error', 5200);
  return false;
}

async function startPull(name, sizeGB, level) {
  if (!name || pulls.has(name)) return;
  const h = view?.hardware;
  if (h?.diskFreeGB != null && sizeGB && h.diskFreeGB < sizeGB + 1) {
    await C.appConfirm({
      title: 'No hay espacio suficiente',
      message: `«${name}» ocupa unos ${fmtGB(sizeGB)} y en tu disco quedan ${fmtGB(h.diskFreeGB)} libres. Libera espacio y vuelve a intentarlo.`,
      buttons: ['Entendido'],
      defaultId: 0,
      cancelId: 0,
      type: 'warning'
    });
    return;
  }
  const big = sizeGB >= 10 || level === 'no' || (h?.diskFreeGB != null && h.diskFreeGB < sizeGB + 10);
  if (big) {
    const extra =
      level === 'no'
        ? '\n\nTu equipo no es suficiente para este modelo: irá muy lento o no cabrá en memoria. Te lo digo antes de que gastes la descarga.'
        : '';
    const pick = await C.appConfirm({
      title: 'Descargar modelo',
      message: `Se descargarán unos ${fmtGB(sizeGB)} de «${name}» desde la biblioteca de Ollama y se guardarán en tu disco.${extra}`,
      detail: `Origen: registry.ollama.ai\nDestino: ${h?.modelsDir || 'la carpeta de Ollama'}\nPuedes cancelar cuando quieras; lo ya descargado se conserva.`,
      buttons: ['Cancelar', 'Descargar'],
      defaultId: level === 'no' ? 0 : 1,
      cancelId: 0,
      type: level === 'no' ? 'warning' : 'question'
    });
    if (pick !== 1) return;
  }
  if (!(await ensureRunning())) return;
  pullErrors.delete(name);
  const r = await C.D.local.pull(hostArg(), name);
  if (!r?.ok) {
    pullErrors.set(name, r?.error?.message || 'No se pudo empezar la descarga.');
    C.toast('No se pudo descargar', pullErrors.get(name), 'error', 7000);
    paint();
    return;
  }
  pulls.set(name, { startedAt: Date.now(), pct: 0, status: 'pulling manifest' });
  paint();
}

async function useModel(name) {
  await C.useLocalModel(name);
  C.toast('Mi PC', `Ahora el chat usa «${name}».`, 'success', 3600);
  paint();
}

async function deleteModel(name, sizeGB) {
  const pick = await C.appConfirm({
    title: 'Borrar modelo',
    message: `¿Borrar «${name}» de tu equipo? Liberará unos ${fmtGB(sizeGB)}. Podrás volver a descargarlo cuando quieras.`,
    buttons: ['Cancelar', 'Borrar'],
    defaultId: 0,
    cancelId: 0,
    type: 'warning'
  });
  if (pick !== 1) return;
  const r = await C.D.local.remove(hostArg(), name);
  if (!r?.ok) {
    C.toast('No se pudo borrar', r?.error?.message || 'Ollama no lo borró.', 'error', 6500);
    return;
  }
  tests.delete(name);
  C.toast('Modelo borrado', name, 'success');
  await load({ quiet: true });
  await C.afterModelsChanged?.();
}

async function editList(edit) {
  const r = await C.D.local.editCatalog(edit);
  if (!r?.ok) throw new Error(r?.error?.message || 'No se pudo cambiar la lista.');
  await load({ quiet: true });
}

async function restoreList() {
  const pick = await C.appConfirm({
    title: 'Restaurar la lista',
    message: 'Se volverán a mostrar los modelos ocultos y se quitarán los que añadiste tú. No se borra ningún modelo descargado.',
    buttons: ['Cancelar', 'Restaurar'],
    defaultId: 1,
    cancelId: 0
  });
  if (pick === 1) await editList({ action: 'restore' });
}

async function addModel() {
  const input = hostEl.querySelector('#lmAddName');
  const id = String(input?.value || '').trim();
  if (!id) return C.toast('Mi PC', 'Escribe el nombre del modelo, por ejemplo qwen3:8b.', 'info', 4200);
  C.toast('Mi PC', 'Consultando la biblioteca de Ollama…', 'info', 2600);
  await editList({ action: 'add', id });
  C.toast('Modelo añadido', id, 'success');
}

async function verifyList() {
  verify = { done: 0, total: (view?.rows || []).length };
  paint();
  try {
    const r = await C.D.local.verify();
    if (!r?.ok) throw new Error(r?.error?.message || 'No se pudo comprobar la lista.');
    const { checked, missing, unreachable } = r;
    if (unreachable && unreachable >= checked)
      C.toast(
        'Sin conexión con la biblioteca',
        'No pude consultar la biblioteca de Ollama. Revisa tu conexión e inténtalo de nuevo.',
        'error',
        6500
      );
    else
      C.toast(
        'Lista comprobada',
        `${checked - unreachable} comprobados${missing ? ` · ${missing} ya no existen y quedan marcados` : ''}${unreachable ? ` · ${unreachable} sin respuesta` : ''}`,
        missing ? 'info' : 'success',
        6000
      );
  } finally {
    verify = null;
    await load({ quiet: true });
  }
}

async function saveHost() {
  const v = String(hostEl.querySelector('#lmHost')?.value || '').trim();
  localSettings().host = v;
  await C.saveState();
  C.toast('Mi PC', v ? 'Dirección guardada.' : 'Se usará la dirección por defecto.', 'success', 3200);
  await load();
}

async function testModel(name) {
  if (tests.get(name)?.state === 'running') return;
  if (!(await ensureRunning())) return;
  tests.set(name, { state: 'running', text: 'Probando… la primera vez puede tardar mientras se carga el modelo.' });
  paint();
  const s = localSettings();
  try {
    const r = await C.D.local.chat({
      host: hostArg(),
      requestId: `test-${Date.now()}`,
      model: name,
      messages: [{ role: 'user', content: 'Responde solo con la palabra: listo' }],
      numCtx: s.numCtx,
      keepAlive: s.keepAlive,
      autoStart: s.autoStart !== false,
      think: 'none'
    });
    if (!r?.ok) throw new Error(r?.error?.message || 'El modelo no respondió.');
    const u = r.result?.usage || {};
    if (u.tokensPerSecond > 0) {
      s.measured = { ...(s.measured || {}), [name]: { tps: u.tokensPerSecond, at: Date.now() } };
      await C.saveState();
    }
    tests.set(name, {
      state: 'ok',
      text: `Funciona${u.tokensPerSecond ? `: unas ${fmt(u.tokensPerSecond * 0.65)} palabras por segundo en tu equipo` : ''}${u.loadMs > 1500 ? ` (tardó ${fmt(u.loadMs / 1000)} s en cargarse)` : ''}.`
    });
  } catch (e) {
    tests.set(name, { state: 'error', text: String(e?.message || e) });
  }
  paint();
}
