---
id: python-development
name: Python Development
description: Proyectos Python con entornos, typing, tests y CLIs reproducibles.
logo: python.png
icon: code
color: blue
triggers: [python, pytest, pip, pyproject]
markers: [pyproject.toml, requirements.txt, setup.py]
tags: [python]
---
## Antes de empezar
- Identifica el entorno: `pyproject.toml` (poetry/uv/hatch/pdm), `requirements*.txt`, `Pipfile`. Usa el entorno del proyecto (`.venv`, `uv run`, `poetry run`); no instales paquetes globalmente.
- Mira la versión de Python soportada (`requires-python`, `.python-version`) y no uses sintaxis más nueva.
- Localiza la configuración de calidad: `ruff`/`flake8`, `black`, `mypy`/`pyright`, `pytest.ini`/`[tool.pytest]`.

## Cómo trabajar
1. Escribe código con type hints en las funciones públicas y docstrings cortas donde el contrato no sea obvio.
2. Usa `pathlib`, `with` para archivos/recursos y `logging` en vez de `print` en librerías.
3. Excepciones específicas (`ValueError`, excepciones propias); nunca `except:` desnudo ni silenciar errores.
4. Dependencias nuevas: añádelas al archivo de dependencias del proyecto con versión acotada, no solo con `pip install`.
5. Verifica: `pytest -x -q ruta::test` (lo más acotado) → linter → mypy/pyright si el proyecto lo usa.
6. CLIs: `argparse`/`typer` con `--help` útil y código de salida distinto de 0 en errores.

## Trampas
- Argumentos mutables por defecto (`def f(x=[])`), importaciones circulares, rutas relativas dependientes del cwd.
- En Windows: encoding explícito (`encoding="utf-8"`) al abrir texto; `subprocess.run([...])` con lista, nunca `shell=True` con datos externos.
- No uses `eval`/`exec`/`pickle` con datos no confiables.
- Secretos fuera del repo (variables de entorno o `.env` ignorado por git).

## Entrega
Di qué cambió, qué tests corriste y el resultado real. Si no hay tests, propón o añade el mínimo que cubra el cambio.
