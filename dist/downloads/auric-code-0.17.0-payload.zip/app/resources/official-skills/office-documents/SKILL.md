---
id: office-documents
name: Documentos de oficina
description: Crea y revisa documentos reales de Word, Excel, PowerPoint y PDF con la herramienta de documentos, sin pisar archivos existentes.
icon: file-text
color: blue
triggers: [docx, xlsx, pptx, pdf, excel, powerpoint, microsoft word, archivo word, documento word, informe, presentación, presentacion, planilla, hoja de cálculo, hoja de calculo, currículum, curriculum]
markers: []
tags: [documentos, oficina]
---
## Cuándo usarla
Cuando el usuario pide un archivo de Word, Excel, PowerPoint o PDF (o un informe, carta, planilla o presentación que va a enviar, imprimir o editar). Si solo quiere leer una respuesta, contéstala en el chat: no crees un archivo que nadie pidió.

## Cómo crear el archivo
Usa `generate_document` (no escribas el binario a mano):
- **Word / PDF**: título + `markdown` con encabezados (`#`), listas, tablas, **negritas** y enlaces. Estructura: título, resumen corto arriba, secciones con encabezados claros, cierre o pasos siguientes.
- **Excel**: `rows` con la primera fila como encabezados; fórmulas como `=SUM(B2:B9)`. Varias hojas con `sheets`. Una tabla por hoja, sin filas decorativas.
- **PowerPoint**: `slides` con título, 3–5 viñetas cortas por diapositiva y `notes` para lo que se dice en voz alta. Una idea por diapositiva.
- Las imágenes y los gráficos no están disponibles en esta herramienta: dilo si el usuario los necesita y ofrece una tabla o describir dónde ponerlos.

## Reglas
- Nunca pises un archivo existente: la herramienta guarda «nombre (2)». Solo reemplaza si el usuario pidió reemplazar ESE archivo exacto.
- No agregues avisos como «generado por IA», el nombre del modelo ni firmas, salvo que el usuario lo pida.
- Usa el nombre, fecha y datos que dio el usuario; si falta uno importante (destinatario, periodo, moneda), pregúntalo antes de inventarlo.
- Escribe en el idioma y tono del usuario (formal para cartas y contratos, directo para informes internos).
- Los números del documento deben salir de los datos reales: calcúlalos con código o fórmulas, no de memoria.

## Al terminar
Di la ruta final del archivo y qué contiene en una o dos frases. Si el usuario pide cambios, crea una versión nueva en vez de pisar la anterior.
