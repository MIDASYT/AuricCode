---
id: database-sql
name: Database & SQL
description: SQLite, PostgreSQL y otras bases con migraciones, consultas y cambios de esquema seguros.
icon: database
color: gold
triggers: [sql, sqlite, postgres, database, migration]
markers: [schema.sql, migrations, prisma]
tags: [database, sql]
---
## Antes de empezar
- Identifica el motor (SQLite, PostgreSQL, MySQL) y cómo se gestiona el esquema (migraciones, Prisma, Alembic, EF, SQL a mano). No cambies el esquema fuera de ese mecanismo.
- Revisa el esquema actual y los índices antes de escribir consultas.

## Cómo trabajar
1. Consultas siempre parametrizadas; nunca concatenes entrada del usuario en SQL.
2. Cambios de esquema como migraciones pequeñas, reversibles cuando se pueda, con nombre claro. Para columnas NOT NULL sobre tablas con datos: añade con valor por defecto o en dos pasos.
3. Antes de `UPDATE`/`DELETE`, ejecuta el mismo `WHERE` como `SELECT COUNT(*)` y revisa el número. Usa transacciones en cambios multi-sentencia.
4. Rendimiento: comprueba con `EXPLAIN` / `EXPLAIN QUERY PLAN`; añade índices con criterio (columnas de filtro/orden/join), no por defecto.
5. SQLite: respeta `PRAGMA foreign_keys=ON`, usa `WAL` para concurrencia, y haz copia del archivo antes de migraciones destructivas.
6. Integridad: claves foráneas, `UNIQUE` y `CHECK` en la base, no solo en la aplicación.

## Trampas
- Nunca ejecutes operaciones destructivas (`DROP`, `TRUNCATE`, `DELETE` sin `WHERE`) sin confirmación explícita del usuario y copia previa.
- No apliques migraciones contra producción desde aquí.
- Cuidado con zonas horarias y tipos monetarios (usa enteros en centavos o `NUMERIC`).

## Entrega
Muestra la migración/consulta, el plan de verificación y el resultado real (filas afectadas, EXPLAIN).
