---
id: firebase-web-app
name: Firebase Web App
description: Hosting, Firestore, reglas, Functions y emuladores para proyectos Firebase públicos o privados.
logo: firebase.png
icon: web
color: orange
triggers: [firebase, firestore, hosting, cloud functions, deploy]
markers: [firebase.json, .firebaserc, firestore.rules]
tags: [firebase, web, deploy]
---
## Antes de empezar
- Localiza `firebase.json`, `.firebaserc` (proyectos y alias), `firestore.rules`, `firestore.indexes.json`, `storage.rules` y `functions/`. Lee qué proyecto está activo (`firebase use`) ANTES de cualquier comando que escriba o despliegue.
- Comprueba que el CLI esté instalado y con sesión (`firebase --version`, `firebase projects:list`). Si no hay sesión, pide al usuario que ejecute `firebase login` él mismo; nunca pidas ni guardes credenciales.

## Cómo trabajar
1. **Emuladores primero**: `firebase emulators:start` (Hosting, Firestore, Auth, Functions) para probar sin tocar datos reales. Apunta el código a los emuladores solo en desarrollo.
2. **Hosting**: confirma `public` (carpeta de build), `rewrites` para SPA y `headers`/cache. Genera el build antes de desplegar y verifica que la carpeta existe y no está vacía. Para probar sin publicar usa un canal de previsualización: `firebase hosting:channel:deploy nombre-pr --expires 7d`.
3. **Reglas de Firestore/Storage**: parte de "denegar todo" y abre solo lo necesario con `request.auth` y comprobaciones de propiedad (`request.auth.uid == resource.data.uid`). Nunca dejes `allow read, write: if true` ni reglas con fecha de expiración abierta. Valida con el emulador y `firebase deploy --only firestore:rules --dry-run` si está disponible.
4. **Functions**: respeta la versión de runtime de `functions/package.json`, define secretos con `firebase functions:secrets:set` (no en el código ni en `.env` versionado) y fija región y límites razonables.
5. **Despliegues parciales y reversibles**: `--only hosting`, `--only firestore:rules`, `--only functions:miFuncion`. Hosting permite volver a una versión anterior desde la consola o con `hosting:clone`.

## Publicar a producción (requiere confirmación)
Desplegar cambia el sitio real. Antes de ejecutar `firebase deploy`: muestra al usuario el proyecto/alias, qué se desplegará (`--only ...`) y espera su confirmación explícita en este chat. Tras desplegar, abre la URL real y comprueba que carga y que no hay errores en consola; reporta la URL y la versión desplegada.

## Trampas
- Desplegar al proyecto equivocado (revisa alias), reglas demasiado abiertas, claves de servicio (`serviceAccount*.json`) dentro del repo o del bundle del cliente.
- La configuración web de Firebase (`apiKey`, `projectId`) no es secreta, pero SÍ lo son las claves de servicio y los secretos de Functions.
- No cambies IDs de proyecto, dominios personalizados ni targets sin petición explícita.
- Si hay un MCP/CLI de Firebase conectado, descubre sus herramientas y úsalo cuando dé una verificación más fiable.

## Entrega
Indica proyecto/alias usados, qué se desplegó, URL verificada y qué NO se pudo probar.
