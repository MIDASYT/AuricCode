---
id: plugin-author
name: Crear plugins de Auric
description: Ayuda a crear, probar y compartir un plugin de Auric (manifiesto, skills, instrucciones, servidor MCP y permisos).
icon: puzzle
color: violet
triggers: [auric-plugin.json, plugin de auric, crear un plugin, crear plugin, hacer un plugin, mi propio plugin]
markers: [auric-plugin.json]
tags: [plugins, desarrollo]
---
## Qué es un plugin
Una carpeta (o ZIP, o repositorio de GitHub) con un `auric-plugin.json` en la raíz y, si hace falta, skills, un texto de instrucciones y servidores MCP. Se instala desde **Complementos → Plugins → Importar**, siempre con una revisión de seguridad antes.

## Manifiesto mínimo
```json
{
  "schema": "auric-plugin/1",
  "id": "mi-plugin",
  "name": "Mi plugin",
  "version": "1.0.0",
  "description": "Qué hace, en una frase.",
  "author": "Tu nombre",
  "skills": ["skills/mi-skill"]
}
```
- `id`: 3–48 letras minúsculas, números y guiones. `version`: formato `1.2.3`.
- Cada carpeta de `skills` lleva un `SKILL.md` con cabecera (`name`, `description`, `triggers` y/o `markers`). Sin palabras clave ni marcadores la skill se aplica siempre: usa palabras clave para que no moleste.
- `instructions`: ruta a un `.md` corto con reglas generales del plugin (máx. 16 KB). Se entrega a la IA como guía de un tercero.

## Servidor MCP (opcional)
```json
"mcp": [{ "id": "calculo", "name": "Cálculo", "command": "${AURIC_NODE}", "args": ["${PLUGIN_DIR}/servidor.mjs"] }]
```
- Variables: `${PLUGIN_DIR}` (archivos del plugin, solo lectura), `${PLUGIN_DATA}` (carpeta propia para guardar datos), `${WORKSPACE}` (proyecto abierto) y `${AURIC_NODE}` (el motor de JavaScript de Auric: no exige instalar Node.js).
- El servidor arranca con un entorno limpio: no ve las variables de la persona. Para pedir una clave, decláralo en `permissions.env` y úsalo como `"env": { "MI_CLAVE": "${MI_CLAVE}" }`; la persona la escribe en «Detalles» y se guarda cifrada.
- Habla MCP por stdio (JSON por línea). Máximo 8 servidores.

## Permisos (muy recomendado)
```json
"permissions": { "network": ["api.ejemplo.com"], "env": ["MI_CLAVE"], "runs": ["node"], "files": "none", "notes": "Qué hace con cada permiso." }
```
Declarar lo que usas es lo que hace que la revisión salga limpia y que la persona confíe. Lo que el código hace y no declaraste se marca como aviso.

## Buenas prácticas
- Nada de descargar y ejecutar cosas, `curl | sh`, `powershell -enc` ni tocar el registro de Windows: se marca como riesgo alto.
- No pidas más de lo necesario. Un plugin de solo skills es el más fácil de confiar.
- Prueba con **Importar → Carpeta**, abre «Detalles» y usa «Probar» en cada servidor.
- Para compartirlo: sube la carpeta a GitHub (público) y se instala con `usuario/repo`; si tiene varios plugins, usa la dirección de la carpeta (`…/tree/rama/carpeta`).
- Límites: 1500 archivos, 25 MB en total, 8 MB por archivo, 60 skills, 64 KB por skill.
