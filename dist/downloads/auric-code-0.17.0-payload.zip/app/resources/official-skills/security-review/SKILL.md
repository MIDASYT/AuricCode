---
id: security-review
name: Security Review
description: Revisión defensiva de permisos, secretos, autenticación, rutas, inyección y exposición de datos.
icon: shield
color: red
triggers: [security, auth, permission, secret, vulnerability]
markers: []
tags: [security]
---
## Alcance
Revisión DEFENSIVA del código y la configuración del usuario. No se escriben exploits ni se prueba contra sistemas ajenos.

## Qué revisar (por orden)
1. **Secretos**: claves, tokens y contraseñas en el código, `.env` versionado, historial de git, logs y mensajes de error. Si hay uno expuesto: recomienda revocarlo/rotarlo (borrarlo del archivo no basta).
2. **Autenticación y autorización**: ¿se comprueba el permiso sobre cada recurso (IDOR)? ¿Sesiones/tokens con caducidad? ¿Contraseñas con hash adecuado (argon2/bcrypt)?
3. **Entrada no confiable**: inyección SQL/NoSQL/comandos, rutas (`../`), SSRF, deserialización insegura, XSS (salida sin escapar, `innerHTML`), CSRF.
4. **Superficie expuesta**: CORS, cabeceras de seguridad, puertos, endpoints de depuración, permisos de archivos, reglas de Firestore/Storage abiertas.
5. **Dependencias**: versiones con vulnerabilidades conocidas (`npm audit`, `pip-audit`, `cargo audit`), paquetes abandonados o con nombres sospechosos.
6. **Datos**: qué se guarda, dónde y cifrado en reposo/tránsito; datos personales en logs.

## Cómo informar
Para cada hallazgo: severidad (crítica/alta/media/baja), ubicación exacta (archivo:línea), cómo se explotaría en términos generales, y el arreglo concreto. Ordena por severidad. Distingue lo confirmado leyendo el código de lo que es solo sospecha.

## Reglas
- No ejecutes pruebas de intrusión ni escaneos contra servidores que no sean del usuario.
- No imprimas secretos completos en la respuesta: enmascara (`sk-…abcd`).
- Prefiere arreglos que reduzcan la superficie (validar, limitar permisos) a parches puntuales.
