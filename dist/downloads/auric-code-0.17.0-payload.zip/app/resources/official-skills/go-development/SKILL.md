---
id: go-development
name: Go Development
description: Módulos Go, servicios, CLIs, concurrencia y tests idiomáticos.
logo: go.png
icon: code
color: cyan
triggers: [golang, go test, go.mod, goroutine]
markers: [go.mod]
tags: [go, backend]
---
## Antes de empezar
- Lee `go.mod` (versión de Go, módulo) y la estructura (`cmd/`, `internal/`, `pkg/`). Respeta los límites de `internal/`.
- Usa las herramientas estándar: `gofmt`/`goimports`, `go vet`, `go test ./...`. Si el repo usa `golangci-lint`, respeta su configuración.

## Cómo trabajar
1. Errores explícitos: devuelve `error`, envuélvelo con contexto (`fmt.Errorf("leer config: %w", err)`) y compara con `errors.Is/As`. No uses `panic` para flujo normal.
2. Concurrencia: pasa `context.Context` como primer parámetro; cada goroutine debe tener forma clara de terminar (cancelación o canal cerrado). Protege estado compartido con mutex o canales, y valida con `go test -race`.
3. Interfaces pequeñas definidas donde se consumen; no crees interfaces "por si acaso".
4. Tests: table-driven con `t.Run`, `t.Helper()`, `t.TempDir()`; evita dormir (`time.Sleep`) para sincronizar.
5. Dependencias: `go get` solo lo necesario y termina con `go mod tidy`.

## Trampas
- Cierra siempre `resp.Body`, archivos y filas SQL (`defer` justo después de comprobar el error).
- Captura de variables de bucle en closures (Go < 1.22).
- Para cross-compilar a Windows: `GOOS=windows GOARCH=amd64 go build`; sin CGO salvo que sea imprescindible.

## Entrega
Resume cambios y el resultado real de `go vet` y `go test` (con `-race` si tocaste concurrencia).
