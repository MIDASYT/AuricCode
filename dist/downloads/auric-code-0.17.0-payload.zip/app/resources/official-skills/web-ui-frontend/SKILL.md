---
id: web-ui-frontend
name: Web UI & Frontend
description: Interfaces web responsivas, accesibles y consistentes con el sistema visual existente.
icon: palette
color: rose
triggers: [ui, ux, frontend, css, responsive, web]
markers: [index.html, package.json]
tags: [frontend, ui, web]
---
## Principio
La interfaz debe parecer parte del producto existente, no una plantilla genérica. Antes de diseñar, mira el CSS, los tokens (colores, tipografía, espaciado, radios) y 2–3 pantallas actuales.

## Cómo trabajar
1. Reutiliza variables CSS y componentes existentes; si añades un valor nuevo, hazlo token. No hardcodees colores sueltos ni tamaños mágicos.
2. Jerarquía clara: un único foco por pantalla, espaciado consistente (escala de 4/8 px), tipografía con 2–3 tamaños bien diferenciados.
3. Estados completos para todo control: normal, hover, foco visible, activo, deshabilitado, cargando, vacío y error. Un botón sin estado de foco o de carga está incompleto.
4. Responsive real: diseña desde móvil (~360 px) y comprueba ~768 y ≥1280 px; sin scroll horizontal; zonas táctiles ≥ 40 px.
5. Accesibilidad: HTML semántico, `alt`, `label` asociado, contraste ≥ 4.5:1, navegación por teclado, respeta `prefers-reduced-motion` y modo claro/oscuro si el proyecto lo soporta.
6. Rendimiento: imágenes dimensionadas, sin librerías pesadas para efectos pequeños, animaciones con `transform`/`opacity`.

## Verificación obligatoria
- Abre la página en Preview (URL local) o la ventana conectada y captura evidencia en al menos dos anchos. Revisa la captura: recortes, solapes, texto cortado, contraste.
- Si cambias CSS global, busca selectores duplicados o reglas que se pisan antes de añadir más (`!important` es una señal de alarma).

## Entrega
Cuenta qué mejoró visualmente y muestra las capturas. No declares "pixel perfect" sin haberlas revisado.
