---
id: dotnet-csharp
name: .NET & C#
description: Soluciones .NET, C#, ASP.NET, NuGet y tests.
icon: code
color: violet
triggers: [csharp, c#, dotnet, asp.net, nuget]
markers: [.sln, .csproj, Directory.Build.props]
tags: [dotnet, csharp]
---
## Antes de empezar
- Localiza la solución (`*.sln`) y los proyectos (`*.csproj`); lee `TargetFramework`, `Nullable`, `LangVersion` y `Directory.Build.props`.
- Comandos base: `dotnet build`, `dotnet test --filter`, `dotnet format --verify-no-changes`.

## Cómo trabajar
1. Respeta nullable reference types: no uses `!` para silenciar; modela la ausencia de valor.
2. `async`/`await` de punta a punta (`Task`, `CancellationToken`); no uses `.Result`/`.Wait()` (bloqueos/deadlocks).
3. Inyección de dependencias con el contenedor existente; evita `new` de servicios dentro de otros servicios.
4. Configuración: `IOptions<T>` y `appsettings.*.json`; los secretos van en User Secrets o variables de entorno, nunca en el repo.
5. Verifica: `dotnet build -warnaserror` (si el proyecto lo usa) → `dotnet test --filter "FullyQualifiedName~Nombre"`.

## Trampas
- Paquetes NuGet: no cambies versiones masivamente; mantén coherencia entre proyectos (Central Package Management si existe).
- EF Core: crea migraciones con nombre claro y revísalas antes de aplicarlas; nunca apliques `database update` contra producción.
- ASP.NET: valida modelos, no expongas entidades directamente, devuelve `ProblemDetails` en errores.

## Entrega
Resume cambios y el resultado real de build y tests.
