---
id: rust-development
name: Rust Development
description: Cargo, ownership, errores, crates, rendimiento y tests en Rust.
logo: rust.png
icon: code
color: orange
triggers: [rust, cargo, borrow, ownership]
markers: [Cargo.toml]
tags: [rust]
---
## Antes de empezar
- Lee `Cargo.toml` (edition, features, workspace) y el layout (`src/lib.rs`, `src/main.rs`, `tests/`, `benches/`).
- Herramientas: `cargo check`, `cargo clippy -- -D warnings`, `cargo fmt`, `cargo test`.

## Cómo trabajar
1. Prefiere `Result<T, E>` y el operador `?`; define errores con `thiserror` en librerías y `anyhow` en binarios, si el proyecto ya los usa.
2. Evita `unwrap()`/`expect()` fuera de tests y de invariantes realmente imposibles (documéntalos).
3. Ownership: toma referencias (`&str`, `&[T]`) en parámetros, devuelve tipos con dueño; no clones para silenciar al borrow checker sin entender el motivo.
4. Dependencias: comprueba features mínimas (`default-features = false` cuando proceda) y la licencia; no añadas crates pesados por una función trivial.
5. Verifica en orden: `cargo check` → `cargo clippy` → `cargo test <filtro>` → `cargo build --release` si el cambio afecta rendimiento o empaquetado.

## Trampas
- `async`: no bloquees el runtime con IO síncrono; no mantengas un `MutexGuard` a través de un `.await`.
- `unsafe` solo con comentario `SAFETY:` que justifique la invariante.
- En Windows, rutas con `std::path::Path`, no concatenar strings.

## Entrega
Indica qué comandos ejecutaste y su resultado. Si clippy da avisos nuevos, corrígelos o explica por qué no.
