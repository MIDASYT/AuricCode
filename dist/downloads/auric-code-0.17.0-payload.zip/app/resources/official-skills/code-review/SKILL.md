---
id: code-review
name: Revisión de código
description: Revisa cambios (diff, PR o archivos) buscando bugs reales, regresiones y riesgos, con hallazgos ordenados y verificables.
icon: search
color: cyan
triggers: [review, revisar, revisión, pull request, pr, diff, auditar]
markers: []
tags: [review, calidad]
---
## Cómo revisar
1. **Entiende la intención**: lee la descripción, el issue o el mensaje del commit; sin saber qué debe hacer el cambio no se puede juzgar si lo hace.
2. **Lee el diff completo** (`git diff`, `git diff --staged` o el PR) y después el código circundante de cada cambio importante: llamadores, contratos, tests.
3. **Busca, por prioridad**: errores de lógica y casos límite → seguridad (entrada no confiable, permisos, secretos) → pérdida de datos/concurrencia/reintentos → regresiones de comportamiento público → rendimiento evidente → legibilidad y pruebas ausentes.
4. **Verifica antes de afirmar**: si dudas de un hallazgo, léelo en el código o ejecútalo. No reportes problemas que no puedas sostener con una línea concreta.
5. **Ejecuta lo que exista**: tests, lint y typecheck del proyecto, y reporta su resultado real.

## Formato del informe
- Ordena por severidad: **Bloqueante**, **Importante**, **Menor**.
- Cada hallazgo: `archivo:línea`, qué falla, escenario concreto que lo dispara y arreglo sugerido (corto).
- Cierra con lo que está bien y con lo que NO pudiste revisar (por ejemplo, partes que requieren ejecutar la app).

## Reglas
- Critica el código, no a la persona. Sin relleno ni elogios vacíos.
- No cambies archivos durante la revisión salvo que el usuario lo pida; propón el parche.
- Si no hay nada importante, dilo con claridad en lugar de inventar objeciones.
