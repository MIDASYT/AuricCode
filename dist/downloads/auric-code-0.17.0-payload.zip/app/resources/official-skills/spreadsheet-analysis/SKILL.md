---
id: spreadsheet-analysis
name: Análisis de planillas y datos
description: Analiza CSV y planillas con código (no de memoria), revisa la calidad de los datos y explica los resultados en simple.
icon: table
color: green
triggers: [csv, xlsx, planilla, hoja de cálculo, hoja de calculo, excel, promedio, estadística, estadistica, tabla dinámica, tabla dinamica]
markers: []
tags: [datos, análisis]
---
## Método
1. **Lee** el archivo con `read_document` (xlsx, csv, pdf) y mira primero la estructura: hojas, encabezados, tipos y cantidad de filas.
2. **Revisa la calidad** antes de analizar: celdas vacías, duplicados, fechas en formatos mezclados, números guardados como texto, totales dentro de los datos, unidades distintas. Cuéntale al usuario lo que encontraste.
3. **Calcula con código** (`run_command` con Python o Node si hay en el equipo) o con fórmulas. Nunca hagas sumas, promedios o porcentajes «de cabeza» con más de unos pocos números.
4. **Comprueba**: que los totales cuadren con los de la planilla, que las filas contadas sean las esperadas y que no se hayan perdido filas al filtrar.

## Cómo informar
- Primero la respuesta (la cifra o la conclusión), después cómo se calculó.
- Muestra una tabla corta con lo importante; no pegues cientos de filas.
- Aclara supuestos («tomé solo las filas de 2025», «excluí las anuladas»).
- Si los datos no alcanzan para concluir algo, dilo en vez de forzar una conclusión.

## Reglas
- Trabaja sobre una copia: no modifiques el archivo original del usuario salvo que lo pida. Para entregar resultados usa `generate_document` (nombre nuevo).
- Datos personales (nombres, RUT, correos, sueldos): úsalos solo para lo pedido y no los repitas de más en la respuesta.
- Los gráficos no están disponibles en `generate_document`; ofrece una tabla o instrucciones para crearlos en Excel.
