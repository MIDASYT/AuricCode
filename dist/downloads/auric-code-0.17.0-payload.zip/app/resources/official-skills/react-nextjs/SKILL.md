---
id: react-nextjs
name: React & Next.js
description: Componentes React, Next.js, estado, rutas, renderizado y verificación frontend.
logo: nextjs.png
icon: web
color: cyan
triggers: [react, next.js, nextjs, jsx, tsx, component]
markers: [next.config.js, next.config.mjs, next.config.ts, src/app, src/pages]
tags: [react, nextjs, frontend]
---
## Antes de empezar
- Detecta el router: `src/app` o `app/` (App Router) vs `pages/` (Pages Router); versión de React/Next en `package.json`; TypeScript sí/no; librería de estilos (Tailwind, CSS Modules, styled-components).
- Revisa componentes existentes antes de crear uno nuevo y reutiliza el sistema de diseño del proyecto.

## Cómo trabajar
1. App Router: los componentes son de servidor por defecto; añade `'use client'` solo donde haya estado, efectos o eventos, y lo más abajo posible del árbol.
2. Estado: el mínimo necesario; deriva valores en vez de duplicarlos en `useState`. Efectos (`useEffect`) solo para sincronizar con sistemas externos, con limpieza y dependencias correctas.
3. Datos: usa el mecanismo del proyecto (server components/fetch, React Query, SWR). Maneja carga, vacío y error en la UI.
4. Listas con `key` estable (no el índice si el orden cambia). Formularios accesibles (`label`, errores asociados).
5. Accesibilidad y responsive: elementos semánticos, foco visible, contraste, navegación por teclado, prueba en ancho móvil.
6. Verifica: typecheck → lint → tests acotados → `next build` si cambian rutas, metadata o configuración. Si hay servidor de desarrollo, abre la página en Preview y comprueba el resultado real.

## Trampas
- Hidratación: no uses `Date.now()`, `Math.random()` o `window` durante el render del servidor.
- Variables públicas: solo `NEXT_PUBLIC_*` llega al navegador; nunca pongas secretos ahí.
- Imágenes: `next/image` con dimensiones; no cargues librerías enormes por una utilidad pequeña.

## Entrega
Describe qué pantallas/componentes cambiaron y adjunta la evidencia visual (captura de Preview) cuando el cambio sea de interfaz.
