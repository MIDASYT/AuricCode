---
id: electron-node-desktop
name: Electron Desktop
description: Aplicaciones Electron/Node con IPC, preload, procesos, seguridad y empaquetado de escritorio.
logo: electron.png
icon: terminal
color: violet
triggers: [electron, preload, ipc, desktop app]
markers: [preload.js, electron-builder.yml, electron-builder.json]
tags: [desktop, electron, node]
---
## Antes de empezar
- Localiza `main`, `preload` y el renderer; lee `package.json` (versión de Electron, scripts, `build` de electron-builder si existe) y la CSP del `index.html`.

## Seguridad (no negociable)
- `contextIsolation: true`, `nodeIntegration: false`, `sandbox: true` salvo motivo documentado. El renderer solo accede a capacidades expuestas por `contextBridge` en el preload, con funciones específicas (no expongas `ipcRenderer` completo ni `require`).
- Todo handler `ipcMain.handle` valida sus argumentos (tipos, rutas dentro de carpetas permitidas, URLs https) y comprueba el origen del emisor.
- CSP restrictiva (`script-src 'self'`), sin `eval` ni scripts inline. Navegación externa con `shell.openExternal` solo para `https:`.
- Secretos con `safeStorage`, no en JSON plano ni en `localStorage`.

## Cómo trabajar
1. Un canal IPC por acción, con nombre claro y respuesta `{ ok, value | error }`. Errores del main llegan al renderer como mensajes legibles.
2. Escritura de estado atómica (archivo temporal + `rename`) y respaldo; una sola instancia (`requestSingleInstanceLock`).
3. Procesos hijo: `spawn` con args en array; al detener, mata el ÁRBOL de procesos (en Windows `taskkill /PID <pid> /T /F`).
4. Pruebas: unitarias para lógica pura y E2E con Playwright (`_electron.launch`) para flujos reales de la ventana.
5. Empaquetado: verifica que los recursos (`resources/`) se incluyen y que la app arranca desde el paquete, no solo con `electron .`.

## Trampas
- `webSecurity: false`, `allowRunningInsecureContent`, `enableRemoteModule`: no.
- Listeners acumulados en cada render; ventanas sin `closed` limpiando referencias; rutas con espacios/acentos en Windows.

## Entrega
Indica qué se probó realmente (unitario, E2E, ejecución empaquetada) y qué no.
