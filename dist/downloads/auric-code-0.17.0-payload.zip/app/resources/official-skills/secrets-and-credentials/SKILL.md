---
id: secrets-and-credentials
name: Claves y credenciales
description: Manejo seguro de claves de API, tokens y contraseñas: dónde guardarlas, cómo no filtrarlas y qué hacer si ya se expusieron.
icon: key
color: red
triggers: [api key, apikey, token, contraseña, contrasena, password, credenciales, .env, filtrada, rotar la clave, revocar, secreto]
markers: []
tags: [seguridad, secretos]
---
## Regla de oro
Una clave que se pegó en un chat, un commit, un log o una captura **ya no es secreta**. Se revoca y se crea otra; borrarla del archivo no basta.

## Al escribir o revisar código
- Las claves van en variables de entorno o en un archivo `.env` que esté en `.gitignore` (y se incluye un `.env.example` sin valores).
- Nunca las pongas en el código, en el front-end de una web (cualquiera las ve) ni en mensajes de error o logs.
- Una clave por servicio y con los permisos mínimos; con fecha de caducidad cuando el servicio lo permita.
- Si el usuario te pega una clave real, úsala solo para lo que pidió, no la repitas completa (`sk-…abcd`) y recuérdale rotarla si se compartió en un lugar público.

## Si una clave se filtró
1. Revócala o rótala en el panel del servicio (primero esto, antes que limpiar nada).
2. Revisa el uso reciente en busca de actividad que no reconozca.
3. Si llegó a un repositorio: quítala del código, pero asume que el historial ya la contiene; no hace falta reescribir el historial si ya se revocó. Usa `git log -S` para ver dónde apareció.
4. Cambia también cualquier otra clave o contraseña que compartiera valor con esa.

## Contraseñas de personas
Recomienda un gestor de contraseñas, contraseñas largas y únicas, y verificación en dos pasos (app autenticadora mejor que SMS). No guardes contraseñas de otras personas ni las pidas en el chat.

## Reglas
- Nunca imprimas el contenido de un `.env` ni de archivos de credenciales completos; enmascara los valores.
- No subas claves a servicios externos ni las incluyas en documentos generados.
