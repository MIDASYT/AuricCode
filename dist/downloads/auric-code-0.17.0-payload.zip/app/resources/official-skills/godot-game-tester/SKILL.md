---
id: godot-game-tester
name: Godot Game Tester
description: Desarrolla, depura y PRUEBA juegos Godot 4.x jugándolos de verdad en segundo plano (sin molestar la pantalla, con sonido y con datos de prueba aislados).
logo: godot.png
icon: game
color: blue
triggers: [godot, gdscript, scene, escena, gameplay, project.godot, juego, nivel, personaje]
markers: [project.godot]
tags: [game, godot, testing]
---
## Cuándo usar esta skill
Proyectos con `project.godot`: escribir o arreglar GDScript/escenas, y sobre todo **verificar jugando**, no solo compilando.

## Herramientas reales (úsalas, no inventes otras)
- `detect_godot`: localiza el ejecutable (PATH, Descargas, Escritorio, Documentos).
- `start_godot_test` con `mode: "headless"`: comprobación rápida de sintaxis/carga sin ventana. Sirve para detectar errores de parseo, rutas rotas y scripts de prueba propios (`script`). No produce imágenes.
- `godot_session_start`: abre el juego **completo** (escena principal, autoloads, físicas, audio) en segundo plano. La ventana queda fuera de pantalla y sin foco, el sonido SIGUE sonando (usa `mute: true` solo si el usuario lo pide) y el usuario ve el juego en vivo en Preview. Los datos del juego (`user://`, partidas guardadas, ajustes) van a un **perfil de prueba aislado**: el progreso real del jugador no se toca. Nunca pongas `isolateUserData: false` salvo petición explícita.
- `godot_session_command`: controla la sesión (ver tabla). `godot_session_stop`: ciérrala al terminar (descarta el perfil de prueba).
- `get_process_output` con el id de la sesión: stdout/stderr del juego (`print`, errores de script).

## Comandos de `godot_session_command`
| cmd | Parámetros | Para qué |
|---|---|---|
| `info` | – | FPS, escena actual, tamaño de ventana, `user_dir` (confirma el aislamiento), nodos |
| `tree` | `node`, `depth`, `max_nodes` | Árbol de nodos con clase, posición, texto y visibilidad |
| `screenshot` | `name`, `max_width` | Captura (queda en la evidencia del chat; **mírala** antes de afirmar algo visual) |
| `key` | `key` ("Space", "d", "Left", "Escape"), `mode` tap/down/up, `hold_ms` | Teclado |
| `action` | `name`, `mode`, `hold_ms`, `strength` | Acciones del InputMap (`ui_accept`, `jump`…) |
| `mouse` | `x`, `y`, `button`, `mode` click/down/up/move/wheel_up/wheel_down | Ratón en coordenadas del viewport |
| `type` | `text` | Escribir texto en campos |
| `wait` | `ms` o `frames` | Dejar pasar tiempo real |
| `get` | `node`, `prop` (admite `position:x`) | Leer una propiedad |
| `set` | `node`, `prop`, `value` (JSON, p. ej. `[100,50]`) | Cambiar una propiedad para montar una situación |
| `call` | `node`, `method`, `args` | Llamar a un método del juego |
| `eval` | `expr`, `node` | Expresión de GDScript (`get_node("Player").position.x * 2`, `root.get_node("Score").points`) |
| `scene` | `path` | Cambiar de escena |
| `time_scale` | `scale` | Acelerar o ralentizar el juego (p. ej. 3 para saltar esperas) |
| `pause`, `mute`, `log`, `quit` | – | Utilidades |

Notas: las rutas de nodo son relativas a la escena actual (`Player`, `UI/Label`) o absolutas (`/root/Score`). En `eval` no existe `$Nodo`: usa `get_node("Nodo")`. `eval`, `call` y `set` ejecutan código dentro del juego y piden permiso del usuario (salvo modo completo); además se rechazan expresiones que toquen el sistema, archivos o red. Las teclas se inyectan como entrada real, así que el juego reacciona igual que con un jugador.

## Flujo recomendado
1. Lee `project.godot` (escena principal, autoloads, InputMap) y los scripts afectados antes de editar.
2. Edita el código. Haz una comprobación `headless` rápida; corrige errores de GDScript hasta que cargue limpio.
3. `godot_session_start` → `info` (comprueba `user_dir` dentro de `test-profiles`) → `tree` → `screenshot` inicial.
4. Reproduce lo que cambiaste: entradas (`key`/`action`/`mouse`), `wait`, y mide con `get`/`eval`. Después de cada acción relevante toma `screenshot` y descríbelo con lo que ves de verdad.
5. Para casos difíciles prepara el estado con `set`/`call` (vida baja, otra escena, enemigo cerca) en lugar de jugar 10 minutos; usa `time_scale` para saltar esperas.
6. Revisa `get_process_output`: cualquier `ERROR`/`SCRIPT ERROR` es un fallo aunque el juego siga abierto.
7. Si algo falla: corrige, **reinicia la sesión** (los scripts se cargan al arrancar) y repite la misma secuencia para confirmar el arreglo.
8. Termina con `godot_session_stop`. Informa qué probaste, qué viste y qué no pudiste comprobar.

## Buenas prácticas de GDScript 4.x
- Tipado estático donde aporte (`var speed: float = 200.0`), `@export` y `@onready` en vez de `export`/`onready` de Godot 3.
- Señales: `button.pressed.connect(_on_pressed)`; no uses `connect("pressed", self, "…")`.
- Movimiento físico en `_physics_process(delta)`; entrada continua con `Input.get_vector()` / `Input.is_action_pressed()`; eventos puntuales en `_unhandled_input`.
- Para cuerpos usa `CharacterBody2D/3D` con `velocity` + `move_and_slide()`; no multipliques `velocity` por `delta` antes de `move_and_slide()`.
- Escenas y recursos con rutas `res://`; guardados solo en `user://` (así el perfil aislado funciona).
- Conserva nombres de nodos, señales y propiedades exportadas salvo que el cambio pedido lo exija: otras escenas dependen de ellos.
- Los `.tscn` son texto: ediciones pequeñas y coherentes (`[ext_resource]`, `[node …]`); no reescribas una escena completa para cambiar una propiedad. Si añades un `.gd`/recurso nuevo, deja que Godot lo importe (la ejecución headless lo hace).

## Qué NO hacer
- No digas que “funciona” sin haberlo jugado y visto (captura) o medido (`get`/`eval`).
- No uses el `user://` real del jugador ni copies sus partidas.
- No dejes sesiones abiertas: consumen CPU y sonido.
- No escribas harness de prueba dentro de escenas de producción. Si necesitas un script propio, créalo en `.auriccode/tests/` y bórralo o márcalo al terminar.
- Si no hay Godot instalado, dilo claramente y explica dónde ponerlo (PATH o carpeta Descargas/Escritorio) en lugar de simular resultados.
