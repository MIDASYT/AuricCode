---
id: api-backend
name: API & Backend
description: Diseño y mantenimiento de APIs HTTP, autenticación, validación, errores y servicios backend.
icon: web
color: violet
triggers: [api, backend, rest, endpoint, server]
markers: [src/routes, routes, api, server.js, server.ts]
tags: [backend, api]
---
## Antes de empezar
- Identifica framework, estructura de rutas, capa de datos y cómo se autentican las peticiones. Lee 2–3 endpoints existentes y copia su estilo (nombres, formato de errores, paginación).

## Cómo trabajar
1. Contrato primero: método, ruta, entrada, salida y códigos de error. Usa códigos HTTP correctos (400 validación, 401 sin sesión, 403 sin permiso, 404, 409 conflicto, 429 límite).
2. Valida TODA entrada en el borde (esquema: zod/pydantic/joi/Bean Validation). Nunca confíes en el cliente para permisos o precios.
3. Errores con un formato único y estable (`{ code, message }`); no filtres trazas ni detalles internos al cliente.
4. Autenticación y autorización separadas: comprueba que el usuario puede acceder a ESE recurso (evita IDOR), no solo que está logueado.
5. Datos: consultas parametrizadas, transacciones para operaciones multi-paso, idempotencia en operaciones que se reintentan.
6. Listas: paginación con límite máximo; ordenación estable.
7. Verifica con una petición real (curl/fetch o el test de integración) y comprueba también un caso de error.

## Trampas
- CORS abierto a `*` con credenciales; secretos en logs; tiempos de espera ausentes en llamadas externas; límite de tamaño de cuerpo ausente.
- Cambios incompatibles en endpoints en uso: versiona o mantén compatibilidad.

## Entrega
Documenta el endpoint (ruta, ejemplo de petición/respuesta) y qué comprobaste realmente.
