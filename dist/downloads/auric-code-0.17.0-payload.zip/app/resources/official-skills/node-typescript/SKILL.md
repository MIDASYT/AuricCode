---
id: node-typescript
name: Node.js & TypeScript
description: Servicios y herramientas Node.js/TypeScript con scripts, tipos, lint, tests y dependencias coherentes.
logo: nodejs.png
icon: code
color: green
triggers: [node, typescript, javascript, npm, pnpm, yarn]
markers: [package.json, tsconfig.json]
tags: [node, typescript]
---
## Antes de empezar
- Detecta el gestor por el lockfile: `pnpm-lock.yaml` → pnpm, `yarn.lock` → yarn, `package-lock.json` → npm, `bun.lockb` → bun. No mezcles gestores ni regeneres el lockfile sin motivo.
- Lee `package.json` (scripts, `type`, `engines`, `exports`) y `tsconfig*.json` (strict, paths, module/target). Usa los scripts del proyecto (`npm run test`, `lint`, `build`) en lugar de inventar comandos.
- Comprueba la versión de Node requerida (`engines`, `.nvmrc`).

## Cómo trabajar
1. Cambios pequeños y tipados: evita `any`; si hace falta, `unknown` + estrechamiento. No desactives reglas de lint ni `strict` para "que compile".
2. Dependencias: añade solo las necesarias, fija el tipo (`-D` para dev) y explica por qué. Antes de añadir una, mira si ya existe algo equivalente en el proyecto o en la biblioteca estándar de Node.
3. ESM vs CJS: respeta el modo del proyecto (`"type": "module"`, extensiones `.js` en imports ESM, `import.meta`).
4. Asincronía: `await` en todo lo que devuelva promesa, maneja errores en el borde (HTTP handler, CLI main), no tragues excepciones.
5. Verifica en este orden: typecheck (`tsc --noEmit`) → lint → test acotado → build si hay empaquetado.

## Trampas
- Variables de entorno: lee y valida una sola vez al arrancar; nunca imprimas secretos en logs.
- Rutas en Windows: usa `path.join`/`path.resolve`, no concatenes con `/`.
- Procesos hijo: `spawn` con args en array (no concatenar comandos del usuario en un string).
- No ejecutes `npm audit fix --force` ni `npm update` globalmente sin pedirlo.

## Entrega
Resume cambios, comandos ejecutados y su salida real. Si algo no se pudo verificar (sin red, sin tests), dilo.
