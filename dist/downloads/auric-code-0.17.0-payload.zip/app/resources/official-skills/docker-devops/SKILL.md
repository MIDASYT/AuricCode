---
id: docker-devops
name: Docker & DevOps
description: Dockerfiles, Compose, CI/CD y despliegues reproducibles y verificables.
logo: docker.png
icon: process
color: blue
triggers: [docker, compose, container, ci, cd, deploy, pipeline]
markers: [Dockerfile, docker-compose.yml, docker-compose.yaml, .github/workflows]
tags: [docker, devops, ci]
---
## Antes de empezar
- Lee `Dockerfile`, `docker-compose*.yml`, `.dockerignore` y los workflows (`.github/workflows`). Identifica qué se construye, con qué base y cómo se despliega.

## Cómo trabajar
1. Dockerfile: base oficial con versión fijada (no `latest`), multi-stage para dejar fuera herramientas de build, copia primero los archivos de dependencias para aprovechar caché, usuario no root, `HEALTHCHECK` cuando aplique.
2. `.dockerignore` obligatorio (`node_modules`, `.git`, `.env`, builds locales).
3. Compose: variables por `env_file`/entorno (nunca secretos en el YAML), volúmenes con nombre para datos, `depends_on` con `condition: service_healthy`.
4. CI/CD (GitHub Actions u otro): fija versiones de acciones, usa `secrets.*`, permisos mínimos del token (`permissions:`), caché de dependencias y jobs pequeños (lint → test → build → deploy).
5. Verifica localmente: `docker build`, `docker compose config` (valida el YAML), y si se puede `docker compose up` con prueba de salud. En CI, valida el YAML y los comandos antes de proponer el cambio.

## Trampas
- Secretos en capas de imagen (ARG/ENV con claves), `latest`, ejecutar como root, puertos innecesarios publicados.
- No ejecutes `docker system prune`, `rm -rf` de volúmenes ni despliegues a producción sin confirmación explícita.

## Entrega
Explica qué cambió, cómo se probó y qué falta por probar (por ejemplo, el despliegue real).
