---
id: java-gradle
name: Java & Gradle
description: Proyectos Java/Kotlin con Gradle/Maven, tests y estructura multiproyecto.
logo: java.png
icon: code
color: orange
triggers: [java, kotlin, gradle, maven]
markers: [build.gradle, build.gradle.kts, pom.xml]
tags: [java, gradle, maven]
---
## Antes de tocar nada
- Identifica el sistema de build: `gradlew`/`build.gradle(.kts)` (Gradle) o `mvnw`/`pom.xml` (Maven). Usa SIEMPRE el wrapper del repo (`./gradlew`, `mvnw`), nunca una versión global.
- Lee `settings.gradle(.kts)` para saber los módulos y `gradle/libs.versions.toml` si existe (catálogo de versiones): las dependencias nuevas se declaran ahí, no con versiones sueltas.
- Comprueba la versión de Java objetivo (`java.toolchain`, `sourceCompatibility`, `maven.compiler.release`) y no uses APIs más nuevas.

## Cómo trabajar
1. Cambia lo mínimo dentro del módulo afectado; respeta el estilo existente (Lombok sí/no, records, Optional, nulabilidad con anotaciones).
2. Compila solo lo necesario: `./gradlew :modulo:compileJava` o `mvn -pl modulo -am compile`.
3. Ejecuta el test más acotado: `./gradlew :modulo:test --tests "pkg.Clase.metodo"` o `mvn -pl modulo -Dtest=Clase#metodo test`.
4. Si falla, lee el informe real (`build/reports/tests`, `target/surefire-reports`) antes de arreglar; no supongas.
5. Antes de terminar, corre `./gradlew build` (o `mvn verify`) si el cambio toca varias clases o dependencias.

## Trampas habituales
- No actualices Gradle, plugins ni dependencias "de paso": es un cambio aparte y debe pedirse.
- Paper/Spigot/Bukkit u otros plugins: respeta `plugin.yml`/`paper-plugin.yml`, la versión de API declarada y que el hilo principal no se bloquee con IO.
- Kotlin + Java mezclados: cuida el orden de compilación y las anotaciones de nulabilidad.
- No ejecutes `clean` si no es necesario; no borres `.gradle/` ni caches del usuario.
- Nunca guardes claves en `gradle.properties` del repo.

## Entrega
Indica qué módulos cambiaron, qué comando de test ejecutaste y su resultado real (verde/rojo). Si no pudiste ejecutar el build, dilo.
