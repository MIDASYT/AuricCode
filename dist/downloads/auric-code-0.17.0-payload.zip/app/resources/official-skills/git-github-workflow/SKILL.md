---
id: git-github-workflow
name: Git & GitHub Workflow
description: Revisión de cambios, ramas, commits, conflictos y flujos Git/GitHub sin destruir trabajo local.
logo: github.png
icon: code
color: cyan
triggers: [git, github, commit, branch, pull request, merge]
markers: []
tags: [git, github]
---
## Principio
Nunca destruyas trabajo local. Mira antes de actuar y explica lo que harás.

## Rutina
1. `git status` y `git diff` (y `git diff --staged`) antes de cualquier operación. Si hay cambios del usuario sin relación, no los mezcles ni los descartes.
2. Ramas: trabaja en una rama de tarea (`feat/...`, `fix/...`), nunca directamente en `main` si el repo usa PRs.
3. Commits pequeños y atómicos; mensaje en imperativo con el porqué ("Corrige X porque Y"). No incluyas secretos ni archivos generados.
4. Antes de hacer commit: formatea, ejecuta los tests acotados y revisa `git diff --staged` línea por línea.
5. Conflictos: entiende ambas versiones; no resuelvas aceptando uno de los lados a ciegas. Después de resolver, compila y prueba.

## Operaciones que requieren permiso explícito del usuario
`git push --force`, `git reset --hard`, `git clean -fd`, `git checkout -- .`, reescribir historia publicada, borrar ramas remotas, publicar (`push`, abrir/mergear PR, crear releases). Si el usuario no lo pidió en este chat, pregunta primero.

## GitHub
- PR con título claro, resumen de qué y por qué, cómo se probó y capturas si hay cambios visuales. Enlaza el issue.
- Responde revisiones con cambios concretos; no cierres hilos sin resolverlos.
- Si hay conector de GitHub conectado, úsalo para leer issues/PRs; crear o mergear siempre pasa por la confirmación del usuario.

## Entrega
Resume ramas, commits creados y el estado final de `git status`.
