// Protocolo versionado entre el modelo y el renderizador de componentes visuales de Auric Code.
// El modelo entrega una ESPECIFICACIÓN (JSON); aquí se valida de forma estricta y se normaliza. Nunca se ejecuta contenido del modelo.
import { validateExpr } from './expr.js';

export const SCHEMA_VERSION = 1;
export const LIMITS = {
  rawBytes: 400_000,
  rows: 5000,
  keysPerRow: 24,
  series: 8,
  items: 24,
  text: 2000,
  title: 160,
  mermaid: 20_000,
  svg: 200_000,
  math: 4000,
  inputs: 12,
  outputs: 12,
  actions: 4,
  columns: 8,
  tableRows: 60
};
export const CHART_TYPES = ['bar', 'hbar', 'line', 'area', 'pie', 'donut', 'scatter', 'histogram'];
export const TONES = ['text', 'muted', 'accent', 'success', 'danger', 'blue'];
const ID_RE = /^[A-Za-z_][A-Za-z0-9_]{0,23}$/;
const ICON_RE = /^[a-z0-9][a-z0-9-]{0,63}$/;

class SchemaError extends Error {}
const fail = msg => {
  throw new SchemaError(msg);
};
const isObj = v => v && typeof v === 'object' && !Array.isArray(v);
const str = (v, max, name, { required = false } = {}) => {
  if (v == null || v === '') {
    if (required) fail(`Falta "${name}".`);
    return '';
  }
  if (typeof v !== 'string' && typeof v !== 'number') fail(`"${name}" debe ser texto.`);
  const s = String(v);
  if (s.length > max) fail(`"${name}" es demasiado largo (máx. ${max}).`);
  return s;
};
const num = (v, name, { min = -Infinity, max = Infinity, def } = {}) => {
  if (v == null || v === '') {
    if (def !== undefined) return def;
    fail(`Falta "${name}".`);
  }
  const n = Number(v);
  if (!Number.isFinite(n)) fail(`"${name}" debe ser un número.`);
  return Math.min(max, Math.max(min, n));
};
const arr = (v, max, name, { min = 0 } = {}) => {
  if (v == null) v = [];
  if (!Array.isArray(v)) fail(`"${name}" debe ser una lista.`);
  if (v.length < min) fail(`"${name}" necesita al menos ${min} elemento(s).`);
  if (v.length > max) fail(`"${name}" tiene demasiados elementos (máx. ${max}).`);
  return v;
};
const oneOf = (v, list, name, def) => {
  if (v == null || v === '') {
    if (def !== undefined) return def;
    fail(`Falta "${name}".`);
  }
  if (!list.includes(v)) fail(`"${name}" debe ser uno de: ${list.join(', ')}.`);
  return v;
};
export function safeHttpsUrl(u) {
  try {
    const x = new URL(String(u));
    return x.protocol === 'https:' ? x.toString() : '';
  } catch {
    return '';
  }
}
export function imageSource(src, name = 'src') {
  src = str(src, 2_800_000, name, { required: true }).trim();
  if (/^data:image\/(png|jpeg|jpg|gif|webp);base64,[A-Za-z0-9+/=]+$/.test(src)) {
    if (src.length > 2_700_000) fail('Imagen incrustada demasiado grande.');
    return { kind: 'data', value: src };
  }
  if (/^https:\/\//i.test(src)) {
    const u = safeHttpsUrl(src);
    if (!u) fail('URL de imagen no válida.');
    return { kind: 'remote', value: u };
  }
  if (/^[a-z][a-z0-9+.-]*:/i.test(src) && !/^[a-z]:[\\/]/i.test(src)) fail('Solo se admiten imágenes del proyecto, https o data:image.');
  if (/(^|[\\/])\.\.([\\/]|$)/.test(src)) fail('La ruta de la imagen no puede salir del proyecto.');
  return { kind: 'project', value: src.replace(/\\/g, '/') };
}

function cell(v) {
  if (v == null) return null;
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (typeof v === 'string') return v.length > 300 ? v.slice(0, 300) : v;
  fail('Los datos solo pueden contener texto, números o null.');
}
function normData(raw, name = 'data') {
  const rows = arr(raw, LIMITS.rows, name, { min: 1 });
  return rows.map((r, i) => {
    if (!isObj(r)) fail(`${name}[${i}] debe ser un objeto.`);
    const keys = Object.keys(r);
    if (keys.length > LIMITS.keysPerRow) fail(`${name}[${i}] tiene demasiadas columnas.`);
    const o = {};
    for (const k of keys) {
      if (!/^[\p{L}\p{N}_ .-]{1,40}$/u.test(k) || k === '__proto__') fail(`Nombre de columna no válido: ${k.slice(0, 40)}`);
      o[k] = cell(r[k]);
    }
    return o;
  });
}
function normActions(raw) {
  return arr(raw, LIMITS.actions, 'actions').map(a => {
    if (!isObj(a)) fail('Cada acción debe ser un objeto.');
    const kind = str(a.kind, 20, 'kind', { required: true });
    const label = str(a.label, 60, 'label', { required: true });
    if (kind === 'copy') return { kind, label, text: str(a.text, 4000, 'text', { required: true }) };
    if (kind === 'ask') return { kind, label, text: str(a.text, 1000, 'text', { required: true }) };
    if (kind === 'open') {
      const url = safeHttpsUrl(a.url);
      if (!url) fail('La acción "open" necesita una URL https.');
      return { kind, label, url };
    }
    // Cualquier otra acción (ejecutar comandos, escribir archivos...) NO existe: se muestra desactivada.
    return { kind: 'blocked', label, requested: kind.slice(0, 20) };
  });
}
function common(raw, out) {
  out.title = str(raw.title, LIMITS.title, 'title');
  out.subtitle = str(raw.subtitle, LIMITS.title, 'subtitle');
  out.source = str(raw.source, 300, 'source');
  out.actions = normActions(raw.actions);
  return out;
}

function normSeries(raw, chartType) {
  const list = arr(raw, LIMITS.series, 'series', { min: 1 });
  return list.map((s, i) => {
    if (typeof s === 'string') s = { key: s };
    if (!isObj(s)) fail(`series[${i}] no es válida.`);
    return {
      key: str(s.key, 40, 'series.key', { required: true }),
      label: str(s.label, 60, 'series.label') || str(s.key, 40, 'series.key'),
      unit: str(s.unit, 12, 'series.unit')
    };
  });
}
function chart(raw) {
  const chartType = oneOf(raw.chartType ?? raw.kind, CHART_TYPES, 'chartType');
  const out = common(raw, { type: 'chart', chartType });
  out.data = normData(raw.data);
  out.series = normSeries(raw.series ?? (raw.yKey ? [raw.yKey] : undefined), chartType);
  out.xKey = str(raw.xKey ?? raw.labelKey, 40, 'xKey') || Object.keys(out.data[0])[0];
  out.stacked = !!raw.stacked && ['bar', 'hbar', 'area'].includes(chartType);
  out.unit = str(raw.unit, 12, 'unit');
  out.format = oneOf(raw.format, ['number', 'percent'], 'format', 'number');
  out.xLabel = str(raw.xLabel, 60, 'xLabel');
  out.yLabel = str(raw.yLabel, 60, 'yLabel');
  out.bins = Math.round(num(raw.bins, 'bins', { min: 2, max: 60, def: 10 }));
  out.dataKind = oneOf(raw.dataKind, ['real', 'example'], 'dataKind', 'real');
  if (raw.filter != null) {
    if (!isObj(raw.filter)) fail('"filter" debe ser un objeto.');
    out.filter = { key: str(raw.filter.key, 40, 'filter.key', { required: true }), label: str(raw.filter.label, 40, 'filter.label') };
  }
  for (const s of out.series)
    if (!(s.key in out.data[0]) && !out.data.some(r => s.key in r)) fail(`La serie "${s.key}" no existe en los datos.`);
  if (chartType !== 'histogram' && !out.data.some(r => out.xKey in r)) fail(`La columna "${out.xKey}" no existe en los datos.`);
  return out;
}
function diagram(raw) {
  const out = common(raw, { type: 'diagram', engine: 'mermaid' });
  out.code = str(raw.code ?? raw.source_code ?? raw.definition ?? raw.mermaid, LIMITS.mermaid, 'code', { required: true });
  return out;
}
function svg(raw) {
  const out = common(raw, { type: 'svg' });
  out.markup = str(raw.markup ?? raw.svg, LIMITS.svg, 'markup', { required: true });
  return out;
}
function icons(raw) {
  const out = common(raw, { type: 'icons' });
  out.items = arr(raw.items, 60, 'items', { min: 1 }).map(it => {
    if (typeof it === 'string') it = { name: it };
    if (!isObj(it)) fail('Cada icono debe ser un objeto o un nombre.');
    const name = str(it.name, 64, 'name', { required: true }).toLowerCase();
    if (!ICON_RE.test(name)) fail(`Identificador de icono no válido: ${name}`);
    return { name, label: str(it.label, 60, 'label') };
  });
  out.size = Math.round(num(raw.size, 'size', { min: 12, max: 64, def: 24 }));
  out.strokeWidth = num(raw.strokeWidth, 'strokeWidth', { min: 0.5, max: 3, def: 1.75 });
  out.tone = oneOf(raw.tone, TONES, 'tone', 'accent');
  return out;
}
function image(raw) {
  const out = common(raw, { type: 'image' });
  out.src = imageSource(raw.src);
  out.alt = str(raw.alt, 300, 'alt');
  out.caption = str(raw.caption, 300, 'caption');
  return out;
}
function gallery(raw) {
  const out = common(raw, { type: 'gallery' });
  out.images = arr(raw.images, LIMITS.items, 'images', { min: 1 }).map(im => {
    if (!isObj(im)) fail('Cada imagen debe ser un objeto.');
    return { src: imageSource(im.src), alt: str(im.alt, 300, 'alt'), caption: str(im.caption, 200, 'caption') };
  });
  return out;
}
function cards(raw) {
  const out = common(raw, { type: 'cards' });
  out.columns = Math.round(num(raw.columns, 'columns', { min: 1, max: 4, def: 3 }));
  out.items = arr(raw.items, LIMITS.items, 'items', { min: 1 }).map(it => {
    if (!isObj(it)) fail('Cada tarjeta debe ser un objeto.');
    const icon = str(it.icon, 64, 'icon').toLowerCase();
    if (icon && !ICON_RE.test(icon)) fail(`Identificador de icono no válido: ${icon}`);
    const href = it.href ? safeHttpsUrl(it.href) : '';
    if (it.href && !href) fail('Los enlaces de las tarjetas deben ser https.');
    return {
      title: str(it.title, 120, 'title', { required: true }),
      text: str(it.text, 600, 'text'),
      icon,
      badge: str(it.badge, 30, 'badge'),
      href
    };
  });
  return out;
}
function compare(raw) {
  const out = common(raw, { type: 'compare' });
  out.columns = arr(raw.columns, LIMITS.columns, 'columns', { min: 2 }).map(c => str(c, 60, 'columns', { required: true }));
  out.rows = arr(raw.rows, LIMITS.tableRows, 'rows', { min: 1 }).map(r => {
    if (!isObj(r)) fail('Cada fila debe ser un objeto.');
    const values = arr(r.values, LIMITS.columns, 'values').map(v => String(cell(v) ?? '').slice(0, 200));
    return { label: str(r.label, 80, 'label', { required: true }), values: out.columns.map((_, i) => values[i] ?? '') };
  });
  out.selectable = !!raw.selectable;
  return out;
}
function progress(raw) {
  const out = common(raw, { type: 'progress' });
  out.items = arr(raw.items, 20, 'items', { min: 1 }).map(it => {
    if (!isObj(it)) fail('Cada indicador debe ser un objeto.');
    const max = num(it.max, 'max', { min: 0.000001, def: 100 });
    return {
      label: str(it.label, 80, 'label', { required: true }),
      value: num(it.value, 'value', { min: 0, max }),
      max,
      unit: str(it.unit, 12, 'unit')
    };
  });
  return out;
}
function stats(raw) {
  const out = common(raw, { type: 'stats' });
  out.items = arr(raw.items, 12, 'items', { min: 1 }).map(it => {
    if (!isObj(it)) fail('Cada dato debe ser un objeto.');
    return {
      label: str(it.label, 60, 'label', { required: true }),
      value: str(it.value, 40, 'value', { required: true }),
      unit: str(it.unit, 12, 'unit'),
      note: str(it.note, 80, 'note')
    };
  });
  return out;
}
function math(raw) {
  const out = common(raw, { type: 'math' });
  out.tex = str(raw.tex ?? raw.latex ?? raw.formula, LIMITS.math, 'tex', { required: true });
  out.display = raw.display !== false;
  return out;
}
function widget(raw) {
  const out = common(raw, { type: 'widget' });
  const ids = new Set();
  out.inputs = arr(raw.inputs, LIMITS.inputs, 'inputs', { min: 1 }).map(it => {
    if (!isObj(it)) fail('Cada control debe ser un objeto.');
    const id = str(it.id, 24, 'id', { required: true });
    if (!ID_RE.test(id)) fail(`Identificador de control no válido: ${id}`);
    if (ids.has(id)) fail(`Control repetido: ${id}`);
    ids.add(id);
    const kind = oneOf(it.kind, ['slider', 'number', 'select', 'checkbox'], 'kind');
    const base = { id, kind, label: str(it.label, 80, 'label') || id, unit: str(it.unit, 12, 'unit') };
    if (kind === 'select') {
      const options = arr(it.options, 24, 'options', { min: 2 }).map((o, i) => {
        if (typeof o !== 'object') o = { label: String(o), value: i };
        return { label: str(o.label, 60, 'label', { required: true }), value: num(o.value, 'value', { def: i }) };
      });
      const dv = it.value == null ? options[0].value : num(it.value, 'value');
      return { ...base, options, value: options.some(o => o.value === dv) ? dv : options[0].value };
    }
    if (kind === 'checkbox') return { ...base, value: it.value ? 1 : 0 };
    const min = num(it.min, 'min', { def: 0 }),
      max = num(it.max, 'max', { def: 100 });
    if (max <= min) fail(`En "${id}" el máximo debe ser mayor que el mínimo.`);
    const step = num(it.step, 'step', { min: 0.0000001, def: (max - min) / 100 });
    return { ...base, min, max, step, value: Math.min(max, Math.max(min, num(it.value, 'value', { def: min }))) };
  });
  const names = [...ids];
  out.outputs = arr(raw.outputs, LIMITS.outputs, 'outputs').map(o => {
    if (!isObj(o)) fail('Cada resultado debe ser un objeto.');
    const expr = str(o.expr, 400, 'expr', { required: true });
    const err = validateExpr(expr, names);
    if (err) fail(`Fórmula inválida en "${o.label || expr}": ${err}`);
    return {
      label: str(o.label, 80, 'label', { required: true }),
      expr,
      unit: str(o.unit, 12, 'unit'),
      decimals: Math.round(num(o.decimals, 'decimals', { min: 0, max: 8, def: 2 })),
      format: oneOf(o.format, ['number', 'percent', 'currency'], 'format', 'number')
    };
  });
  if (raw.chart != null) {
    if (!isObj(raw.chart)) fail('"chart" debe ser un objeto.');
    const c = chart({ ...raw.chart, data: raw.chart.data });
    // Los valores "=formula" se evalúan en local con los controles actuales.
    for (const row of c.data)
      for (const v of Object.values(row))
        if (typeof v === 'string' && v.startsWith('=')) {
          const err = validateExpr(v.slice(1), names);
          if (err) fail(`Fórmula inválida en el gráfico: ${err}`);
        }
    out.chart = c;
  }
  if (!out.outputs.length && !out.chart) fail('Un widget necesita "outputs" o "chart".');
  return out;
}

export const VALIDATORS = { chart, diagram, svg, icons, image, gallery, cards, compare, progress, stats, math, widget };
// Permite añadir componentes nuevos sin tocar el motor.
export function registerValidator(type, fn) {
  if (!/^[a-z][a-z0-9_-]{1,24}$/.test(type)) throw new Error('Nombre de componente no válido.');
  VALIDATORS[type] = fn;
}

export function validateSpec(raw) {
  try {
    if (!isObj(raw)) fail('La especificación debe ser un objeto JSON.');
    const version = raw.version == null ? 1 : Number(raw.version);
    if (!Number.isInteger(version) || version < 1) fail('"version" no es válida.');
    if (version > SCHEMA_VERSION)
      fail(`Esta especificación usa la versión ${version} y esta app solo entiende hasta la ${SCHEMA_VERSION}.`);
    const type = str(raw.type, 24, 'type', { required: true });
    const fn = VALIDATORS[type];
    if (!fn) fail(`Tipo de componente desconocido: "${type}". Disponibles: ${Object.keys(VALIDATORS).join(', ')}.`);
    const spec = fn(raw);
    spec.version = SCHEMA_VERSION;
    return { ok: true, spec };
  } catch (e) {
    if (e instanceof SchemaError) return { ok: false, error: e.message };
    return { ok: false, error: `Error al validar: ${e?.message || e}` };
  }
}

// Convierte un bloque de código del chat (```lang ... ```) en una especificación validada.
export const RICH_LANGS = ['auric-ui', 'chart', 'mermaid', 'svg', 'math', 'latex', 'widget'];
export function parseFence(lang, body) {
  lang = String(lang || '')
    .trim()
    .toLowerCase();
  body = String(body ?? '');
  if (body.length > LIMITS.rawBytes) return { ok: false, error: 'El bloque es demasiado grande.' };
  if (lang === 'mermaid') return validateSpec({ type: 'diagram', code: body });
  if (lang === 'svg') return validateSpec({ type: 'svg', markup: body });
  if (lang === 'math' || lang === 'latex') return validateSpec({ type: 'math', tex: body.trim() });
  let json;
  try {
    json = JSON.parse(body);
  } catch (e) {
    return { ok: false, error: `JSON mal formado: ${e.message}` };
  }
  if (lang === 'chart') json = { ...json, type: 'chart' };
  else if (lang === 'widget') json = { ...json, type: 'widget' };
  return validateSpec(json);
}
