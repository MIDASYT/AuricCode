// Catálogo de componentes visuales que el agente puede pedir. Se entrega BAJO DEMANDA (herramienta ui_components),
// no en cada prompt, para no inflar el contexto ni perjudicar a los modelos pequeños.
export const UI_CATALOG = [
  {
    type: 'chart',
    fence: 'chart',
    when: 'Datos reales que cambian en el tiempo, comparaciones numéricas o proporciones.',
    summary: 'barras (bar/hbar), líneas, áreas, sectores (pie/donut), dispersión (scatter), histograma'
  },
  {
    type: 'diagram',
    fence: 'mermaid',
    when: 'Arquitectura, flujos, secuencias, clases, estados, Gantt, ER, mapas mentales.',
    summary: 'Código Mermaid en un bloque ```mermaid'
  },
  {
    type: 'svg',
    fence: 'svg',
    when: 'Ilustración o esquema vectorial sencillo. Sin scripts ni recursos externos.',
    summary: 'Un <svg> completo en un bloque ```svg'
  },
  { type: 'math', fence: 'math', when: 'Fórmulas matemáticas (LaTeX).', summary: '```math con LaTeX, o $$ … $$ en líneas propias' },
  {
    type: 'icons',
    fence: 'auric-ui',
    when: 'Mostrar iconos Lucide por nombre (búscalos antes con icon_search).',
    summary: 'Lista de iconos con etiqueta'
  },
  {
    type: 'image',
    fence: 'auric-ui',
    when: 'Mostrar una imagen del proyecto, una https (el usuario pulsa para cargarla) o data:image.',
    summary: 'src, alt, caption'
  },
  { type: 'gallery', fence: 'auric-ui', when: 'Varias imágenes a comparar.', summary: 'images: [{src, alt, caption}]' },
  {
    type: 'cards',
    fence: 'auric-ui',
    when: 'Varias opciones o resúmenes cortos con título, texto, icono y enlace https.',
    summary: 'items: [{title, text, icon, badge, href}]'
  },
  {
    type: 'compare',
    fence: 'auric-ui',
    when: 'Comparar varias opciones; con selectable el usuario elige columnas.',
    summary: 'columns + rows[{label, values}]'
  },
  { type: 'progress', fence: 'auric-ui', when: 'Avance o cuota (valor sobre un máximo).', summary: 'items: [{label, value, max, unit}]' },
  { type: 'stats', fence: 'auric-ui', when: 'Pocas cifras clave destacadas.', summary: 'items: [{label, value, unit, note}]' },
  {
    type: 'widget',
    fence: 'widget',
    when: 'Calculadora o simulador: el usuario mueve controles y los resultados se recalculan en local.',
    summary: 'inputs (slider/number/select/checkbox) + outputs con fórmulas (+ chart opcional)'
  }
];

const DOCS = {
  chart: `Bloque \`\`\`chart con JSON. Campos:
- chartType: bar | hbar | line | area | pie | donut | scatter | histogram
- title, subtitle, source (de dónde salen los datos), unit (p. ej. "ms"), format ("number"|"percent"), xLabel, yLabel
- xKey: columna del eje X (o de las etiquetas en pie/donut)
- series: [{"key":"columna","label":"Nombre","unit":"opcional"}] (pie/donut/histogram usan la primera)
- data: [{"mes":"Ene","ventas":120}, ...] (máx. 5000 filas; solo texto, números o null)
- stacked: true (bar/hbar/area), bins (histogram), filter: {"key":"columna","label":"Periodo"} (añade un selector que filtra filas)
- dataKind: "real" (por defecto) o "example". NUNCA inventes estadísticas: si los datos son ilustrativos pon "example".
Ejemplo: {"chartType":"bar","title":"Tokens por modelo","xKey":"modelo","series":[{"key":"tokens","label":"Tokens"}],"data":[{"modelo":"A","tokens":1200},{"modelo":"B","tokens":800}],"source":"registro de uso"}`,
  diagram:
    'Bloque ```mermaid con código Mermaid estándar (flowchart, sequenceDiagram, classDiagram, stateDiagram-v2, erDiagram, gantt, mindmap, architecture-beta, journey). Si el código tiene errores se muestra el texto original.',
  svg: 'Bloque ```svg con un <svg viewBox="…"> completo. Se permiten formas, texto, degradados y <use href="#id">. Se eliminan scripts, estilos <style>, eventos, imágenes y enlaces externos.',
  math: 'Bloque ```math con LaTeX (KaTeX), o $$ en líneas propias antes y después de la fórmula. Ejemplo: E = mc^2',
  icons:
    'Bloque ```auric-ui con {"type":"icons","items":[{"name":"heart","label":"Favorito"}],"size":24,"strokeWidth":1.75,"tone":"accent|text|muted|success|danger|blue"}. Los nombres son de Lucide (usa icon_search para encontrarlos); si no existe se avisa.',
  image:
    'Bloque ```auric-ui con {"type":"image","src":"assets/logo.png","alt":"…","caption":"…"}. src: ruta RELATIVA del proyecto, https:// (se carga cuando el usuario lo pide) o data:image/png;base64,…',
  gallery: 'Bloque ```auric-ui con {"type":"gallery","images":[{"src":"…","alt":"…","caption":"…"}]} (máx. 24).',
  cards:
    'Bloque ```auric-ui con {"type":"cards","columns":3,"items":[{"title":"…","text":"…","icon":"zap","badge":"Nuevo","href":"https://…"}]}',
  compare:
    'Bloque ```auric-ui con {"type":"compare","selectable":true,"columns":["A","B"],"rows":[{"label":"Precio","values":["$1","$2"]}]}',
  progress: 'Bloque ```auric-ui con {"type":"progress","items":[{"label":"Cuota diaria","value":30,"max":100,"unit":"%"}]}',
  stats: 'Bloque ```auric-ui con {"type":"stats","items":[{"label":"Tests","value":"70","note":"todos pasan"}]}',
  widget: `Bloque \`\`\`widget con JSON. Los cálculos se hacen EN LOCAL (no consultan al modelo ni ejecutan herramientas).
- inputs: [{"id":"horas","kind":"slider|number|select|checkbox","label":"Horas","min":0,"max":24,"step":1,"value":8,"unit":"h"}] (select: "options":[{"label":"Plan A","value":10}])
- outputs: [{"label":"Total","expr":"horas*precio","unit":"USD","decimals":2,"format":"number|percent|currency"}]
- chart (opcional): igual que un gráfico, y los valores de datos pueden ser fórmulas con "=" (p. ej. "=horas*2")
Fórmulas: números, ids de controles, + - * / % ^, comparaciones, && || !, y las funciones min max abs sqrt floor ceil round(x,d) pow log exp clamp(x,a,b) if(c,a,b), constantes pi y e.`
};
const COMMON =
  'Todos los componentes admiten title, subtitle, source y actions: [{"kind":"copy","label":"…","text":"…"} | {"kind":"ask","label":"…","text":"…"} (escribe el texto en el cuadro de mensaje, el usuario decide enviarlo) | {"kind":"open","label":"…","url":"https://…"}]. No existen acciones que ejecuten comandos o modifiquen archivos: para eso usa las herramientas normales.';

export function uiComponentDoc(type) {
  type = String(type || '')
    .trim()
    .toLowerCase();
  if (!type || type === 'all')
    return [
      'Componentes visuales de Auric Code (se dibujan en local, sin gastar tokens). Úsalos solo cuando aporten más que el texto o una tabla Markdown.',
      ...UI_CATALOG.map(
        c => `- ${c.type} (bloque \`\`\`${c.fence}${c.fence === 'auric-ui' ? ` con "type":"${c.type}"` : ''}): ${c.when} → ${c.summary}`
      ),
      '',
      COMMON,
      'Llama a ui_components con {"type":"chart"} (u otro) para ver los campos exactos. Si dudas, responde con texto y tablas Markdown: siempre funcionan.'
    ].join('\n');
  if (!DOCS[type]) return `Tipo desconocido "${type}". Disponibles: ${Object.keys(DOCS).join(', ')}.`;
  return `${DOCS[type]}\n\n${COMMON}`;
}
