// Renderizador de componentes visuales. Construye el DOM con createElement/textContent (nunca innerHTML con datos del modelo),
// salvo SVG propio generado por charts.js, SVG saneado por svg-safe.js, y la salida de Mermaid (securityLevel strict) y KaTeX.
import { parseFence, safeHttpsUrl } from './schema.js';
import { chartSvg, chartCsv, EXPORT_CSS, fmtValue, escXml } from './charts.js';
import { sanitizeSvg } from './svg-safe.js';
import { evaluate } from './expr.js';
import { renderMermaid, renderMath, getLucide, lucideSvgFrom } from './loaders.js';

const SVG_NS = 'http://www.w3.org/2000/svg';
const states = new WeakMap(); // elemento .rich-block → estado (para la delegación de eventos)
const mermaidCache = new Map(),
  mermaidPending = new Map();
export const richErrors = [];
function logError(where, err) {
  richErrors.push({ at: new Date().toISOString(), where, message: String(err?.message || err) });
  if (richErrors.length > 50) richErrors.shift();
  console.warn('[rich]', where, err);
}

function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'text') el.textContent = v;
    else if (k === 'on') for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  for (const kid of kids.flat())
    if (kid != null && kid !== false) el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  return el;
}
// replaceChildren que ignora null/false (si no, el navegador escribiría "null" en pantalla)
const put = (el, ...kids) => el.replaceChildren(...kids.flat().filter(x => x != null && x !== false));
const svgToNode = svgText => {
  const t = document.createElement('template');
  t.innerHTML = svgText;
  return t.content.firstElementChild;
};
const TONE_VAR = {
  text: 'var(--text)',
  muted: 'var(--muted)',
  accent: 'var(--accent)',
  success: 'var(--success)',
  danger: 'var(--danger)',
  blue: 'var(--blue)'
};

// ---------- utilidades de interfaz ----------
function toolbarBtn(act, label, svgInner) {
  return h(
    'button',
    { class: 'rich-btn', type: 'button', 'data-rich-act': act, title: label, 'aria-label': label },
    svgToNode(
      `<svg xmlns="${SVG_NS}" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${svgInner}</svg>`
    ),
    h('span', { text: label })
  );
}
const ICON = {
  copy: '<rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  save: '<path d="M12 15V3"/><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/>',
  expand: '<path d="M15 3h6v6"/><path d="m21 3-7 7"/><path d="m3 21 7-7"/><path d="M9 21H3v-6"/>',
  code: '<path d="m16 18 6-6-6-6"/><path d="m8 6-6 6 6 6"/>',
  table: '<path d="M12 3v18"/><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/>'
};
function shell(spec, { toolbar = [], className = '' } = {}) {
  const head = h(
    'div',
    { class: 'rich-head' },
    h(
      'div',
      { class: 'rich-titles' },
      spec.title ? h('strong', { class: 'rich-title', text: spec.title }) : null,
      spec.subtitle ? h('span', { class: 'rich-sub', text: spec.subtitle }) : null
    ),
    spec.dataKind === 'example' ? h('span', { class: 'rich-badge', text: 'Datos de ejemplo' }) : null,
    toolbar.length ? h('div', { class: 'rich-tools' }, toolbar) : null
  );
  const body = h('div', { class: 'rich-body' });
  const foot = h('div', { class: 'rich-foot' });
  if (spec.source) foot.append(h('span', { class: 'rich-source', text: `Fuente: ${spec.source}` }));
  const actions = renderActions(spec.actions || []);
  if (actions) foot.append(actions);
  const block = h(
    'section',
    { class: `rich-block ${className}`, 'data-rich-type': spec.type },
    spec.title || spec.subtitle || toolbar.length ? head : null,
    body,
    foot.childNodes.length ? foot : null
  );
  states.set(block, { spec });
  return { block, body };
}
function renderActions(actions) {
  if (!actions.length) return null;
  const wrap = h('div', { class: 'rich-actions' });
  actions.forEach((a, i) => {
    if (a.kind === 'blocked')
      wrap.append(
        h('button', {
          class: 'rich-act is-blocked',
          type: 'button',
          disabled: true,
          title: `Acción no permitida ("${a.requested}"): los componentes no pueden ejecutar comandos ni modificar archivos.`,
          text: a.label
        })
      );
    else
      wrap.append(
        h('button', {
          class: 'rich-act',
          type: 'button',
          'data-rich-act': 'action',
          'data-i': i,
          title:
            a.kind === 'ask'
              ? 'Escribe este texto en el cuadro de mensaje (tú decides si enviarlo)'
              : a.kind === 'open'
                ? `Abrir ${new URL(a.url).host}`
                : 'Copiar al portapapeles',
          text: a.label
        })
      );
  });
  return wrap;
}
function legendNode(items) {
  if (!items?.length) return null;
  return h(
    'ul',
    { class: 'rich-legend' },
    items.map(it => h('li', {}, h('i', { class: `rc-sw rc-f${it.cls}` }), h('span', { text: it.label })))
  );
}

// ---------- componentes ----------
function chartBody(spec, state) {
  const wrap = h('div', { class: 'rich-chart-wrap' });
  const draw = data => {
    const s = { ...spec, data };
    const { svg, legend } = chartSvg(s);
    state.svg = svg;
    state.csv = chartCsv(s);
    put(wrap, svgToNode(svg), legendNode(legend));
  };
  if (spec.filter) {
    const key = spec.filter.key,
      values = [...new Set(spec.data.map(r => (r[key] == null ? '' : String(r[key]))))];
    const sel = h(
      'select',
      { class: 'rich-select', 'aria-label': spec.filter.label || key },
      h('option', { value: '', text: 'Todos' }),
      values.map(v => h('option', { value: v, text: v || '(vacío)' }))
    );
    sel.addEventListener('change', () => draw(sel.value === '' ? spec.data : spec.data.filter(r => String(r[key] ?? '') === sel.value)));
    const row = h('label', { class: 'rich-filter' }, h('span', { text: spec.filter.label || key }), sel);
    const box = h('div', {}, row, wrap);
    draw(spec.data);
    return box;
  }
  draw(spec.data);
  return wrap;
}
function chartComponent(spec) {
  const state = { spec };
  const { block, body } = shell(spec, {
    toolbar: [
      toolbarBtn('copy-data', 'Copiar datos', ICON.table),
      toolbarBtn('save-svg', 'SVG', ICON.save),
      toolbarBtn('save-png', 'PNG', ICON.save),
      toolbarBtn('zoom', 'Ampliar', ICON.expand)
    ],
    className: 'rich-chart'
  });
  body.append(chartBody(spec, state));
  states.set(block, state);
  return block;
}

function setDiagramSvg(block, svg) {
  const body = block.querySelector('.rich-body');
  const view = h('div', { class: 'rich-diagram' });
  view.innerHTML = svg; // salida de Mermaid con securityLevel 'strict'
  body.replaceChildren(view);
  const st = states.get(block);
  if (st) st.svg = svg;
}
function diagramFallback(block, code, err) {
  const body = block.querySelector('.rich-body');
  body.replaceChildren(
    h('div', { class: 'rich-note', text: `No se pudo dibujar el diagrama (${err}). Se muestra su definición:` }),
    h('pre', { class: 'rich-code' }, h('code', { text: code }))
  );
}
function diagramComponent(spec) {
  const state = { spec, code: spec.code, svg: '' };
  const { block, body } = shell(spec, {
    toolbar: [
      toolbarBtn('toggle-code', 'Código', ICON.code),
      toolbarBtn('save-svg', 'SVG', ICON.save),
      toolbarBtn('copy-code', 'Copiar', ICON.copy),
      toolbarBtn('zoom', 'Ampliar', ICON.expand)
    ],
    className: 'rich-diagram-block'
  });
  states.set(block, state);
  const hit = mermaidCache.get(spec.code);
  if (hit) setDiagramSvg(block, hit);
  else {
    body.append(h('div', { class: 'rich-loading', text: 'Dibujando diagrama…' }));
    if (!mermaidPending.has(spec.code))
      mermaidPending.set(
        spec.code,
        renderMermaid(spec.code)
          .then(svg => (mermaidCache.set(spec.code, svg), svg))
          .finally(() => mermaidPending.delete(spec.code))
      );
    mermaidPending.get(spec.code).then(
      svg => block.isConnected !== false && setDiagramSvg(block, svg),
      e => {
        logError('mermaid', e);
        diagramFallback(
          block,
          spec.code,
          String(e?.message || e)
            .split('\n')[0]
            .slice(0, 160)
        );
      }
    );
  }
  return block;
}

function svgComponent(spec) {
  const clean = sanitizeSvg(spec.markup);
  if (!clean) throw new Error('SVG no válido o con contenido no permitido');
  const state = { spec, svg: clean, code: spec.markup };
  const { block, body } = shell(spec, {
    toolbar: [
      toolbarBtn('save-svg', 'SVG', ICON.save),
      toolbarBtn('copy-code', 'Copiar', ICON.copy),
      toolbarBtn('zoom', 'Ampliar', ICON.expand)
    ],
    className: 'rich-svg'
  });
  const view = h('div', { class: 'rich-svgview' });
  view.append(svgToNode(clean));
  body.append(view);
  states.set(block, state);
  return block;
}

function mathComponent(spec) {
  const { block, body } = shell(spec, { className: 'rich-math' });
  const view = h('div', { class: 'rich-mathview' }, h('span', { class: 'rich-loading', text: 'Calculando fórmula…' }));
  body.append(view);
  renderMath(spec.tex, spec.display).then(
    html => (view.innerHTML = html), // KaTeX con trust:false
    e => {
      logError('katex', e);
      view.replaceChildren(
        h('div', { class: 'rich-note', text: 'Fórmula no válida. Texto original:' }),
        h('pre', { class: 'rich-code' }, h('code', { text: spec.tex }))
      );
    }
  );
  return block;
}

function iconsComponent(spec) {
  const { block, body } = shell(spec, { className: 'rich-icons' });
  const row = h('div', { class: 'rich-icon-row' });
  body.append(row);
  getLucide().then(
    lib => {
      for (const it of spec.items) {
        const svg = lucideSvgFrom(lib, it.name, {
          size: spec.size,
          stroke: spec.strokeWidth,
          color: TONE_VAR[spec.tone],
          label: it.label || it.name
        });
        row.append(
          h(
            'figure',
            { class: 'rich-icon' + (svg ? '' : ' is-missing') },
            svg ? svgToNode(svg) : h('span', { class: 'rich-missing', text: '?' }),
            h('figcaption', { text: svg ? it.label || it.name : `${it.name} (no existe)` })
          )
        );
      }
    },
    e => {
      logError('lucide', e);
      row.append(h('div', { class: 'rich-note', text: 'No se pudo cargar la biblioteca de iconos.' }));
    }
  );
  return block;
}

function imageFigure(im, ctx) {
  const fig = h('figure', { class: 'rich-fig' });
  const fail = msg =>
    put(fig, h('div', { class: 'rich-img-missing', text: msg }), im.caption ? h('figcaption', { text: im.caption }) : null);
  const show = url => {
    const img = h('img', { src: url, alt: im.alt || '', loading: 'lazy', referrerpolicy: 'no-referrer', 'data-rich-act': 'zoom-img' });
    img.addEventListener('error', () => fail(`No se pudo cargar la imagen${im.src.kind === 'project' ? ` "${im.src.value}"` : ''}.`));
    put(fig, img, im.caption ? h('figcaption', { text: im.caption }) : null);
  };
  if (im.src.kind === 'data') show(im.src.value);
  else if (im.src.kind === 'remote') {
    const host = new URL(im.src.value).host;
    fig.append(
      h('button', {
        class: 'rich-load-img',
        type: 'button',
        on: { click: () => show(im.src.value) },
        text: `Cargar imagen de ${host}`,
        title: 'Las imágenes externas solo se cargan cuando tú lo pides'
      }),
      im.caption ? h('figcaption', { text: im.caption }) : null
    );
  } else {
    fig.append(h('div', { class: 'rich-loading', text: 'Cargando imagen…' }));
    Promise.resolve(ctx.readProjectImage?.(im.src.value)).then(
      url => (url ? show(url) : fail(`Imagen no encontrada en el proyecto: ${im.src.value}`)),
      () => fail(`No se pudo leer la imagen: ${im.src.value}`)
    );
  }
  return fig;
}
function imageComponent(spec, ctx) {
  const { block, body } = shell(spec, { className: 'rich-image' });
  body.append(imageFigure({ src: spec.src, alt: spec.alt, caption: spec.caption }, ctx));
  return block;
}
function galleryComponent(spec, ctx) {
  const { block, body } = shell(spec, { className: 'rich-gallery' });
  body.append(
    h(
      'div',
      { class: 'rich-grid-gallery' },
      spec.images.map(im => imageFigure(im, ctx))
    )
  );
  return block;
}

function cardsComponent(spec) {
  const { block, body } = shell(spec, { className: 'rich-cards' });
  const grid = h('div', { class: 'rich-cardgrid', style: `--cols:${spec.columns}` });
  body.append(grid);
  const cardEls = spec.items.map(it => {
    const card = h(
      it.href ? 'a' : 'div',
      { class: 'rich-card', href: it.href || null, target: it.href ? '_blank' : null, rel: it.href ? 'noreferrer' : null },
      h(
        'div',
        { class: 'rich-card-top' },
        it.icon ? h('span', { class: 'rich-card-ic', 'data-icon': it.icon }) : null,
        h('strong', { text: it.title }),
        it.badge ? h('span', { class: 'rich-badge', text: it.badge }) : null
      ),
      it.text ? h('p', { text: it.text }) : null
    );
    grid.append(card);
    return card;
  });
  if (spec.items.some(i => i.icon))
    getLucide()
      .then(lib => {
        cardEls.forEach((c, i) => {
          const slot = c.querySelector('.rich-card-ic');
          const svg = slot && lucideSvgFrom(lib, spec.items[i].icon, { size: 18, color: 'var(--accent)' });
          if (svg) slot.append(svgToNode(svg));
          else slot?.remove();
        });
      })
      .catch(e => logError('lucide', e));
  return block;
}

function compareComponent(spec) {
  const { block, body } = shell(spec, { className: 'rich-compare' });
  const visible = new Set(spec.columns.map((_, i) => i));
  const wrap = h('div', { class: 'md-table-wrap' });
  const draw = () => {
    const cols = [...visible].sort((a, b) => a - b);
    wrap.replaceChildren(
      h(
        'table',
        {},
        h(
          'thead',
          {},
          h(
            'tr',
            {},
            h('th', { text: '' }),
            cols.map(i => h('th', { text: spec.columns[i] }))
          )
        ),
        h(
          'tbody',
          {},
          spec.rows.map(r =>
            h(
              'tr',
              {},
              h('th', { scope: 'row', text: r.label }),
              cols.map(i => h('td', { text: r.values[i] }))
            )
          )
        )
      )
    );
  };
  if (spec.selectable)
    body.append(
      h(
        'div',
        { class: 'rich-chips', role: 'group', 'aria-label': 'Elegir qué columnas comparar' },
        spec.columns.map((c, i) => {
          const cb = h('input', { type: 'checkbox', checked: true });
          cb.addEventListener('change', () => {
            if (cb.checked) visible.add(i);
            else if (visible.size > 1) visible.delete(i);
            else cb.checked = true;
            draw();
          });
          return h('label', { class: 'rich-chip' }, cb, h('span', { text: c }));
        })
      )
    );
  draw();
  body.append(wrap);
  return block;
}

function progressComponent(spec) {
  const { block, body } = shell(spec, { className: 'rich-progress' });
  for (const it of spec.items) {
    const pct = Math.round((it.value / it.max) * 1000) / 10;
    body.append(
      h(
        'div',
        { class: 'rich-prog' },
        h(
          'div',
          { class: 'rich-prog-top' },
          h('span', { text: it.label }),
          h('span', {
            class: 'rich-prog-val',
            text: `${fmtValue(it.value, { unit: it.unit })}${it.max !== 100 || it.unit ? ` / ${fmtValue(it.max, { unit: it.unit })}` : ''} · ${pct}%`
          })
        ),
        h(
          'div',
          {
            class: 'rich-bar',
            role: 'progressbar',
            'aria-valuenow': it.value,
            'aria-valuemin': 0,
            'aria-valuemax': it.max,
            'aria-label': it.label
          },
          h('i', { style: `width:${Math.min(100, pct)}%` })
        )
      )
    );
  }
  return block;
}
function statsComponent(spec) {
  const { block, body } = shell(spec, { className: 'rich-stats' });
  body.append(
    h(
      'div',
      { class: 'rich-statgrid' },
      spec.items.map(it =>
        h(
          'div',
          { class: 'rich-stat' },
          h('span', { class: 'rich-stat-l', text: it.label }),
          h('strong', { class: 'rich-stat-v' }, it.value, it.unit ? h('small', { text: ` ${it.unit}` }) : null),
          it.note ? h('span', { class: 'rich-stat-n', text: it.note }) : null
        )
      )
    )
  );
  return block;
}

// Widget interactivo LOCAL: controles → fórmulas seguras → resultados/gráfico. No consulta al modelo ni ejecuta herramientas.
function fmtOut(v, o) {
  if (!Number.isFinite(v)) return '—';
  const s = new Intl.NumberFormat('es', { minimumFractionDigits: 0, maximumFractionDigits: o.decimals }).format(v);
  return o.format === 'percent' ? `${s}%` : o.unit ? `${s} ${o.unit}` : s;
}
function widgetComponent(spec) {
  const { block, body } = shell(spec, {
    className: 'rich-widget',
    toolbar: spec.chart
      ? [
          toolbarBtn('copy-data', 'Copiar datos', ICON.table),
          toolbarBtn('save-png', 'PNG', ICON.save),
          toolbarBtn('zoom', 'Ampliar', ICON.expand)
        ]
      : []
  });
  const vals = Object.fromEntries(spec.inputs.map(i => [i.id, i.value]));
  const controls = h('div', { class: 'rich-controls' });
  const results = h('div', { class: 'rich-results', 'aria-live': 'polite' });
  const chartHost = h('div', { class: 'rich-widget-chart' });
  const chartState = { spec };
  let raf = 0;
  const compute = () => {
    results.replaceChildren(
      ...spec.outputs.map(o => {
        let text;
        try {
          text = fmtOut(evaluate(o.expr, vals), o);
        } catch {
          text = '—';
        }
        return h(
          'div',
          { class: 'rich-stat' },
          h('span', { class: 'rich-stat-l', text: o.label }),
          h('strong', { class: 'rich-stat-v', text })
        );
      })
    );
    if (spec.chart) {
      const data = spec.chart.data.map(row => {
        const r = {};
        for (const [k, v] of Object.entries(row)) {
          if (typeof v === 'string' && v.startsWith('=')) {
            try {
              r[k] = evaluate(v.slice(1), vals);
            } catch {
              r[k] = null;
            }
          } else r[k] = v;
        }
        return r;
      });
      const s = { ...spec.chart, data };
      const { svg, legend } = chartSvg(s);
      chartState.svg = svg;
      chartState.csv = chartCsv(s);
      put(chartHost, svgToNode(svg), legendNode(legend));
    }
  };
  const schedule = () => {
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(compute);
  };
  for (const inp of spec.inputs) {
    let ctl,
      readout = null;
    if (inp.kind === 'slider' || inp.kind === 'number') {
      ctl = h('input', {
        type: inp.kind === 'slider' ? 'range' : 'number',
        min: inp.min,
        max: inp.max,
        step: inp.step,
        value: inp.value,
        'aria-label': inp.label
      });
      if (inp.kind === 'slider') readout = h('output', { text: `${inp.value}${inp.unit ? ' ' + inp.unit : ''}` });
      ctl.addEventListener('input', () => {
        const n = Math.min(inp.max, Math.max(inp.min, Number(ctl.value)));
        if (Number.isFinite(n)) vals[inp.id] = n;
        if (readout) readout.textContent = `${vals[inp.id]}${inp.unit ? ' ' + inp.unit : ''}`;
        schedule();
      });
    } else if (inp.kind === 'select') {
      ctl = h(
        'select',
        { class: 'rich-select', 'aria-label': inp.label },
        inp.options.map((o, i) => h('option', { value: o.value, selected: o.value === inp.value, text: o.label }))
      );
      ctl.addEventListener('change', () => {
        vals[inp.id] = Number(ctl.value);
        schedule();
      });
    } else {
      ctl = h('input', { type: 'checkbox', checked: !!inp.value, 'aria-label': inp.label });
      ctl.addEventListener('change', () => {
        vals[inp.id] = ctl.checked ? 1 : 0;
        schedule();
      });
    }
    controls.append(h('label', { class: 'rich-control' }, h('span', { class: 'rich-control-l', text: inp.label }), ctl, readout));
  }
  compute();
  body.append(controls, results, spec.chart ? chartHost : null);
  states.set(block, chartState);
  return block;
}

export const COMPONENTS = {
  chart: chartComponent,
  diagram: diagramComponent,
  svg: svgComponent,
  math: mathComponent,
  icons: iconsComponent,
  image: imageComponent,
  gallery: galleryComponent,
  cards: cardsComponent,
  compare: compareComponent,
  progress: progressComponent,
  stats: statsComponent,
  widget: widgetComponent
};
export function registerComponent(type, fn) {
  COMPONENTS[type] = fn;
}

// ---------- API pública ----------
export function fallbackNode(reason, lang, src) {
  return h(
    'section',
    { class: 'rich-block rich-fallback' },
    h('div', { class: 'rich-note', text: `No se pudo mostrar este componente: ${reason}` }),
    h(
      'details',
      {},
      h('summary', { text: 'Ver contenido original' }),
      h('pre', { class: 'rich-code' }, h('code', { text: String(src ?? '') }))
    )
  );
}
export function buildRich(lang, src, ctx = {}) {
  const parsed = parseFence(lang, src);
  if (!parsed.ok) {
    logError(`validate:${lang}`, parsed.error);
    return fallbackNode(parsed.error, lang, src);
  }
  try {
    const fn = COMPONENTS[parsed.spec.type];
    if (!fn) throw new Error(`Sin renderizador para "${parsed.spec.type}"`);
    return fn(parsed.spec, ctx);
  } catch (e) {
    logError(`render:${lang}`, e);
    return fallbackNode(String(e?.message || e), lang, src);
  }
}
export function hydrateRich(root, ctx) {
  const slots = root.querySelectorAll ? root.querySelectorAll('.rich-slot:not([data-done])') : [];
  for (const slot of slots) {
    slot.dataset.done = '1';
    const node = buildRich(slot.dataset.lang, slot.dataset.src, ctx);
    slot.replaceChildren(node);
  }
}

// ---------- ampliar / exportar / acciones (delegación de eventos) ----------
function openZoom(inner) {
  const overlay = h('div', { class: 'rich-zoom', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Vista ampliada' });
  const stage = h('div', { class: 'rich-zoom-stage' });
  stage.append(inner);
  let scale = 1,
    x = 0,
    y = 0,
    drag = null;
  const apply = () => (stage.style.transform = `translate(${x}px,${y}px) scale(${scale})`);
  const close = () => {
    overlay.remove();
    document.removeEventListener('keydown', onKey, true);
  };
  const onKey = e => {
    if (e.key === 'Escape') {
      e.stopPropagation();
      close();
    }
  };
  const btn = (t, fn, label) =>
    h('button', { type: 'button', class: 'rich-btn', title: label, 'aria-label': label, text: t, on: { click: fn } });
  overlay.append(
    h(
      'div',
      { class: 'rich-zoom-bar' },
      btn('+', () => ((scale = Math.min(8, scale * 1.25)), apply()), 'Acercar'),
      btn('−', () => ((scale = Math.max(0.2, scale / 1.25)), apply()), 'Alejar'),
      btn('Restablecer', () => ((scale = 1), (x = y = 0), apply()), 'Restablecer vista'),
      btn('Cerrar', close, 'Cerrar')
    ),
    stage
  );
  overlay.addEventListener(
    'wheel',
    e => {
      e.preventDefault();
      scale = Math.min(8, Math.max(0.2, scale * (e.deltaY < 0 ? 1.12 : 1 / 1.12)));
      apply();
    },
    { passive: false }
  );
  overlay.addEventListener('pointerdown', e => {
    if (e.target.closest('.rich-zoom-bar')) return;
    drag = { sx: e.clientX - x, sy: e.clientY - y };
    overlay.setPointerCapture(e.pointerId);
  });
  overlay.addEventListener('pointermove', e => drag && ((x = e.clientX - drag.sx), (y = e.clientY - drag.sy), apply()));
  overlay.addEventListener('pointerup', () => (drag = null));
  document.addEventListener('keydown', onKey, true);
  document.body.append(overlay);
  overlay.querySelector('button')?.focus();
}
function exportableSvg(svgText) {
  const css = getComputedStyle(document.documentElement);
  let out = svgText;
  const colors = Array.from({ length: 8 }, (_, i) => css.getPropertyValue(`--rc-${i + 1}`).trim() || '#d9ad3c');
  const style = `<style>${EXPORT_CSS}${colors.map((c, i) => `.rc-f${i + 1}{fill:${c}}.rc-k${i + 1}{stroke:${c}}`).join('')}</style>`;
  return out.replace(/(<svg[^>]*>)/, `$1${style}`);
}
async function svgToPngBase64(svgText) {
  const svg = exportableSvg(svgText);
  const m = /viewBox="0 0 (\d+) (\d+)"/.exec(svg);
  const w = m ? Number(m[1]) : 640,
    hh = m ? Number(m[2]) : 320,
    scale = 2;
  const img = new Image();
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg.replace('<svg', `<svg width="${w}" height="${hh}"`));
  await img.decode();
  const c = document.createElement('canvas');
  c.width = w * scale;
  c.height = hh * scale;
  const g = c.getContext('2d');
  g.fillStyle = document.documentElement.dataset.theme === 'light' ? '#ffffff' : '#0e1219';
  g.fillRect(0, 0, c.width, c.height);
  g.drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL('image/png').split(',')[1];
}
export function installRichEvents(ctx) {
  document.addEventListener('click', async e => {
    const el = e.target.closest?.('[data-rich-act]');
    if (!el) return;
    const block = el.closest('.rich-block');
    const act = el.dataset.richAct;
    if (act === 'zoom-img')
      return openZoom(h('img', { src: el.getAttribute('src'), alt: el.getAttribute('alt') || '', class: 'rich-zoom-img' }));
    const st = block && states.get(block);
    if (!st) return;
    try {
      if (act === 'copy-data') return ctx.copy(st.csv || '', 'Datos copiados (CSV)');
      if (act === 'copy-code') return ctx.copy(st.code || '', 'Código copiado');
      if (act === 'toggle-code') {
        const body = block.querySelector('.rich-body');
        const pre = body.querySelector('.rich-code');
        if (pre) pre.remove();
        else body.append(h('pre', { class: 'rich-code' }, h('code', { text: st.code || '' })));
        return;
      }
      if (act === 'zoom') {
        const node = block.querySelector('.rich-chart-wrap svg, .rich-widget-chart svg, .rich-diagram svg, .rich-svgview svg');
        if (node) openZoom(node.cloneNode(true));
        return;
      }
      if (act === 'save-svg' && st.svg)
        return ctx.saveFile('grafico.svg', btoa(unescape(encodeURIComponent(exportableSvg(st.svg)))), 'SVG');
      if (act === 'save-png' && st.svg) return ctx.saveFile('grafico.png', await svgToPngBase64(st.svg), 'PNG');
      if (act === 'action') {
        const a = (st.spec.actions || [])[Number(el.dataset.i)];
        if (!a) return;
        if (a.kind === 'copy') return ctx.copy(a.text, 'Copiado');
        if (a.kind === 'ask') return ctx.ask(a.text);
        if (a.kind === 'open') return ctx.openUrl(a.url);
      }
    } catch (err) {
      logError(`action:${act}`, err);
      ctx.toast?.('No se pudo completar la acción', String(err?.message || err));
    }
  });
}
