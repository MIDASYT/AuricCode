// Carga diferida de las librerías locales (Mermaid, KaTeX, Lucide). Todo vive dentro de la app: funciona sin conexión.
const scripts = new Map();
export function loadScriptOnce(src) {
  if (!scripts.has(src))
    scripts.set(
      src,
      new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = src;
        s.async = true;
        s.onload = () => resolve();
        s.onerror = () => {
          scripts.delete(src);
          reject(new Error(`No se pudo cargar ${src}`));
        };
        document.head.appendChild(s);
      })
    );
  return scripts.get(src);
}
function loadCssOnce(href) {
  if (document.querySelector(`link[data-rich-css="${href}"]`)) return;
  const l = document.createElement('link');
  l.rel = 'stylesheet';
  l.href = href;
  l.dataset.richCss = href;
  document.head.appendChild(l);
}

// ---------- Mermaid ----------
let mermaidReady = null,
  mermaidTheme = '';
const isDark = () => document.documentElement.dataset.theme !== 'light';
export async function getMermaid() {
  await loadScriptOnce('./vendor/mermaid.min.js');
  const dark = isDark(),
    key = dark ? 'dark' : 'light';
  if (!mermaidReady || mermaidTheme !== key) {
    mermaidTheme = key;
    window.mermaid.initialize({
      startOnLoad: false,
      securityLevel: 'strict',
      theme: 'base',
      fontFamily: "'Segoe UI Variable Text','Segoe UI',system-ui,sans-serif",
      themeVariables: dark
        ? {
            background: 'transparent',
            primaryColor: '#151c28',
            primaryTextColor: '#edf2f8',
            primaryBorderColor: '#d9ad3c',
            lineColor: '#8a97aa',
            secondaryColor: '#111722',
            tertiaryColor: '#0e1219',
            noteBkgColor: '#151c28',
            noteTextColor: '#edf2f8',
            textColor: '#edf2f8',
            mainBkg: '#151c28',
            clusterBkg: '#0e1219',
            edgeLabelBackground: '#0e1219'
          }
        : {
            background: 'transparent',
            primaryColor: '#f8fafc',
            primaryTextColor: '#17202c',
            primaryBorderColor: '#b98a14',
            lineColor: '#69778a',
            secondaryColor: '#f1f4f8',
            tertiaryColor: '#fff',
            noteBkgColor: '#fff8e1',
            noteTextColor: '#17202c',
            textColor: '#17202c',
            mainBkg: '#f8fafc',
            clusterBkg: '#fff',
            edgeLabelBackground: '#fff'
          }
    });
    mermaidReady = true;
  }
  return window.mermaid;
}
let mermaidSeq = 0;
export async function renderMermaid(code) {
  const m = await getMermaid();
  const id = `auric-mmd-${Date.now().toString(36)}-${++mermaidSeq}`;
  try {
    await m.parse(code);
    const { svg } = await m.render(id, code);
    return svg;
  } finally {
    document.getElementById(id)?.remove();
    document.getElementById('d' + id)?.remove();
  }
}

// ---------- KaTeX ----------
export async function renderMath(tex, display = true) {
  loadCssOnce('./vendor/katex/katex.min.css');
  await loadScriptOnce('./vendor/katex/katex.min.js');
  return window.katex.renderToString(tex, {
    displayMode: display,
    throwOnError: true,
    trust: false,
    strict: 'ignore',
    maxSize: 20,
    maxExpand: 1000,
    output: 'html'
  });
}

// ---------- Lucide ----------
let lucidePromise = null;
export function getLucide() {
  if (!lucidePromise)
    lucidePromise = fetch('./vendor/lucide.json')
      .then(r => {
        if (!r.ok) throw new Error('lucide.json');
        return r.json();
      })
      .catch(e => {
        lucidePromise = null;
        throw e;
      });
  return lucidePromise;
}
export function lucideSvgFrom(lib, name, { size = 24, stroke = 1.75, color = 'currentColor', label = '' } = {}) {
  const ic = Object.prototype.hasOwnProperty.call(lib, name) ? lib[name] : null;
  if (!ic) return null;
  const a11y = label ? `role="img" aria-label="${String(label).replace(/[&<>"]/g, '')}"` : 'aria-hidden="true"';
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round" ${a11y}>${ic.b}</svg>`;
}
export function searchLucide(lib, query, limit = 20) {
  const terms = String(query || '')
    .toLowerCase()
    .split(/[\s,]+/)
    .filter(Boolean);
  if (!terms.length) return [];
  const scored = [];
  for (const [name, v] of Object.entries(lib)) {
    let score = 0;
    for (const t of terms) {
      if (name === t) score += 10;
      else if (name.startsWith(t)) score += 6;
      else if (name.includes(t)) score += 4;
      if (v.t.some(x => x === t)) score += 3;
      else if (v.t.some(x => x.includes(t))) score += 1;
    }
    if (score) scored.push([score, name]);
  }
  return scored
    .sort((a, b) => b[0] - a[0] || a[1].localeCompare(b[1]))
    .slice(0, Math.max(1, Math.min(50, limit)))
    .map(x => x[1]);
}
