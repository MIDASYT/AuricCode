// Sanea un SVG que viene del modelo: solo elementos y atributos de una lista blanca; sin scripts, sin eventos, sin recursos externos.
const ELEMENTS = new Set([
  'svg',
  'g',
  'path',
  'circle',
  'ellipse',
  'rect',
  'line',
  'polyline',
  'polygon',
  'text',
  'tspan',
  'defs',
  'lineargradient',
  'radialgradient',
  'stop',
  'clippath',
  'mask',
  'title',
  'desc',
  'use',
  'symbol',
  'marker',
  'pattern'
]);
const ATTRS = new Set([
  'viewbox',
  'width',
  'height',
  'x',
  'y',
  'x1',
  'x2',
  'y1',
  'y2',
  'cx',
  'cy',
  'r',
  'rx',
  'ry',
  'd',
  'points',
  'transform',
  'fill',
  'fill-opacity',
  'fill-rule',
  'clip-rule',
  'stroke',
  'stroke-width',
  'stroke-opacity',
  'stroke-linecap',
  'stroke-linejoin',
  'stroke-dasharray',
  'stroke-dashoffset',
  'stroke-miterlimit',
  'opacity',
  'offset',
  'stop-color',
  'stop-opacity',
  'gradientunits',
  'gradienttransform',
  'patternunits',
  'patterntransform',
  'clip-path',
  'mask',
  'id',
  'class',
  'font-family',
  'font-size',
  'font-weight',
  'font-style',
  'text-anchor',
  'dominant-baseline',
  'dx',
  'dy',
  'preserveaspectratio',
  'xmlns',
  'role',
  'aria-label',
  'aria-hidden',
  'marker-start',
  'marker-mid',
  'marker-end',
  'markerwidth',
  'markerheight',
  'refx',
  'refy',
  'orient',
  'fx',
  'fy',
  'spreadmethod',
  'letter-spacing',
  'style',
  'href',
  'xlink:href'
]);
const MAX_NODES = 3000;

function safeValue(name, value) {
  const v = String(value);
  if (/javascript:|expression\(|@import|<\s*script/i.test(v)) return null;
  // url(...) solo hacia referencias internas (#id)
  const urls = [...v.matchAll(/url\(\s*(['"]?)([^)'"]*)\1\s*\)/gi)];
  if (urls.some(u => !u[2].startsWith('#'))) return null;
  if (name === 'href' || name === 'xlink:href') return v.startsWith('#') ? v : null;
  return v;
}

// Devuelve un SVG saneado (texto) o null si no es un SVG válido. Requiere DOMParser (entorno de navegador).
export function sanitizeSvg(src, parser = new DOMParser()) {
  src = String(src || '').trim();
  if (!src || src.length > 200_000) return null;
  const doc = parser.parseFromString(src, 'image/svg+xml');
  const root = doc.documentElement;
  if (!root || root.nodeName.toLowerCase() !== 'svg' || doc.querySelector('parsererror')) return null;
  let count = 0;
  const out = [];
  const walk = el => {
    if (++count > MAX_NODES) throw new Error('SVG demasiado complejo');
    const tag = el.localName.toLowerCase();
    if (!ELEMENTS.has(tag)) return '';
    let attrs = '';
    for (const a of [...el.attributes]) {
      const n = a.name.toLowerCase();
      if (n.startsWith('on') || !ATTRS.has(n)) continue;
      const v = safeValue(n, a.value);
      if (v == null) continue;
      attrs += ` ${a.name}="${v.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;')}"`;
    }
    if (tag === 'use' && !/href=/.test(attrs)) return '';
    let inner = '';
    for (const c of el.childNodes) {
      if (c.nodeType === 1) inner += walk(c);
      else if (c.nodeType === 3 && ['text', 'tspan', 'title', 'desc'].includes(tag))
        inner += c.nodeValue.replace(/&/g, '&amp;').replace(/</g, '&lt;');
    }
    return `<${el.localName}${attrs}>${inner}</${el.localName}>`;
  };
  try {
    let svg = walk(root);
    if (!/xmlns=/.test(svg.slice(0, 200))) svg = svg.replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg"');
    return svg;
  } catch {
    return null;
  }
}
