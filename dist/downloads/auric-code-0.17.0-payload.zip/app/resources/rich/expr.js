// Evaluador de fórmulas seguro para los widgets interactivos: solo números, variables, operadores y funciones de una lista blanca.
// No usa eval ni Function; no permite acceso a propiedades ni a objetos globales.
const MAX_LEN = 400;
const FN = {
  min: Math.min,
  max: Math.max,
  abs: Math.abs,
  sqrt: Math.sqrt,
  floor: Math.floor,
  ceil: Math.ceil,
  exp: Math.exp,
  log: Math.log,
  log10: Math.log10,
  log2: Math.log2,
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  pow: Math.pow,
  round: (x, d = 0) => {
    const k = 10 ** Math.max(0, Math.min(10, Number(d) || 0));
    return Math.round(x * k) / k;
  },
  clamp: (x, a, b) => Math.min(Math.max(x, a), b),
  if: (c, a, b) => (c ? a : b)
};
const CONST = { pi: Math.PI, e: Math.E };

function tokenize(src) {
  const out = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (/\s/.test(c)) {
      i++;
      continue;
    }
    let m;
    if ((m = /^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(src.slice(i)))) {
      out.push({ t: 'num', v: Number(m[0]) });
      i += m[0].length;
    } else if ((m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(src.slice(i)))) {
      out.push({ t: 'id', v: m[0] });
      i += m[0].length;
    } else if ((m = /^(<=|>=|==|!=|&&|\|\||[-+*/%^()<>!,])/.exec(src.slice(i)))) {
      out.push({ t: 'op', v: m[0] });
      i += m[0].length;
    } else throw new Error(`Carácter no permitido en la fórmula: "${c}"`);
  }
  return out;
}

export function evaluate(src, vars = {}) {
  src = String(src ?? '');
  if (src.length > MAX_LEN) throw new Error('Fórmula demasiado larga.');
  const toks = tokenize(src);
  let p = 0,
    depth = 0,
    steps = 0;
  const peek = () => toks[p],
    next = () => toks[p++],
    isOp = v => peek()?.t === 'op' && peek().v === v;
  const tick = () => {
    if (++steps > 2000) throw new Error('Fórmula demasiado compleja.');
  };
  function parseOr() {
    let l = parseAnd();
    while (isOp('||')) {
      next();
      const r = parseAnd();
      l = l || r ? 1 : 0;
    }
    return l;
  }
  function parseAnd() {
    let l = parseCmp();
    while (isOp('&&')) {
      next();
      const r = parseCmp();
      l = l && r ? 1 : 0;
    }
    return l;
  }
  function parseCmp() {
    let l = parseAdd();
    while (peek()?.t === 'op' && ['<', '>', '<=', '>=', '==', '!='].includes(peek().v)) {
      const op = next().v,
        r = parseAdd();
      l = { '<': l < r, '>': l > r, '<=': l <= r, '>=': l >= r, '==': l === r, '!=': l !== r }[op] ? 1 : 0;
    }
    return l;
  }
  function parseAdd() {
    let l = parseMul();
    while (isOp('+') || isOp('-')) {
      const op = next().v,
        r = parseMul();
      l = op === '+' ? l + r : l - r;
    }
    return l;
  }
  function parseMul() {
    let l = parseUnary();
    while (isOp('*') || isOp('/') || isOp('%')) {
      const op = next().v,
        r = parseUnary();
      l = op === '*' ? l * r : op === '/' ? l / r : l % r;
    }
    return l;
  }
  function parseUnary() {
    tick();
    if (isOp('-')) {
      next();
      return -parseUnary();
    }
    if (isOp('+')) {
      next();
      return parseUnary();
    }
    if (isOp('!')) {
      next();
      return parseUnary() ? 0 : 1;
    }
    return parsePow();
  }
  function parsePow() {
    const base = parsePrimary();
    if (isOp('^')) {
      next();
      return Math.pow(base, parseUnary());
    }
    return base;
  }
  function parsePrimary() {
    tick();
    const t = next();
    if (!t) throw new Error('Fórmula incompleta.');
    if (t.t === 'num') return t.v;
    if (t.t === 'op' && t.v === '(') {
      if (++depth > 40) throw new Error('Demasiados paréntesis anidados.');
      const v = parseOr();
      if (!isOp(')')) throw new Error('Falta cerrar un paréntesis.');
      next();
      depth--;
      return v;
    }
    if (t.t === 'id') {
      if (isOp('(')) {
        if (!Object.prototype.hasOwnProperty.call(FN, t.v)) throw new Error(`Función no permitida: ${t.v}`);
        next();
        const args = [];
        if (!isOp(')')) {
          do args.push(parseOr());
          while (isOp(',') && next());
        }
        if (!isOp(')')) throw new Error('Falta cerrar una función.');
        next();
        return FN[t.v](...args);
      }
      if (Object.prototype.hasOwnProperty.call(vars, t.v)) return Number(vars[t.v]);
      if (Object.prototype.hasOwnProperty.call(CONST, t.v)) return CONST[t.v];
      throw new Error(`Variable desconocida: ${t.v}`);
    }
    throw new Error(`Símbolo inesperado: ${t.v}`);
  }
  const v = parseOr();
  if (p < toks.length) throw new Error(`Símbolo inesperado: ${toks[p].v}`);
  if (typeof v !== 'number' || Number.isNaN(v)) throw new Error('La fórmula no produjo un número.');
  return v;
}

export function validateExpr(src, names = []) {
  try {
    const vars = Object.fromEntries(names.map(n => [n, 1]));
    evaluate(src, vars);
    return null;
  } catch (e) {
    return e.message;
  }
}
