// Resaltado de sintaxis ligero y local (sin dependencias). Devuelve HTML ya escapado.
// Seguro para streaming: solo transforma texto; si algo no se reconoce, queda como texto normal.
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const MAX_CHARS = 30000;

const kw = s => new Set(s.split(/\s+/).filter(Boolean));
const JS = kw(
  'async await break case catch class const continue debugger default delete do else export extends finally for from function if import in instanceof let new of return static super switch this throw try typeof var void while with yield as interface type enum implements public private protected readonly abstract declare namespace'
);
const PY = kw(
  'and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case self'
);
const GO = kw(
  'break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var'
);
const RUST = kw(
  'as async await break const continue crate dyn else enum extern fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait type unsafe use where while'
);
const CLIKE = kw(
  'abstract auto bool break case catch char class const constexpr continue default delete do double else enum explicit extern final finally float for foreach goto if implements import inline int interface internal long namespace new null operator override package private protected public readonly ref return sealed short signed sizeof static string struct switch template this throw try typedef typeof union unsigned using var virtual void volatile while record'
);
const GD = kw(
  'and as assert await break breakpoint class class_name const continue elif else enum export extends for func if in is match not onready or pass preload return setget signal static super var while yield await @export @onready'
);
const SH = kw(
  'if then else elif fi for while do done case esac function in return export local echo cd ls cat rm cp mv mkdir sudo npm npx node git pip python go cargo'
);
const SQL = kw(
  'select from where insert into values update set delete create table drop alter add join left right inner outer on group by order having limit offset as and or not null is in like distinct union all primary key foreign references index'
);
const LITERALS = kw('true false null undefined None True False nil NaN Infinity');

const LANGS = {
  js: { kw: JS, line: '//', block: true, str: '\'"`' },
  py: { kw: PY, line: '#', str: '\'"', triple: true },
  go: { kw: GO, line: '//', block: true, str: '\'"`' },
  rust: { kw: RUST, line: '//', block: true, str: '"\'' },
  c: { kw: CLIKE, line: '//', block: true, str: '\'"' },
  gd: { kw: GD, line: '#', str: '\'"' },
  sh: { kw: SH, line: '#', str: '\'"' },
  sql: { kw: SQL, line: '--', block: true, str: '\'"', ci: true },
  json: { kw: new Set(), line: null, str: '"' },
  css: { kw: new Set(), line: null, block: true, str: '\'"', css: true },
  html: { kw: new Set(), line: null, str: '\'"', markup: true }
};
const ALIAS = {
  js: 'js',
  go: 'go',
  rust: 'rust',
  gd: 'gd',
  javascript: 'js',
  jsx: 'js',
  mjs: 'js',
  cjs: 'js',
  ts: 'js',
  typescript: 'js',
  tsx: 'js',
  python: 'py',
  py: 'py',
  golang: 'go',
  rs: 'rust',
  java: 'c',
  cs: 'c',
  csharp: 'c',
  c: 'c',
  cpp: 'c',
  'c++': 'c',
  h: 'c',
  kotlin: 'c',
  swift: 'c',
  php: 'c',
  dart: 'c',
  gdscript: 'gd',
  gd: 'gd',
  bash: 'sh',
  shell: 'sh',
  sh: 'sh',
  zsh: 'sh',
  powershell: 'sh',
  ps1: 'sh',
  sql: 'sql',
  json: 'json',
  jsonc: 'json',
  css: 'css',
  scss: 'css',
  html: 'html',
  xml: 'html',
  svg: 'html',
  vue: 'html'
};

export function canHighlight(lang) {
  return Boolean(
    ALIAS[
      String(lang || '')
        .trim()
        .toLowerCase()
    ]
  );
}

export function highlight(code, lang) {
  const key =
    ALIAS[
      String(lang || '')
        .trim()
        .toLowerCase()
    ];
  const src = String(code ?? '');
  if (!key || src.length > MAX_CHARS) return esc(src);
  const L = LANGS[key];
  let out = '';
  let i = 0;
  const n = src.length;
  const span = (cls, text) => `<span class="hl-${cls}">${esc(text)}</span>`;
  while (i < n) {
    const c = src[i];
    const rest2 = src.slice(i, i + 2);
    // comentarios
    if (L.markup && src.startsWith('<!--', i)) {
      const e = src.indexOf('-->', i + 4);
      const end = e < 0 ? n : e + 3;
      out += span('c', src.slice(i, end));
      i = end;
      continue;
    }
    if (L.line && src.startsWith(L.line, i)) {
      let e = src.indexOf('\n', i);
      if (e < 0) e = n;
      out += span('c', src.slice(i, e));
      i = e;
      continue;
    }
    if (L.block && rest2 === '/*') {
      const e = src.indexOf('*/', i + 2);
      const end = e < 0 ? n : e + 2;
      out += span('c', src.slice(i, end));
      i = end;
      continue;
    }
    // cadenas
    if (L.triple && (src.startsWith('"""', i) || src.startsWith("'''", i))) {
      const q = src.slice(i, i + 3);
      const e = src.indexOf(q, i + 3);
      const end = e < 0 ? n : e + 3;
      out += span('s', src.slice(i, end));
      i = end;
      continue;
    }
    if (L.str.includes(c)) {
      let j = i + 1;
      while (j < n && src[j] !== c && !(src[j] === '\n' && c !== '`')) {
        if (src[j] === '\\') j++;
        j++;
      }
      const end = Math.min(j + 1, n);
      const text = src.slice(i, end);
      // en JSON, una cadena seguida de ':' es una clave
      const isKey = key === 'json' && /^\s*:/.test(src.slice(end, end + 8));
      out += span(isKey ? 'k' : 's', text);
      i = end;
      continue;
    }
    if (L.markup && c === '<') {
      const m = /^<\/?[A-Za-z][\w:-]*/.exec(src.slice(i, i + 60));
      if (m) {
        out += span('t', m[0]);
        i += m[0].length;
        continue;
      }
    }
    // números
    if (/[0-9]/.test(c) && !/[\w$]/.test(src[i - 1] || '')) {
      const m = /^(0[xX][0-9a-fA-F_]+|\d[\d_]*\.?\d*(?:[eE][+-]?\d+)?)/.exec(src.slice(i, i + 40));
      if (m) {
        out += span('n', m[0]);
        i += m[0].length;
        continue;
      }
    }
    // palabras
    if (/[A-Za-z_$@]/.test(c)) {
      const m = /^[@A-Za-z_$][\w$]*/.exec(src.slice(i, i + 80));
      const w = m ? m[0] : c;
      const lookup = L.ci ? w.toLowerCase() : w;
      if (L.css && src[i + w.length] === ':') out += span('k', w);
      else if (L.kw.has(lookup)) out += span('kw', w);
      else if (LITERALS.has(w)) out += span('n', w);
      else if (/^[A-Z][A-Za-z0-9]*$/.test(w) && key !== 'sh' && key !== 'sql') out += span('ty', w);
      else if (src[i + w.length] === '(' && key !== 'json') out += span('f', w);
      else out += esc(w);
      i += w.length;
      continue;
    }
    out += esc(c);
    i++;
  }
  return out;
}
