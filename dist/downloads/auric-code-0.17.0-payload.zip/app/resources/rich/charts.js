// Dibuja gráficos como SVG a partir de una especificación ya validada (schema.js). Funciones puras, sin DOM ni dependencias.
// Todo texto que viene de los datos se escapa; los colores salen de variables CSS del tema (--rc-1 … --rc-8).
const W = 640,
  H = 320;
export const PALETTE_SIZE = 8;

export const escXml = s =>
  String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const nf = new Intl.NumberFormat('es', { maximumFractionDigits: 2 });
const nfc = new Intl.NumberFormat('es', { notation: 'compact', maximumFractionDigits: 1 });
export function fmtValue(v, spec = {}, compact = false) {
  if (v == null || !Number.isFinite(Number(v))) return '—';
  const n = Number(v);
  const s = compact && Math.abs(n) >= 10000 ? nfc.format(n) : nf.format(n);
  if (spec.format === 'percent') return `${s}%`;
  return spec.unit ? `${s} ${spec.unit}` : s;
}
export function niceScale(min, max, count = 5) {
  if (!Number.isFinite(min) || !Number.isFinite(max)) return { min: 0, max: 1, step: 0.2, ticks: [0, 0.2, 0.4, 0.6, 0.8, 1] };
  if (min === max) {
    if (min === 0) max = 1;
    else {
      min = Math.min(0, min);
      max = Math.max(0, max);
    }
  }
  const range = max - min,
    rough = range / Math.max(1, count),
    mag = 10 ** Math.floor(Math.log10(rough)),
    norm = rough / mag,
    step = (norm < 1.5 ? 1 : norm < 3 ? 2 : norm < 7 ? 5 : 10) * mag,
    lo = Math.floor(min / step) * step,
    hi = Math.ceil(max / step) * step,
    ticks = [];
  for (let v = lo; v <= hi + step / 2; v += step) ticks.push(Number(v.toFixed(10)));
  return { min: lo, max: hi, step, ticks };
}
const short = (s, n = 14) => (String(s).length > n ? String(s).slice(0, n - 1) + '…' : String(s));
const f2 = n => Number(n.toFixed(2));
const colorClass = i => (i % PALETTE_SIZE) + 1;

function categories(spec) {
  const seen = new Set(),
    out = [];
  for (const r of spec.data) {
    const k = r[spec.xKey] == null ? '' : String(r[spec.xKey]);
    if (!seen.has(k)) {
      seen.add(k);
      out.push(k);
    }
  }
  return out;
}
function valueFor(spec, cat, key) {
  let sum = 0,
    any = false;
  for (const r of spec.data) {
    if (String(r[spec.xKey] ?? '') === cat && typeof r[key] === 'number') {
      sum += r[key];
      any = true;
    }
  }
  return any ? sum : null;
}
function decimate(arr, max) {
  if (arr.length <= max) return arr;
  const out = [],
    step = (arr.length - 1) / (max - 1);
  for (let i = 0; i < max; i++) out.push(arr[Math.round(i * step)]);
  return out;
}
function legendOf(spec) {
  return spec.series.map((s, i) => ({ label: s.label, cls: colorClass(i) }));
}
const wrap = (inner, title, extra = '') =>
  `<svg class="rc-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="${escXml(title || 'Gráfico')}" xmlns="http://www.w3.org/2000/svg"${extra}>${inner}</svg>`;

function axesFrame(spec, ml, mr, mt, mb, yScale, { horizontal = false } = {}) {
  const iw = W - ml - mr,
    ih = H - mt - mb;
  let g = '';
  if (!horizontal) {
    for (const t of yScale.ticks) {
      const y = mt + ih - ((t - yScale.min) / (yScale.max - yScale.min)) * ih;
      g += `<line class="rc-grid" x1="${ml}" x2="${W - mr}" y1="${f2(y)}" y2="${f2(y)}"/><text class="rc-tick" x="${ml - 8}" y="${f2(y + 4)}" text-anchor="end">${escXml(fmtValue(t, spec, true))}</text>`;
    }
    g += `<line class="rc-axis" x1="${ml}" x2="${W - mr}" y1="${mt + ih}" y2="${mt + ih}"/>`;
    if (spec.yLabel)
      g += `<text class="rc-label" transform="translate(12 ${mt + ih / 2}) rotate(-90)" text-anchor="middle">${escXml(spec.yLabel)}</text>`;
  } else {
    for (const t of yScale.ticks) {
      const x = ml + ((t - yScale.min) / (yScale.max - yScale.min)) * iw;
      g += `<line class="rc-grid" y1="${mt}" y2="${mt + ih}" x1="${f2(x)}" x2="${f2(x)}"/><text class="rc-tick" y="${mt + ih + 16}" x="${f2(x)}" text-anchor="middle">${escXml(fmtValue(t, spec, true))}</text>`;
    }
    g += `<line class="rc-axis" y1="${mt}" y2="${mt + ih}" x1="${ml}" x2="${ml}"/>`;
  }
  return { g, iw, ih };
}

function barChart(spec) {
  const cats = categories(spec),
    ns = spec.series.length,
    horizontal = spec.chartType === 'hbar';
  const vals = spec.series.map(s => cats.map(c => valueFor(spec, c, s.key)));
  let lo = 0,
    hi = 0;
  if (spec.stacked) {
    for (let ci = 0; ci < cats.length; ci++) {
      let pos = 0,
        neg = 0;
      for (let si = 0; si < ns; si++) {
        const v = vals[si][ci] ?? 0;
        if (v >= 0) pos += v;
        else neg += v;
      }
      hi = Math.max(hi, pos);
      lo = Math.min(lo, neg);
    }
  } else
    for (const row of vals)
      for (const v of row)
        if (v != null) {
          hi = Math.max(hi, v);
          lo = Math.min(lo, v);
        }
  const sc = niceScale(lo, hi, 5);
  const maxLabel = Math.max(...cats.map(c => c.length), 1);
  const ml = horizontal ? Math.min(150, 14 + maxLabel * 6.4) : 56,
    mr = 18,
    mt = 14,
    mb = horizontal ? 30 : cats.length > 8 ? 62 : 40;
  const { g, iw, ih } = axesFrame(spec, ml, mr, mt, mb, sc, { horizontal });
  let inner = g;
  const band = (horizontal ? ih : iw) / cats.length,
    pad = Math.min(band * 0.18, 14),
    inner_ = band - pad * 2,
    barW = spec.stacked ? inner_ : inner_ / ns,
    span = sc.max - sc.min,
    zero = horizontal ? ml + ((0 - sc.min) / span) * iw : mt + ih - ((0 - sc.min) / span) * ih;
  const every = Math.ceil(cats.length / (horizontal ? 18 : 12));
  cats.forEach((c, ci) => {
    const base = (horizontal ? mt : ml) + ci * band + pad;
    let posAcc = 0,
      negAcc = 0;
    spec.series.forEach((s, si) => {
      const v = vals[si][ci];
      if (v == null) return;
      let a, b;
      if (spec.stacked) {
        if (v >= 0) {
          a = posAcc;
          b = posAcc + v;
          posAcc = b;
        } else {
          a = negAcc;
          b = negAcc + v;
          negAcc = b;
        }
      } else {
        a = 0;
        b = v;
      }
      const pa = horizontal ? ml + ((a - sc.min) / span) * iw : mt + ih - ((a - sc.min) / span) * ih,
        pb = horizontal ? ml + ((b - sc.min) / span) * iw : mt + ih - ((b - sc.min) / span) * ih;
      const off = base + (spec.stacked ? 0 : si * barW);
      const title = `<title>${escXml(`${c} · ${s.label}: ${fmtValue(v, { ...spec, unit: s.unit || spec.unit })}`)}</title>`;
      if (horizontal)
        inner += `<rect class="rc-f${colorClass(si)}" x="${f2(Math.min(pa, pb))}" y="${f2(off)}" width="${f2(Math.max(1, Math.abs(pb - pa)))}" height="${f2(Math.max(1, barW - 1))}" rx="2">${title}</rect>`;
      else
        inner += `<rect class="rc-f${colorClass(si)}" x="${f2(off)}" y="${f2(Math.min(pa, pb))}" width="${f2(Math.max(1, barW - 1))}" height="${f2(Math.max(1, Math.abs(pb - pa)))}" rx="2">${title}</rect>`;
    });
    if (ci % every === 0) {
      if (horizontal)
        inner += `<text class="rc-tick" x="${ml - 8}" y="${f2(base + inner_ / 2 + 4)}" text-anchor="end">${escXml(short(c, 22))}</text>`;
      else {
        const x = base + inner_ / 2,
          rot = cats.length > 8;
        inner += `<text class="rc-tick" ${rot ? `transform="translate(${f2(x)} ${mt + ih + 14}) rotate(-35)" text-anchor="end"` : `x="${f2(x)}" y="${mt + ih + 18}" text-anchor="middle"`}>${escXml(short(c))}</text>`;
      }
    }
  });
  inner += horizontal
    ? `<line class="rc-axis" x1="${f2(zero)}" x2="${f2(zero)}" y1="${mt}" y2="${mt + ih}"/>`
    : `<line class="rc-axis" x1="${ml}" x2="${W - mr}" y1="${f2(zero)}" y2="${f2(zero)}"/>`;
  return wrap(inner, spec.title);
}

function lineChart(spec) {
  const area = spec.chartType === 'area';
  let cats = categories(spec);
  const MAXPTS = 400;
  if (cats.length > MAXPTS) cats = decimate(cats, MAXPTS);
  const ns = spec.series.length;
  const vals = spec.series.map(s => cats.map(c => valueFor(spec, c, s.key)));
  let lo = 0,
    hi = 0;
  if (spec.stacked && area) {
    for (let ci = 0; ci < cats.length; ci++) {
      let acc = 0;
      for (let si = 0; si < ns; si++) acc += vals[si][ci] ?? 0;
      hi = Math.max(hi, acc);
    }
  } else {
    lo = Infinity;
    hi = -Infinity;
    for (const r of vals) for (const v of r) if (v != null) ((lo = Math.min(lo, v)), (hi = Math.max(hi, v)));
    if (!Number.isFinite(lo)) ((lo = 0), (hi = 1));
    if (area) lo = Math.min(lo, 0);
  }
  const sc = niceScale(lo, hi, 5),
    ml = 56,
    mr = 18,
    mt = 14,
    mb = 42,
    iw = W - ml - mr,
    ih = H - mt - mb,
    span = sc.max - sc.min;
  const { g } = axesFrame(spec, ml, mr, mt, mb, sc);
  let inner = g;
  const xAt = i => ml + (cats.length === 1 ? iw / 2 : (i / (cats.length - 1)) * iw),
    yAt = v => mt + ih - ((v - sc.min) / span) * ih;
  const every = Math.ceil(cats.length / 10);
  cats.forEach((c, i) => {
    if (i % every === 0)
      inner += `<text class="rc-tick" x="${f2(xAt(i))}" y="${mt + ih + 18}" text-anchor="middle">${escXml(short(c))}</text>`;
  });
  const acc = new Array(cats.length).fill(0);
  for (let si = 0; si < ns; si++) {
    const pts = [],
      base = [];
    cats.forEach((c, i) => {
      const v = vals[si][i];
      if (v == null) return;
      const y0 = spec.stacked && area ? acc[i] : 0;
      const y1 = spec.stacked && area ? acc[i] + v : v;
      if (spec.stacked && area) acc[i] = y1;
      pts.push([xAt(i), yAt(y1), v, c]);
      base.push([xAt(i), yAt(spec.stacked && area ? y0 : Math.max(sc.min, Math.min(0, sc.max)))]);
    });
    if (!pts.length) continue;
    const d = pts.map((p, i) => `${i ? 'L' : 'M'}${f2(p[0])} ${f2(p[1])}`).join('');
    if (area) {
      const back = base
        .slice()
        .reverse()
        .map(p => `L${f2(p[0])} ${f2(p[1])}`)
        .join('');
      inner += `<path class="rc-f${colorClass(si)} rc-area" d="${d}${back}Z"/>`;
    }
    inner += `<path class="rc-k${colorClass(si)} rc-line" d="${d}" fill="none"/>`;
    if (cats.length <= 80)
      for (const p of pts)
        inner += `<circle class="rc-f${colorClass(si)}" cx="${f2(p[0])}" cy="${f2(p[1])}" r="3.2"><title>${escXml(`${p[3]} · ${spec.series[si].label}: ${fmtValue(p[2], { ...spec, unit: spec.series[si].unit || spec.unit })}`)}</title></circle>`;
  }
  return wrap(inner, spec.title);
}

function pieChart(spec) {
  const donut = spec.chartType === 'donut',
    key = spec.series[0].key;
  const cats = categories(spec);
  let slices = cats.map(c => ({ label: c || '(sin nombre)', v: valueFor(spec, c, key) })).filter(s => s.v != null && s.v > 0);
  slices.sort((a, b) => b.v - a.v);
  if (slices.length > 10) {
    const rest = slices.slice(9).reduce((a, s) => a + s.v, 0);
    slices = [...slices.slice(0, 9), { label: 'Otros', v: rest }];
  }
  const total = slices.reduce((a, s) => a + s.v, 0);
  const cx = W / 2,
    cy = H / 2,
    r = H / 2 - 18,
    r0 = donut ? r * 0.58 : 0;
  let inner = '',
    ang = -Math.PI / 2;
  if (!total)
    return {
      svg: wrap(`<text class="rc-tick" x="${cx}" y="${cy}" text-anchor="middle">Sin valores positivos</text>`, spec.title),
      legend: []
    };
  const legend = [];
  slices.forEach((s, i) => {
    const frac = s.v / total,
      a1 = ang + frac * Math.PI * 2,
      pct = nf.format(frac * 100) + '%',
      title = `<title>${escXml(`${s.label}: ${fmtValue(s.v, spec)} (${pct})`)}</title>`;
    legend.push({ label: `${s.label} · ${pct}`, cls: colorClass(i) });
    if (slices.length === 1) {
      inner += `<circle class="rc-f${colorClass(i)}" cx="${cx}" cy="${cy}" r="${r}">${title}</circle>`;
      if (donut) inner += `<circle class="rc-hole" cx="${cx}" cy="${cy}" r="${f2(r0)}"/>`;
    } else {
      const large = frac > 0.5 ? 1 : 0,
        p = (rad, a) => [cx + rad * Math.cos(a), cy + rad * Math.sin(a)];
      const [x0, y0] = p(r, ang),
        [x1, y1] = p(r, a1);
      let d = `M${f2(x0)} ${f2(y0)}A${r} ${r} 0 ${large} 1 ${f2(x1)} ${f2(y1)}`;
      if (donut) {
        const [x2, y2] = p(r0, a1),
          [x3, y3] = p(r0, ang);
        d += `L${f2(x2)} ${f2(y2)}A${f2(r0)} ${f2(r0)} 0 ${large} 0 ${f2(x3)} ${f2(y3)}Z`;
      } else d += `L${cx} ${cy}Z`;
      inner += `<path class="rc-f${colorClass(i)} rc-slice" d="${d}">${title}</path>`;
    }
    ang = a1;
  });
  return { svg: wrap(inner, spec.title), legend };
}

function scatterChart(spec) {
  const pts = spec.series.map(s =>
    decimate(
      spec.data.filter(r => typeof r[spec.xKey] === 'number' && typeof r[s.key] === 'number').map(r => [r[spec.xKey], r[s.key]]),
      2000
    )
  );
  const xs = pts.flat().map(p => p[0]),
    ys = pts.flat().map(p => p[1]);
  if (!xs.length)
    return wrap(`<text class="rc-tick" x="${W / 2}" y="${H / 2}" text-anchor="middle">Sin puntos numéricos</text>`, spec.title);
  const sx = niceScale(Math.min(...xs), Math.max(...xs), 6),
    sy = niceScale(Math.min(...ys), Math.max(...ys), 5),
    ml = 56,
    mr = 18,
    mt = 14,
    mb = 44,
    iw = W - ml - mr,
    ih = H - mt - mb;
  const { g } = axesFrame(spec, ml, mr, mt, mb, sy);
  let inner = g;
  for (const t of sx.ticks) {
    const x = ml + ((t - sx.min) / (sx.max - sx.min)) * iw;
    inner += `<text class="rc-tick" x="${f2(x)}" y="${mt + ih + 18}" text-anchor="middle">${escXml(fmtValue(t, { unit: '' }, true))}</text>`;
  }
  if (spec.xLabel) inner += `<text class="rc-label" x="${ml + iw / 2}" y="${H - 4}" text-anchor="middle">${escXml(spec.xLabel)}</text>`;
  pts.forEach((arr, si) => {
    for (const [x, y] of arr) {
      const px = ml + ((x - sx.min) / (sx.max - sx.min)) * iw,
        py = mt + ih - ((y - sy.min) / (sy.max - sy.min)) * ih;
      inner += `<circle class="rc-f${colorClass(si)} rc-dot" cx="${f2(px)}" cy="${f2(py)}" r="3.6"><title>${escXml(`${spec.series[si].label}: (${nf.format(x)}, ${nf.format(y)})`)}</title></circle>`;
    }
  });
  return wrap(inner, spec.title);
}

function histogramChart(spec) {
  const key = spec.series[0].key,
    values = spec.data.map(r => r[key]).filter(v => typeof v === 'number');
  if (!values.length)
    return wrap(`<text class="rc-tick" x="${W / 2}" y="${H / 2}" text-anchor="middle">Sin valores numéricos</text>`, spec.title);
  let min = Infinity,
    max = -Infinity;
  for (const v of values) {
    if (v < min) min = v;
    if (v > max) max = v;
  }
  if (min === max) max = min + 1;
  const bins = spec.bins,
    width = (max - min) / bins,
    counts = new Array(bins).fill(0);
  for (const v of values) counts[Math.min(bins - 1, Math.floor((v - min) / width))]++;
  const sc = niceScale(0, Math.max(...counts), 5),
    ml = 56,
    mr = 18,
    mt = 14,
    mb = 44,
    iw = W - ml - mr,
    ih = H - mt - mb;
  const { g } = axesFrame({ ...spec, unit: '', format: 'number' }, ml, mr, mt, mb, sc);
  let inner = g;
  const bw = iw / bins;
  counts.forEach((c, i) => {
    const h = (c / (sc.max - sc.min)) * ih,
      lo = min + i * width;
    inner += `<rect class="rc-f1" x="${f2(ml + i * bw + 1)}" y="${f2(mt + ih - h)}" width="${f2(Math.max(1, bw - 2))}" height="${f2(h)}" rx="2"><title>${escXml(`${nf.format(lo)} – ${nf.format(lo + width)}: ${c}`)}</title></rect>`;
    if (i % Math.ceil(bins / 8) === 0)
      inner += `<text class="rc-tick" x="${f2(ml + i * bw)}" y="${mt + ih + 18}" text-anchor="middle">${escXml(nf.format(lo))}</text>`;
  });
  inner += `<text class="rc-tick" x="${ml + iw}" y="${mt + ih + 18}" text-anchor="middle">${escXml(nf.format(max))}</text>`;
  return wrap(inner, spec.title);
}

// → { svg, legend:[{label, cls}] }
export function chartSvg(spec) {
  let svg,
    legend = legendOf(spec);
  switch (spec.chartType) {
    case 'bar':
    case 'hbar':
      svg = barChart(spec);
      break;
    case 'line':
    case 'area':
      svg = lineChart(spec);
      break;
    case 'pie':
    case 'donut': {
      const r = pieChart(spec);
      svg = r.svg;
      legend = r.legend;
      break;
    }
    case 'scatter':
      svg = scatterChart(spec);
      break;
    case 'histogram':
      svg = histogramChart(spec);
      legend = [];
      break;
    default:
      throw new Error(`Tipo de gráfico no soportado: ${spec.chartType}`);
  }
  if (spec.series.length < 2 && !['pie', 'donut'].includes(spec.chartType)) legend = [];
  return { svg, legend };
}

export function chartCsv(spec) {
  const q = v => {
    const s = v == null ? '' : String(v);
    return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const cols = spec.chartType === 'histogram' ? [spec.series[0].key] : [spec.xKey, ...spec.series.map(s => s.key)];
  return [cols.map(q).join(','), ...spec.data.map(r => cols.map(c => q(r[c])).join(','))].join('\n');
}
// Hoja de estilos mínima para exportar el SVG fuera de la app (con colores ya resueltos).
export const EXPORT_CSS = `.rc-grid{stroke:#8a97aa;stroke-opacity:.25}.rc-axis{stroke:#8a97aa}.rc-tick,.rc-label{fill:#8a97aa;font:11px 'Segoe UI',system-ui,sans-serif}.rc-line{stroke-width:2.2;stroke-linejoin:round;stroke-linecap:round}.rc-area{fill-opacity:.18}.rc-hole{fill:#fff}`;
