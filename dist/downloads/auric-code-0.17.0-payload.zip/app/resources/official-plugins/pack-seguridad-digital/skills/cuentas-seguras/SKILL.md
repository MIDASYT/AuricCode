---
id: cuentas-seguras
name: Cuentas seguras
description: Guía para ordenar contraseñas, activar verificación en dos pasos y recuperar una cuenta si hubo un robo o una filtración.
triggers: [cuenta hackeada, me hackearon, robaron mi cuenta, verificación en dos pasos, verificacion en dos pasos, gestor de contraseñas, gestor de contrasenas, filtración de datos, filtracion de datos, recuperar mi cuenta]
markers: []
tags: [cuentas, seguridad]
---
## Base sólida
1. Un **gestor de contraseñas** y una contraseña maestra larga (una frase de 4–5 palabras al azar) que no se use en ningún otro lado.
2. Una contraseña **única** por cuenta, generada por el gestor. Empieza por el correo principal, el banco y las redes sociales.
3. **Verificación en dos pasos** en todo lo importante, mejor con una app autenticadora o llave física que por SMS. Guarda los códigos de recuperación impresos o en un lugar aparte.
4. Revisa qué dispositivos y aplicaciones tienen sesión abierta y cierra los que no reconozcas.

## Si le robaron o hackearon una cuenta
1. Desde un dispositivo de confianza, cambia la contraseña y cierra todas las sesiones.
2. Revisa el correo de recuperación, el teléfono asociado y las reglas de reenvío del correo (los atacantes suelen agregarlas).
3. Avisa a los contactos si el atacante pudo escribirles en su nombre.
4. Cambia las contraseñas de otras cuentas que repitieran la misma.
5. Si hay dinero de por medio, contacta al banco o servicio por su canal oficial y haz la denuncia que corresponda.

## Si hubo una filtración de datos
Revisa en un servicio de confianza de verificación de filtraciones si el correo aparece, cambia la contraseña de ese servicio y de las cuentas parecidas, y desconfía de mensajes que mencionen datos tuyos reales: ahora los estafadores los tienen.

## Regla
Nunca pidas ni recibas las contraseñas de la persona: explica los pasos y que los haga ella.
