---
id: privacidad-antes-de-compartir
name: Privacidad antes de compartir
description: Revisa un texto, captura o documento y señala los datos personales o secretos que conviene tapar antes de compartirlo.
triggers: [antes de compartir, datos personales, tapar datos, anonimizar, anonimizar este, censurar datos, datos sensibles, privacidad de mis datos]
markers: []
tags: [privacidad, seguridad]
---
## Qué buscar
- **Identidad**: nombre completo, RUT/DNI/pasaporte, fecha de nacimiento, foto, firma.
- **Contacto**: dirección, teléfono, correos personales, ubicación exacta.
- **Dinero**: números de cuenta o tarjeta, saldos, montos asociados a una persona.
- **Salud y otros datos sensibles**: diagnósticos, recetas, orientación, creencias.
- **Acceso**: contraseñas, claves de API, tokens, códigos de verificación, enlaces privados de documentos.
- **Metadatos**: ubicación en las fotos, autor y comentarios ocultos en documentos, historial de cambios.

## Cómo ayudar
1. Lista lo que encontraste, dónde está y por qué conviene tapar (sin repetir el dato completo: usa `1•••-9`).
2. Propón una versión limpia con marcadores como `[NOMBRE]`, `[RUT]` o `[CUENTA]`, conservando el sentido del texto.
3. Para capturas y PDFs: recuerda que **tapar con un recuadro negro encima no siempre borra el texto de abajo**; conviene exportar de nuevo a imagen o usar la función de censura real de la herramienta.
4. Pregunta con quién se va a compartir: para un servicio de IA o un foro público conviene quitar más que para un contador o un médico.

## Reglas
- Decide la persona: tú señalas riesgos, ella elige qué compartir.
- No guardes ni repitas los datos que encuentres.
