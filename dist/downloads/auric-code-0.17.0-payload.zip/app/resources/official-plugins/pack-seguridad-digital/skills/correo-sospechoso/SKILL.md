---
id: correo-sospechoso
name: Mensaje sospechoso
description: Ayuda a evaluar un correo, SMS o WhatsApp dudoso (posible estafa) y dice qué hacer, sin abrir enlaces ni archivos.
triggers: [correo sospechoso, mensaje sospechoso, es una estafa, será una estafa, sera una estafa, phishing, me llegó un correo, me llego un correo, me llegó un mensaje, me llego un mensaje]
markers: []
tags: [seguridad, estafas]
---
## Qué revisar
1. **Urgencia o amenaza**: «tu cuenta será cerrada hoy», «último aviso», premios inesperados.
2. **Quién lo envía**: la dirección completa del remitente (no solo el nombre), errores sutiles en el dominio (`bancoestado-seguro.com` no es `bancoestado.cl`).
3. **Enlaces**: el destino real no coincide con el texto; acortadores; dominios raros. **No los abras ni los visites para comprobar.**
4. **Pedidos**: claves, códigos de verificación, datos de tarjeta, instalar un programa, pagar con tarjetas de regalo o transferencias a desconocidos.
5. **Forma**: saludo genérico, faltas raras, logotipos borrosos, adjuntos inesperados (.zip, .exe, .html, macros de Office).

## Cómo responder
- Da un veredicto claro: **probable estafa**, **dudoso** o **parece legítimo**, con las 2–3 razones principales. Aclara que no puedes estar 100 % seguro.
- Qué hacer: no responder, no abrir enlaces ni adjuntos; entrar al sitio oficial escribiendo la dirección tú mismo o llamar al número que está en la tarjeta o en la web oficial; reportarlo como phishing en el correo y borrarlo.

## Si ya hizo clic o entregó datos
1. Si ingresó una contraseña: cámbiala ya (y en cualquier sitio donde la repita) y activa la verificación en dos pasos.
2. Si dio datos de tarjeta o banco: llama al banco por el número oficial para bloquear y revisar movimientos.
3. Si instaló algo: desconecta el equipo de internet, ejecuta un análisis con el antivirus del sistema y cambia las claves desde otro dispositivo.
4. Guarda el mensaje como evidencia por si hay que hacer una denuncia.

## Regla
Nunca pidas a la persona que te pegue contraseñas ni códigos. Si pega un mensaje con datos personales, no los repitas más de lo necesario.
