---
id: respaldo-simple
name: Respaldo simple
description: Explica y arma un plan de copias de seguridad fácil de mantener (regla 3-2-1) para fotos, documentos y trabajo.
triggers: [respaldo, copia de seguridad, backup, respaldar mis archivos, no perder mis archivos, copia de mis fotos]
markers: []
tags: [respaldo, seguridad]
---
## La regla 3-2-1 explicada fácil
- **3 copias** de lo importante (el original + 2 respaldos).
- En **2 tipos de almacenamiento** distintos (por ejemplo el PC y un disco externo).
- **1 copia fuera de casa** (nube o un disco guardado en otro lugar), por si hay robo, incendio o inundación.

## Cómo armar el plan
1. Pregunta qué es lo que NO se puede perder (fotos, documentos, proyectos, bases de datos) y cuánto pesa, aproximadamente.
2. Propón una combinación sencilla: disco externo + una nube con capacidad suficiente; sincronizar no es respaldar (si borras algo, se borra en todos lados): conviene que la nube guarde versiones anteriores.
3. Define la frecuencia: automática si se puede (diaria o semanal), o un recordatorio mensual.
4. **Prueba la restauración** una vez: un respaldo que nunca se probó no es una garantía.
5. Cifra el disco o la carpeta si contiene datos sensibles y guarda la clave en un lugar seguro, aparte.

## Reglas
- No borres nada del equipo original como parte del plan.
- Para copias de proyectos con Git, recuerda que Git no reemplaza el respaldo del disco (lo que no se subió al servidor no está respaldado).
