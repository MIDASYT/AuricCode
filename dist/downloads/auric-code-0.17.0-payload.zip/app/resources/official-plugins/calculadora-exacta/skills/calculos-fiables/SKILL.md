---
id: calculos-fiables
name: Cálculos fiables
description: Para cuentas, porcentajes, fechas y conversiones usa el servidor de cálculo en vez de calcular de cabeza.
triggers: [cuánto es, cuanto es, calcula, cálculo, calculo, porcentaje, descuento, cuántos días, cuantos dias, días entre, dias entre, convierte, convertir, diferencia de fechas, día de la semana, dia de la semana]
markers: []
tags: [cálculo, fechas]
---
## Cuándo usar el servidor de cálculo
Para cualquier cuenta que no sea trivial (más de dos números, decimales, porcentajes, IVA o descuentos), para fechas (diferencias, sumar días, día de la semana, días hábiles) y para convertir unidades. Calcular «de cabeza» es la fuente más común de errores.

## Cómo usarlo
1. Llama a `mcp_list_tools` con el servidor `calculadora-exacta/calculos` (una vez por conversación) para ver sus herramientas.
2. Llama a `mcp_call` con ese servidor y la herramienta que corresponda:
   - `calcular`: `{ "expresion": "(1250 + 340) * 0.19" }`. Usa punto como decimal y sin separador de miles.
   - `porcentajes`: acciones `parte`, `aumentar`, `descontar`, `quitar_incluido`, `variacion` y `que_porcentaje_es`.
   - `fechas`: acciones `diferencia`, `sumar`, `dia_semana` y `dias_habiles` (fechas en formato AAAA-MM-DD; los días hábiles son de lunes a viernes y NO consideran feriados).
   - `convertir_unidades`: `{ "valor": 5, "desde": "km", "hasta": "mi" }`.
3. Informa el resultado con las unidades y di qué cuenta hiciste, para que la persona pueda comprobarla.

## Reglas
- Si el servidor da un error, léelo: casi siempre es un formato (coma en vez de punto, fecha mal escrita). Corrígelo y vuelve a intentar.
- Si el servidor no está disponible, calcula con cuidado paso a paso y avisa que no pudiste verificar con el programa.
- Los resultados están redondeados a 12 decimales; redondea al final según lo que pida la persona (por ejemplo, pesos sin decimales).
