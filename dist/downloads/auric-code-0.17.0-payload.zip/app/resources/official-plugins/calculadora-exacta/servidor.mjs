// Servidor MCP (stdio) de la «Calculadora exacta». Sin dependencias, sin Internet y sin tocar archivos.
// Habla JSON-RPC por líneas: cada línea de entrada es un mensaje y cada línea de salida una respuesta.
import { createInterface } from 'node:readline';

const SERVER = { name: 'calculadora-exacta', version: '1.0.0' };

// ── Utilidades ──────────────────────────────────────────────────────────────────────────────────
class UserError extends Error {}
const fail = msg => {
  throw new UserError(msg);
};
// Quita el «ruido» binario (0.1+0.2 = 0.30000000000000004) y evita notación científica en cifras normales.
function fmt(n) {
  if (!Number.isFinite(n)) fail('El resultado no es un número finito.');
  const r = Math.round(n * 1e12) / 1e12;
  if (Object.is(r, -0)) return '0';
  if (Math.abs(r) >= 1e21 || (Math.abs(r) > 0 && Math.abs(r) < 1e-9)) return r.toExponential(9).replace(/\.?0+e/, 'e');
  return String(r);
}
const num = (v, name) => {
  if (typeof v === 'string' && /^\s*-?\d+(\.\d+)?\s*$/.test(v)) v = Number(v);
  if (typeof v !== 'number' || !Number.isFinite(v)) fail(`«${name}» debe ser un número (usa punto para los decimales, sin separador de miles).`);
  return v;
};

// ── Expresiones ─────────────────────────────────────────────────────────────────────────────────
const FUNCS = {
  sqrt: [1, Math.sqrt],
  abs: [1, Math.abs],
  floor: [1, Math.floor],
  ceil: [1, Math.ceil],
  ln: [1, Math.log],
  log10: [1, Math.log10],
  exp: [1, Math.exp],
  sin: [1, Math.sin],
  cos: [1, Math.cos],
  tan: [1, Math.tan],
  pow: [2, Math.pow],
  min: [-1, Math.min],
  max: [-1, Math.max],
  round: [-2, (x, d = 0) => {
    const k = 10 ** Math.trunc(d);
    return Math.round((x + Number.EPSILON * Math.sign(x)) * k) / k;
  }]
};
const CONSTS = { pi: Math.PI, e: Math.E };

function tokenize(src) {
  const out = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (/\s/.test(c)) {
      i++;
    } else if (/[0-9.]/.test(c)) {
      const m = /^(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?/.exec(src.slice(i));
      if (!m) fail(`Número mal escrito cerca de «${src.slice(i, i + 8)}».`);
      out.push({ t: 'n', v: Number(m[0]) });
      i += m[0].length;
    } else if (/[A-Za-z_]/.test(c)) {
      const m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(src.slice(i));
      out.push({ t: 'id', v: m[0].toLowerCase() });
      i += m[0].length;
    } else if ('+-*/^(),'.includes(c)) {
      out.push({ t: c });
      i++;
    } else if (c === '×') {
      out.push({ t: '*' });
      i++;
    } else if (c === '÷') {
      out.push({ t: '/' });
      i++;
    } else if (c === ',') {
      fail('Usa punto para los decimales (3.5) y separa los argumentos de una función con coma solo dentro de paréntesis.');
    } else if (c === '%') {
      fail('El símbolo % es ambiguo en una cuenta. Usa la herramienta «porcentajes» o escribe el número (20% de 50 → 0.20 * 50).');
    } else {
      fail(`Carácter no permitido en la expresión: «${c}».`);
    }
  }
  return out;
}
// Descenso recursivo con la precedencia de las matemáticas (y de Python): -2^2 = -4 y 2^-1 = 0.5.
// expr → term (±term)* · term → unary (*,/ unary)* · unary → ±unary | power · power → primary (^ unary)?
function evaluate(src) {
  if (typeof src !== 'string' || !src.trim()) fail('Falta la expresión.');
  if (src.length > 400) fail('La expresión es demasiado larga (máximo 400 caracteres).');
  if (/\d,\d{3}(?!\d)/.test(src) && !/\(/.test(src)) fail('Parece que usas coma como separador de miles. Escribe los números sin separador (1234.56).');
  const toks = tokenize(src);
  let p = 0;
  let depth = 0;
  const peek = () => toks[p];
  const eat = t => (toks[p] && toks[p].t === t ? toks[p++] : null);
  function expr() {
    let v = term();
    for (;;) {
      if (eat('+')) v += term();
      else if (eat('-')) v -= term();
      else return v;
    }
  }
  function term() {
    let v = unary();
    for (;;) {
      if (eat('*')) v *= unary();
      else if (eat('/')) {
        const d = unary();
        if (d === 0) fail('División por cero.');
        v /= d;
      } else return v;
    }
  }
  function unary() {
    if (eat('-')) return -unary();
    if (eat('+')) return unary();
    return power();
  }
  function power() {
    const base = primary();
    if (eat('^')) {
      const ex = unary();
      const r = base ** ex;
      if (Number.isNaN(r)) fail('Esa potencia no tiene resultado real.');
      return r;
    }
    return base;
  }
  function primary() {
    const tk = peek();
    if (!tk) fail('La expresión está incompleta.');
    if (tk.t === 'n') {
      p++;
      return tk.v;
    }
    if (tk.t === '(') {
      p++;
      if (++depth > 40) fail('Demasiados paréntesis anidados.');
      const v = expr();
      if (!eat(')')) fail('Falta cerrar un paréntesis.');
      depth--;
      return v;
    }
    if (tk.t === 'id') {
      p++;
      if (eat('(')) {
        const args = [];
        if (!eat(')')) {
          do args.push(expr());
          while (eat(','));
          if (!eat(')')) fail('Falta cerrar el paréntesis de la función.');
        }
        const f = FUNCS[tk.v];
        if (!f) fail(`Función desconocida: ${tk.v}. Disponibles: ${Object.keys(FUNCS).join(', ')}.`);
        const [arity, fn] = f;
        if (arity >= 0 ? args.length !== arity : args.length < 1 || args.length > -arity * (arity === -1 ? 50 : 1)) fail(`La función ${tk.v} recibe una cantidad de argumentos distinta.`);
        const r = fn(...args);
        if (Number.isNaN(r)) fail(`${tk.v} no tiene resultado para esos valores.`);
        return r;
      }
      if (tk.v in CONSTS) return CONSTS[tk.v];
      fail(`No entiendo «${tk.v}». Constantes: pi, e. Funciones: ${Object.keys(FUNCS).join(', ')}.`);
    }
    fail(`Se esperaba un número y apareció «${tk.t}».`);
  }
  const v = expr();
  if (p < toks.length) fail(`Sobra algo al final de la expresión («${toks[p].t === 'n' ? toks[p].v : toks[p].t === 'id' ? toks[p].v : toks[p].t}»).`);
  return v;
}

// ── Porcentajes ─────────────────────────────────────────────────────────────────────────────────
function porcentajes(a) {
  const accion = String(a.accion || '');
  switch (accion) {
    case 'parte': {
      const base = num(a.base, 'base'), pct = num(a.porcentaje, 'porcentaje');
      return `${fmt(pct)}% de ${fmt(base)} = ${fmt((base * pct) / 100)}`;
    }
    case 'aumentar': {
      const base = num(a.base, 'base'), pct = num(a.porcentaje, 'porcentaje');
      const extra = (base * pct) / 100;
      return `${fmt(base)} + ${fmt(pct)}% = ${fmt(base + extra)} (el aumento es ${fmt(extra)})`;
    }
    case 'descontar': {
      const base = num(a.base, 'base'), pct = num(a.porcentaje, 'porcentaje');
      const menos = (base * pct) / 100;
      return `${fmt(base)} − ${fmt(pct)}% = ${fmt(base - menos)} (el descuento es ${fmt(menos)})`;
    }
    case 'quitar_incluido': {
      const total = num(a.base, 'base'), pct = num(a.porcentaje, 'porcentaje');
      if (pct <= -100) fail('El porcentaje debe ser mayor que -100.');
      const neto = total / (1 + pct / 100);
      return `Si ${fmt(total)} ya incluye ${fmt(pct)}%, el valor sin ese porcentaje es ${fmt(neto)} (el porcentaje incluido es ${fmt(total - neto)})`;
    }
    case 'variacion': {
      const antes = num(a.antes, 'antes'), despues = num(a.despues, 'despues');
      if (antes === 0) fail('No se puede calcular una variación porcentual desde 0.');
      const v = ((despues - antes) / Math.abs(antes)) * 100;
      return `De ${fmt(antes)} a ${fmt(despues)}: ${v >= 0 ? 'sube' : 'baja'} ${fmt(Math.abs(v))}% (${v >= 0 ? '+' : '−'}${fmt(Math.abs(despues - antes))})`;
    }
    case 'que_porcentaje_es': {
      const parte = num(a.parte, 'parte'), total = num(a.total, 'total');
      if (total === 0) fail('El total no puede ser 0.');
      return `${fmt(parte)} es el ${fmt((parte / total) * 100)}% de ${fmt(total)}`;
    }
    default:
      fail('Acción desconocida. Usa: parte, aumentar, descontar, quitar_incluido, variacion o que_porcentaje_es.');
  }
}

// ── Fechas (siempre en UTC para que el horario de verano no mueva un día) ───────────────────────
const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
function parseDate(v, name) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v ?? '').trim());
  if (!m) fail(`«${name}» debe tener el formato AAAA-MM-DD (por ejemplo 2026-03-15).`);
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const date = new Date(Date.UTC(y, mo - 1, d));
  if (date.getUTCFullYear() !== y || date.getUTCMonth() !== mo - 1 || date.getUTCDate() !== d) fail(`«${name}» no es una fecha real (${v}).`);
  return date;
}
const iso = d => `${String(d.getUTCFullYear()).padStart(4, '0')}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
const nice = d => `${DIAS[d.getUTCDay()]} ${d.getUTCDate()} de ${MESES[d.getUTCMonth()]} de ${d.getUTCFullYear()}`;
const DAY = 86400000;
function addMonths(d, n) {
  const y = d.getUTCFullYear(), m = d.getUTCMonth() + n, day = d.getUTCDate();
  const last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  return new Date(Date.UTC(y, m, Math.min(day, last)));
}
function businessDaysBetween(a, b) {
  // cuenta los días hábiles (lunes a viernes) desde a (sin contarlo) hasta b (contándolo)
  let n = 0;
  const step = a <= b ? 1 : -1;
  for (let t = a.getTime() + step * DAY; step > 0 ? t <= b.getTime() : t >= b.getTime(); t += step * DAY) {
    const wd = new Date(t).getUTCDay();
    if (wd !== 0 && wd !== 6) n += step;
  }
  return n;
}
function fechas(a) {
  const accion = String(a.accion || '');
  if (accion === 'dia_semana') {
    const d = parseDate(a.fecha, 'fecha');
    return `${iso(d)} es ${nice(d)}`;
  }
  if (accion === 'diferencia') {
    const d1 = parseDate(a.desde, 'desde'), d2 = parseDate(a.hasta, 'hasta');
    const days = Math.round((d2 - d1) / DAY);
    const [lo, hi] = d1 <= d2 ? [d1, d2] : [d2, d1];
    let months = (hi.getUTCFullYear() - lo.getUTCFullYear()) * 12 + (hi.getUTCMonth() - lo.getUTCMonth());
    if (addMonths(lo, months) > hi) months--;
    const rest = Math.round((hi - addMonths(lo, months)) / DAY);
    const sign = days < 0 ? 'hacia atrás ' : '';
    const n = (k, one, many) => `${k} ${k === 1 ? one : many}`;
    const ad = Math.abs(days);
    return `Entre ${iso(d1)} (${DIAS[d1.getUTCDay()]}) y ${iso(d2)} (${DIAS[d2.getUTCDay()]}) hay ${sign}${n(ad, 'día', 'días')} = ${n(Math.trunc(ad / 7), 'semana', 'semanas')} y ${n(ad % 7, 'día', 'días')} = ${n(Math.trunc(months / 12), 'año', 'años')}, ${n(months % 12, 'mes', 'meses')} y ${n(rest, 'día', 'días')}. Días hábiles (lunes a viernes, sin considerar feriados): ${Math.abs(businessDaysBetween(d1, d2))}.`;
  }
  if (accion === 'sumar') {
    let d = parseDate(a.fecha, 'fecha');
    const dias = a.dias == null ? 0 : num(a.dias, 'dias'), meses = a.meses == null ? 0 : num(a.meses, 'meses'), anios = a.anios == null ? 0 : num(a.anios, 'anios');
    if (![dias, meses, anios].every(Number.isInteger)) fail('«dias», «meses» y «anios» deben ser números enteros (pueden ser negativos).');
    if (Math.abs(dias) > 200000 || Math.abs(meses) > 12000 || Math.abs(anios) > 1000) fail('Ese desplazamiento es demasiado grande.');
    d = addMonths(d, meses + anios * 12);
    d = new Date(d.getTime() + dias * DAY);
    if (d.getUTCFullYear() < 1 || d.getUTCFullYear() > 9999) fail('La fecha resultante queda fuera de rango.');
    return `${iso(d)} (${nice(d)})`;
  }
  if (accion === 'dias_habiles') {
    let d = parseDate(a.fecha, 'fecha');
    const n = num(a.dias, 'dias');
    if (!Number.isInteger(n) || Math.abs(n) > 20000) fail('«dias» debe ser un entero (positivo o negativo) de hasta 20000.');
    const step = n >= 0 ? 1 : -1;
    for (let left = Math.abs(n); left > 0; ) {
      d = new Date(d.getTime() + step * DAY);
      const wd = d.getUTCDay();
      if (wd !== 0 && wd !== 6) left--;
    }
    return `${iso(d)} (${nice(d)}) — ${Math.abs(n)} días hábiles ${n >= 0 ? 'después' : 'antes'} de ${a.fecha}, de lunes a viernes y sin considerar feriados.`;
  }
  fail('Acción desconocida. Usa: diferencia, sumar, dia_semana o dias_habiles.');
}

// ── Unidades ────────────────────────────────────────────────────────────────────────────────────
// Cada grupo tiene una unidad base y el factor para llegar a ella (la temperatura se trata aparte).
const UNITS = {
  longitud: { base: 'm', f: { mm: 0.001, cm: 0.01, m: 1, km: 1000, in: 0.0254, ft: 0.3048, yd: 0.9144, mi: 1609.344 } },
  masa: { base: 'kg', f: { mg: 1e-6, g: 0.001, kg: 1, t: 1000, oz: 0.028349523125, lb: 0.45359237 } },
  volumen: { base: 'l', f: { ml: 0.001, l: 1, m3: 1000, tsp: 0.00492892159375, tbsp: 0.01478676478125, floz: 0.0295735295625, cup: 0.2365882365, gal: 3.785411784 } },
  tiempo: { base: 's', f: { s: 1, min: 60, h: 3600, dia: 86400, semana: 604800 } },
  area: { base: 'm2', f: { cm2: 0.0001, m2: 1, ha: 10000, km2: 1e6, ft2: 0.09290304, acre: 4046.8564224 } },
  velocidad: { base: 'm/s', f: { 'm/s': 1, 'km/h': 1 / 3.6, mph: 0.44704, nudo: 0.514444444444 } },
  datos: { base: 'b', f: { b: 1, kb: 1e3, mb: 1e6, gb: 1e9, tb: 1e12, kib: 1024, mib: 1048576, gib: 1073741824, tib: 1099511627776 } }
};
const ALIAS = { pulgada: 'in', pulgadas: 'in', pie: 'ft', pies: 'ft', milla: 'mi', millas: 'mi', yarda: 'yd', yardas: 'yd', metro: 'm', metros: 'm', kilometro: 'km', kilometros: 'km', libra: 'lb', libras: 'lb', onza: 'oz', onzas: 'oz', gramo: 'g', gramos: 'g', kilo: 'kg', kilos: 'kg', litro: 'l', litros: 'l', galon: 'gal', galones: 'gal', tonelada: 't', segundo: 's', segundos: 's', minuto: 'min', minutos: 'min', hora: 'h', horas: 'h', dias: 'dia', 'día': 'dia', 'días': 'dia', semanas: 'semana', 'celsius': 'c', 'fahrenheit': 'f', 'kelvin': 'k', '°c': 'c', '°f': 'f', mph: 'mph', nudos: 'nudo', 'km/hr': 'km/h', kph: 'km/h', hectarea: 'ha', 'hectárea': 'ha', 'hectáreas': 'ha', hectareas: 'ha' };
const TEMPS = new Set(['c', 'f', 'k']);
const unitKey = u => {
  const k = String(u ?? '').trim().toLowerCase();
  return ALIAS[k] || k;
};
function toCelsius(v, u) {
  return u === 'c' ? v : u === 'f' ? ((v - 32) * 5) / 9 : v - 273.15;
}
function fromCelsius(v, u) {
  return u === 'c' ? v : u === 'f' ? (v * 9) / 5 + 32 : v + 273.15;
}
function convertir(a) {
  const valor = num(a.valor, 'valor');
  const from = unitKey(a.desde), to = unitKey(a.hasta);
  if (TEMPS.has(from) || TEMPS.has(to)) {
    if (!(TEMPS.has(from) && TEMPS.has(to))) fail('Una temperatura solo se convierte a otra temperatura (c, f, k).');
    const c = toCelsius(valor, from);
    if (c < -273.15 - 1e-9) fail('Esa temperatura está por debajo del cero absoluto.');
    return `${fmt(valor)} ${from.toUpperCase()} = ${fmt(fromCelsius(c, to))} ${to.toUpperCase()}`;
  }
  const group = Object.values(UNITS).find(g => from in g.f && to in g.f);
  if (!group) {
    const known = Object.entries(UNITS).map(([g, x]) => `${g}: ${Object.keys(x.f).join(', ')}`).join(' · ');
    fail(`No sé convertir «${a.desde}» a «${a.hasta}» (o son de tipos distintos). Unidades — ${known} · temperatura: c, f, k.`);
  }
  return `${fmt(valor)} ${from} = ${fmt((valor * group.f[from]) / group.f[to])} ${to}`;
}

// ── MCP ─────────────────────────────────────────────────────────────────────────────────────────
const NUM = { type: 'number', description: 'Número con punto decimal y sin separador de miles.' };
const TOOLS = [
  {
    name: 'calcular',
    description: 'Calcula una expresión matemática: + − * / ^, paréntesis, constantes pi y e, y funciones sqrt, abs, round(x, decimales), floor, ceil, min, max, pow, ln, log10, exp, sin, cos, tan. Decimales con punto, sin separador de miles. Resultado redondeado a 12 decimales.',
    inputSchema: { type: 'object', properties: { expresion: { type: 'string', description: 'Ejemplo: (1250 + 340) * 0.19' } }, required: ['expresion'] }
  },
  {
    name: 'porcentajes',
    description: 'Porcentajes: parte (p% de base), aumentar, descontar, quitar_incluido (valor sin un % ya incluido, p. ej. neto sin IVA), variacion (de antes a después) y que_porcentaje_es (parte de un total).',
    inputSchema: {
      type: 'object',
      properties: { accion: { type: 'string', enum: ['parte', 'aumentar', 'descontar', 'quitar_incluido', 'variacion', 'que_porcentaje_es'] }, base: NUM, porcentaje: NUM, antes: NUM, despues: NUM, parte: NUM, total: NUM },
      required: ['accion']
    }
  },
  {
    name: 'fechas',
    description: 'Fechas (AAAA-MM-DD): diferencia entre dos fechas, sumar días/meses/años, día de la semana y días hábiles (lunes a viernes, sin considerar feriados).',
    inputSchema: {
      type: 'object',
      properties: { accion: { type: 'string', enum: ['diferencia', 'sumar', 'dia_semana', 'dias_habiles'] }, fecha: { type: 'string' }, desde: { type: 'string' }, hasta: { type: 'string' }, dias: { type: 'integer' }, meses: { type: 'integer' }, anios: { type: 'integer' } },
      required: ['accion']
    }
  },
  {
    name: 'convertir_unidades',
    description: 'Convierte entre unidades de longitud, masa, volumen, tiempo, área, velocidad, datos y temperatura (c, f, k).',
    inputSchema: { type: 'object', properties: { valor: NUM, desde: { type: 'string', description: 'Ejemplo: km' }, hasta: { type: 'string', description: 'Ejemplo: mi' } }, required: ['valor', 'desde', 'hasta'] }
  }
];
function callTool(name, args) {
  const a = args && typeof args === 'object' ? args : {};
  if (name === 'calcular') {
    const r = evaluate(a.expresion);
    return `${String(a.expresion).trim()} = ${fmt(r)}`;
  }
  if (name === 'porcentajes') return porcentajes(a);
  if (name === 'fechas') return fechas(a);
  if (name === 'convertir_unidades') return convertir(a);
  fail(`No existe la herramienta «${name}».`);
}

const send = msg => process.stdout.write(`${JSON.stringify(msg)}\n`);
function handle(msg) {
  const { id, method, params } = msg;
  const reply = result => id !== undefined && id !== null && send({ jsonrpc: '2.0', id, result });
  const error = (code, message) => id !== undefined && id !== null && send({ jsonrpc: '2.0', id, error: { code, message } });
  try {
    if (method === 'initialize') return reply({ protocolVersion: params?.protocolVersion || '2025-06-18', capabilities: { tools: {} }, serverInfo: SERVER });
    if (method === 'ping') return reply({});
    if (method === 'tools/list') return reply({ tools: TOOLS });
    if (method === 'tools/call') {
      try {
        return reply({ content: [{ type: 'text', text: callTool(String(params?.name || ''), params?.arguments) }] });
      } catch (e) {
        if (e instanceof UserError) return reply({ isError: true, content: [{ type: 'text', text: e.message }] });
        throw e;
      }
    }
    if (typeof method === 'string' && method.startsWith('notifications/')) return undefined;
    return error(-32601, `Método no soportado: ${method}`);
  } catch (e) {
    return error(-32603, 'Error interno del servidor de cálculo.');
  }
}

const rl = createInterface({ input: process.stdin });
rl.on('line', line => {
  const text = line.trim();
  if (!text) return;
  let msg;
  try {
    msg = JSON.parse(text);
  } catch {
    return send({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'JSON no válido.' } });
  }
  if (msg && typeof msg === 'object') handle(msg);
});
rl.on('close', () => process.exit(0));
