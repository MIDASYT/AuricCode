---
id: plan-de-estudio
name: Plan de estudio
description: Arma un plan de estudio realista con bloques de tiempo, repaso espaciado y simulacros, según la fecha del examen y las horas disponibles.
triggers: [plan de estudio, plan para estudiar, calendario de estudio, preparar el examen, preparar la prueba, cómo estudiar para, como estudiar para]
markers: []
tags: [estudio, planificación]
---
## Lo que necesitas saber (pregunta lo que falte, todo junto)
- Qué se va a evaluar y qué temas incluye.
- Fecha del examen y cuántas horas por día o semana puede dedicar la persona.
- Cómo está hoy: qué domina y qué le cuesta.

## Cómo armar el plan
1. Divide los temas en bloques y dale más tiempo a lo más débil y a lo que más pesa en la nota.
2. Bloques de estudio de 25–50 minutos con pausas cortas; no más de 4 bloques seguidos.
3. **Repaso espaciado**: repasar cada tema a los 1, 3 y 7 días de verlo por primera vez.
4. Practicar recordando sin mirar (preguntas, tarjetas, ejercicios) en vez de solo releer.
5. Un simulacro completo en el último tramo, con el tiempo real del examen, y un día final liviano.
6. Deja 10–15 % de holgura para imprevistos.

## Entrega
Una tabla por semana (*Día · Tema · Qué hacer · Tiempo*) y las reglas de ajuste: qué hacer si se atrasa un día. Si el tiempo no alcanza, dilo y propone qué priorizar. Cuenta los días con exactitud (puede usar un cálculo de fechas si hay uno disponible).
