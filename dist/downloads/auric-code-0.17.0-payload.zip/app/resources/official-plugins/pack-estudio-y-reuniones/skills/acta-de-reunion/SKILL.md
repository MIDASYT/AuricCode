---
id: acta-de-reunion
name: Acta de reunión
description: Convierte apuntes o una transcripción en un acta clara con decisiones, tareas, responsables y plazos.
triggers: [acta de reunión, acta de reunion, acta de la reunión, minuta de reunión, minuta de reunion, resumen de la reunión, resumen de la reunion, transcripción de la reunión]
markers: []
tags: [reuniones]
---
## Estructura del acta
1. **Datos**: fecha, hora, lugar o enlace, asistentes y quién tomó el acta (solo los que aparezcan en el material).
2. **Objetivo** de la reunión en una frase.
3. **Resumen** de lo hablado: 3–6 viñetas, en orden del temario.
4. **Decisiones tomadas**: una línea cada una, con quién la tomó si se sabe.
5. **Tareas**: tabla con *Tarea · Responsable · Fecha límite · Estado*.
6. **Pendientes y dudas** que quedaron abiertas.
7. **Próxima reunión**, si se acordó.

## Reglas
- Usa solo lo que está en los apuntes. Si falta el responsable o la fecha de una tarea, escribe «por definir» y avísalo al final; no los inventes.
- Distingue lo acordado de lo que solo se comentó. Una opinión no es una decisión.
- Redacta en tercera persona y en tiempo pasado para lo hablado, y en infinitivo para las tareas («Enviar la cotización»).
- Si el material es una transcripción larga, sintetiza: el acta no es la transcripción.
- Ofrece generar el acta como documento Word o PDF si la persona la va a enviar.
