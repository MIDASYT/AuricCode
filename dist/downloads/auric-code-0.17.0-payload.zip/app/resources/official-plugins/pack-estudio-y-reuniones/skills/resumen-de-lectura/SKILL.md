---
id: resumen-de-lectura
name: Resumen de lectura
description: Resume artículos, capítulos o apuntes en tres niveles (una frase, un párrafo y un esquema) conservando las ideas y los datos clave.
triggers: [resume este texto, resumen del capítulo, resumen del artículo, resumir el artículo, resumen de lectura, resumir este documento, ideas principales]
markers: []
tags: [estudio, resumen]
---
## Cómo resumir
Entrega siempre, en este orden:
1. **En una frase**: de qué trata y cuál es su idea central.
2. **En un párrafo**: el argumento completo, con el «porque» de las conclusiones.
3. **Esquema**: ideas principales con sus subideas (máximo dos niveles) y los datos o fechas que importan.
4. **Términos clave**: 4–8 conceptos con una definición breve, tal como los usa el texto.
5. **Preguntas para pensar**: 2–3 preguntas que ayuden a comprobar si se entendió.

## Reglas
- Resume solo lo que dice el texto; no agregues información de afuera sin marcarla como tal.
- Conserva cifras, nombres y fechas exactos. Si el texto es ambiguo, di que lo es.
- Si el texto es largo y se recortó al leerlo, avisa qué parte no se leyó.
- Pregunta para qué lo necesita (estudiar, decidir, citar) solo si el resultado cambiaría mucho.
