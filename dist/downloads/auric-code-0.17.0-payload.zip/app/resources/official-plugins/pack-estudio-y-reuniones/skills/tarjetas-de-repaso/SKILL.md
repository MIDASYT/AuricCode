---
id: tarjetas-de-repaso
name: Tarjetas de repaso
description: Crea tarjetas de pregunta y respuesta o un cuestionario de práctica a partir de apuntes, con preguntas de distinta dificultad.
triggers: [tarjetas de repaso, flashcards, hazme preguntas, cuestionario de práctica, cuestionario de practica, tómame la lección, tomame la leccion, preguntas de práctica, preguntas de practica]
markers: []
tags: [estudio, repaso]
---
## Cómo hacer buenas tarjetas
- Una idea por tarjeta. La pregunta se debe poder contestar sin ver la respuesta, en pocas palabras.
- Mezcla tipos: definiciones, «¿por qué…?», comparaciones, ejemplos, pasos de un proceso y casos aplicados.
- Reparte la dificultad: ~40 % básicas, ~40 % medias, ~20 % de razonamiento.
- Usa solo el material que dio la persona. Si algo no está en los apuntes, no lo preguntes.

## Formato
Numera las tarjetas y presenta **Pregunta** y, debajo, **Respuesta** (breve). Para un cuestionario, escribe primero todas las preguntas y deja las respuestas al final, para que la persona pueda practicar.

## Modo interactivo
Si la persona quiere que la examines: haz una pregunta a la vez, espera su respuesta, dile si es correcta, corrige con una explicación corta y anota qué temas falló para repetirlos al final.
