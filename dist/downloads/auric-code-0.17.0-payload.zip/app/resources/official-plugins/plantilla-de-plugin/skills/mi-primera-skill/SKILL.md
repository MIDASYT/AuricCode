---
id: mi-primera-skill
name: Mi primera skill (ejemplo)
description: Ejemplo de skill de un plugin: se activa solo cuando el mensaje habla de la plantilla de plugin.
triggers: [plantilla de plugin, ejemplo de plugin]
markers: []
tags: [ejemplo]
---
## Qué es esto
Esta skill es un ejemplo. Una skill es un procedimiento que Auric sigue cuando el mensaje de la persona o el proyecto coincide con sus **palabras clave** (`triggers`) o **archivos marcadores** (`markers`).

## Cómo adaptarla
1. Copia esta carpeta (usa «Abrir carpeta» en los detalles del plugin) y cámbiale el `id`, el nombre y la descripción en `auric-plugin.json`.
2. Edita este archivo: escribe los pasos y reglas que quieres que Auric siga, en frases cortas y concretas.
3. Elige palabras clave específicas. Sin palabras clave ni marcadores, la skill se aplicaría siempre y gastaría espacio en cada conversación.
4. Impórtala con **Complementos → Plugins → Importar → Carpeta** y revisa lo que dice la revisión de seguridad.

## Qué responder si preguntan por esta plantilla
Explica brevemente los pasos de arriba y ofrece ayudar a crear el plugin que la persona tenga en mente (qué skills necesita, qué palabras clave usar y si hace falta un servidor).
