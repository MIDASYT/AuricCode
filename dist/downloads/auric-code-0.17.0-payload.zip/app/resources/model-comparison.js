const valid = n => n != null && Number.isFinite(Number(n));
export function benchmarkTitle(b) {
  if (!b) return 'Sin evaluación de Artificial Analysis para esta variante.';
  const date = String(b.fetchedAt || '').slice(0, 10);
  return `Artificial Analysis · índice v${b.version || '?'} · ${b.source === 'live' ? 'Actualizado' : 'Copia incluida'} ${date}`;
}
export function comparisonPanel(b, esc, speedMax = 200) {
  if (!b || (!valid(b.index) && !valid(b.speed))) return '';
  const metric = (label, value, reference, units) => {
    if (!valid(value)) return '';
    const amount = Math.max(0, Math.min(10, Math.round(Number(value) / reference * 10)));
    const formatted = Number(value).toLocaleString('es', { maximumFractionDigits: 1 });
    const title = `${label}: ${formatted}${units}. ${benchmarkTitle(b)}. Escala visual hasta ${reference}${units}.`;
    return `<div class="model-metric" title="${esc(title)}"><span>${esc(label)}</span><i aria-hidden="true">${Array.from({ length: 10 }, (_, i) => `<b class="${i < amount ? 'on' : ''}"></b>`).join('')}</i><small>${esc(formatted + units)}</small></div>`;
  };
  return `<div class="model-bench" aria-label="Comparación de Artificial Analysis">${metric('Calidad AA', b.index, 100, '')}${metric('Velocidad', b.speed, Math.max(200, speedMax), ' t/s')}</div>`;
}
