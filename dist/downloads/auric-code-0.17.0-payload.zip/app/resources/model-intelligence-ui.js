export async function renderModelIntelligence(host, { D, esc, update, state, saveState }) {
  host.innerHTML = '<h4>Modelos al día</h4><p class="desc">Consultando la copia guardada…</p>';
  const response = await D.modelIntel.status();
  if (!response.ok) { host.textContent = response.error; return; }
  const data = response.value, date = value => value ? new Date(value).toLocaleString() : 'Pendiente de actualización';
  host.innerHTML = `<h4>Modelos al día</h4><p class="desc">Las recomendaciones combinan calidad, velocidad y cupo disponible. Se renuevan en segundo plano al iniciar la app y cuando caduca la copia diaria.</p>
    <div class="settings-section"><label><input type="checkbox" id="intelEnabled" ${data.enabled ? 'checked' : ''}> Actualizar datos automáticamente</label><p class="desc">Se consultan catálogos y evaluaciones. No se envían tus conversaciones ni se gastan peticiones de tus modelos para evaluarlos.</p><p>Catálogo · ${esc(date(data.updatedAt))}<br>${data.catalog.length} modelos y rutas</p><p>Artificial Analysis · ${esc(date(data.aaUpdatedAt))}<br>${data.benchmarks.length} evaluaciones guardadas</p>${!data.aaConfigured ? '<p class="desc">Mientras el servicio central se configura o recupera conexión, se usa la última información disponible.</p>' : ''}</div>
    <div class="settings-section"><label><input id="preferFreeRecommendations" type="checkbox" ${state.settings.freeRecommendations !== false ? 'checked' : ''}> Priorizar modelos gratis cuando los haya</label><p class="desc">Calidad, Rápido y Cupo amplio señalan ventajas diferentes. Las barras muestran las mediciones publicadas; sin medición se elige por capacidades declaradas.</p><button class="primary-btn" id="refreshIntel">Actualizar datos</button><p id="intelResult" aria-live="polite">${esc((data.errors || []).map(x => x.message).join(' '))}</p></div>
    <p class="desc">Fuentes: <a href="https://artificialanalysis.ai/" id="aaAttribution">Artificial Analysis</a> y <a href="https://models.dev/" id="modelsAttribution">models.dev</a>. La velocidad observada depende de tu conexión y del proveedor. Gratis no significa ilimitado.</p>`;
  const result = host.querySelector('#intelResult');
  const invoke = async fn => { try { const r = await fn(); if (!r.ok) throw new Error(r.error); update(r.value); result.textContent = r.value.errors?.length ? r.value.errors.map(x=>x.message).join(' ') : 'Datos guardados.'; } catch (error) { result.textContent = error.message; } };
  host.querySelector('#intelEnabled').onchange = e => invoke(() => D.modelIntel.configure({ enabled: e.target.checked }));
  host.querySelector('#preferFreeRecommendations').onchange = async e => { state.settings.freeRecommendations = e.target.checked; await saveState(); };
  host.querySelector('#refreshIntel').onclick = async e => { e.target.disabled = true; result.textContent = 'Consultando fuentes…'; await invoke(() => D.modelIntel.refresh(true)); e.target.disabled = false; };
  for (const [id, url] of [['aaAttribution', 'https://artificialanalysis.ai/'], ['modelsAttribution', 'https://models.dev/']]) host.querySelector('#' + id).onclick = e => { e.preventDefault(); D.openExternal(url); };
}
