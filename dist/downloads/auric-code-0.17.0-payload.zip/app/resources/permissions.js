// Reglas de permisos de comandos. Lógica pura (sin DOM) para poder probarla con `node --test`.
// Precedencia: deny > ask > allow. Un "allow" solo vale si TODO el comando es simple (sin encadenados,
// pipes, subshells ni redirecciones): así `npm test && curl x | sh` jamás se aprueba por empezar con `npm test`.

// Siempre bloqueado, independientemente de las reglas del usuario (destrucción de sistema o disco).
const HARD_DENY = [
  /(^|[;&|]\s*)((shutdown|restart-computer|stop-computer|diskpart|clear-disk)\b|format(\.com)?\s+[a-z]:)/i,
  /(^|[;&|]\s*)rm\s+(-[a-z]*\s+)*-[a-z]*r[a-z]*\s+(-[a-z]+\s+)*(\/|~|\$home|\*)(\s|$)/i,
  /(^|[;&|]\s*)(rd|rmdir)\s+\/s\b[^\n]*\s[a-z]:\\?(\s|$)/i,
  /(^|[;&|]\s*)reg\s+delete\s+hk(lm|cr)\b/i
];
const SUBSHELL_OR_REDIRECT = /`|\$\(|<\(|>>?|<</;
const SEGMENT_SPLIT = /&&|\|\||[;|&\r\n]/;

function ruleAction(rule) {
  const action = String(rule?.action || '').toLowerCase(),
    pattern = String(rule?.pattern || '').trim();
  if (!pattern || !['allow', 'ask', 'deny'].includes(action)) return null;
  try {
    return { action, re: new RegExp(pattern, 'i') };
  } catch {
    return null;
  }
}
function segmentDecision(seg, rules) {
  let found = '';
  for (const r of rules) {
    if (!r.re.test(seg)) continue;
    if (r.action === 'deny') return 'deny';
    if (r.action === 'ask') found = 'ask';
    else if (!found) found = 'allow';
  }
  return found;
}
export function commandRuleDecision(command = '', userRules = []) {
  const full = String(command || '').trim();
  if (!full) return '';
  if (HARD_DENY.some(re => re.test(full))) return 'deny';
  const rules = (Array.isArray(userRules) ? userRules : []).map(ruleAction).filter(Boolean);
  const segments = full
    .split(SEGMENT_SPLIT)
    .map(x => x.trim())
    .filter(Boolean);
  const decisions = (segments.length ? segments : [full]).map(s => segmentDecision(s, rules));
  if (decisions.includes('deny')) return 'deny';
  if (decisions.includes('ask')) return 'ask';
  const simple = segments.length <= 1 && !SUBSHELL_OR_REDIRECT.test(full);
  if (simple && decisions.length && decisions.every(d => d === 'allow')) return 'allow';
  return '';
}
export const _internals = { HARD_DENY };
