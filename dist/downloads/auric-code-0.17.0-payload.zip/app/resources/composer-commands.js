// Ayudas del cuadro de escribir: «@» (archivos y carpetas del proyecto) y «/» (comandos).
//
// Aquí vive la lógica (que se prueba sin pantalla) y el desplegable que aparece sobre el cuadro de texto.
// Reglas que este archivo respeta:
//  · «@» solo PROPONE una referencia: escribe «@ruta» en el mensaje y, al enviar, deja que el modelo CONSULTE ese archivo o carpeta.
//    Nunca es una orden de modificar nada.
//  · «/» solo ejecuta acciones de la propia aplicación (cambiar de chat, de modelo, de modo…). Ningún comando envía un mensaje al modelo.
//  · Los nombres de archivo son datos no confiables: se escriben siempre con textContent, nunca como HTML.
//  · Las referencias solo pueden apuntar DENTRO de las carpetas de trabajo (se rechazan «..», «C:\», «/x», «~» y «:»).

export const MAX_MENTIONS = 8;
export const FOLDER_NOTE_ENTRIES = 80;
export const MENTION_TEXT_CHARS = 40000;
export const SUGGEST_LIMIT = 40;

export const foldText = s =>
  String(s ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();

// ───────────────────────── Coincidencias ─────────────────────────

// Puntaje de coincidencia (0 = no coincide). Prefiere: igual > empieza por > palabra que empieza por > contiene > letras en orden.
export function scoreMatch(query, text) {
  const q = foldText(query).trim(),
    t = foldText(text);
  if (!q) return 1;
  if (!t) return 0;
  if (t === q) return 1000;
  if (t.startsWith(q)) return 800 - Math.min(t.length - q.length, 200) / 10;
  const idx = t.indexOf(q);
  if (idx >= 0) {
    const wordStart = /[\s/\\._\-]/.test(t[idx - 1] || ' ');
    return (wordStart ? 600 : 400) - Math.min(idx, 200) / 10 - Math.min(t.length - q.length, 200) / 100;
  }
  let at = 0,
    gaps = 0;
  for (const ch of q) {
    const j = t.indexOf(ch, at);
    if (j < 0) return 0;
    gaps += j - at;
    at = j + 1;
  }
  return Math.max(1, 200 - Math.min(gaps, 190));
}

export function scoreEntry(query, entry) {
  const q = String(query ?? '').trim();
  if (!q) return 1;
  const byPath = scoreMatch(q.replace(/\\/g, '/'), entry.label || entry.rel),
    byName = q.includes('/') ? 0 : scoreMatch(q, entry.name) * 2,
    best = Math.max(byName, byPath);
  return best > 0 && entry.dir ? best + 3 : best; // a igualdad, las carpetas primero; sin coincidencia no hay bonus
}

export function filterFiles(entries, query, limit = SUGGEST_LIMIT) {
  const list = Array.isArray(entries) ? entries : [];
  if (!String(query ?? '').trim()) {
    return list
      .filter(e => e.depth === 0)
      .sort((a, b) => (a.dir === b.dir ? a.name.localeCompare(b.name) : a.dir ? -1 : 1))
      .concat(
        list
          .filter(e => e.depth === 1)
          .sort((a, b) => a.label.localeCompare(b.label))
          .slice(0, 20)
      )
      .slice(0, limit);
  }
  const scored = [];
  for (const e of list) {
    const s = scoreEntry(query, e);
    if (s > 0) scored.push([s, e]);
  }
  scored.sort((a, b) => b[0] - a[0] || a[1].label.length - b[1].label.length || a[1].label.localeCompare(b[1].label));
  return scored.slice(0, limit).map(x => x[1]);
}

// ───────────────────────── Qué se está escribiendo ─────────────────────────

// ¿El cursor está dentro de un «@archivo» o de un «/comando»? Devuelve null si no.
// opts.textCommands: nombres de comandos cuyo argumento es texto libre (por ejemplo «plan»): ahí también se puede usar «@».
export function detectTrigger(value, caret, opts = {}) {
  const text = String(value ?? ''),
    pos = Math.max(0, Math.min(Number.isFinite(caret) ? caret : text.length, text.length)),
    head = text.slice(0, pos);
  if (head.startsWith('/') && !head.includes('\n')) {
    let m = /^\/([^\s/]*)$/.exec(head);
    if (m) return { kind: 'command', stage: 'name', query: m[1], start: 0, end: pos };
    m = /^\/([^\s/]+)([ \t]+)([^\n]*)$/.exec(head);
    if (m) {
      const free = opts.textCommands && opts.textCommands.has(foldText(m[1]));
      if (!free) return { kind: 'command', stage: 'arg', name: m[1], query: m[3], start: m[1].length + 1 + m[2].length, end: pos };
    } else return null;
  }
  const at = head.lastIndexOf('@');
  if (at < 0) return null;
  const prev = at === 0 ? '' : head[at - 1];
  if (prev && !/[\s(\[{"'`,;]/.test(prev)) return null; // «correo@sitio.com» no es una referencia
  const rest = head.slice(at + 1);
  if (rest.startsWith('"')) {
    const q = rest.slice(1);
    if (q.includes('"') || q.includes('\n')) return null;
    return { kind: 'mention', query: q, quoted: true, start: at, end: pos };
  }
  if (/[\s"]/.test(rest)) return null;
  return { kind: 'mention', query: rest, quoted: false, start: at, end: pos };
}

// Reemplaza lo que se estaba escribiendo por «insertion». Deja un espacio detrás si hace falta.
export function applyInsert(value, trigger, insertion, { space = true } = {}) {
  const text = String(value ?? ''),
    before = text.slice(0, trigger.start),
    after = text.slice(trigger.end),
    gap = space && (after === '' || !/^\s/.test(after)) ? ' ' : '',
    ins = String(insertion) + gap;
  return { value: before + ins + after, caret: before.length + ins.length };
}

const NEEDS_QUOTES = /[\s"'<>(){}[\],;!?]/;
export function mentionLabel(label, dir = false) {
  const body = String(label || '') + (dir && !String(label).endsWith('/') ? '/' : '');
  return '@' + (NEEDS_QUOTES.test(body) ? `"${body}"` : body);
}

// Todas las referencias «@…» que hay en un texto (al inicio o tras un espacio). Los correos no cuentan.
export function findMentions(text) {
  const src = String(text ?? ''),
    out = [],
    re = /(^|[\s(\[{"'`,;])@(?:"([^"\n]+)"|([^\s"'<>(){}[\],;!?@][^\s"'<>(){}[\],;!?]*))/g;
  let m;
  while ((m = re.exec(src))) {
    const quoted = m[2] != null;
    let body = quoted ? m[2] : m[3];
    if (!quoted) body = body.replace(/[.:]+$/, ''); // «mira @README.md.» → README.md
    if (!body) continue;
    const start = m.index + m[1].length,
      label = '@' + (quoted ? `"${body}"` : body);
    out.push({ label, rel: body, start, end: start + label.length });
  }
  return out;
}

// Ruta relativa segura (siempre dentro de la carpeta de trabajo). Devuelve '' si no es aceptable.
export function cleanRel(input) {
  const s = String(input ?? '').replace(/\\/g, '/').trim();
  if (!s || /[\u0000-\u001f\u007f]/.test(s)) return '';
  if (/^[A-Za-z]:/.test(s) || s.startsWith('/') || s.startsWith('~')) return '';
  const parts = [];
  for (const p of s.split('/')) {
    if (!p || p === '.') continue;
    if (p === '..' || /[:*?"<>|]/.test(p)) return '';
    parts.push(p);
  }
  return parts.join('/');
}

// Nombres que no se ofrecen (ni se aceptan): vacíos, con caracteres de control o con los que Windows no permite (: * ? " < > |).
const badName = n => !n || n === '.' || n === '..' || /[\u0000-\u001f\u007f:*?"<>|]/.test(n);

// ───────────────────────── Índice de archivos del proyecto ─────────────────────────

// Recorre las carpetas de trabajo a lo ancho (lo más cercano primero), sin entrar en las ignoradas y con límites de cantidad y de tiempo.
// readDir(root, rel) → [{ entry, type: 'FILE' | 'DIRECTORY' }]
export async function buildFileIndex({
  roots,
  readDir,
  ignore = new Set(),
  maxEntries = 6000,
  maxDepth = 8,
  deadlineMs = 2500,
  concurrency = 8,
  now = () => Date.now()
}) {
  const started = now(),
    entries = [],
    multi = roots.length > 1;
  let truncated = false;
  outer: for (const root of roots) {
    const queue = [{ rel: '', depth: 0 }];
    while (queue.length) {
      if (entries.length >= maxEntries || now() - started > deadlineMs) {
        truncated = true;
        break outer;
      }
      const batch = queue.splice(0, concurrency),
        results = await Promise.all(
          batch.map(async job => {
            try {
              return { job, list: (await readDir(root, job.rel)) || [] };
            } catch {
              return { job, list: [] };
            }
          })
        );
      for (const { job, list } of results) {
        list.sort((a, b) => (a.type === b.type ? String(a.entry).localeCompare(String(b.entry)) : a.type === 'DIRECTORY' ? -1 : 1));
        for (const e of list) {
          const name = String(e.entry ?? '');
          if (ignore.has(name) || badName(name)) continue;
          const rel = job.rel ? `${job.rel}/${name}` : name,
            dir = e.type === 'DIRECTORY';
          entries.push({
            rel,
            name,
            dir,
            depth: job.depth,
            rootId: root.id,
            rootName: root.name,
            label: multi ? `${root.name}/${rel}` : rel
          });
          if (dir && job.depth + 1 < maxDepth) queue.push({ rel, depth: job.depth + 1 });
          if (entries.length >= maxEntries) {
            truncated = true;
            break outer;
          }
        }
      }
    }
  }
  return { entries, truncated, builtAt: now() };
}

// ───────────────────────── Resolver las referencias al enviar ─────────────────────────

// io: { join(rootPath, ...parts), stat(path) → {isDirectory,isFile,size}, readDir(path) → [{entry,type}] }
// Devuelve lo que existe de verdad dentro de las carpetas de trabajo. Lo que no existe se queda como texto normal.
export async function resolveMentions({ text, roots, io, ignore = new Set(), max = MAX_MENTIONS, folderEntries = FOLDER_NOTE_ENTRIES }) {
  const res = { files: [], folders: [], rejected: [], overflow: 0 },
    found = findMentions(text);
  if (!found.length || !Array.isArray(roots) || !roots.length) return res;
  const ordered = [...roots].sort((a, b) => (b.primary ? 1 : 0) - (a.primary ? 1 : 0)),
    multi = roots.length > 1,
    seen = new Set();
  for (const f of found) {
    const rel = cleanRel(f.rel);
    if (!rel) {
      res.rejected.push(f.label);
      continue;
    }
    const segs = rel.split('/'),
      candidates = [],
      byName = multi ? ordered.find(r => foldText(r.name) === foldText(segs[0])) : null;
    if (byName) candidates.push({ root: byName, rel: segs.slice(1).join('/') });
    for (const r of ordered) candidates.push({ root: r, rel });
    for (const c of candidates) {
      let abs, st;
      try {
        abs = await io.join(c.root.path, ...(c.rel ? c.rel.split('/') : []));
        st = await io.stat(abs);
      } catch {
        continue;
      }
      const key = String(abs).replace(/\\/g, '/').replace(/\/+$/, '').toLowerCase();
      if (seen.has(key)) break;
      seen.add(key);
      if (res.files.length + res.folders.length >= max) {
        res.overflow++;
        break;
      }
      const shown = c.rel || c.root.name;
      if (st.isDirectory) {
        let list = [];
        try {
          list = (await io.readDir(abs)) || [];
        } catch {}
        list = list.filter(e => !ignore.has(String(e.entry)) && !badName(String(e.entry)));
        list.sort((a, b) => (a.type === b.type ? String(a.entry).localeCompare(String(b.entry)) : a.type === 'DIRECTORY' ? -1 : 1));
        res.folders.push({
          kind: 'folder',
          label: f.label,
          rel: shown,
          rootName: c.root.name,
          path: abs,
          total: list.length,
          entries: list.slice(0, folderEntries).map(e => ({ name: String(e.entry), dir: e.type === 'DIRECTORY' }))
        });
      } else if (st.isFile) {
        res.files.push({
          kind: 'file',
          label: f.label,
          rel: shown,
          rootName: c.root.name,
          path: abs,
          name: segs[segs.length - 1],
          size: st.size
        });
      }
      break;
    }
  }
  return res;
}

// Texto que acompaña al mensaje para que el modelo sepa qué son esas referencias. Siempre aclara que son de CONSULTA.
export function mentionNotesFor({ files = [], folders = [], unsupported = [], multi = false }) {
  const where = x => (multi && x.rootName ? ` (carpeta de trabajo «${x.rootName}»)` : '');
  const notes = [];
  for (const f of files) notes.push(`Archivo ${f.rel}${where(f)}: va adjunto en este mensaje.`);
  for (const f of unsupported) notes.push(`Archivo ${f.rel}${where(f)}: ${f.why || 'no se puede leer como texto desde aquí'}.`);
  for (const d of folders) {
    const names = d.entries.map(e => (e.dir ? `${e.name}/` : e.name)).join(', '),
      more = d.total > d.entries.length ? `, … (${d.total - d.entries.length} más)` : '';
    notes.push(`Carpeta ${d.rel}${where(d)}: ${d.total} elemento${d.total === 1 ? '' : 's'}${d.total ? ` → ${names}${more}` : ' (vacía)'}.`);
  }
  return notes;
}

// ───────────────────────── Comandos «/» ─────────────────────────

export const COMMAND_DEFS = [
  { name: 'nuevo', aliases: ['new', 'n'], title: 'Nuevo chat', desc: 'Empieza una conversación nueva (en el mismo proyecto)' },
  { name: 'modelo', aliases: ['model', 'm'], title: 'Cambiar de modelo', desc: 'Abre la lista de modelos' },
  { name: 'modo', aliases: ['permisos', 'permiso'], title: 'Cambiar el modo de permisos', desc: 'chat · lectura · preguntar · guardado · completo', args: 'choice' },
  { name: 'plan', aliases: ['planificar'], title: 'Pedir un plan antes de actuar', desc: 'Prepara el mensaje; no toca nada hasta que tú lo apruebes', args: 'text' },
  { name: 'compactar', aliases: ['compact', 'resumir'], title: 'Compactar la conversación', desc: 'Resume lo antiguo para que el modelo reciba menos texto' },
  { name: 'memoria', aliases: ['memory'], title: 'Abrir la memoria', desc: 'Lo que Auric recuerda de ti y de tus proyectos' },
  { name: 'skills', aliases: ['habilidades'], title: 'Abrir las skills', desc: 'Instrucciones reutilizables que Auric puede usar' },
  { name: 'web', aliases: ['internet'], title: 'Búsqueda web', desc: 'auto · sí · no', args: 'choice' },
  { name: 'ayuda', aliases: ['help', '?'], title: 'Ayuda del chat', desc: 'Cómo usar @ y los comandos' }
];
export const TEXT_COMMANDS = new Set(COMMAND_DEFS.filter(c => c.args === 'text').map(c => c.name));

export function findCommand(word) {
  const w = foldText(word).trim();
  if (!w) return null;
  return COMMAND_DEFS.find(c => c.name === w || c.aliases.includes(w)) || null;
}
// Primero los que EMPIEZAN por lo escrito (nombre exacto, nombre, alias); después los que lo contienen en su nombre o en una palabra del título.
export function filterCommands(query) {
  const q = foldText(query).trim();
  if (!q) return [...COMMAND_DEFS];
  const rank = [],
    contains = [];
  for (const c of COMMAND_DEFS) {
    if (c.name === q) rank.push([0, c]);
    else if (c.name.startsWith(q)) rank.push([1, c]);
    else if (c.aliases.some(a => a.startsWith(q))) rank.push([2, c]);
    else if (c.name.includes(q) || c.aliases.some(a => a.includes(q)) || foldText(c.title).split(/\s+/).some(w => w.startsWith(q))) contains.push(c);
  }
  rank.sort((a, b) => a[0] - b[0]);
  return [...rank.map(x => x[1]), ...contains];
}

export const MODE_CHOICES = [
  { word: 'chat', perm: 'chat' },
  { word: 'lectura', perm: 'readonly' },
  { word: 'preguntar', perm: 'ask' },
  { word: 'guardado', perm: 'guarded' },
  { word: 'completo', perm: 'full' }
];
const MODE_WORDS = {
  chat: 'chat',
  sin: 'chat',
  conversar: 'chat',
  ninguno: 'chat',
  lectura: 'readonly',
  leer: 'readonly',
  'solo-lectura': 'readonly',
  sololectura: 'readonly',
  readonly: 'readonly',
  preguntar: 'ask',
  pregunta: 'ask',
  ask: 'ask',
  guardado: 'guarded',
  guarded: 'guarded',
  seguro: 'guarded',
  normal: 'guarded',
  peligrosas: 'guarded',
  completo: 'full',
  full: 'full',
  total: 'full'
};
export function parseMode(word) {
  const k = foldText(word).trim().replace(/\s+/g, '-');
  return Object.prototype.hasOwnProperty.call(MODE_WORDS, k) ? MODE_WORDS[k] : null;
}
export const WEB_CHOICES = [
  { word: 'auto', mode: 'auto' },
  { word: 'si', mode: 'on' },
  { word: 'no', mode: 'off' }
];
const WEB_WORDS = { auto: 'auto', automatico: 'auto', si: 'on', on: 'on', activada: 'on', no: 'off', off: 'off', desactivada: 'off' };
export function parseWeb(word) {
  const k = foldText(word).trim();
  return Object.prototype.hasOwnProperty.call(WEB_WORDS, k) ? WEB_WORDS[k] : null;
}

// Mensaje para pedir un plan sin tocar nada. Si no hay objetivo, deja el cursor justo después de «Objetivo: ».
export function planPrompt(goal) {
  const g = String(goal ?? '').trim(),
    head = 'Quiero que planifiques primero y no toques nada todavía.\n\nObjetivo: ',
    tail =
      '\n\nHaz un plan corto y claro con la herramienta set_plan. No modifiques archivos ni ejecutes comandos hasta que yo apruebe el plan. Si te falta información, pregúntamela antes.';
  return { text: head + g + tail, caret: head.length + g.length };
}

// ───────────────────────── Desplegable ─────────────────────────

const ICONS = {
  file: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>',
  folder:
    '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  command:
    '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 20 16 4"/></svg>',
  option:
    '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4 10-10"/></svg>',
  dot: '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" opacity="0.35"><circle cx="12" cy="12" r="2.5"/></svg>'
};

export function createComposerSuggest({
  input,
  host,
  getRoots,
  readDir,
  ignored = () => new Set(),
  argChoices = () => [],
  runCommand = () => {},
  sendKey = e => e.key === 'Enter' && !e.shiftKey,
  notify = () => {},
  now = () => Date.now()
}) {
  const doc = host.ownerDocument,
    TTL = 15000;
  let open = false,
    items = [],
    active = 0,
    trigger = null,
    dismissed = '',
    dismissedSlash = '', // texto «/…» que la persona decidió enviar tal cual (pulsó Escape)
    footer = '',
    index = null,
    indexKey = '',
    inflight = null;

  const rootsKey = roots => roots.map(r => r.path).join('|');
  const signature = t => (t ? `${t.kind}:${t.stage || ''}:${t.start}:${t.query}` : '');

  function ensureIndex() {
    const roots = getRoots(),
      key = rootsKey(roots);
    if (inflight && inflight.key === key) return inflight.promise;
    const promise = buildFileIndex({ roots, readDir, ignore: ignored() })
      .then(r => {
        index = r;
        indexKey = key;
        return r;
      })
      .finally(() => {
        if (inflight && inflight.promise === promise) inflight = null;
      });
    inflight = { key, promise };
    return promise;
  }
  const indexFresh = key => index && indexKey === key && now() - index.builtAt < TTL;

  function place() {
    const card = input.closest('.composer-card') || input,
      r = card.getBoundingClientRect(),
      view = doc.defaultView;
    host.style.left = `${Math.max(8, r.left)}px`;
    host.style.width = `${Math.max(240, r.width)}px`;
    host.style.bottom = `${Math.max(8, view.innerHeight - r.top + 8)}px`;
    host.style.maxHeight = `${Math.max(140, Math.min(340, r.top - 24))}px`;
  }

  function close() {
    if (!open && !host.firstChild) return;
    open = false;
    items = [];
    trigger = null;
    footer = '';
    host.classList.add('hidden');
    host.textContent = '';
    input.removeAttribute('aria-activedescendant');
    input.setAttribute('aria-expanded', 'false');
  }

  function render(title, hint) {
    host.textContent = '';
    const head = doc.createElement('div');
    head.className = 'cs-head';
    const t = doc.createElement('span');
    t.className = 'cs-title';
    t.textContent = title;
    const h = doc.createElement('span');
    h.className = 'cs-hint';
    h.textContent = hint;
    head.append(t, h);
    const list = doc.createElement('div');
    list.className = 'cs-list';
    list.setAttribute('role', 'listbox');
    list.id = 'composerSuggestList';
    items.forEach((it, i) => {
      if (it.kind === 'note') {
        const n = doc.createElement('div');
        n.className = 'cs-note';
        n.textContent = it.title;
        list.append(n);
        return;
      }
      const b = doc.createElement('button');
      b.type = 'button';
      b.className = `cs-item${i === active ? ' active' : ''}`;
      b.id = `composerSuggestItem${i}`;
      b.setAttribute('role', 'option');
      b.setAttribute('aria-selected', String(i === active));
      b.dataset.i = String(i);
      const ico = doc.createElement('span');
      ico.className = 'cs-ico';
      ico.innerHTML = ICONS[it.ico] || ICONS.file; // constante del módulo, no viene de datos
      const copy = doc.createElement('span');
      copy.className = 'cs-copy';
      const bold = doc.createElement('b');
      bold.textContent = it.title;
      copy.append(bold);
      if (it.sub) {
        const small = doc.createElement('small');
        small.textContent = it.sub;
        copy.append(small);
      }
      b.append(ico, copy);
      b.addEventListener('mousedown', e => {
        e.preventDefault(); // no quitar el foco al cuadro de texto
        accept(it);
      });
      b.addEventListener('mouseenter', () => setActive(i, false));
      list.append(b);
    });
    host.append(head, list);
    if (footer) {
      const f = doc.createElement('div');
      f.className = 'cs-foot';
      f.textContent = footer;
      host.append(f);
    }
    host.classList.remove('hidden');
    open = true;
    input.setAttribute('aria-expanded', 'true');
    input.setAttribute('aria-controls', 'composerSuggestList');
    place();
    const cur = items[active] && items[active].kind !== 'note' ? doc.getElementById(`composerSuggestItem${active}`) : null;
    if (cur) {
      input.setAttribute('aria-activedescendant', cur.id);
      cur.scrollIntoView({ block: 'nearest' });
    }
  }

  function setActive(i, scroll = true) {
    const selectable = items.map((x, n) => (x.kind === 'note' ? -1 : n)).filter(n => n >= 0);
    if (!selectable.length) return;
    if (!selectable.includes(i)) i = selectable[0];
    active = i;
    host.querySelectorAll('.cs-item').forEach(el => {
      const on = Number(el.dataset.i) === active;
      el.classList.toggle('active', on);
      el.setAttribute('aria-selected', String(on));
      if (on) {
        input.setAttribute('aria-activedescendant', el.id);
        if (scroll) el.scrollIntoView({ block: 'nearest' });
      }
    });
  }
  function move(delta) {
    const selectable = items.map((x, n) => (x.kind === 'note' ? -1 : n)).filter(n => n >= 0);
    if (!selectable.length) return;
    const at = Math.max(0, selectable.indexOf(active)),
      next = selectable[(at + delta + selectable.length) % selectable.length];
    setActive(next);
  }

  function setValue(value, caret) {
    input.value = value;
    const c = caret == null ? value.length : caret;
    try {
      input.setSelectionRange(c, c);
    } catch {}
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function run(name, arg) {
    dismissed = '';
    dismissedSlash = '';
    setValue('', 0);
    close();
    return runCommand(name, arg);
  }

  function accept(it) {
    if (!it || it.kind === 'note') return false;
    const trig = trigger;
    if (it.kind === 'file' || it.kind === 'folder') {
      if (!trig) return false;
      const r = applyInsert(input.value, trig, mentionLabel(it.data.label, it.kind === 'folder'));
      close();
      setValue(r.value, r.caret);
      input.focus();
      return true;
    }
    if (it.kind === 'command') {
      const def = it.data;
      if (def.args === 'choice') {
        setValue(`/${def.name} `, def.name.length + 2);
        update();
      } else run(def.name, '');
      return true;
    }
    if (it.kind === 'arg' && trig) {
      run(trig.name, it.data.value);
      return true;
    }
    return false;
  }

  function show(newItems, title, hint, extraFooter = '') {
    items = newItems;
    footer = extraFooter;
    const first = items.findIndex(x => x.kind !== 'note');
    active = first < 0 ? 0 : first;
    render(title, hint);
  }

  function updateMention(trig) {
    const roots = getRoots();
    if (!roots.length) {
      show(
        [{ kind: 'note', title: 'Para usar @ abre una carpeta de trabajo o elige un proyecto.' }],
        'Archivos y carpetas',
        'Esc para cerrar'
      );
      return;
    }
    const key = rootsKey(roots),
      usable = index && indexKey === key;
    if (!usable) {
      show([{ kind: 'note', title: 'Buscando archivos…' }], 'Archivos y carpetas', 'Esc para cerrar');
      ensureIndex().then(() => {
        if (trigger === trig) update();
      });
      return;
    }
    if (!indexFresh(key)) ensureIndex().then(() => update());
    const found = filterFiles(index.entries, trig.query);
    if (!found.length) {
      show([{ kind: 'note', title: 'No hay nada con ese nombre en el proyecto.' }], 'Archivos y carpetas', 'Esc para cerrar');
      return;
    }
    show(
      found.map(e => ({
        kind: e.dir ? 'folder' : 'file',
        ico: e.dir ? 'folder' : 'file',
        title: e.name + (e.dir ? '/' : ''),
        sub: e.label.includes('/') ? e.label.slice(0, e.label.length - e.name.length - 1) || '' : '',
        data: e
      })),
      'Archivos y carpetas',
      '↑↓ moverte · Enter elegir · Esc cerrar',
      index.truncated ? 'El proyecto es muy grande: se muestra solo una parte. Escribe más letras para acotar.' : ''
    );
  }

  function updateCommand(trig) {
    if (trig.stage === 'name') {
      const list = filterCommands(trig.query);
      if (!list.length) return close();
      show(
        list.map(c => ({ kind: 'command', ico: 'command', title: `/${c.name}`, sub: `${c.title} — ${c.desc}`, data: c })),
        'Comandos',
        '↑↓ moverte · Enter elegir · Esc cerrar'
      );
      return;
    }
    const def = findCommand(trig.name);
    if (!def || def.args !== 'choice') return close();
    const q = foldText(trig.query).trim(),
      options = argChoices(def.name).filter(o => !q || foldText(o.value).startsWith(q) || foldText(o.label || '').includes(q));
    if (!options.length) return close();
    show(
      options.map(o => ({ kind: 'arg', ico: o.current ? 'option' : 'dot', title: o.label || o.value, sub: o.desc || '', data: o })),
      `/${def.name}`,
      '↑↓ moverte · Enter elegir · Esc cerrar'
    );
  }

  function update() {
    if (!input.isConnected || doc.activeElement !== input) return close();
    trigger = detectTrigger(input.value, input.selectionStart, { textCommands: TEXT_COMMANDS });
    if (!trigger) return close();
    if (dismissed && dismissed === signature(trigger)) return close();
    if (trigger.kind === 'mention') updateMention(trigger);
    else updateCommand(trigger);
  }

  // Cuando se escribe «/orden …» completa y no hay desplegable que elegir, la tecla de enviar no manda el texto al modelo:
  // ejecuta la orden (o explica qué le falta). Devuelve true si se encargó de la tecla.
  function interceptSlash(e) {
    const m = /^\/([^\s/]+)(?:[ \t]+([^\n]*))?$/.exec(input.value.replace(/\s+$/, '')) || null;
    if (!m) return false;
    const def = findCommand(m[1]);
    if (!def) return false;
    if (dismissedSlash && dismissedSlash === input.value) return false;
    const arg = (m[2] || '').trim();
    if (def.args === 'text') {
      run(def.name, arg);
      return true;
    }
    if (def.args === 'choice') {
      if (!arg) {
        setValue(`/${def.name} `, def.name.length + 2);
        update();
        return true;
      }
      const ok = argChoices(def.name).find(o => foldText(o.value) === foldText(arg) || foldText(o.label || '') === foldText(arg));
      if (ok) {
        run(def.name, ok.value);
        return true;
      }
      // «solo lectura», «sí», etc.
      if ((def.name === 'modo' && parseMode(arg)) || (def.name === 'web' && parseWeb(arg))) {
        run(def.name, arg);
        return true;
      }
      notify(
        `No entendí «${arg}» en /${def.name}`,
        `Opciones: ${argChoices(def.name)
          .map(o => o.value)
          .join(', ')}. Pulsa Esc si querías enviar ese texto tal cual.`
      );
      return true;
    }
    if (arg) {
      notify(`/${def.name} no necesita nada más`, 'Borra lo que sobra, o pulsa Esc si querías enviar ese texto tal cual.');
      return true;
    }
    run(def.name, '');
    return true;
  }

  function consume(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    return true;
  }

  function handleKeydown(e) {
    if (e.isComposing || e.keyCode === 229) return false;
    if (open) {
      if (e.key === 'ArrowDown') return move(1), consume(e);
      if (e.key === 'ArrowUp') return move(-1), consume(e);
      if ((e.key === 'Enter' && !e.shiftKey && !e.altKey) || e.key === 'Tab') {
        const it = items[active];
        if (it && it.kind !== 'note') {
          accept(it);
          return consume(e);
        }
      }
      if (e.key === 'Escape') {
        dismissed = signature(trigger);
        if (trigger?.kind === 'command' && input.value.startsWith('/')) dismissedSlash = input.value; // Escape sobre la lista de comandos = «envíalo tal cual»
        close();
        return consume(e);
      }
    } else if (e.key === 'Escape' && input.value.startsWith('/')) {
      dismissedSlash = input.value;
    }
    if (sendKey(e) && input.value.startsWith('/') && interceptSlash(e)) return consume(e);
    return false;
  }

  input.setAttribute('aria-autocomplete', 'list');
  input.setAttribute('aria-expanded', 'false');
  input.addEventListener('keydown', handleKeydown);
  input.addEventListener('input', () => {
    if (dismissedSlash && dismissedSlash !== input.value) dismissedSlash = '';
    update();
  });
  input.addEventListener('click', () => update());
  input.addEventListener('keyup', e => {
    if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) update();
  });
  input.addEventListener('blur', () => setTimeout(() => doc.activeElement !== input && close(), 120));
  doc.defaultView.addEventListener('resize', () => open && place());

  return {
    update,
    close,
    invalidate() {
      index = null;
      inflight = null;
    },
    handleKeydown,
    isOpen: () => open
  };
}
