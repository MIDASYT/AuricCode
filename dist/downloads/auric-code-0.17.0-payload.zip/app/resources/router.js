// Enrutador de motores con salud por ruta. Sin dependencias del DOM: se prueba con `node --test`.
// Idea: cada ruta (proveedor::modelo) acumula fallos con enfriamiento exponencial. Se elige siempre la
// primera ruta sana en orden de preferencia (la principal vuelve a usarse en cuanto se recupera).
export function errorStatus(e) {
  return Number(e?.status || String(e?.message || '').match(/HTTP\s+(\d{3})/i)?.[1] || 0);
}
const LOCAL_PERMANENT = new Set(['LOCAL_OFF', 'LOCAL_MISSING', 'LOCAL_NO_MODEL', 'LOCAL_MODEL_NOT_FOUND', 'LOCAL_NO_MEMORY', 'LOCAL_BAD_HOST', 'LOCAL_BAD_REQUEST']);
const LOCAL_TRANSIENT = new Set(['LOCAL_TIMEOUT', 'LOCAL_SERVER']);
export function isPermanentFailure(e) {
  const msg = String(e?.message || e || ''),
    code = String(e?.code || '').toUpperCase(),
    status = errorStatus(e);
  if (code === 'QUOTA_EXHAUSTED' || /cuota diaria.*agot|agotó la cuota diaria|daily quota.*exhaust/i.test(msg)) return true;
  // Mi PC: si Ollama no está, falta el modelo o no hay memoria, reintentar igual no sirve: se pasa al respaldo o se avisa.
  if (LOCAL_PERMANENT.has(code)) return true;
  if ([400, 401, 402, 403, 404, 422].includes(status)) return true;
  return /Falta la API key|No hay modelo seleccionado|Falta la Base URL|Authorization failed|rechazaron la autorización|INVALID_ARGUMENT|not supported|no admite/i.test(
    msg
  );
}
export function isTransientFailure(e) {
  if (isPermanentFailure(e)) return false;
  if (/^ABORTED:/.test(String(e?.message || ''))) return false;
  const msg = String(e?.message || e || ''),
    status = errorStatus(e),
    code = String(e?.code || '').toUpperCase();
  return (
    [408, 409, 425, 429, 500, 502, 503, 504].includes(status) ||
    ['QUEUE_TIMEOUT', 'PROVIDER_SATURATED', 'UPSTREAM_ERROR', 'ETIMEDOUT', 'NETWORK', 'STREAM_CUT', 'EMPTY_RESPONSE'].includes(code) ||
    LOCAL_TRANSIENT.has(code) ||
    /^(NETWORK|ETIMEDOUT):/.test(msg) ||
    /high demand|temporar|satur|ocupad|overload|unavailable|rate.?limit|RESOURCE_EXHAUSTED|timeout|network|fetch|ECONN|EAI_AGAIN/i.test(msg)
  );
}

export class RouteRouter {
  constructor({ now = () => Date.now(), baseCooldownMs = 15000, maxCooldownMs = 240000 } = {}) {
    this.now = now;
    this.base = baseCooldownMs;
    this.max = maxCooldownMs;
    this.health = new Map();
    this.cycles = 0;
  }
  _h(key) {
    if (!this.health.has(key)) this.health.set(key, { fails: 0, until: 0, permanent: false, last: '' });
    return this.health.get(key);
  }
  recordSuccess(key) {
    const h = this._h(key);
    h.fails = 0;
    h.until = 0;
  }
  recordFailure(key, { permanent = false, retryAfterMs = 0, message = '' } = {}) {
    const h = this._h(key);
    h.fails++;
    h.last = String(message || '').slice(0, 300);
    if (permanent) {
      h.permanent = true;
      return h;
    }
    const backoff = Math.min(this.max, this.base * Math.pow(2, Math.min(h.fails - 1, 6)));
    h.until = this.now() + Math.max(backoff, Math.min(this.max, Number(retryAfterMs) || 0));
    return h;
  }
  // Devuelve { key, waitMs, allCooling } o null si todas las rutas fallaron de forma permanente.
  pick(routeKeys) {
    const live = routeKeys.filter(k => !this._h(k).permanent);
    if (!live.length) return null;
    const t = this.now();
    for (const k of live) if (this._h(k).until <= t) return { key: k, waitMs: 0, allCooling: false };
    let best = live[0];
    for (const k of live) if (this._h(k).until < this._h(best).until) best = k;
    return { key: best, waitMs: Math.max(0, this._h(best).until - t), allCooling: true };
  }
  nextCycle() {
    return ++this.cycles;
  }
  isPermanent(key) {
    return !!this._h(key).permanent;
  }
  snapshot() {
    return Object.fromEntries([...this.health].map(([k, v]) => [k, { ...v, coolingMs: Math.max(0, v.until - this.now()) }]));
  }
}
