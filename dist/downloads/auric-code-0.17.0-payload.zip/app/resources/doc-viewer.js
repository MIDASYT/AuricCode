// Vista previa de documentos (Word, Excel, PowerPoint, PDF) en el panel lateral.
// Todo el texto del documento entra con textContent/atributos: jamás con innerHTML. Un documento hostil no puede ejecutar nada.
const SAFE_LINK = /^(https?:|mailto:)/i;

export function documentKindOf(path = '') {
  const m = /\.(docx|xlsx|pptx|pdf)$/i.exec(String(path));
  return m ? m[1].toLowerCase() : '';
}
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined && text !== null) e.textContent = String(text);
  return e;
}
let current = null; // { dispose() }
export function disposeDocumentPreview() {
  try {
    current?.dispose?.();
  } catch {}
  current = null;
}

function appendRuns(parent, runs, openLink) {
  for (const r of runs || []) {
    if (r.br) {
      parent.append(document.createElement('br'));
      continue;
    }
    let node = document.createTextNode(String(r.text ?? ''));
    const wrap = tag => {
      const w = document.createElement(tag);
      w.append(node);
      node = w;
    };
    if (r.code) wrap('code');
    if (r.b) wrap('strong');
    if (r.i) wrap('em');
    if (r.u) wrap('u');
    if (r.s) wrap('s');
    if (r.href && SAFE_LINK.test(r.href)) {
      const a = document.createElement('a');
      a.append(node);
      a.href = '#';
      a.title = r.href;
      a.className = 'doc-link';
      a.addEventListener('click', e => {
        e.preventDefault();
        openLink?.(r.href);
      });
      node = a;
    }
    parent.append(node);
  }
}
const BULLETS = ['•', '◦', '▪'];
function liNode(b, openLink) {
  const d = el('div', 'doc-li');
  d.style.marginLeft = `${Math.min(8, b.level || 0) * 1.5}em`;
  d.append(el('span', 'doc-li-mark', b.ordered ? `${b.num ?? ''}.` : BULLETS[(b.level || 0) % 3]));
  const body = el('span', 'doc-li-body');
  appendRuns(body, b.runs, openLink);
  d.append(body);
  return d;
}
function tableNode(b, openLink) {
  const t = el('table', 'doc-table');
  const cell = (tag, runs, align) => {
    const c = document.createElement(tag);
    appendRuns(c, runs, openLink);
    if (align === 'r') c.classList.add('doc-right');
    if (align === 'c') c.classList.add('doc-center');
    return c;
  };
  if (b.head) {
    const tr = document.createElement('tr');
    b.head.forEach((runs, i) => tr.append(cell('th', runs, b.align?.[i])));
    const th = document.createElement('thead');
    th.append(tr);
    t.append(th);
  }
  const body = document.createElement('tbody');
  for (const row of b.rows || []) {
    const tr = document.createElement('tr');
    row.forEach((runs, i) => tr.append(cell('td', runs, b.align?.[i])));
    body.append(tr);
  }
  t.append(body);
  const wrap = el('div', 'doc-table-wrap');
  wrap.append(t);
  if (b.moreRows || b.moreCols) wrap.append(el('div', 'doc-more', `${b.moreRows ? `… y ${b.moreRows} fila${b.moreRows === 1 ? '' : 's'} más` : ''}${b.moreRows && b.moreCols ? ' · ' : ''}${b.moreCols ? `… y ${b.moreCols} columna${b.moreCols === 1 ? '' : 's'} más` : ''}`));
  return wrap;
}

function renderDocx(host, data, openLink) {
  const wrap = el('div', 'doc-view doc-docx');
  const page = el('div', 'doc-page');
  for (const b of data.blocks || []) {
    if (b.t === 'title') appendRuns(page.appendChild(el('h1', 'doc-title')), b.runs, openLink);
    else if (b.t === 'subtitle') appendRuns(page.appendChild(el('p', 'doc-subtitle')), b.runs, openLink);
    else if (b.t === 'h') appendRuns(page.appendChild(el('h' + Math.max(1, Math.min(6, b.level || 1)), 'doc-h doc-h' + Math.max(1, Math.min(6, b.level || 1)))), b.runs, openLink);
    else if (b.t === 'p') appendRuns(page.appendChild(el('p')), b.runs, openLink);
    else if (b.t === 'li') page.append(liNode(b, openLink));
    else if (b.t === 'table') page.append(tableNode(b, openLink));
    else if (b.t === 'quote') appendRuns(page.appendChild(el('blockquote')), b.runs, openLink);
    else if (b.t === 'code') page.append(el('pre', 'doc-code', b.text));
    else if (b.t === 'hr') page.append(el('hr'));
    else if (b.t === 'pb') page.append(el('div', 'doc-pagebreak', 'salto de página'));
  }
  if (data.moreBlocks) page.append(el('div', 'doc-more', `… el documento sigue (${data.moreBlocks} bloques más). Ábrelo con Word para verlo completo.`));
  if (!page.childNodes.length) page.append(el('p', 'doc-more', '(El documento no tiene contenido que mostrar.)'));
  wrap.append(page);
  const st = data.stats || {};
  const n = (k, one, many) => `${k} ${k === 1 ? one : many}`;
  wrap.append(el('div', 'doc-foot', `Vista simplificada del contenido · ${n(st.words ?? 0, 'palabra', 'palabras')} · ${n(st.headings ?? 0, 'título', 'títulos')} · ${n(st.tables ?? 0, 'tabla', 'tablas')}${st.images ? ` · ${n(st.images, 'imagen no se muestra', 'imágenes no se muestran')}` : ''}`));
  host.append(wrap);
}

function colLetters(i) {
  let s = '';
  i++;
  while (i) {
    const r = (i - 1) % 26;
    s = String.fromCharCode(65 + r) + s;
    i = Math.floor((i - 1) / 26);
  }
  return s;
}
const NUMBERISH = /^[+-]?(\d{1,3}(,\d{3})+|\d+)([.,]\d+)?%?$/;
function renderXlsx(host, data) {
  const wrap = el('div', 'doc-view doc-xlsx');
  const tabs = el('div', 'xl-tabs');
  const body = el('div', 'xl-body');
  const sheets = data.sheets || [];
  const show = idx => {
    tabs.querySelectorAll('button').forEach((b, i) => b.classList.toggle('active', i === idx));
    body.textContent = '';
    const s = sheets[idx];
    if (!s) return;
    if (s.error) {
      body.append(el('div', 'doc-more', s.error));
      return;
    }
    const formulas = new Map((s.formulas || []).map(f => [f.ref, f]));
    const cols = Math.max(1, ...s.rows.map(r => r.cells.length));
    const scroll = el('div', 'xl-scroll');
    const t = el('table', 'xl-grid');
    const head = document.createElement('tr');
    head.append(el('th', 'xl-corner', ''));
    for (let c = 0; c < cols; c++) head.append(el('th', 'xl-col', colLetters(c)));
    const thead = document.createElement('thead');
    thead.append(head);
    t.append(thead);
    const tb = document.createElement('tbody');
    for (const r of s.rows) {
      const tr = document.createElement('tr');
      tr.append(el('th', 'xl-row', r.n));
      for (let c = 0; c < cols; c++) {
        const v = r.cells[c] ?? '';
        const td = el('td', NUMBERISH.test(String(v).trim()) ? 'xl-num' : '', v);
        const f = formulas.get(`${colLetters(c)}${r.n}`);
        if (f) {
          td.classList.add('xl-f');
          td.title = `=${String(f.f).replace(/^=/, '')}`;
          if (v === '') td.textContent = '='; // fórmula sin valor guardado: Excel la calcula al abrir
        }
        tr.append(td);
      }
      tb.append(tr);
    }
    t.append(tb);
    scroll.append(t);
    body.append(scroll);
    const more = s.rowCount > s.rows.length || s.colCount > cols;
    body.append(el('div', 'doc-more', `${s.rowCount} fila${s.rowCount === 1 ? '' : 's'} × ${s.colCount} columna${s.colCount === 1 ? '' : 's'}${more ? ' · se muestra solo el comienzo' : ''}${(s.formulas || []).length ? ' · las celdas con fórmula tienen un borde de color (pasa el mouse para verla)' : ''}`));
  };
  sheets.forEach((s, i) => {
    const b = el('button', 'xl-tab', `${s.name}${s.state && s.state !== 'visible' ? ' (oculta)' : ''}`);
    b.type = 'button';
    b.addEventListener('click', () => show(i));
    tabs.append(b);
  });
  wrap.append(tabs, body);
  host.append(wrap);
  show(0);
}

function renderPptx(host, data, openLink) {
  const wrap = el('div', 'doc-view doc-pptx');
  for (const s of data.slides || []) {
    const box = el('section', 'sl-box');
    box.append(el('div', 'sl-label', `Diapositiva ${s.n}${s.hidden ? ' · oculta' : ''}`));
    const card = el('div', 'sl-card');
    if (s.title) card.append(el('h3', 'sl-title', s.title));
    if (s.subtitle) card.append(el('p', 'sl-subtitle', s.subtitle));
    for (const it of s.items || []) {
      const d = el('div', 'doc-li');
      d.style.marginLeft = `${Math.min(6, it.level || 0) * 1.4}em`;
      d.append(el('span', 'doc-li-mark', it.bullet === false ? '' : BULLETS[(it.level || 0) % 3]), el('span', 'doc-li-body', it.text));
      card.append(d);
    }
    for (const t of s.tables || []) {
      const table = el('table', 'doc-table');
      t.forEach((row, ri) => {
        const tr = document.createElement('tr');
        row.forEach(c => tr.append(el(ri === 0 ? 'th' : 'td', '', c)));
        table.append(tr);
      });
      const tw = el('div', 'doc-table-wrap');
      tw.append(table);
      card.append(tw);
    }
    if (s.images || s.charts) card.append(el('div', 'doc-more', `${s.images ? `${s.images} imagen(es)` : ''}${s.images && s.charts ? ' y ' : ''}${s.charts ? `${s.charts} gráfico(s)` : ''} no se muestran aquí`));
    box.append(card);
    if (s.notes) {
      const n = el('div', 'sl-notes');
      n.append(el('b', '', 'Notas del orador: '), document.createTextNode(s.notes));
      box.append(n);
    }
    wrap.append(box);
  }
  if (!(data.slides || []).length) wrap.append(el('div', 'doc-more', '(La presentación no tiene diapositivas.)'));
  wrap.append(el('div', 'doc-foot', 'Vista simplificada del contenido: el diseño final se ve al abrir el archivo con PowerPoint.'));
  host.append(wrap);
}

async function renderPdf(host, data) {
  const wrap = el('div', 'doc-view doc-pdf');
  const bar = el('div', 'pdf-bar');
  const info = el('span', 'pdf-info', 'Cargando PDF…');
  const zoomOut = el('button', 'secondary-btn pdf-zoom', '−');
  const zoomIn = el('button', 'secondary-btn pdf-zoom', '+');
  zoomOut.type = zoomIn.type = 'button';
  zoomOut.title = 'Reducir';
  zoomIn.title = 'Ampliar';
  bar.append(info, zoomOut, zoomIn);
  const pages = el('div', 'pdf-pages');
  wrap.append(bar, pages);
  host.append(wrap);
  const pdfjs = await import('./vendor/pdfjs/pdf.min.mjs');
  pdfjs.GlobalWorkerOptions.workerSrc = new URL('./vendor/pdfjs/pdf.worker.min.mjs', import.meta.url).href;
  const task = pdfjs.getDocument({ data: data.bytes, isEvalSupported: false, enableXfa: false, useSystemFonts: false, verbosity: 0 });
  let disposed = false;
  let observer = null;
  const dispose = () => {
    disposed = true;
    try {
      observer?.disconnect();
    } catch {}
    try {
      task.destroy();
    } catch {}
  };
  current = { dispose };
  let doc;
  try {
    doc = await task.promise;
  } catch (e) {
    info.textContent = e?.name === 'PasswordException' ? 'El PDF está protegido con contraseña.' : 'No se pudo abrir el PDF (puede estar dañado).';
    return;
  }
  if (disposed) return;
  info.textContent = `${doc.numPages} página${doc.numPages === 1 ? '' : 's'}`;
  let zoom = 1;
  const slots = [];
  const first = await doc.getPage(1);
  const v1 = first.getViewport({ scale: 1 });
  const render = async slot => {
    if (disposed || slot.busy) return;
    slot.busy = true;
    try {
      const page = slot.n === 1 ? first : await doc.getPage(slot.n);
      const avail = Math.max(280, (pages.clientWidth || 640) - 8);
      const base = page.getViewport({ scale: 1 });
      const scale = (avail / base.width) * zoom;
      const vp = page.getViewport({ scale });
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const canvas = document.createElement('canvas');
      canvas.width = Math.floor(vp.width * dpr);
      canvas.height = Math.floor(vp.height * dpr);
      canvas.style.width = `${Math.floor(vp.width)}px`;
      canvas.style.height = `${Math.floor(vp.height)}px`;
      slot.box.style.width = canvas.style.width;
      slot.box.style.height = canvas.style.height;
      await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : null }).promise;
      if (disposed) return;
      slot.box.textContent = '';
      slot.box.append(canvas);
      slot.done = true;
      slot.zoom = zoom;
    } catch {
      slot.box.textContent = `No se pudo dibujar la página ${slot.n}.`;
    } finally {
      slot.busy = false;
    }
  };
  for (let n = 1; n <= doc.numPages; n++) {
    const box = el('div', 'pdf-page');
    const avail = Math.max(280, (pages.clientWidth || 640) - 8);
    box.style.width = `${Math.floor(avail)}px`;
    box.style.height = `${Math.floor((avail * v1.height) / v1.width)}px`;
    box.dataset.page = String(n);
    pages.append(box);
    slots.push({ n, box, done: false, busy: false, zoom: 1 });
  }
  observer = new IntersectionObserver(
    entries => {
      for (const en of entries) if (en.isIntersecting) {
        const slot = slots[Number(en.target.dataset.page) - 1];
        if (slot && (!slot.done || slot.zoom !== zoom)) render(slot);
      }
    },
    { rootMargin: '600px 0px' }
  );
  slots.forEach(s => observer.observe(s.box));
  const rezoom = z => {
    zoom = Math.max(0.5, Math.min(2.5, z));
    for (const s of slots) {
      const avail = Math.max(280, (pages.clientWidth || 640) - 8) * zoom;
      s.box.style.width = `${Math.floor(avail)}px`;
      s.box.style.height = `${Math.floor((avail * v1.height) / v1.width)}px`;
      s.done = false;
    }
    slots.forEach(s => {
      const r = s.box.getBoundingClientRect();
      if (r.bottom > -600 && r.top < window.innerHeight + 600) render(s);
    });
  };
  zoomOut.addEventListener('click', () => rezoom(zoom - 0.25));
  zoomIn.addEventListener('click', () => rezoom(zoom + 0.25));
}

// host: elemento vacío donde se pinta. data: respuesta de D.documents.preview(). opts: { openLink(url) }.
export async function renderDocumentPreview(host, data, opts = {}) {
  disposeDocumentPreview();
  host.textContent = '';
  const openLink = opts.openLink;
  if (data.kind === 'docx') renderDocx(host, data, openLink);
  else if (data.kind === 'xlsx') renderXlsx(host, data);
  else if (data.kind === 'pptx') renderPptx(host, data, openLink);
  else if (data.kind === 'pdf') await renderPdf(host, data);
  else host.append(el('div', 'empty-panel', 'Este archivo no tiene vista previa.'));
}
