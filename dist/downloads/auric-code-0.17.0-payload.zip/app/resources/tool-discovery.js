const CORE = new Set(['list_files', 'read_file', 'search_text', 'write_file', 'apply_patch', 'run_command', 'git', 'web_search', 'web_fetch', 'set_plan', 'ask_user', 'update_memory', 'find_path', 'set_workspace', 'discover_tools', 'agent_capabilities']);
export function toolGroup(name) {
  if (name.startsWith('desktop_')) return 'windows';
  if (name.includes('godot')) return 'godot';
  if (name.startsWith('browser_')) return 'browser';
  if (name.startsWith('gallery_')) return 'gallery';
  if (name.startsWith('mcp_')) return 'mcp';
  if (name.startsWith('connector_')) return 'connectors';
  if (name.includes('document')) return 'documents';
  if (name.includes('preview')) return 'preview';
  if (/^(?:image_|icon_|ui_components)/.test(name)) return 'images';
  if (name.includes('process') || name === 'start_repl') return 'processes';
  if (name.startsWith('git')) return 'git';
  if (name === 'task_worktree') return 'worktrees';
  if (/^(?:index_|lsp_|run_tests|sqlite_)/.test(name)) return 'development';
  if (/^(?:download_|install_)/.test(name)) return 'downloads';
  if (name.includes('memory')) return 'memory';
  return 'files';
}
export function discoverDefinitions(definitions, group = '') {
  const groups = {};
  for (const tool of definitions) (groups[toolGroup(tool.name)] ||= []).push(tool.name);
  return { groups, tools: group && groups[group] ? definitions.filter(tool => toolGroup(tool.name) === group) : [] };
}
export function progressiveDefinitions(definitions, loaded = []) {
  const active = new Set(loaded);
  return definitions.filter(tool => CORE.has(tool.name) || active.has(tool.name));
}
