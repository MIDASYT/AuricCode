// Imágenes con IA: la herramienta image_generate (la que usa el agente) y la pantalla Ajustes → Imágenes.
// Módulo de interfaz. Toda la seguridad real (dirección fija de cada servicio, claves cifradas que nunca vuelven a la pantalla,
// tipo y tamaño de la imagen, límites) vive en el proceso principal (image-gen.js). Aquí solo se pregunta, se guarda en la Galería
// y se muestra. Todo texto que viene de fuera (nombres, avisos, errores) se escapa.
let C = null;

// Para no gastar sin querer el cupo gratis de la persona: en una misma tarea el agente puede crear como máximo estas imágenes.
export const MAX_IMAGES_PER_TASK = 8;
export const NOT_CONFIGURED =
  'Todavía no hay un servicio de imágenes activado. Para crear imágenes hay que activar uno gratis en Ajustes → Imágenes (ahí se explica paso a paso cómo sacar la clave). Dile esto al usuario; no intentes crear la imagen de otra forma.';
const TEST_PROMPT = 'a small friendly golden dragon, flat vector icon, plain light background';

const e = s => C.esc(s);
export function initImagesUi(ctx) {
  C = ctx;
}

// Todas las llamadas al proceso principal devuelven { ok, value, error, code }.
async function call(fn) {
  let r;
  try {
    r = await fn();
  } catch (err) {
    throw new Error(String(err?.message || err));
  }
  if (!r?.ok) {
    const err = new Error(r?.error || 'No se pudo completar la acción.');
    err.code = r?.code || '';
    err.resetsAt = r?.resetsAt || null;
    throw err;
  }
  return r.value;
}
export const imageStatus = () => call(() => C.D.images.status());

const live = (session, text, detail = '') => {
  if (session) C.setLive?.(session, text, detail);
};
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const cutText = (s, n) => {
  const t = String(s ?? '').replace(/\s+/g, ' ').trim();
  return t.length > n ? `${t.slice(0, n - 1).trimEnd()}…` : t;
};
const taskKey = session => String(session.activeTaskId || session.id || '');
const budgetOf = session => {
  const taskId = taskKey(session);
  if (!session.imageTask || session.imageTask.id !== taskId) session.imageTask = { id: taskId, count: 0 };
  return session.imageTask;
};
// Si la persona dice que no, la IA no insiste en esa tarea (como en el navegador): se le avisa claro y no se vuelve a preguntar.
export const imageMarkDenied = session => {
  session.imageDenied = taskKey(session);
};
const sizeName = a => ({ '1:1': 'cuadrada', '16:9': 'horizontal', '9:16': 'vertical' })[a] || cutText(a, 20) || 'cuadrada';

// ── Antes de pedir permiso: ¿hay un servicio listo?, ¿cuál se usaría?, ¿no se pasa del tope? ─────────────────────────────────
// Si algo falla aquí, el error sale ANTES de molestar a la persona con una ventana de permiso.
export async function imagePreflight(session, args = {}) {
  if (session.imageDenied && session.imageDenied === taskKey(session))
    throw new Error('La persona no permitió crear imágenes en esta tarea. No lo repitas ni busques otra forma de crear la imagen; dile que si cambia de idea puede pedirlo otra vez.');
  const prompt = String(args.prompt ?? '').trim();
  if (!prompt) throw new Error('Falta la descripción de la imagen (prompt).');
  const n = clamp(Math.floor(Number(args.count ?? args.n) || 1), 1, 4);
  const budget = budgetOf(session);
  if (budget.count + n > MAX_IMAGES_PER_TASK)
    throw new Error(
      `En una misma tarea Auric crea como máximo ${MAX_IMAGES_PER_TASK} imágenes (para no gastar sin querer tu cupo gratis). Ya se crearon ${budget.count}. Si quieres más, pídelas en una tarea nueva.`
    );
  let st;
  try {
    st = await imageStatus();
  } catch (err) {
    throw new Error(`No se pudo comprobar el servicio de imágenes: ${err.message}`);
  }
  if (!st.anyConfigured) throw new Error(NOT_CONFIGURED);
  const requested = String(args.provider || '')
    .trim()
    .toLowerCase();
  let provider;
  if (requested) {
    provider = st.providers.find(p => p.id === requested);
    if (!provider) throw new Error(`El servicio «${cutText(requested, 40)}» no existe. Los disponibles son: ${st.providers.map(p => p.id).join(', ')}.`);
    if (!provider.configured) throw new Error(`${provider.name} todavía no está configurado (Ajustes → Imágenes).`);
  } else provider = st.providers.find(p => p.id === st.default && p.configured) || st.providers.find(p => p.configured);
  // Sin un servicio pedido a propósito, si el primero llega a su límite gratis se sigue con los otros configurados (la ventana de permiso lo dice).
  const others = requested ? [] : st.providers.filter(p => p.configured && p.id !== provider.id);
  return { provider, others, explicit: !!requested, status: st, n, prompt };
}

// Lo que ve la persona en la ventana de permiso: a QUIÉN se manda qué, cuántas imágenes y cuánto cupo gratis lleva.
export function imagePermissionText(args = {}, pre) {
  const p = pre.provider;
  const u = p.usage || {};
  const lines = [`Servicio: ${p.name} (${p.model}) — capa gratis`, '', 'Descripción que se enviará:', `«${cutText(pre.prompt, 1500)}»`, '', `Cantidad: ${pre.n} · Formato: ${sizeName(String(args.aspect || '').toLowerCase())}`];
  if (u.perDay) lines.push(`Uso de hoy: ${u.used} de unas ${u.perDay} imágenes gratis.`);
  else if (u.perMinute) lines.push(`Límite del servicio: unas ${u.perMinute} por minuto.`);
  if (pre.others?.length) lines.push(`Si ${p.name} llega a su límite gratis, Auric seguirá con ${pre.others.map(o => o.name).join(' o ')} (con la misma descripción).`);
  lines.push('', 'La imagen se guardará en tu Galería. No se toca ninguna otra carpeta tuya.');
  return lines.join('\n');
}

// ── La herramienta ────────────────────────────────────────────────────────────────────────────────────────────────────────────
// Devuelve { text, shownAttachments }: lo segundo se muestra en el chat pero NO se le devuelve al modelo (no gasta su cuota ni
// necesita que el modelo vea imágenes).
export async function imageGenerateTool(session, args = {}, pre, { project = null } = {}) {
  pre = pre || (await imagePreflight(session, args));
  const budget = budgetOf(session);
  const requestId = `img-${C.uid()}`;
  live(session, 'Creando una imagen…', `${pre.provider.name} · puede tardar unos segundos`);
  // «Detener» corta la creación en curso.
  const watcher = setInterval(() => {
    if (C.isStopped?.(session)) Promise.resolve(C.D.httpAbort?.(requestId)).catch(() => {});
  }, 300);
  let r;
  try {
    // Si la IA no pidió un servicio concreto se manda vacío: así, si el primero llega a su límite, el módulo sigue con el otro (ya avisado en el permiso).
    r = await call(() => C.D.images.generate({ prompt: pre.prompt, aspect: args.aspect, n: pre.n, provider: pre.explicit ? pre.provider.id : '', requestId }));
  } finally {
    clearInterval(watcher);
  }
  budget.count += r.images.length;
  // Cada imagen pasa a la Galería (copia propia de la app) y se borra el original temporal.
  const title = cutText(args.name || pre.prompt.split(/[.,;\n]/)[0], 48) || 'Imagen creada con IA';
  const items = [];
  const shown = [];
  const problems = [];
  for (let i = 0; i < r.images.length; i++) {
    const img = r.images[i];
    try {
      const imported = await C.D.gallery.importFile(img.path);
      const display = r.images.length > 1 ? `${title} ${i + 1}` : title;
      const item = {
        id: C.uid(),
        identifier: C.galleryIdentifier(display),
        name: display,
        path: imported.path,
        size: imported.size || img.size,
        mime: img.mime,
        note: `Creada con IA (${r.provider.name}). Descripción: ${cutText(pre.prompt, 300)}`,
        scope: project ? 'project' : 'global',
        projectId: project?.id || null,
        createdAt: C.nowIso(),
        width: img.width || null,
        height: img.height || null
      };
      C.state.gallery.push(item);
      items.push(item);
      shown.push({ id: C.uid(), galleryId: item.id, path: item.path, name: item.name, size: item.size, mime: item.mime });
      await Promise.resolve(C.D.images.discard([img.path])).catch(() => {}); // el original temporal ya no hace falta
    } catch (err) {
      // No se pierde la imagen: se queda donde se creó y se avisa.
      problems.push(`No se pudo copiar «${img.name}» a la Galería (${String(err?.message || err).slice(0, 120)}); quedó en: ${img.path}`);
      shown.push({ id: C.uid(), path: img.path, name: img.name, size: img.size, mime: img.mime });
    }
  }
  if (items.length) {
    await C.saveState();
    C.renderGallery?.();
  }
  const made = r.images.length;
  const lines = [
    `Listo: se ${made === 1 ? 'creó 1 imagen' : `crearon ${made} imágenes`} con ${r.provider.name} y ${items.length === made ? (made === 1 ? 'quedó guardada' : 'quedaron guardadas') : 'se intentó guardar'} en la Galería${items.length ? `: ${items.map(x => `@${x.identifier}${x.width && x.height ? ` (${x.width}×${x.height})` : ''}`).join(', ')}` : ''}.`,
    'Ya se muestra al usuario en el chat: no describas la imagen con detalle, no pegues rutas de archivo y no la vuelvas a crear a menos que lo pida.'
  ];
  const u = r.usage || {};
  if (u.perDay) lines.push(`Uso de hoy con ${r.provider.name}: ${u.used} de unas ${u.perDay} imágenes gratis.`);
  const notes = [...(r.warnings || []), ...problems];
  if (notes.length) lines.push(`Avisos que debes comunicarle al usuario con tus palabras: ${notes.join(' ')}`);
  return { text: lines.join('\n'), shownAttachments: shown };
}

// ── Ajustes → Imágenes ───────────────────────────────────────────────────────────────────────────────────────────────────────
const fmtDay = iso => {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : d.toLocaleString('es', { weekday: 'short', hour: '2-digit', minute: '2-digit' });
};
const fmtReviewed = s => {
  const d = new Date(`${String(s)}T12:00:00`);
  return Number.isNaN(d.getTime()) ? String(s || '') : d.toLocaleDateString('es', { day: 'numeric', month: 'long', year: 'numeric' });
};
const safeUrl = u => (/^https:\/\/[a-z0-9.-]+(\/|$)/i.test(String(u || '')) ? String(u) : '');
const LINK_TEXT = { dashboard: 'Abrir la página para sacar la clave', pricing: 'Ver los límites oficiales' };

function usageLine(p) {
  const u = p.usage || {};
  if (u.perDay) {
    const left = Math.max(0, u.perDay - u.used);
    const when = u.resetsAt ? ` Se renueva ${fmtDay(u.resetsAt)} (hora de tu equipo).` : '';
    return `Hoy: <b>${e(u.used)}</b> de unas ${e(u.perDay)} imágenes gratis (quedan unas ${e(left)}).${e(when)}`;
  }
  if (u.perMinute) return `Límite: unas ${e(u.perMinute)} peticiones por minuto. Hoy hiciste ${e(u.used)}.`;
  return '';
}

function fieldHtml(p, f) {
  const stored = !!p.stored?.[f.name];
  const id = `im-${p.id}-${f.name}`;
  const value = f.name === 'accountId' && p.accountId ? p.accountId : '';
  const ph = stored && f.secret ? '•••••••• guardada (déjalo vacío para conservarla)' : f.placeholder || '';
  return `<div class="form-field full im-field"><label for="${e(id)}">${e(f.label)} ${stored ? '<span class="cx-pill ok im-saved">guardado</span>' : ''}</label><input id="${e(id)}" data-im-field="${e(f.name)}" type="${f.secret ? 'password' : 'text'}" autocomplete="off" spellcheck="false" value="${e(value)}" placeholder="${e(ph)}"></div>`;
}

function providerCard(p, st) {
  const isDefault = st.default === p.id && p.configured;
  const pill = p.configured
    ? `<span class="cx-pill ok" data-im="state">Listo para usar</span>`
    : `<span class="cx-pill warn" data-im="state">Falta la clave</span>`;
  const chatKeyNote =
    p.source === 'chat'
      ? `<p class="im-line im-info" data-im="chat-key">Está usando la clave de NVIDIA que ya pusiste para el chat. Si quieres, puedes guardar otra solo para imágenes.</p>`
      : '';
  const steps = ensureList(p.steps)
    .map(s => `<li>${e(s)}</li>`)
    .join('');
  const links = Object.entries(p.links || {})
    .filter(([, url]) => safeUrl(url))
    .map(([k, url]) => `<button class="secondary-btn compact-btn" data-im-open="${e(safeUrl(url))}">${e(LINK_TEXT[k] || 'Abrir página')}</button>`)
    .join('');
  return `<section class="lm-card im-card" data-im-provider="${e(p.id)}" data-im-name="${e(p.name)}">
  <div class="lm-card-head"><div class="lm-card-title">${e(p.name)} <span class="im-model">${e(p.model)}</span></div><div class="im-pills">${isDefault ? '<span class="cx-pill accent" data-im="default">Se usa primero</span>' : ''}${pill}</div></div>
  <p class="lm-text">${e(p.summary)}</p>
  <p class="im-line"><b>Qué es gratis:</b> ${e(p.free)}</p>
  <p class="im-line"><b>Tamaños:</b> ${e(p.sizes)}</p>
  <p class="im-line im-usage" data-im="usage">${usageLine(p)}</p>
  ${chatKeyNote}
  <details class="im-steps"><summary>Cómo sacar la clave gratis (paso a paso)</summary><ol>${steps}</ol><div class="im-links">${links}</div></details>
  <div class="form-grid im-fields">${p.fields.map(f => fieldHtml(p, f)).join('')}</div>
  <div class="im-actions">
    <button class="primary-btn compact-btn" data-im-act="save">Guardar</button>
    <button class="secondary-btn compact-btn" data-im-act="test" ${p.configured ? '' : 'disabled'} title="Crea 1 imagen de prueba (gasta 1 de tu cupo gratis) y no se guarda en la Galería">Probar (crea 1 imagen)</button>
    <button class="secondary-btn compact-btn" data-im-act="default" ${p.configured && !isDefault ? '' : 'disabled'}>Usar este primero</button>
    <button class="secondary-btn compact-btn" data-im-act="clear" ${p.stored && Object.values(p.stored).some(Boolean) ? '' : 'disabled'}>Quitar la clave</button>
  </div>
  <div class="im-result" data-im="result" aria-live="polite"></div>
</section>`;
}
const ensureList = v => (Array.isArray(v) ? v : []);

export async function renderImagesSettings(host) {
  host.innerHTML = '<h4>Imágenes con IA</h4><p class="desc">Cargando…</p>';
  let st;
  try {
    st = await imageStatus();
  } catch (err) {
    host.innerHTML = `<h4>Imágenes con IA</h4><div class="cx-banner warn" data-im="problem">No se pudo leer la configuración de imágenes: ${e(err.message)}</div><button class="secondary-btn compact-btn" id="imReload">Reintentar</button>`;
    host.querySelector('#imReload').onclick = () => renderImagesSettings(host);
    return;
  }
  // El catálogo con los pasos viene del proceso principal (providers[].steps/links); si no, se muestra lo básico.
  const notAvail = ensureList(st.notAvailable)
    .map(t => `<li>${e(t)}</li>`)
    .join('');
  host.innerHTML = `<h4>Imágenes con IA</h4>
<p class="im-intro">La IA de Auric puede crear imágenes cuando se lo pides en el chat. Se hacen con servicios que tienen <b>capa gratis</b>: tú pones tu propia clave gratuita y las imágenes quedan guardadas en tu <b>Galería</b>. Lo único que se envía al servicio es la descripción de la imagen.</p>
<div class="cx-banner warn" data-im="limits"><b>Sobre los límites:</b> los pone cada empresa y pueden cambiar sin aviso. Esto se comprobó el ${e(fmtReviewed(st.reviewed))}. Auric cuenta las imágenes que haces y te avisa cuando te acercas al tope; si el servicio ya no es gratis o se acaba el cupo, rechaza la imagen y Auric te lo dice.</div>
<div class="im-list">${st.providers.map(p => providerCard(p, st)).join('')}</div>
${notAvail ? `<details class="im-notavail" data-im="notavail"><summary>Servicios que ya NO sirven gratis para imágenes</summary><ul>${notAvail}</ul></details>` : ''}
<p class="cx-foot">Para tu seguridad: las claves se guardan cifradas en este equipo y nunca se muestran de nuevo. Cuando la IA quiere crear una imagen te pregunta antes (salvo en modo Completo) y enseña la descripción exacta que se va a enviar.</p>`;
  bindImagesSettings(host, st);
}

function bindImagesSettings(host, st) {
  const result = id => host.querySelector(`[data-im-provider="${CSS.escape(id)}"] [data-im="result"]`);
  const show = (id, html, cls = '') => {
    const box = result(id);
    if (box) box.innerHTML = `<div class="im-msg ${cls}">${html}</div>`;
  };
  host.onclick = async ev => {
    const open = ev.target.closest('[data-im-open]');
    if (open && host.contains(open)) {
      const url = safeUrl(open.dataset.imOpen);
      if (url) C.D.openExternal(url).catch(() => {});
      return;
    }
    const b = ev.target.closest('[data-im-act]');
    if (!b || !host.contains(b)) return;
    const card = b.closest('[data-im-provider]');
    const id = card.dataset.imProvider;
    const act = b.dataset.imAct;
    try {
      if (act === 'save') {
        const fields = {};
        card.querySelectorAll('[data-im-field]').forEach(inp => {
          const v = inp.value.trim();
          if (v) fields[inp.dataset.imField] = v;
        });
        if (!Object.keys(fields).length) return show(id, 'Escribe la clave (o el ID de cuenta) antes de guardar.', 'warn');
        b.disabled = true;
        await call(() => C.D.images.save(id, fields));
        C.toast('Imágenes', 'Datos guardados', 'success');
        await renderImagesSettings(host);
        show(id, 'Guardado. Pulsa «Probar» para comprobar que funciona (crea 1 imagen de prueba).', 'ok');
      } else if (act === 'clear') {
        const sure = await C.appConfirm({
          title: 'Quitar la clave',
          message: `¿Quitar la clave de ${card.dataset.imName || 'este servicio'}?`,
          detail: 'Se borra de este equipo. Las imágenes que ya creaste siguen en tu Galería.',
          buttons: ['Cancelar', 'Quitar'],
          defaultId: 0,
          cancelId: 0,
          type: 'warning'
        });
        if (sure !== 1) return;
        await call(() => C.D.images.clear(id));
        await renderImagesSettings(host);
      } else if (act === 'default') {
        await call(() => C.D.images.setDefault(id));
        await renderImagesSettings(host);
      } else if (act === 'test') {
        b.disabled = true;
        show(id, 'Creando una imagen de prueba…', 'busy');
        const r = await call(() => C.D.images.generate({ provider: id, prompt: TEST_PROMPT, aspect: '1:1', n: 1 }));
        const img = r.images[0];
        let thumb = '';
        try {
          const data = await C.D.fs.readBase64(img.path);
          thumb = `<img class="im-thumb" alt="Imagen de prueba" src="data:${e(img.mime)};base64,${e(data)}">`;
        } catch {}
        await Promise.resolve(C.D.images.discard([img.path])).catch(() => {}); // la prueba no se guarda
        const warn = (r.warnings || []).map(w => `<div>${e(w)}</div>`).join('');
        show(id, `<b>Funciona.</b> ${e(r.provider.name)} creó la imagen de prueba (no se guardó en tu Galería).${warn}${thumb}`, 'ok');
        const line = host.querySelector(`[data-im-provider="${CSS.escape(id)}"] [data-im="usage"]`);
        if (line) line.innerHTML = usageLine({ usage: r.usage });
      }
    } catch (err) {
      show(id, e(err.message), 'err');
    } finally {
      if (b.isConnected && act === 'test') b.disabled = false;
      if (b.isConnected && act === 'save') b.disabled = false;
    }
  };
}
