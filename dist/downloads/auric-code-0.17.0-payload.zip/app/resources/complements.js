// Complementos: conectores reales (MCP + OAuth), plugins, skills por ámbitos y ajustes avanzados.
// Módulo de interfaz: no guarda secretos; todo lo sensible vive en el proceso principal.
import { initPluginsUi, renderPluginsTab } from './ui-plugins.js';

let C = null;
let tab = 'connectors';
let skillQuery = '';
let connectorQuery = '';
const busy = new Set();

export function initComplements(ctx) {
  C = ctx;
  initPluginsUi({ ...ctx, rerender: () => (tab === 'plugins' ? renderComplements() : null), onChanged: ctx.onPluginsChanged });
}
export function setComplementsTab(t) {
  tab = ['connectors', 'plugins', 'skills', 'advanced'].includes(t) ? t : 'connectors';
}
export function complementsTab() {
  return tab;
}

const initial = name => (String(name || '').match(/[\p{L}\p{N}]/u)?.[0] || '?').toUpperCase();
function logoHtml(item) {
  const src = item.logo || item.iconPath || '';
  return src
    ? `<span class="cx-logo"><img src="${C.esc(src)}" alt=""></span>`
    : `<span class="cx-logo skill-symbol" aria-hidden="true">${item.icon ? C.icon(item.icon, 26) : C.icon('code', 26)}</span>`;
}
const pill = (text, cls = '') => `<span class="cx-pill ${cls}">${C.esc(text)}</span>`;

// ── Pestañas ────────────────────────────────────────────────────────────────────────────────────
export async function renderComplements() {
  const grid = C.$('#integrationsGrid'),
    meta = C.$('#integrationsMeta');
  if (!grid || !meta) return;
  C.$$('[data-integration-tab]').forEach(b => b.classList.toggle('active', b.dataset.integrationTab === tab));
  if (tab === 'connectors') renderConnectors(grid, meta);
  else if (tab === 'plugins') renderPluginsTab(grid, meta);
  else if (tab === 'skills') renderSkills(grid, meta);
  else renderAdvanced(grid, meta);
}

// ── Conectores ──────────────────────────────────────────────────────────────────────────────────
function connectorCard(c) {
  const status = c.connected ? pill('Conectado', 'ok') : c.needsAuth ? pill('Reconectar', 'warn') : pill('Sin conectar');
  const note = c.verified
    ? ''
    : '<span class="cx-note" title="La dirección de este servicio no se pudo comprobar en la documentación; Auric la valida al conectar.">Se valida al conectar</span>';
  const tools = c.connected && c.toolCount ? `<span class="cx-note">${c.toolCount} herramienta${c.toolCount === 1 ? '' : 's'}</span>` : '';
  const err = c.error && !c.connected ? `<div class="cx-error">${C.esc(c.error)}</div>` : '';
  const isBusy = busy.has(c.id);
  const actions = c.connected
    ? `<button class="secondary-btn compact-btn" data-cx-test="${C.esc(c.id)}">Probar</button><button class="secondary-btn compact-btn" data-cx-disconnect="${C.esc(c.id)}">Desconectar</button>`
    : `<button class="primary-btn compact-btn" data-cx-connect="${C.esc(c.id)}" ${isBusy ? 'disabled' : ''}>${isBusy ? 'Conectando…' : c.needsAuth ? 'Volver a conectar' : 'Conectar'}</button>`;
  const remove = c.custom ? `<button class="secondary-btn compact-btn" data-cx-remove="${C.esc(c.id)}">Quitar</button>` : '';
  return `<article class="cx-card ${c.connected ? 'is-on' : ''}" data-cx-card="${C.esc(c.id)}"><div class="cx-card-top">${logoHtml(c)}<div class="cx-card-title"><h3>${C.esc(c.name)}</h3><span class="cx-cat">${C.esc(c.category || '')}</span></div>${status}</div><p class="cx-desc">${C.esc(c.description)}</p>${err}<div class="cx-meta">${tools}${note}</div><div class="cx-actions">${actions}${remove}</div></article>`;
}
function renderConnectors(grid, meta) {
  const all = C.getConnectors();
  const q = connectorQuery.trim().toLowerCase();
  const list = all.filter(c => !q || `${c.name} ${c.category} ${c.description}`.toLowerCase().includes(q));
  const connected = all.filter(c => c.connected).length;
  const secure = all.length ? all[0].persistentSecrets !== false : true;
  meta.innerHTML = `<span>${connected} conectado${connected === 1 ? '' : 's'}</span><span>${all.length} disponibles</span>`;
  const banner = secure
    ? ''
    : '<div class="cx-banner warn">Este equipo no ofrece cifrado seguro del sistema: las conexiones durarán solo mientras la app esté abierta.</div>';
  const groups = new Map();
  for (const c of list) {
    if (!groups.has(c.category)) groups.set(c.category, []);
    groups.get(c.category).push(c);
  }
  const html = [...groups.entries()]
    .map(
      ([cat, items]) =>
        `<div class="cx-group"><div class="cx-group-title">${C.esc(cat)}</div><div class="cx-grid">${items.map(connectorCard).join('')}</div></div>`
    )
    .join('');
  grid.innerHTML = `${banner}<div class="cx-toolbar"><input id="cxSearch" class="cx-search" placeholder="Buscar conector…" value="${C.esc(connectorQuery)}"><button id="cxAddCustom" class="secondary-btn">＋ Servidor MCP personalizado</button></div>${html || '<div class="empty-panel">Ningún conector coincide.</div>'}<p class="cx-foot">Tus credenciales se guardan cifradas en este equipo y nunca se envían a ningún proveedor de IA. Auric siempre pide confirmación antes de enviar, borrar o publicar algo en tu nombre.</p>`;
  const search = C.$('#cxSearch', grid);
  search.oninput = () => {
    connectorQuery = search.value;
    const pos = search.selectionStart;
    renderConnectors(grid, meta);
    const s2 = C.$('#cxSearch', grid);
    s2.focus();
    s2.setSelectionRange(pos, pos);
  };
  C.$('#cxAddCustom', grid).onclick = openCustomModal;
  C.$$('[data-cx-connect]', grid).forEach(b => (b.onclick = () => openConnectModal(b.dataset.cxConnect)));
  C.$$('[data-cx-disconnect]', grid).forEach(b => (b.onclick = () => disconnect(b.dataset.cxDisconnect)));
  C.$$('[data-cx-remove]', grid).forEach(b => (b.onclick = () => removeCustom(b.dataset.cxRemove)));
  C.$$('[data-cx-test]', grid).forEach(b => (b.onclick = () => testConnector(b.dataset.cxTest)));
}
async function testConnector(id) {
  const c = C.getConnectors().find(x => x.id === id);
  const r = await C.connectorsApi('health', id).catch(e => ({ ok: false, error: e.message }));
  if (r.ok) C.toast(`${c?.name || id} funciona`, `${r.toolCount} herramientas · ${r.ms} ms`, 'success');
  else C.toast(`${c?.name || id} no responde`, r.error || 'Error desconocido', 'error', 7000);
  await C.refreshConnectors();
  renderComplements();
}
async function disconnect(id) {
  const c = C.getConnectors().find(x => x.id === id);
  const ok = await C.appConfirm({
    title: `Desconectar ${c?.name || id}`,
    message: 'Se borrarán las credenciales guardadas en este equipo.',
    detail: 'Podrás volver a conectarlo cuando quieras.',
    buttons: ['Cancelar', 'Desconectar'],
    defaultId: 0,
    cancelId: 0,
    type: 'warning'
  });
  if (ok !== 1) return;
  await C.connectorsApi('disconnect', id);
  await C.refreshConnectors();
  C.toast('Desconectado', c?.name || id, 'info');
  renderComplements();
}
async function removeCustom(id) {
  const c = C.getConnectors().find(x => x.id === id);
  const ok = await C.appConfirm({
    title: 'Quitar servidor',
    message: `¿Quitar ${c?.name || id}?`,
    buttons: ['Cancelar', 'Quitar'],
    defaultId: 0,
    cancelId: 0,
    type: 'warning'
  });
  if (ok !== 1) return;
  await C.connectorsApi('removeCustom', id);
  await C.refreshConnectors();
  renderComplements();
}

function modalShell(inner, cls = 'small') {
  const layer = C.$('#modalLayer');
  layer.classList.remove('hidden');
  layer.innerHTML = `<div class="modal ${cls} cx-modal">${inner}</div>`;
  const close = () => {
    layer.classList.add('hidden');
    layer.innerHTML = '';
  };
  C.$$('[data-close]', layer).forEach(b => (b.onclick = close));
  return { layer, close };
}
function openConnectModal(id) {
  const c = C.getConnectors().find(x => x.id === id);
  if (!c) return;
  const steps = (c.setup?.steps || []).map(s => `<li>${C.esc(s)}</li>`).join('');
  const notes = (c.setup?.notes || []).map(s => `<li>${C.esc(s)}</li>`).join('');
  const fields = (c.fields || [])
    .map(
      f =>
        `<div class="form-field full"><label>${C.esc(f.label)}${f.optional ? ' <small>(opcional)</small>' : ''}</label><input data-cx-field="${C.esc(f.key)}" ${f.secret ? 'type="password" autocomplete="off"' : ''} spellcheck="false"></div>`
    )
    .join('');
  const links = (c.setup?.links || [])
    .map(l => `<button class="secondary-btn compact-btn" data-cx-link="${C.esc(l.url)}">${C.esc(l.label)}</button>`)
    .join(' ');
  const redirect = !c.bundled && c.setup?.redirectUri
    ? `<div class="form-field full"><label>URI de redirección (cópiala en Google Cloud)</label><div class="cx-copy"><code>${C.esc(c.setup.redirectUri)}</code><button class="secondary-btn compact-btn" data-cx-copy="${C.esc(c.setup.redirectUri)}">Copiar</button></div></div>`
    : '';
  const { layer, close } = modalShell(
    `<div class="modal-header">${logoHtml(c)}<h3>Conectar ${C.esc(c.name)}</h3><div class="spacer"></div><button class="icon-btn" data-close>${C.icon('close', 15)}</button></div><div class="modal-body"><p class="desc">${C.esc(c.description)}</p><div class="cx-setup"><b>${C.esc(c.setup?.title || '')}</b><ol>${steps}</ol></div>${links ? `<div class="cx-links">${links}</div>` : ''}${redirect}<div class="form-grid">${fields}</div>${notes ? `<ul class="cx-notes">${notes}</ul>` : ''}<div id="cxWait" class="cx-wait hidden"><span class="cx-spin"></span><span>Esperando la autorización en tu navegador… Cuando termines, vuelve aquí.</span></div></div><div class="modal-actions"><button class="secondary-btn" id="cxCancel">Cancelar</button><button class="primary-btn" id="cxGo">Conectar</button></div>`,
    'medium'
  );
  C.$$('[data-cx-link]', layer).forEach(b => (b.onclick = () => C.D.openExternal?.(b.dataset.cxLink)));
  C.$$('[data-cx-copy]', layer).forEach(
    b => (b.onclick = () => navigator.clipboard.writeText(b.dataset.cxCopy).then(() => C.toast('Copiado', '', 'success', 1500)))
  );
  C.$('#cxCancel', layer).onclick = async () => {
    if (busy.has(id)) await C.D.connectors.cancel(id).catch(() => {});
    close();
  };
  C.$('#cxGo', layer).onclick = async () => {
    const input = {};
    C.$$('[data-cx-field]', layer).forEach(el => (input[el.dataset.cxField] = el.value.trim()));
    for (const f of c.fields || []) if (!f.optional && !input[f.key]) return C.toast('Falta un dato', f.label, 'error');
    busy.add(id);
    C.$('#cxGo', layer).disabled = true;
    C.$('#cxWait', layer).classList.toggle('hidden', c.auth === 'token');
    try {
      const r = await C.connectorsApi('connect', id, input);
      close();
      C.toast(`${c.name} conectado`, `${r.toolCount} herramientas disponibles`, 'success');
    } catch (e) {
      if (e.code !== 'CANCELLED') C.toast(`No se pudo conectar ${c.name}`, e.message, 'error', 9000);
      if (C.$('#cxGo', layer)) {
        C.$('#cxGo', layer).disabled = false;
        C.$('#cxWait', layer).classList.add('hidden');
      }
    } finally {
      busy.delete(id);
      await C.refreshConnectors();
      renderComplements();
    }
  };
}
function openCustomModal() {
  const { layer, close } = modalShell(
    `<div class="modal-header"><h3>Servidor MCP personalizado</h3><div class="spacer"></div><button class="icon-btn" data-close>${C.icon('close', 15)}</button></div><div class="modal-body"><p class="desc">Conecta cualquier servidor MCP remoto (Streamable HTTP). Si pide inicio de sesión, Auric abrirá el navegador.</p><div class="form-grid"><div class="form-field full"><label>Nombre</label><input id="cxcName" placeholder="Mi servidor"></div><div class="form-field full"><label>URL del servidor</label><input id="cxcUrl" placeholder="https://ejemplo.com/mcp" spellcheck="false"></div><div class="form-field full"><label>Token (opcional)</label><input id="cxcToken" type="password" autocomplete="off" placeholder="Solo si el servidor usa un token fijo"></div></div></div><div class="modal-actions"><button class="secondary-btn" data-close>Cancelar</button><button class="primary-btn" id="cxcGo">Conectar</button></div>`
  );
  C.$('#cxcGo', layer).onclick = async () => {
    const name = C.$('#cxcName', layer).value.trim(),
      url = C.$('#cxcUrl', layer).value.trim(),
      token = C.$('#cxcToken', layer).value.trim();
    if (!url) return C.toast('Falta la URL', '', 'error');
    C.$('#cxcGo', layer).disabled = true;
    try {
      const r = await C.connectorsApi('addCustom', { name: name || url, url, token });
      close();
      C.toast('Servidor conectado', `${r.toolCount} herramientas`, 'success');
    } catch (e) {
      C.toast('No se pudo conectar', e.message, 'error', 9000);
      C.$('#cxcGo', layer) && (C.$('#cxcGo', layer).disabled = false);
    } finally {
      await C.refreshConnectors();
      renderComplements();
    }
  };
}

// ── Skills ──────────────────────────────────────────────────────────────────────────────────────
const SCOPE_LABEL = { workspace: 'Proyecto', global: 'Mía', system: 'Sistema', plugin: 'Plugin' };
function skillRow(sk) {
  const disabled = new Set(C.ensureArray(C.state.settings.disabledSkills));
  const on = !disabled.has(sk.id);
  const editable = sk.source !== 'system' && sk.source !== 'plugin';
  const fromPlugin = sk.source === 'plugin';
  const tags = [
    ...C.ensureArray(sk.markers)
      .slice(0, 3)
      .map(m => `<span class="cx-tag">${C.esc(m)}</span>`)
  ].join('');
  const override = sk.overrides
    ? `<span class="cx-note">reemplaza a la del ${sk.overrides === 'system' ? 'sistema' : 'perfil'}</span>`
    : '';
  return `<article class="cx-skill ${on ? '' : 'is-off'}" data-skill-row="${C.esc(sk.id)}"><div class="cx-skill-main">${logoHtml(sk)}<div class="cx-skill-copy"><div class="cx-skill-head"><h3>${C.esc(sk.name)}</h3>${pill(fromPlugin && sk.pluginName ? `Plugin · ${sk.pluginName}` : SCOPE_LABEL[sk.source] || sk.source, sk.source === 'system' ? '' : 'accent')}${override}</div><p>${C.esc(sk.description || 'Sin descripción.')}</p><div class="cx-tags">${tags}</div></div><label class="cx-switch" title="${on ? 'Activa' : 'Desactivada'}"><input type="checkbox" data-skill-toggle="${C.esc(sk.id)}" ${on ? 'checked' : ''}><span></span></label></div><div class="cx-skill-actions"><button class="secondary-btn compact-btn" data-skill-view="${C.esc(sk.id)}">${editable ? 'Editar' : 'Ver'}</button><button class="secondary-btn compact-btn" data-skill-dup="${C.esc(sk.id)}">Duplicar</button>${fromPlugin ? `<button class="secondary-btn compact-btn" data-skill-plugin="${C.esc(sk.pluginId || '')}">Carpeta del plugin</button>` : `<button class="secondary-btn compact-btn" data-skill-reveal="${C.esc(sk.folder)}">Carpeta</button>`}${editable ? `<button class="secondary-btn compact-btn" data-skill-del="${C.esc(sk.folder)}">Eliminar</button>` : ''}</div></article>`;
}
function renderSkills(grid, meta) {
  const all = C.getSkills();
  const q = skillQuery.trim().toLowerCase();
  const list = all.filter(s => !q || `${s.name} ${s.description} ${C.ensureArray(s.tags).join(' ')}`.toLowerCase().includes(q));
  const dirs = C.getSkillDirs();
  const errors = C.getSkillErrors();
  meta.innerHTML = `<span>${all.length} skills</span><span>${all.filter(s => !C.ensureArray(C.state.settings.disabledSkills).includes(s.id)).length} activas</span>`;
  const group = (title, src, hint) => {
    const items = list.filter(s => s.source === src);
    if (!items.length) return '';
    return `<div class="cx-group"><div class="cx-group-title">${title}<small>${hint}</small></div><div class="cx-skill-list">${items.map(skillRow).join('')}</div></div>`;
  };
  const errHtml = errors.length
    ? `<div class="cx-banner warn"><b>${errors.length} skill${errors.length === 1 ? '' : 's'} no se pudo${errors.length === 1 ? '' : 'ieron'} leer:</b> ${errors.map(e => `${C.esc(C.basename(e.folder))} (${C.esc(e.error)})`).join(' · ')}</div>`
    : '';
  grid.innerHTML = `${errHtml}<div class="cx-toolbar"><input id="cxSkillSearch" class="cx-search" placeholder="Buscar skill…" value="${C.esc(skillQuery)}"><button id="cxNewSkill" class="primary-btn">＋ Nueva skill</button><button id="cxOpenSkills" class="secondary-btn">Abrir mi carpeta</button></div><p class="cx-foot top">Una skill es un procedimiento que Auric sigue cuando el proyecto o tu mensaje coincide con sus marcadores o palabras clave. Las del sistema y las de plugins son de solo lectura: duplícalas para adaptarlas.</p>${group('Del proyecto', 'workspace', 'solo en este proyecto')}${group('Mías', 'global', 'en todos tus proyectos')}${group('De plugins', 'plugin', 'vienen con un plugin; se activan o quitan desde la pestaña Plugins')}${group('Del sistema', 'system', 'incluidas con Auric Code')}${list.length ? '' : '<div class="empty-panel">Ninguna skill coincide.</div>'}`;
  const search = C.$('#cxSkillSearch', grid);
  search.oninput = () => {
    skillQuery = search.value;
    const pos = search.selectionStart;
    renderSkills(grid, meta);
    const s2 = C.$('#cxSkillSearch', grid);
    s2.focus();
    s2.setSelectionRange(pos, pos);
  };
  C.$('#cxNewSkill', grid).onclick = () => openSkillEditor(null);
  C.$('#cxOpenSkills', grid).onclick = () =>
    C.D.skills.reveal(dirs.globalDir).catch(e => C.toast('No se pudo abrir', e.message || String(e), 'error'));
  const byId = id => all.find(s => s.id === id);
  C.$$('[data-skill-toggle]', grid).forEach(
    b =>
      (b.onchange = async () => {
        const set = new Set(C.ensureArray(C.state.settings.disabledSkills));
        b.checked ? set.delete(b.dataset.skillToggle) : set.add(b.dataset.skillToggle);
        C.state.settings.disabledSkills = [...set];
        await C.saveState();
        renderComplements();
      })
  );
  C.$$('[data-skill-view]', grid).forEach(b => (b.onclick = () => openSkillEditor(byId(b.dataset.skillView))));
  C.$$('[data-skill-dup]', grid).forEach(b => (b.onclick = () => openSkillEditor(byId(b.dataset.skillDup), { duplicate: true })));
  C.$$('[data-skill-reveal]', grid).forEach(
    b =>
      (b.onclick = () => C.D.skills.reveal(b.dataset.skillReveal).catch(e => C.toast('No se pudo abrir', e.message || String(e), 'error')))
  );
  C.$$('[data-skill-plugin]', grid).forEach(
    b => (b.onclick = () => C.D.plugins.reveal(b.dataset.skillPlugin).then(r => r?.ok === false && C.toast('No se pudo abrir', r.error || '', 'error')))
  );
  C.$$('[data-skill-del]', grid).forEach(
    b =>
      (b.onclick = async () => {
        const ok = await C.appConfirm({
          title: 'Eliminar skill',
          message: 'La skill se moverá a la Papelera de Auric.',
          buttons: ['Cancelar', 'Eliminar'],
          defaultId: 0,
          cancelId: 0,
          type: 'warning'
        });
        if (ok !== 1) return;
        try {
          await C.D.skills.remove(b.dataset.skillDel);
          await C.refreshSkills(true);
          renderComplements();
        } catch (e) {
          C.toast('No se pudo eliminar', e.message || String(e), 'error');
        }
      })
  );
}
const slugify = s =>
  String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
function openSkillEditor(sk, { duplicate = false } = {}) {
  const readOnly = sk && (sk.source === 'system' || sk.source === 'plugin') && !duplicate;
  const isNew = !sk || duplicate;
  const roots = C.sessionRoots(C.currentSession());
  const base = sk || { name: '', description: '', triggers: [], markers: [], procedure: '' };
  const joined = v => C.ensureArray(v).join(', ');
  const scopeOptions = `<option value="global">En todos mis proyectos</option>${roots.length ? '<option value="workspace">Solo en el proyecto actual</option>' : ''}`;
  const { layer, close } = modalShell(
    `<div class="modal-header"><h3>${readOnly ? (sk.source === 'plugin' ? 'Skill de un plugin' : 'Skill del sistema') : isNew ? 'Nueva skill' : 'Editar skill'}</h3><div class="spacer"></div><button class="icon-btn" data-close>${C.icon('close', 15)}</button></div><div class="modal-body"><div class="form-grid"><div class="form-field"><label>Nombre</label><input id="skName" value="${C.esc(duplicate ? base.name + ' (copia)' : base.name)}" ${readOnly ? 'disabled' : ''}></div><div class="form-field"><label>Dónde se usa</label><select id="skScope" ${readOnly || !isNew ? 'disabled' : ''}>${scopeOptions}</select></div><div class="form-field full"><label>Descripción (una frase)</label><input id="skDesc" value="${C.esc(base.description)}" ${readOnly ? 'disabled' : ''}></div><div class="form-field"><label>Palabras clave (coma)</label><input id="skTrig" value="${C.esc(joined(base.triggers))}" placeholder="godot, escena, gameplay" ${readOnly ? 'disabled' : ''}></div><div class="form-field"><label>Archivos marcadores (coma)</label><input id="skMark" value="${C.esc(joined(base.markers))}" placeholder="project.godot" ${readOnly ? 'disabled' : ''}></div><div class="form-field full"><label>Procedimiento</label><textarea id="skProc" style="min-height:280px" ${readOnly ? 'readonly' : ''} placeholder="Pasos y reglas que Auric debe seguir…">${C.esc(base.procedure)}</textarea><div class="form-help">Sin palabras clave ni marcadores, la skill se aplica siempre. Con ellas, solo cuando el proyecto o tu mensaje coincide.</div></div></div></div><div class="modal-actions"><button class="secondary-btn" data-close>${readOnly ? 'Cerrar' : 'Cancelar'}</button>${readOnly ? `<button class="primary-btn" id="skDup">Duplicar para editar</button>` : '<button class="primary-btn" id="skSave">Guardar</button>'}</div>`,
    'large'
  );
  if (readOnly) {
    C.$('#skDup', layer).onclick = () => {
      close();
      openSkillEditor(sk, { duplicate: true });
    };
    return;
  }
  C.$('#skSave', layer).onclick = async () => {
    const name = C.$('#skName', layer).value.trim();
    const procedure = C.$('#skProc', layer).value.trim();
    if (!name) return C.toast('Falta el nombre', '', 'error');
    if (!procedure) return C.toast('Falta el procedimiento', 'La skill necesita instrucciones.', 'error');
    const scope = isNew ? C.$('#skScope', layer).value : sk.source;
    const id = isNew ? slugify(name) || `skill-${Date.now().toString(36)}` : sk.id;
    if (isNew && C.getSkills().some(s => s.id === id && s.source === scope))
      return C.toast('Ya existe', 'Ya tienes una skill con ese nombre.', 'error');
    try {
      await C.D.skills.save({
        id,
        name,
        description: C.$('#skDesc', layer).value.trim(),
        triggers: C.$('#skTrig', layer).value,
        markers: C.$('#skMark', layer).value,
        procedure,
        scope,
        workspaceRoot: scope === 'workspace' ? roots[0]?.path : ''
      });
      close();
      await C.refreshSkills(true);
      C.toast('Skill guardada', name, 'success');
      renderComplements();
    } catch (e) {
      C.toast('No se pudo guardar', e.message || String(e), 'error');
    }
  };
}

// ── Avanzado: MCP locales, plugin.json y capacidades integradas ────────────────────────────────
function renderAdvanced(grid, meta) {
  const manual = C.ensureArray(C.state.mcpServers).filter(x => x && x.id && x.command);
  const files = C.getFilePlugins();
  const caps = C.builtinCapabilities;
  meta.innerHTML = `<span>${manual.length} MCP manuales</span><span>${files.length} plugin.json</span>`;
  const row = (title, sub, actions = '') =>
    `<div class="cx-row"><div><b>${C.esc(title)}</b><small>${C.esc(sub)}</small></div><div class="cx-row-actions">${actions}</div></div>`;
  const mcpRows = manual
    .map(s =>
      row(
        s.name || s.id,
        `${s.command} ${C.ensureArray(s.args).join(' ')}`.trim(),
        `<button class="secondary-btn compact-btn" data-test-mcp-quick="${C.esc(s.id)}">Probar</button>`
      )
    )
    .join('');
  const fileRows = files
    .map(p =>
      row(
        p.name,
        p.description || p.folder,
        `${p.server ? `<button class="secondary-btn compact-btn" data-test-plugin="${C.esc(p.id)}">Probar</button>` : ''}<button class="secondary-btn compact-btn" data-reveal-plugin="${C.esc(p.path)}">Abrir</button>`
      )
    )
    .join('');
  const capRows = caps.map(c => row(c.name, c.desc)).join('');
  grid.innerHTML = `<div class="cx-group"><div class="cx-group-title">Servidores MCP locales<small>programas que se ejecutan en tu PC (comando)</small></div><div class="cx-box">${mcpRows || '<div class="cx-empty">Ninguno configurado.</div>'}<div class="cx-box-foot"><button class="secondary-btn compact-btn" data-open-integrations-settings>Configurar MCP</button></div></div></div><div class="cx-group"><div class="cx-group-title">Plugins por archivo<small>plugin.json que define un servidor MCP</small></div><div class="cx-box">${fileRows || '<div class="cx-empty">Ninguno instalado.</div>'}<div class="cx-box-foot"><button id="cxAddPluginFile" class="secondary-btn compact-btn">Añadir plugin.json</button></div></div></div><div class="cx-group"><div class="cx-group-title">Capacidades incluidas<small>funciones propias de la app, no son plugins</small></div><div class="cx-box">${capRows}</div></div>`;
  C.$('#cxAddPluginFile', grid).onclick = () => C.addPluginManifest();
  C.$$('[data-open-integrations-settings]', grid).forEach(b => (b.onclick = () => C.openSettings('mcp')));
  C.$$('[data-reveal-plugin]', grid).forEach(b => (b.onclick = () => C.D.reveal(b.dataset.revealPlugin)));
  C.$$('[data-test-plugin]', grid).forEach(
    b =>
      (b.onclick = async () => {
        const pl = files.find(x => x.id === b.dataset.testPlugin);
        if (!pl?.server) return;
        try {
          const tools = await C.D.mcp.listTools({ ...pl.server, id: pl.server.id || pl.id });
          C.toast('Plugin conectado', `${pl.name}: ${tools.length} herramientas.`, 'success', 5000);
        } catch (e) {
          C.toast('Plugin no disponible', e.message || String(e), 'error', 7000);
        }
      })
  );
  C.$$('[data-test-mcp-quick]', grid).forEach(
    b =>
      (b.onclick = async () => {
        try {
          const spec = C.mcpSpecById(b.dataset.testMcpQuick),
            tools = await C.D.mcp.listTools(spec);
          C.toast('MCP conectado', `${spec.id}: ${tools.length} herramientas.`, 'success', 5000);
        } catch (e) {
          C.toast('MCP no disponible', e.message || String(e), 'error', 7000);
        }
      })
  );
}
