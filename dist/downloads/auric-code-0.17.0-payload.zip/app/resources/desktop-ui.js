export const DESKTOP_TOOLS = [
  ['desktop_list', 'List controllable Windows application windows after the user enabled Control de Windows. Browsers, terminals, authentication and security apps are excluded. No screen content is read yet.', {}],
  ['desktop_connect', 'Connect one returned window id. The user must approve this window for this task before screenshots or input. Never guess a window id.', { id: 'string' }],
  ['desktop_capture', 'Capture only the approved window. Returns pixels and a captureId. Observe this image before every input; coordinates are image pixels.', {}],
  ['desktop_click', 'Click a point from the latest approved-window screenshot. Requires its captureId. A moved window or stale screenshot is rejected. Returns an updated screenshot.', { x: 'number', y: 'number', captureId: 'string' }],
  ['desktop_type', 'Type literal text into the focused field of the approved window. Password fields are blocked. Requires the latest captureId. Returns an updated screenshot.', { text: 'string', captureId: 'string' }],
  ['desktop_press', 'Press a supported navigation key or Ctrl/Shift/Alt shortcut in the approved window, with the latest captureId. Windows/system shortcuts are blocked. Returns an updated screenshot.', { key: 'string', captureId: 'string' }],
  ['desktop_disconnect', 'Stop access to the connected window for this task.', {}]
];
const actions = { desktop_list: 'list', desktop_connect: 'connect', desktop_capture: 'capture', desktop_click: 'click', desktop_type: 'type', desktop_press: 'press', desktop_disconnect: 'disconnect' };
const denied = new Set();
export async function desktopTool(session, tool, args, C) {
  const key = session.id + ':' + session.activeTaskId;
  if (denied.has(key)) throw new Error('El usuario rechazó el control de Windows para esta tarea. No se vuelve a pedir.');
  if (!C.modelSeesImages(session) && !['desktop_list', 'desktop_disconnect'].includes(tool)) throw new Error('Este modelo no puede interpretar capturas. Selecciona uno con visión para controlar una ventana.');
  const spec = { ...args, action: actions[tool] }, ctx = C.nativeAgentContext(session);
  const call = async input => { const r = await C.D.desktop.run(input, ctx); if (!r.ok) throw new Error(r.error); return r.value; };
  let result = await call(spec);
  if (result.needs) {
    const need = result.needs;
    const answer = await C.queued(() => C.appConfirm({ title: need.type === 'connect' ? 'Permitir esta ventana a la IA' : 'Confirmar una acción en Windows',
      message: need.window.title + ' · ' + need.window.process,
      detail: need.type === 'connect' ? 'Durante esta tarea, Auric podrá ver esta ventana y actuar en ella. Las capturas se enviarán al modelo que elegiste y podrás ver la ventana en Preview. Mantén la aplicación visible. Las acciones sensibles volverán a preguntar.' : 'Elemento: ' + need.element + '\nAcción: ' + need.action + '\nContenido/punto: ' + need.text,
      buttons: ['Cancelar', 'Permitir'], defaultId: 0, cancelId: 0 }));
    if (answer !== 1) { denied.add(key); throw new Error('El usuario rechazó la acción de Windows.'); }
    if (C.stopped(session)) throw new Error('Tarea detenida por el usuario.');
    result = await call({ ...spec, confirmation: need.ticket });
  }
  if (result.connected) await C.connected(session, result.connected);
  if (['click', 'type', 'press'].includes(spec.action)) result = await call({ action: 'capture' });
  if (result.image?.base64) {
    const attachment = await C.saveGeneratedInline(result.image.base64, result.image.mime || 'image/png', 1, 'windows');
    return { text: result.text + '\nCaptureId: ' + result.captureId, attachment };
  }
  return result.windows ? JSON.stringify(result.windows.map(({ id, title, process, width, height }) => ({ id, title, process, width, height })), null, 2) : result.text || JSON.stringify(result);
}
export async function renderDesktopSettings(host, { D, esc, update }) {
  const r = await D.desktop.status();
  if (!r.ok) { host.textContent = r.error; return; }
  host.innerHTML = '<h4>Control de Windows · experimental</h4><p class="desc">La IA puede observar una ventana y hacer clic, escribir y pulsar teclas. Tú eliges y autorizas cada ventana por tarea; puedes ver su trabajo en Preview.</p><label><input type="checkbox" id="desktopEnabled" ' + (r.value.enabled ? 'checked' : '') + (!r.value.supported ? ' disabled' : '') + '> Ofrecer herramientas de Windows al agente</label><p class="desc">Requiere un modelo con visión y un escritorio activo. Algunas aplicaciones pueden impedir la captura o la entrada. No permite terminales, gestores de contraseñas, aplicaciones de seguridad ni navegadores con tus sesiones. Para páginas web usa el navegador propio de Auric. Los campos de contraseña se bloquean; la detección de otras acciones sensibles depende de las etiquetas que publique cada aplicación.</p><p id="desktopResult" aria-live="polite"></p>';
  host.querySelector('#desktopEnabled').onchange = async e => { const result = await D.desktop.configure(e.target.checked); host.querySelector('#desktopResult').textContent = result.ok ? (e.target.checked ? 'Herramientas habilitadas. Cada ventana pedirá permiso.' : 'Acceso revocado; las ventanas se desconectaron.') : result.error; if (result.ok) update(result.value.enabled); };
}
