const states = {
  queued: ['Esperando al servicio', '<circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/>'],
  thinking: ['Pensando', '<circle cx="6" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="18" cy="12" r="1"/>'],
  working: ['Trabajando', '<path d="m8 7-5 5 5 5m8-10 5 5-5 5m-3-12-2 14"/>'],
  waiting: ['Esperando tu respuesta', '<path d="M8 8a4 4 0 1 1 6 3.5c-2 1-2 1-2 3M12 18h.01"/>'],
  success: ['Terminado', '<path d="m5 12 4 4L19 6"/>'],
  paused: ['En pausa', '<path d="M8 6v12m8-12v12"/>'],
  error: ['Requiere atención', '<path d="M12 5v9m0 4h.01"/>'],
  idle: ['Auric', '<path d="m12 4 2 5 5 3-5 2-2 6-2-6-5-2 5-3z"/>']
};
const normal = state => states[state] ? state : /wait|approv|question|confirm/.test(state) ? 'waiting' : 'thinking';
export function guardianHtml(state = 'thinking') {
  state = normal(state); const [label, drawing] = states[state];
  return `<span class="guardian-avatar" data-guardian="${state}" role="img" aria-label="${label}"><img class="guardian-fallback" src="./icons/auric-dragon.png" alt=""><span class="guardian-signal"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${drawing}</svg></span></span>`;
}
export function paintGuardian(host, state) {
  if (!host) return;
  state = normal(state); const [label, drawing] = states[state];
  host.dataset.guardian = state; host.setAttribute('aria-label', label);
  const signal = host.querySelector('.guardian-signal svg'); if (signal) signal.innerHTML = drawing;
  import('./mascot/renderer.js').then(module => module.mountGuardian(host, state)).catch(() => {});
}
export function openGuardianStudio() {
  let dialog = document.querySelector('#guardianStudio');
  if (dialog) return dialog.showModal();
  dialog = document.createElement('dialog'); dialog.id = 'guardianStudio'; dialog.className = 'guardian-studio';
  dialog.innerHTML = '<header><div><h3>Guardián de Auric</h3><p>El personaje completo, construido por código.</p></div><button class="secondary-btn" data-close-guardian>Cerrar</button></header><div class="guardian-full-stage"></div><footer><label>Animación <select id="guardianAnimation"><option value="idle">En reposo</option><option value="thinking">Pensando</option><option value="working">Trabajando</option><option value="waiting">Esperando tu respuesta</option><option value="success">Terminado</option><option value="paused">En pausa</option></select></label><span>Arrastra para girarlo · rueda para acercar</span></footer>';
  document.body.append(dialog); dialog.showModal();
  let cleanup;
  dialog.querySelector('[data-close-guardian]').onclick = () => dialog.close();
  dialog.addEventListener('close', () => { cleanup?.(); dialog.remove(); });
  import('./mascot/renderer.js').then(module => { if (dialog.open) cleanup = module.mountFullGuardian(dialog.querySelector('.guardian-full-stage'), () => dialog.querySelector('select').value); }).catch(() => { dialog.querySelector('.guardian-full-stage').textContent = 'Esta vista necesita aceleración gráfica. El personaje se conserva en la carpeta Diseño.'; });
}
