import * as THREE from './vendor/three.module.js';

// Geometría original y paramétrica. No hay imágenes generadas ni modelos descargados.
export const concepts = {
  A: { name: 'Guardián', body: '#28313a', gold: '#d4a340', belly: '#aa7931', wing: '#28333e', eye: '#f6c252', length: 1, neck: 1, head: 1, spread: 1, crown: true },
  B: { name: 'Forjador', body: '#c38d34', gold: '#edc668', belly: '#5b5146', wing: '#76604a', eye: '#e5a541', length: .84, neck: .84, head: 1.14, spread: .78, crown: false },
  C: { name: 'Oráculo', body: '#465968', gold: '#cba45b', belly: '#ad833f', wing: '#324653', eye: '#8ed1d5', length: 1.14, neck: 1.15, head: .94, spread: 1.1, crown: false }
};
const sphere = new THREE.SphereGeometry(1, 32, 22);
const jointSphere = new THREE.SphereGeometry(1, 18, 12);
const v = p => new THREE.Vector3(...p);
const TAU = Math.PI * 2;

function tube(points, radius, endRadius, material, { segments = 32, radial = 12, depth = 1 } = {}) {
  const curve = new THREE.CatmullRomCurve3(points.map(v));
  const positions = [], indices = [];
  for (let i=0;i<=segments;i++) {
    const t=i/segments, center=curve.getPoint(t), tangent=curve.getTangent(t).normalize();
    let normal=new THREE.Vector3().crossVectors(tangent,new THREE.Vector3(0,0,1));
    if(normal.lengthSq()<.01)normal.crossVectors(tangent,new THREE.Vector3(0,1,0));
    normal.normalize();const bitangent=new THREE.Vector3().crossVectors(tangent,normal).normalize();
    const r=THREE.MathUtils.lerp(radius,endRadius,t);
    for(let j=0;j<radial;j++) {
      const angle=j/radial*TAU,p=center.clone().addScaledVector(normal,Math.cos(angle)*r).addScaledVector(bitangent,Math.sin(angle)*r*depth);
      positions.push(p.x,p.y,p.z);
      if(i<segments){const a=i*radial+j,b=i*radial+(j+1)%radial,c=(i+1)*radial+j,d=(i+1)*radial+(j+1)%radial;indices.push(a,b,c,b,d,c);}
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setIndex(indices);geometry.computeVertexNormals();
  const mesh=new THREE.Mesh(geometry,material);mesh.castShadow=true;mesh.receiveShadow=true;return mesh;
}

function ellipsoid(parent, material, position, scale, name='', low=false) {
  const mesh=new THREE.Mesh(low?jointSphere:sphere,material);mesh.position.set(...position);mesh.scale.set(...scale);mesh.castShadow=true;mesh.receiveShadow=true;mesh.name=name;parent.add(mesh);return mesh;
}

function membrane(a,b,material) {
  const rows=16,cols=10,positions=[],indices=[];
  const ca=new THREE.CatmullRomCurve3(a.map(v)),cb=new THREE.CatmullRomCurve3(b.map(v));
  for(let i=0;i<=rows;i++)for(let j=0;j<=cols;j++) {
    const t=i/rows,u=j/cols,p=ca.getPoint(t).lerp(cb.getPoint(t),u);
    p.y-=Math.sin(Math.PI*t)*Math.sin(Math.PI*u)*.13;
    positions.push(p.x,p.y,p.z);
    if(i<rows&&j<cols){const q=i*(cols+1)+j;indices.push(q,q+cols+1,q+1,q+1,q+cols+1,q+cols+2);}
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setIndex(indices);geometry.computeVertexNormals();
  const mesh=new THREE.Mesh(geometry,material);mesh.castShadow=true;mesh.receiveShadow=true;return mesh;
}

function scaleCoat(parent, material, center, radii, {rings=13,around=24}={}) {
  const items=[];
  for(let i=1;i<rings;i++)for(let j=0;j<around;j++) {
    const theta=i/rings*Math.PI,phi=(j+(i%2)*.5)/around*TAU;
    const unit=new THREE.Vector3(Math.cos(theta),Math.sin(theta)*Math.cos(phi),Math.sin(theta)*Math.sin(phi));
    if(unit.y<-.42)continue;
    const pos=new THREE.Vector3(unit.x*radii[0],unit.y*radii[1],unit.z*radii[2]).add(v(center));
    const normal=new THREE.Vector3(unit.x/radii[0],unit.y/radii[1],unit.z/radii[2]).normalize();
    items.push({pos,normal});
  }
  const leaf=new THREE.SphereGeometry(1,8,5),mesh=new THREE.InstancedMesh(leaf,material,items.length),dummy=new THREE.Object3D();
  items.forEach((item,i)=>{dummy.position.copy(item.pos);dummy.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),item.normal);dummy.scale.set(.125,.038,.11);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});
  mesh.castShadow=true;mesh.receiveShadow=true;mesh.name='Escamas geométricas';parent.add(mesh);
}

export function createDragon(id='A') {
  const cfg=concepts[id]||concepts.A;
  const mat=(color,metalness=.38,roughness=.38)=>new THREE.MeshStandardMaterial({color,metalness,roughness});
  const materials={body:mat(cfg.body,.28,.44),scales:mat(new THREE.Color(cfg.body).multiplyScalar(1.13),.35,.35),gold:mat(cfg.gold,.7,.27),belly:mat(cfg.belly,.42,.4),black:mat('#10181c',.1,.5),eye:mat(cfg.eye,.35,.22),wing:mat(cfg.wing,.22,.5)};
  materials.wing.side=THREE.DoubleSide;
  const root=new THREE.Group();root.name=`Auric ${id} ${cfg.name}`;root.userData={concept:id,createdBy:'Auric',procedural:true};
  const body=new THREE.Group();root.add(body);body.name='Torso';
  ellipsoid(body,materials.body,[-.15,1.23,0],[1.1*cfg.length,.64,.55]);
  ellipsoid(body,materials.body,[.48,1.48,0],[.64,.77,.56]);
  ellipsoid(body,materials.belly,[.58,1.2,.0],[.38,.55,.47]);
  scaleCoat(body,materials.scales,[-.15,1.23,0],[1.105*cfg.length,.655,.555]);
  const neckPoints=[[.58,1.64,0],[.84,1.94,0],[.92,2.31*cfg.neck,0],[1.20,2.63*cfg.neck,0]];
  body.add(tube(neckPoints,.44,.285,materials.body,{depth:.88,segments:32}));
  const throat=neckPoints.map(([x,y,z])=>[x+.24,y-.08,z]);body.add(tube(throat,.22,.19,materials.belly,{depth:1.28,radial:14}));
  for(let i=0;i<8;i++) {
    const t=i/7,x=THREE.MathUtils.lerp(.7,1.26,t),y=THREE.MathUtils.lerp(1.7,2.59*cfg.neck,t);
    ellipsoid(body,materials.gold,[x+.10,y-.07,0],[.25,.035,.31*(1-t*.37)],'Placa de garganta',true).rotation.z=-.35;
  }
  for(let i=0;i<11;i++) {
    const x=.52-i*.17,y=1.84-Math.pow(i/11,1.7)*.28;
    body.add(tube([[x,y,0],[x-.03,y+.18,0],[x-.19,y+.34-i*.012,0]],.10,.002,materials.gold,{segments:10,radial:8,depth:.55}));
  }
  const neckCurve=new THREE.CatmullRomCurve3(neckPoints.map(v));
  for(let i=1;i<8;i++){const p=neckCurve.getPoint(i/8);body.add(tube([[p.x-.28,p.y,0],[p.x-.45,p.y+.13,0],[p.x-.48,p.y+.27,0]],.075,.002,materials.gold,{segments:9,radial:8,depth:.5}));}

  const head=new THREE.Group();head.name='Cabeza articulada';head.position.set(1.20,2.63*cfg.neck,0);head.scale.setScalar(cfg.head);body.add(head);
  ellipsoid(head,materials.body,[.14,.12,0],[.51,.34,.33]);
  ellipsoid(head,materials.body,[.54,-.025,0],[.43,.19,.25]);
  const jaw=new THREE.Group();jaw.position.set(.05,-.18,0);head.add(jaw);ellipsoid(jaw,materials.belly,[.38,-.015,0],[.52,.095,.235]);
  const eyes=[];
  for(const side of [-1,1]) {
    ellipsoid(head,materials.body,[.10,-.045,side*.22],[.27,.22,.18]);
    const eye=ellipsoid(head,materials.eye,[.30,.16,side*.291],[.115,.09,.07],'Ojo');
    const pupil=ellipsoid(head,materials.black,[.33,.16,side*.35],[.027,.070,.015],'Pupila',true);eyes.push({eye,pupil});
    ellipsoid(head,materials.gold,[.27,.25,side*.27],[.24,.065,.105],'Ceja').rotation.z=-.22;
    ellipsoid(head,materials.black,[.87,.03,side*.135],[.035,.023,.016],'Fosa nasal',true);
    head.add(tube([[.89,-.12,side*.18],[.57,-.20,side*.24],[.19,-.18,side*.30]],.012,.008,materials.black,{segments:14,radial:6}));
    head.add(tube([[-.12,.31,side*.22],[-.31,.62,side*.29],[-.64,.80,side*.34],[-.83,.88,side*.37]],.13,.002,materials.gold,{segments:24,radial:12}));
    for(let i=0;i<4;i++){const y=.18-i*.14;head.add(tube([[-.17,y,side*.25],[-.43,y+.04,side*(.38+i*.02)],[-.53,y-.14,side*(.33+i*.03)]],.095,.001,materials.gold,{segments:13,radial:8,depth:.5}));}
  }
  if(cfg.crown) {
    const crown=new THREE.Group();crown.position.set(.09,.43,0);head.add(crown);
    const band=new THREE.Mesh(new THREE.TorusGeometry(.25,.027,8,32),materials.gold);band.rotation.x=Math.PI/2;crown.add(band);
    for(let i=0;i<5;i++){const angle=i/5*TAU;const spike=new THREE.Mesh(new THREE.ConeGeometry(.065,.25+(i===0?.06:0),4),materials.gold);spike.position.set(Math.cos(angle)*.23,.10,Math.sin(angle)*.23);crown.add(spike);}
  }

  const wings=[];
  for(const side of [-1,1]) {
    const wing=new THREE.Group();wing.name=side<0?'Ala izquierda':'Ala derecha';wing.position.set(.17,1.73,side*.43);wing.scale.set(1,1,side*cfg.spread);body.add(wing);wings.push(wing);
    const rays=[
      [[0,0,0],[.12,.48,.29],[-.18,1.14,.76],[-.65,1.42,1.10]],
      [[0,0,0],[-.11,.63,.56],[-.79,.97,1.30],[-1.33,1.00,1.70]],
      [[0,0,0],[-.48,.40,.56],[-1.13,.46,1.28],[-1.76,.42,1.65]],
      [[0,0,0],[-.68,.20,.35],[-1.33,.11,.79],[-1.84,-.10,1.10]],
      [[0,0,0],[-.59,-.04,.17],[-1.11,-.19,.35],[-1.44,-.35,.45]]
    ];
    for(let i=0;i<rays.length;i++) {
      wing.add(tube(rays[i],i===0?.08:.045,.008,materials.gold,{segments:22,radial:9}));
      if(i)wing.add(membrane(rays[i-1],rays[i],materials.wing));
    }
    wing.add(tube([rays[0][3],[-.73,1.64,1.15],[-.96,1.64,1.12]],.065,.001,materials.gold,{segments:14,radial:8}));
  }

  const legs=[];
  for(const side of [-1,1])for(const front of [true,false]) {
    const leg=new THREE.Group();leg.name=(front?'Brazo':'Pierna')+(side<0?' izquierdo':' derecho');root.add(leg);
    const x=front?.52:-.84*cfg.length;leg.position.set(x,1.3,side*.43);
    const a=[0,0,0],b=[front?.04:-.25,-.55,side*.12],c=[front?.22:-.12,-1.04,side*.15];
    leg.add(tube([a,b,c],front?.25:.34,.13,materials.body,{segments:20,radial:14,depth:1}));
    ellipsoid(leg,materials.body,b,[front?.23:.29,.30,.20]);
    ellipsoid(leg,materials.body,[c[0]+.12,-1.13,c[2]],[.32,.13,.22]);
    for(let toe=0;toe<3;toe++) {
      const z=c[2]+(toe-1)*.14;
      ellipsoid(leg,materials.body,[c[0]+.25,-1.15,z],[.19,.10,.085],'Dedo',true);
      leg.add(tube([[c[0]+.34,-1.14,z],[c[0]+.49,-1.16,z],[c[0]+.52,-1.24,z]],.052,.001,materials.gold,{segments:10,radial:8}));
    }
    legs.push({group:leg,front,side});
  }

  const tail=new THREE.Group();tail.position.set(-.90*cfg.length,1.16,0);tail.name='Cola articulada';root.add(tail);
  tail.add(tube([[0,0,0],[-.72,-.20,.1],[-1.36,-.63,.50],[-1.43,-.88,1.15],[-.83,-.95,1.64],[.03,-.94,1.79]],.32,.012,materials.body,{segments:60,radial:14}));
  const tailCurve=new THREE.CatmullRomCurve3([[0,0,0],[-.72,-.20,.1],[-1.36,-.63,.50],[-1.43,-.88,1.15],[-.83,-.95,1.64],[.03,-.94,1.79]].map(v));
  for(let i=1;i<18;i++){const t=i/18,p=tailCurve.getPoint(t),height=.22*(1-t*.7);tail.add(tube([[p.x,p.y+.12*(1-t),p.z],[p.x-.07,p.y+height+.10,p.z],[p.x-.18,p.y+height+.05,p.z]],.065*(1-t*.7),.001,materials.gold,{segments:8,radial:7,depth:.5}));}
  tail.add(tube([[-.18,-.91,1.78],[.09,-.85,1.81],[.26,-.94,1.83]],.09,.001,materials.gold,{segments:12,radial:8,depth:.5}));
  return {root,rig:{body,head,jaw,eyes,wings,legs,tail},config:cfg};
}

export function animateDragon(dragon,time,state='idle',motion=true) {
  const {body,head,jaw,eyes,wings,legs,tail}=dragon.rig,t=motion?time:0;
  body.scale.y=1+Math.sin(t*1.6)*.012;
  head.rotation.set(0,0,0);jaw.rotation.z=0;
  wings.forEach((wing,i)=>wing.rotation.x=(i?1:-1)*(.06+Math.sin(t*1.4)*.035));
  legs.forEach(({group})=>group.rotation.set(0,0,0));
  tail.rotation.y=Math.sin(t*.7)*.035;
  const blink=motion&&Math.sin(t*.7)>.992?.13:1;
  for(const {eye,pupil} of eyes){eye.scale.y=.09*blink;pupil.scale.y=.07*blink;}
  if(state==='thinking') {head.rotation.z=-.12+Math.sin(t*.8)*.035;head.rotation.y=Math.sin(t*.55)*.13;legs.find(l=>l.front&&l.side===1).group.rotation.z=-.18;tail.rotation.y=Math.sin(t*.9)*.09;}
  if(state==='working') {head.rotation.z=-.09;legs.filter(l=>l.front).forEach(({group,side})=>group.rotation.z=Math.max(0,Math.sin(t*4+side*1.5))*.15);wings.forEach((wing,i)=>wing.rotation.x=(i?1:-1)*(.11+Math.sin(t*2)*.07));}
  if(state==='waiting') {head.rotation.z=-.18;head.rotation.y=.22;tail.rotation.y=.09;}
  if(state==='success') {head.rotation.z=Math.sin(t*3)*.08;wings.forEach((wing,i)=>wing.rotation.x=(i?1:-1)*(.25+Math.sin(t*3)*.18));jaw.rotation.z=-.04;}
  if(state==='paused') {head.rotation.z=-.30;head.rotation.y=.1;eyes.forEach(({eye,pupil})=>{eye.scale.y=.02;pupil.scale.y=.015;});}
}

export function exportOBJ(root) {
  root.updateMatrixWorld(true);let output='# AuricCode — modelo procedural\n',offset=1;
  const point=new THREE.Vector3(),instance=new THREE.Matrix4(),world=new THREE.Matrix4();
  root.traverse(mesh=>{
    if(!mesh.isMesh)return;
    const geometry=mesh.geometry,positions=geometry.getAttribute('position'),index=geometry.index;
    const count=mesh.isInstancedMesh?mesh.count:1;
    for(let n=0;n<count;n++) {
      if(mesh.isInstancedMesh){mesh.getMatrixAt(n,instance);world.multiplyMatrices(mesh.matrixWorld,instance);}else world.copy(mesh.matrixWorld);
      output+='o '+(mesh.name||'parte').replace(/\s/g,'_')+'\n';
      for(let i=0;i<positions.count;i++){point.fromBufferAttribute(positions,i).applyMatrix4(world);output+=`v ${point.x.toFixed(5)} ${point.y.toFixed(5)} ${point.z.toFixed(5)}\n`;}
      const total=index?index.count:positions.count;
      for(let i=0;i<total;i+=3){const a=index?index.getX(i):i,b=index?index.getX(i+1):i+1,c=index?index.getX(i+2):i+2;output+=`f ${a+offset} ${b+offset} ${c+offset}\n`;}
      offset+=positions.count;
    }
  });return output;
}
