import * as THREE from './vendor/three.module.js';
import { createDragon, animateDragon } from './dragon-models.js';
let avatar = null;
const reduced = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
function studio(alpha = true) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha, powerPreference: 'low-power' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5)); renderer.toneMapping = THREE.ACESFilmicToneMapping;
  const scene = new THREE.Scene();
  scene.add(new THREE.HemisphereLight('#f1e9da', '#243543', 3));
  const key = new THREE.DirectionalLight('#fff0cd', 4); key.position.set(3, 5, 5); scene.add(key);
  const rim = new THREE.DirectionalLight('#b5d6ef', 2); rim.position.set(-3, 2, -3); scene.add(rim);
  return { renderer, scene };
}
export function exportGuardianPortrait() {
  const {renderer, scene} = studio(); const dragon = createDragon('A');
  const head = dragon.rig.head; head.position.set(0, 0, 0); scene.add(head);
  const bounds = new THREE.Box3().setFromObject(head), center = bounds.getCenter(new THREE.Vector3());
  const camera = new THREE.PerspectiveCamera(33, 1, .05, 20); camera.position.copy(center).add(new THREE.Vector3(.25, .12, 4.2)); camera.lookAt(center);
  renderer.setPixelRatio(1); renderer.setSize(512, 512); renderer.render(scene, camera);
  const data = renderer.domElement.toDataURL('image/png'); renderer.dispose(); return data;
}
export function mountGuardian(host, state) {
  if (!host?.isConnected) return;
  if (!avatar) {
    const {renderer, scene} = studio(); const dragon = createDragon('A');
    const head = dragon.rig.head; head.position.set(0, 0, 0); scene.add(head);
    const camera = new THREE.PerspectiveCamera(33, 1, .05, 20); camera.position.set(1.15, .42, 2.65); camera.lookAt(.15, .22, 0);
    renderer.setSize(64, 64); renderer.domElement.className = 'guardian-canvas'; renderer.domElement.setAttribute('aria-hidden', 'true');
    avatar = {renderer, scene, camera, dragon, host, state, active: false, last: 0};
  }
  avatar.host = host; avatar.state = state;
  if (avatar.renderer.domElement.parentNode !== host) host.prepend(avatar.renderer.domElement);
  host.classList.add('has-3d');
  if (avatar.active) return;
  avatar.active = true;
  function frame(now) {
    if (!avatar.host?.isConnected) { avatar.active = false; return; }
    if (now - avatar.last >= 66) {
      avatar.last = now;
      if (!document.hidden && avatar.host.getClientRects().length) {
        animateDragon(avatar.dragon, now / 1000, avatar.state, !reduced());
        avatar.renderer.render(avatar.scene, avatar.camera);
      }
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}
export function mountFullGuardian(host, state) {
  const {renderer, scene} = studio(); const dragon = createDragon('A'); scene.add(dragon.root);
  const camera = new THREE.PerspectiveCamera(36, 1, .1, 40); let angle = .72, distance = 9, pitch = .15, stopped = false, pointer = null, last = 0;
  host.append(renderer.domElement);
  const update = () => { camera.position.set(Math.sin(angle)*distance, 1.7 + pitch*distance, Math.cos(angle)*distance); camera.lookAt(0, 1.6, .1); };
  const resize = new ResizeObserver(() => { if (!host.clientWidth || !host.clientHeight) return; renderer.setSize(host.clientWidth, host.clientHeight); camera.aspect = host.clientWidth / host.clientHeight; camera.updateProjectionMatrix(); update(); }); resize.observe(host);
  renderer.domElement.onpointerdown = e => { pointer = [e.clientX, e.clientY]; renderer.domElement.setPointerCapture(e.pointerId); };
  renderer.domElement.onpointermove = e => { if (!pointer) return; angle -= (e.clientX-pointer[0])*.008; pitch = THREE.MathUtils.clamp(pitch+(e.clientY-pointer[1])*.005,-.1,.6); pointer = [e.clientX,e.clientY]; update(); };
  renderer.domElement.onpointerup = renderer.domElement.onpointercancel = () => pointer = null;
  renderer.domElement.addEventListener('wheel', e => { e.preventDefault(); distance = THREE.MathUtils.clamp(distance+e.deltaY*.008, 6, 15); update(); }, {passive:false});
  function frame(now) { if (stopped) return; if (!document.hidden && now-last>=40) { last=now; animateDragon(dragon,now/1000,state(),!reduced()); renderer.render(scene,camera); } requestAnimationFrame(frame); } requestAnimationFrame(frame);
  return () => { stopped = true; resize.disconnect(); renderer.dispose(); const geometries=new Set(),materials=new Set(); dragon.root.traverse(m=>{if(m.geometry)geometries.add(m.geometry);if(m.material)materials.add(m.material);}); geometries.forEach(g=>g.dispose()); materials.forEach(m=>m.dispose()); };
}
