extends SceneTree
# Auric Code · arnés de juego para Godot 4.x
#
# Auric lanza el juego con `--script auric_harness.gd` y le habla escribiendo `cmd.json` dentro de la carpeta
# de sesión; el arnés responde con `res-<id>.json`. El juego corre COMPLETO (escena principal, autoloads,
# audio, físicas): el arnés solo inyecta entradas y observa. No modifica el proyecto del usuario.
#
# Argumentos de usuario (después de `--`):
#   --auric-dir=<carpeta de sesión>   (obligatorio)
#   --auric-scene=res://x.tscn        (opcional, por defecto la escena principal del proyecto)
#   --auric-live=<ms>                 (opcional, guarda live.png cada N ms para el panel Preview)
#   --auric-mute                      (opcional, silencia el bus Master)
#   --auric-background                (opcional, ventana sin foco)
#   --auric-idle=<segundos>           (opcional, cierra el juego si nadie envía comandos; 0 = nunca)

var dir := ""
var scene_override := ""
var live_ms := 0
var idle_s := 900
var busy := false
var want_quit := false
var main_node: Node = null
var last_cmd_ms := 0
var live_next_ms := 0
var live_busy := false
var held := {}
var started_ms := 0

func _initialize() -> void:
	started_ms = Time.get_ticks_msec()
	last_cmd_ms = started_ms
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--auric-dir="): dir = a.substr(12)
		elif a.begins_with("--auric-scene="): scene_override = a.substr(14)
		elif a.begins_with("--auric-live="): live_ms = int(a.substr(13))
		elif a.begins_with("--auric-idle="): idle_s = int(a.substr(13))
		elif a == "--auric-mute": AudioServer.set_bus_mute(0, true)
		elif a == "--auric-background":
			DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_NO_FOCUS, true)
	if dir == "":
		printerr("[auric-harness] falta --auric-dir")
		quit(2)
		return
	var path := scene_override
	if path == "":
		path = str(ProjectSettings.get_setting("application/run/main_scene", ""))
	if path == "":
		_write_json("ready.json", {"ok": false, "error": "El proyecto no tiene escena principal (application/run/main_scene)."})
		printerr("[auric-harness] sin escena principal")
		return
	var packed = load(path)
	if packed == null or not (packed is PackedScene):
		_write_json("ready.json", {"ok": false, "error": "No se pudo cargar la escena " + path})
		printerr("[auric-harness] no se pudo cargar ", path)
		return
	main_node = packed.instantiate()
	root.add_child(main_node)
	current_scene = main_node
	# Un fotograma después para que `info` refleje el estado real.
	process_frame.connect(func(): _write_json("ready.json", _info(true)), CONNECT_ONE_SHOT)

func _process(_delta: float) -> bool:
	var now := Time.get_ticks_msec()
	if live_ms > 0 and not live_busy and now >= live_next_ms and main_node != null:
		live_busy = true
		RenderingServer.frame_post_draw.connect(_live_capture, CONNECT_ONE_SHOT)
	if idle_s > 0 and (now - last_cmd_ms) > idle_s * 1000 and not busy:
		print("[auric-harness] cerrando por inactividad")
		return true
	if not busy and dir != "":
		var p := dir.path_join("cmd.json")
		if FileAccess.file_exists(p):
			var f := FileAccess.open(p, FileAccess.READ)
			var txt := f.get_as_text() if f != null else ""
			if f != null: f.close()
			DirAccess.remove_absolute(p)
			var parsed = JSON.parse_string(txt)
			if typeof(parsed) == TYPE_DICTIONARY:
				busy = true
				last_cmd_ms = now
				_run(parsed)
	return want_quit

func _run(c: Dictionary) -> void:
	var id := str(c.get("id", "0"))
	var out: Dictionary
	var r = await _exec(c)
	if typeof(r) == TYPE_DICTIONARY:
		out = r
	else:
		out = {"ok": true, "value": _j(r)}
	out["id"] = id
	if not out.has("ok"): out["ok"] = true
	_write_json("res-%s.json" % id, out)
	busy = false

func _exec(c: Dictionary):
	var cmd := str(c.get("cmd", ""))
	match cmd:
		"info":
			return _info(false)
		"wait":
			if c.has("frames"):
				for i in range(clampi(int(c["frames"]), 1, 3600)):
					await process_frame
			else:
				await _real_wait(clampf(float(c.get("ms", 500)) / 1000.0, 0.0, 120.0))
			return {"ok": true, "waited": true}
		"key":
			return await _key(c)
		"type":
			return await _type(str(c.get("text", "")))
		"action":
			return await _action(c)
		"mouse":
			return await _mouse(c)
		"screenshot":
			return await _screenshot(c)
		"tree":
			var base := _node(str(c.get("node", "")))
			if base == null: return _err("Nodo no encontrado: " + str(c.get("node", "")))
			var lines: PackedStringArray = []
			var budget := [clampi(int(c.get("max_nodes", 300)), 10, 2000)]
			_dump(base, 0, clampi(int(c.get("depth", 4)), 0, 20), lines, budget)
			return {"ok": true, "tree": "\n".join(lines), "truncated": budget[0] <= 0}
		"get":
			var n := _node(str(c.get("node", "")))
			if n == null: return _err("Nodo no encontrado: " + str(c.get("node", "")))
			var prop := str(c.get("prop", ""))
			if prop == "": return _err("Falta prop.")
			return {"ok": true, "value": _j(n.get_indexed(NodePath(prop)))}
		"set":
			var n2 := _node(str(c.get("node", "")))
			if n2 == null: return _err("Nodo no encontrado: " + str(c.get("node", "")))
			var prop2 := str(c.get("prop", ""))
			if prop2 == "": return _err("Falta prop.")
			var val = _coerce(n2.get_indexed(NodePath(prop2)), c.get("value"))
			if c.has("expr"):
				var ev = _evaluate(str(c["expr"]), n2)
				if typeof(ev) == TYPE_DICTIONARY and ev.has("__error"): return _err(str(ev["__error"]))
				val = ev
			n2.set_indexed(NodePath(prop2), val)
			return {"ok": true, "value": _j(n2.get_indexed(NodePath(prop2)))}
		"call":
			var n3 := _node(str(c.get("node", "")))
			if n3 == null: return _err("Nodo no encontrado: " + str(c.get("node", "")))
			var m := str(c.get("method", ""))
			if not n3.has_method(m): return _err("El nodo no tiene el método " + m)
			var res = n3.callv(m, c.get("args", []))
			return {"ok": true, "value": _j(res)}
		"eval":
			var base2 := _node(str(c.get("node", "")))
			if base2 == null: return _err("Nodo no encontrado: " + str(c.get("node", "")))
			var v = _evaluate(str(c.get("expr", "")), base2)
			if typeof(v) == TYPE_DICTIONARY and v.has("__error"): return _err(str(v["__error"]))
			return {"ok": true, "value": _j(v)}
		"scene":
			var sp := str(c.get("path", ""))
			if not ResourceLoader.exists(sp): return _err("No existe la escena " + sp)
			var e := change_scene_to_file(sp)
			await process_frame
			await process_frame
			main_node = current_scene
			return {"ok": e == OK, "scene": sp}
		"time_scale":
			Engine.time_scale = clampf(float(c.get("scale", 1.0)), 0.05, 20.0)
			return {"ok": true, "time_scale": Engine.time_scale}
		"pause":
			paused = bool(c.get("paused", true))
			return {"ok": true, "paused": paused}
		"mute":
			AudioServer.set_bus_mute(0, bool(c.get("mute", true)))
			return {"ok": true, "muted": AudioServer.is_bus_mute(0)}
		"log":
			print("[auric] ", str(c.get("text", "")))
			return {"ok": true}
		"quit":
			want_quit = true
			return {"ok": true, "quitting": true}
	return _err("Comando desconocido: " + cmd)

# ---------- utilidades ----------
func _err(m: String) -> Dictionary:
	return {"ok": false, "error": m}

func _real_wait(sec: float) -> void:
	if sec <= 0.0:
		await process_frame
		return
	# Tiempo real (ignora Engine.time_scale y la pausa).
	await create_timer(sec, true, false, true).timeout

func _node(p: String) -> Node:
	if p == "" or p == ".":
		return current_scene if current_scene != null else root
	if p.begins_with("/"):
		return root.get_node_or_null(p)
	if current_scene != null:
		var n := current_scene.get_node_or_null(p)
		if n != null: return n
	return root.get_node_or_null(p)

func _info(first: bool) -> Dictionary:
	var d := {
		"ok": true,
		"godot": Engine.get_version_info().get("string", ""),
		"fps": Engine.get_frames_per_second(),
		"frames": Engine.get_process_frames(),
		"scene": current_scene.scene_file_path if current_scene != null else "",
		"scene_name": current_scene.name if current_scene != null else "",
		"window": [root.size.x, root.size.y],
		"time_scale": Engine.time_scale,
		"paused": paused,
		"uptime_ms": Time.get_ticks_msec() - started_ms,
		"user_dir": OS.get_user_data_dir(),
		"muted": AudioServer.is_bus_mute(0),
		"audio_driver": AudioServer.get_driver_name() if AudioServer.has_method("get_driver_name") else "",
		"nodes": int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)),
		"ready": first
	}
	return d

func _live_capture() -> void:
	live_next_ms = Time.get_ticks_msec() + live_ms
	var img := root.get_texture().get_image()
	if img != null and not img.is_empty():
		if img.get_width() > 640:
			img.resize(640, int(img.get_height() * 640.0 / img.get_width()), Image.INTERPOLATE_BILINEAR)
		var tmp := dir.path_join("live.tmp.png")
		if img.save_png(tmp) == OK:
			DirAccess.rename_absolute(tmp, dir.path_join("live.png"))
	live_busy = false

func _screenshot(c: Dictionary) -> Dictionary:
	await RenderingServer.frame_post_draw
	var img := root.get_texture().get_image()
	if img == null or img.is_empty():
		return _err("No hay imagen (¿Godot está en modo headless?). Inicia la sesión con ventana.")
	var maxw := clampi(int(c.get("max_width", 960)), 160, 3840)
	if img.get_width() > maxw:
		img.resize(maxw, int(img.get_height() * float(maxw) / img.get_width()), Image.INTERPOLATE_BILINEAR)
	var name := str(c.get("name", "shot")).validate_filename()
	if name == "": name = "shot"
	var file := "shot-%s-%d.png" % [name, Time.get_ticks_msec()]
	var full := dir.path_join(file)
	var e := img.save_png(full)
	if e != OK: return _err("No se pudo guardar la captura (%d)" % e)
	return {"ok": true, "file": file, "width": img.get_width(), "height": img.get_height()}

func _keycode(name: String) -> int:
	var k := OS.find_keycode_from_string(name)
	if k == KEY_NONE and name.length() == 1:
		k = OS.find_keycode_from_string(name.to_upper())
	return k

func _key_event(k: int, pressed: bool, unicode := 0) -> InputEventKey:
	var ev := InputEventKey.new()
	ev.keycode = k
	ev.physical_keycode = k
	ev.key_label = k
	ev.unicode = unicode
	ev.pressed = pressed
	return ev

func _key(c: Dictionary) -> Dictionary:
	var name := str(c.get("key", ""))
	var k := _keycode(name)
	if k == KEY_NONE: return _err("Tecla desconocida: " + name)
	var mode := str(c.get("mode", "tap"))
	var hold := clampf(float(c.get("hold_ms", 80)) / 1000.0, 0.0, 60.0)
	if mode == "down":
		Input.parse_input_event(_key_event(k, true))
		held[k] = true
	elif mode == "up":
		Input.parse_input_event(_key_event(k, false))
		held.erase(k)
	else:
		Input.parse_input_event(_key_event(k, true))
		await _real_wait(hold)
		Input.parse_input_event(_key_event(k, false))
	return {"ok": true, "key": name, "mode": mode}

func _type(text: String) -> Dictionary:
	for i in text.length():
		var ch := text.substr(i, 1)
		var k := _keycode(ch)
		if k == KEY_NONE: k = KEY_UNKNOWN
		Input.parse_input_event(_key_event(k, true, ch.unicode_at(0)))
		await process_frame
		Input.parse_input_event(_key_event(k, false, ch.unicode_at(0)))
		await process_frame
	return {"ok": true, "typed": text.length()}

func _action(c: Dictionary) -> Dictionary:
	var a := str(c.get("name", ""))
	if not InputMap.has_action(a): return _err("La acción no existe en el InputMap: " + a)
	var mode := str(c.get("mode", "tap"))
	var strength := clampf(float(c.get("strength", 1.0)), 0.0, 1.0)
	var hold := clampf(float(c.get("hold_ms", 100)) / 1000.0, 0.0, 60.0)
	if mode == "up":
		Input.action_release(a)
	else:
		Input.action_press(a, strength)
		if mode != "down":
			await _real_wait(hold)
			Input.action_release(a)
	return {"ok": true, "action": a, "mode": mode}

func _mouse(c: Dictionary) -> Dictionary:
	var pos := Vector2(float(c.get("x", 0)), float(c.get("y", 0)))
	var btn := MOUSE_BUTTON_LEFT
	match str(c.get("button", "left")):
		"right": btn = MOUSE_BUTTON_RIGHT
		"middle": btn = MOUSE_BUTTON_MIDDLE
	var mode := str(c.get("mode", "click"))
	var mv := InputEventMouseMotion.new()
	mv.position = pos
	mv.global_position = pos
	mv.relative = Vector2.ZERO
	Input.parse_input_event(mv)
	if mode == "move":
		return {"ok": true, "x": pos.x, "y": pos.y}
	if mode == "wheel_up" or mode == "wheel_down":
		var w := InputEventMouseButton.new()
		w.position = pos
		w.global_position = pos
		w.button_index = MOUSE_BUTTON_WHEEL_UP if mode == "wheel_up" else MOUSE_BUTTON_WHEEL_DOWN
		w.pressed = true
		Input.parse_input_event(w)
		await process_frame
		w.pressed = false
		Input.parse_input_event(w)
		return {"ok": true}
	var ev := InputEventMouseButton.new()
	ev.position = pos
	ev.global_position = pos
	ev.button_index = btn
	ev.button_mask = 1 << (btn - 1)
	if mode == "up":
		ev.pressed = false
		ev.button_mask = 0
		Input.parse_input_event(ev)
	else:
		ev.pressed = true
		Input.parse_input_event(ev)
		if mode == "click":
			await _real_wait(0.06)
			var up := ev.duplicate() as InputEventMouseButton
			up.pressed = false
			up.button_mask = 0
			Input.parse_input_event(up)
	return {"ok": true, "x": pos.x, "y": pos.y, "mode": mode}

func _brief(n: Node) -> String:
	var s := "%s (%s)" % [n.name, n.get_class()]
	if n.get_script() != null:
		var sc: Script = n.get_script()
		if sc.resource_path != "": s += " script=" + sc.resource_path.get_file()
	if n is Node2D: s += " pos=" + str((n as Node2D).position)
	elif n is Control: s += " pos=" + str((n as Control).position) + " size=" + str((n as Control).size)
	elif n is Node3D: s += " pos=" + str((n as Node3D).position)
	if n is CanvasItem and not (n as CanvasItem).visible: s += " [oculto]"
	if n is Label: s += " text=\"" + str((n as Label).text).left(60) + "\""
	elif n is BaseButton and "text" in n: s += " text=\"" + str(n.get("text")).left(60) + "\""
	elif n is RichTextLabel: s += " text=\"" + (n as RichTextLabel).get_parsed_text().left(60) + "\""
	return s

func _dump(n: Node, depth: int, max_depth: int, lines: PackedStringArray, budget: Array) -> void:
	if budget[0] <= 0: return
	budget[0] -= 1
	lines.append("  ".repeat(depth) + _brief(n))
	if depth >= max_depth: return
	for ch in n.get_children():
		_dump(ch, depth + 1, max_depth, lines, budget)

func _evaluate(src: String, base: Object):
	var ex := Expression.new()
	var e := ex.parse(src, ["root", "scene"])
	if e != OK: return {"__error": "Expresión no válida: " + ex.get_error_text()}
	var r = ex.execute([root, current_scene], base, true)
	if ex.has_execute_failed(): return {"__error": "Falló la evaluación: " + ex.get_error_text()}
	return r

func _coerce(current, v):
	match typeof(current):
		TYPE_VECTOR2:
			if v is Array and v.size() >= 2: return Vector2(float(v[0]), float(v[1]))
		TYPE_VECTOR3:
			if v is Array and v.size() >= 3: return Vector3(float(v[0]), float(v[1]), float(v[2]))
		TYPE_COLOR:
			if v is String: return Color(v)
			if v is Array and v.size() >= 3: return Color(float(v[0]), float(v[1]), float(v[2]), float(v[3]) if v.size() > 3 else 1.0)
		TYPE_INT:
			if v is float: return int(v)
		TYPE_FLOAT:
			if v is int: return float(v)
	return v

func _j(v, depth := 0):
	if depth > 6: return str(v)
	match typeof(v):
		TYPE_NIL, TYPE_BOOL, TYPE_INT, TYPE_FLOAT, TYPE_STRING:
			if typeof(v) == TYPE_FLOAT and (is_nan(v) or is_inf(v)): return str(v)
			return v
		TYPE_STRING_NAME, TYPE_NODE_PATH: return str(v)
		TYPE_VECTOR2, TYPE_VECTOR2I: return [v.x, v.y]
		TYPE_VECTOR3, TYPE_VECTOR3I: return [v.x, v.y, v.z]
		TYPE_RECT2: return {"x": v.position.x, "y": v.position.y, "w": v.size.x, "h": v.size.y}
		TYPE_COLOR: return "#" + v.to_html()
		TYPE_ARRAY, TYPE_PACKED_STRING_ARRAY, TYPE_PACKED_INT32_ARRAY, TYPE_PACKED_FLOAT32_ARRAY, TYPE_PACKED_VECTOR2_ARRAY:
			var a := []
			for x in v:
				a.append(_j(x, depth + 1))
				if a.size() >= 200: break
			return a
		TYPE_DICTIONARY:
			var d := {}
			for k in v:
				d[str(k)] = _j(v[k], depth + 1)
				if d.size() >= 200: break
			return d
		TYPE_OBJECT:
			if v == null: return null
			if v is Node: return "Node:" + str(v.get_path())
			return str(v)
	return str(v)

func _write_json(name: String, data: Dictionary) -> void:
	var tmp := dir.path_join(name + ".tmp")
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		printerr("[auric-harness] no se pudo escribir ", tmp)
		return
	f.store_string(JSON.stringify(data))
	f.close()
	DirAccess.rename_absolute(tmp, dir.path_join(name))
