// Plugins: catálogo, importación, ventana de revisión de seguridad y detalle.
// Solo interfaz: la revisión, la instalación, las claves y la comprobación de integridad ocurren en el proceso principal.
// Todo texto que venga de un plugin (nombres, descripciones, comandos, hallazgos) se escribe SIEMPRE escapado.
let P = null;
let installed = [];
let catalog = [];
let loaded = false;
let loadError = '';
let query = '';
const busy = new Set();

const SEV_LABEL = { danger: 'Riesgo alto', warn: 'Atención', info: 'Informativo' };
const SEV_ORDER = ['danger', 'warn', 'info'];
const AREA_LABEL = {
  programs: 'Programas que ejecuta',
  files: 'Archivos',
  network: 'Internet',
  secrets: 'Claves y datos privados',
  instructions: 'Instrucciones para la IA',
  requirements: 'Requisitos',
  general: 'General'
};
const SOURCE_LABEL = { official: 'Oficial', github: 'GitHub', zip: 'ZIP', folder: 'Carpeta', file: 'Archivo', registry: 'Registro MCP' };
const LEVEL_TEXT = {
  info: ['ok', 'Sin avisos importantes. Aun así, instala solo plugins de quien confías.'],
  warn: ['warn', 'Con avisos: lee la lista antes de instalar.'],
  danger: ['danger', 'Este plugin pide cosas delicadas (mira abajo). Instálalo solo si confías de verdad en quien lo hizo.']
};
const FILES_LABEL = {
  none: 'no necesita leer ni escribir tus archivos',
  workspace: 'solo dentro de la carpeta de tu proyecto',
  any: 'puede tocar cualquier archivo de tu PC'
};
// Los marcadores que se ven en los comandos de un plugin, explicados en palabras simples.
const PLACEHOLDER_HELP = [
  ['${AURIC_NODE}', 'el motor interno de Auric'],
  ['${PLUGIN_DIR}', 'la carpeta del plugin'],
  ['${PLUGIN_DATA}', 'la carpeta de datos del plugin'],
  ['${WORKSPACE}', 'la carpeta de tu proyecto']
];

export function initPluginsUi(ctx) {
  P = ctx;
  // Cuando algo cambia (instalar, activar, claves, conectores) la pantalla se refresca sola.
  try {
    P.D.on?.('plugins-changed', () => {
      refresh().catch(() => {});
    });
  } catch {}
}
export const pluginsInstalled = () => installed;

// Todas las llamadas devuelven { ok, value, error, code }: aquí se convierten en valor o en error con mensaje claro.
async function call(fn, ...args) {
  const r = await fn(...args);
  if (!r || r.ok !== true) throw Object.assign(new Error(r?.error || 'No se pudo completar la acción.'), { code: r?.code || '' });
  return r.value;
}
const api = () => P.D.plugins;
const esc = s => P.esc(s);
const pill = (text, cls = '') => `<span class="cx-pill ${cls}">${esc(text)}</span>`;
const initial = name => (String(name || '').match(/[\p{L}\p{N}]/u)?.[0] || '?').toUpperCase();
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const kb = n => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

export async function refresh() {
  try {
    const [list, cat] = await Promise.all([call(api().list), call(api().catalog).catch(() => [])]);
    installed = Array.isArray(list) ? list : [];
    catalog = Array.isArray(cat) ? cat : [];
    loadError = '';
  } catch (e) {
    loadError = e.message || String(e);
  }
  loaded = true;
  P.rerender?.();
}

// ── Pestaña ─────────────────────────────────────────────────────────────────────────────────────
function statusOf(p) {
  if (p.broken) return pill('Dañado', 'danger');
  if (p.integrity?.status && p.integrity.status !== 'ok') return pill('Modificado', 'danger');
  if (!p.enabled) return pill('Desactivado');
  return pill('Activo', 'ok');
}
function sourcePill(src) {
  const t = SOURCE_LABEL[src?.type];
  return t ? pill(t, src.type === 'official' ? 'accent' : '') : '';
}
function sourceText(src) {
  if (!src) return '';
  if (src.type === 'github') return `github.com/${src.owner}/${src.repo}${src.ref ? `@${src.ref}` : ''}${src.subdir ? `/${src.subdir}` : ''}`;
  if (src.type === 'registry') return src.name || '';
  return src.name || src.path || '';
}
// «Oficial · de Auric Code · licencia MIT»: una sola línea, sin puntos sueltos al principio.
function originHtml(src, p) {
  const bits = [sourceText(src), p.author ? `de ${p.author}` : '', p.license ? `licencia ${p.license}` : ''].filter(Boolean);
  return `${sourcePill(src)}${bits.length ? ` <span class="cx-note">${esc(bits.join(' · '))}</span>` : ''}`;
}
// Explica en palabras simples los marcadores como ${AURIC_NODE} que aparecen en los comandos.
function placeholderNote(lines) {
  const used = PLACEHOLDER_HELP.filter(([k]) => lines.some(l => String(l || '').includes(k)));
  return used.length ? `<p class="cx-note">${used.map(([k, t]) => `<code>${esc(k)}</code> = ${esc(t)}`).join(' · ')}</p>` : '';
}
function installedCard(p) {
  const counts = [plural(p.skills?.length || 0, 'skill', 'skills'), p.mcp?.length ? plural(p.mcp.length, 'servidor', 'servidores') : '', p.connectors?.length ? plural(p.connectors.length, 'conector', 'conectores') : '', p.instructions ? 'instrucciones' : '']
    .filter(Boolean)
    .map(t => `<span class="cx-note">${esc(t)}</span>`)
    .join('');
  const modified = p.integrity?.status && p.integrity.status !== 'ok' ? `<div class="cx-error">${esc(p.integrity.detail || 'Los archivos cambiaron desde que lo instalaste.')} Está desactivado hasta que lo vuelvas a revisar.</div>` : '';
  const missingKeys = (p.secrets || []).filter(s => s.state === 'missing').length;
  const keysNote = missingKeys ? `<div class="cx-note warn-note">Falta${missingKeys === 1 ? '' : 'n'} ${plural(missingKeys, 'clave', 'claves')} por poner (en «Detalles»).</div>` : '';
  const canUpdate = ['github', 'zip', 'folder', 'official', 'registry'].includes(p.source?.type);
  const b = busy.has(p.id);
  return `<article class="cx-card pl-card ${p.active ? 'is-on' : ''}" data-pl-card="${esc(p.id)}"><div class="cx-card-top"><span class="cx-logo ph" aria-hidden="true">${esc(initial(p.name))}</span><div class="cx-card-title"><h3>${esc(p.name)}</h3><span class="cx-cat">v${esc(p.version || '?')}${p.author ? ` · ${esc(p.author)}` : ''}</span></div>${statusOf(p)}</div><p class="cx-desc">${esc(p.description || 'Sin descripción.')}</p><div class="cx-meta">${sourcePill(p.source)}${counts}</div>${modified}${keysNote}<div class="cx-actions"><button class="secondary-btn compact-btn" data-pl-detail="${esc(p.id)}">Detalles</button><label class="cx-switch pl-switch" title="${p.enabled ? 'Activo' : 'Desactivado'}"><input type="checkbox" data-pl-toggle="${esc(p.id)}" ${p.enabled ? 'checked' : ''} ${b || p.broken ? 'disabled' : ''}><span></span></label>${canUpdate ? `<button class="secondary-btn compact-btn" data-pl-update="${esc(p.id)}" ${b ? 'disabled' : ''}>Buscar cambios</button>` : ''}<button class="secondary-btn compact-btn" data-pl-remove="${esc(p.id)}" ${b ? 'disabled' : ''}>Quitar</button></div></article>`;
}
function catalogCard(c) {
  const state = c.installed ? (c.updateAvailable ? pill('Hay una versión nueva', 'warn') : pill('Instalado', 'ok')) : '';
  const parts = [plural(c.skills, 'skill', 'skills'), c.mcp ? plural(c.mcp, 'servidor', 'servidores') : '', c.connectors ? plural(c.connectors, 'conector', 'conectores') : '', c.instructions ? 'instrucciones' : '']
    .filter(Boolean)
    .map(t => `<span class="cx-note">${esc(t)}</span>`)
    .join('');
  const action = c.installed && !c.updateAvailable ? '<button class="secondary-btn compact-btn" disabled>Ya lo tienes</button>' : `<button class="primary-btn compact-btn" data-pl-official="${esc(c.folder)}">${c.updateAvailable ? 'Revisar y actualizar' : 'Revisar e instalar'}</button>`;
  return `<article class="cx-card" data-pl-cat="${esc(c.id)}"><div class="cx-card-top"><span class="cx-logo ph" aria-hidden="true">${esc(initial(c.name))}</span><div class="cx-card-title"><h3>${esc(c.name)}</h3><span class="cx-cat">v${esc(c.version)} · Oficial de Auric</span></div>${state}</div><p class="cx-desc">${esc(c.description)}</p><div class="cx-meta">${parts}</div><div class="cx-actions">${action}</div></article>`;
}

export function renderPluginsTab(grid, meta) {
  if (!loaded) {
    meta.innerHTML = '';
    grid.innerHTML = '<div class="empty-panel">Cargando plugins…</div>';
    refresh().catch(() => {});
    return;
  }
  const q = query.trim().toLowerCase();
  const match = x => !q || `${x.name} ${x.description} ${x.author || ''} ${x.id}`.toLowerCase().includes(q);
  const mine = installed.filter(match);
  const cat = catalog.filter(match);
  const active = installed.filter(p => p.active).length;
  meta.innerHTML = `<span>${plural(installed.length, 'instalado', 'instalados')}</span><span>${plural(active, 'activo', 'activos')}</span>`;
  const err = loadError ? `<div class="cx-banner warn"><b>No se pudo leer la lista de plugins:</b> ${esc(loadError)}</div>` : '';
  const intro =
    '<p class="cx-foot top">Un plugin es un paquete con skills, servidores MCP, conectores e instrucciones que se instala con un clic. Antes de instalar siempre verás una revisión de seguridad con lo que pide, y nada se instala sin que lo confirmes.</p>';
  grid.innerHTML = `${err}<div class="cx-toolbar"><input id="plSearch" class="cx-search" placeholder="Buscar plugin…" value="${esc(query)}" aria-label="Buscar plugin"><button id="plImport" class="primary-btn">＋ Importar</button><button id="plRegistry" class="secondary-btn">Buscar en el registro MCP</button></div>${intro}<div class="cx-group"><div class="cx-group-title">Instalados<small>${plural(installed.length, 'plugin', 'plugins')}</small></div>${mine.length ? `<div class="cx-grid">${mine.map(installedCard).join('')}</div>` : `<div class="cx-box"><div class="cx-empty">${installed.length ? 'Ningún plugin coincide con la búsqueda.' : 'Todavía no tienes plugins. Instala uno del catálogo o impórtalo desde GitHub o un ZIP.'}</div></div>`}</div><div class="cx-group"><div class="cx-group-title">Catálogo de Auric<small>incluidos en la app, sin descargar nada</small></div>${cat.length ? `<div class="cx-grid">${cat.map(catalogCard).join('')}</div>` : `<div class="cx-box"><div class="cx-empty">${catalog.length ? 'Ningún plugin del catálogo coincide.' : 'No hay plugins oficiales disponibles.'}</div></div>`}</div>`;
  const search = P.$('#plSearch', grid);
  search.oninput = () => {
    query = search.value;
    const pos = search.selectionStart;
    renderPluginsTab(grid, meta);
    const again = P.$('#plSearch', grid);
    again.focus();
    again.setSelectionRange(pos, pos);
  };
  P.$('#plImport', grid).onclick = () => openImportDialog();
  P.$('#plRegistry', grid).onclick = () => openRegistryDialog();
  P.$$('[data-pl-detail]', grid).forEach(b => (b.onclick = () => openDetail(b.dataset.plDetail)));
  P.$$('[data-pl-official]', grid).forEach(b => (b.onclick = () => startReview({ type: 'official', id: b.dataset.plOfficial })));
  P.$$('[data-pl-toggle]', grid).forEach(b => (b.onchange = () => toggle(b.dataset.plToggle, b.checked)));
  P.$$('[data-pl-update]', grid).forEach(b => (b.onclick = () => checkUpdate(b.dataset.plUpdate)));
  P.$$('[data-pl-remove]', grid).forEach(b => (b.onclick = () => removePlugin(b.dataset.plRemove)));
}

// ── Acciones ────────────────────────────────────────────────────────────────────────────────────
async function afterChange() {
  await refresh();
  await P.onChanged?.();
}
async function toggle(id, on) {
  busy.add(id);
  try {
    await call(api().setEnabled, id, on);
    await afterChange();
  } catch (e) {
    P.toast('No se pudo cambiar', e.message, 'error', 7000);
    await refresh();
  } finally {
    busy.delete(id);
    P.rerender?.();
  }
}
function sourceToImport(src) {
  if (!src) return null;
  if (src.type === 'github') return { type: 'github', input: `https://github.com/${src.owner}/${src.repo}${src.ref || src.subdir ? `/tree/${src.ref || 'HEAD'}${src.subdir ? `/${src.subdir}` : ''}` : ''}` };
  if (src.type === 'zip' || src.type === 'folder') return { type: src.type, path: src.path };
  if (src.type === 'official') return { type: 'official', id: src.id };
  if (src.type === 'registry') return { type: 'registry', name: src.name };
  return null;
}
async function checkUpdate(id) {
  const p = installed.find(x => x.id === id);
  const src = sourceToImport(p?.source);
  if (!src) return P.toast('No se puede buscar cambios', 'Este plugin se importó de un archivo suelto: impórtalo de nuevo.', 'info', 6000);
  await startReview(src, { updating: p });
}
async function removePlugin(id) {
  const p = installed.find(x => x.id === id);
  if (!p) return;
  const ok = await P.appConfirm({
    title: 'Quitar plugin',
    message: `¿Quitar «${p.name}»?`,
    detail: 'Se borran sus archivos, sus datos y las claves que guardaste para él. Tus skills y proyectos no se tocan.',
    buttons: ['Cancelar', 'Quitar'],
    defaultId: 0,
    cancelId: 0,
    type: 'warning'
  });
  if (ok !== 1) return;
  let removeConnectors = false;
  const linked = (p.connectors || []).filter(c => c.connectedAs);
  if (linked.length) {
    const r = await P.appConfirm({
      title: 'Conectores del plugin',
      message: `Este plugin agregó ${plural(linked.length, 'conector', 'conectores')}: ${linked.map(c => c.name).join(', ')}.`,
      detail: '¿Quieres quitarlos también? Si los dejas, seguirán conectados en la pestaña Conectores.',
      buttons: ['Dejarlos', 'Quitarlos también'],
      defaultId: 0,
      cancelId: 0,
      type: 'question'
    });
    removeConnectors = r === 1;
  }
  busy.add(id);
  P.rerender?.();
  try {
    await call(api().uninstall, id, { removeConnectors });
    P.toast('Plugin quitado', p.name, 'success', 4000);
    await afterChange();
  } catch (e) {
    P.toast('No se pudo quitar', e.message, 'error', 8000);
  } finally {
    busy.delete(id);
    P.rerender?.();
  }
}

// ── Importar ────────────────────────────────────────────────────────────────────────────────────
function modal(inner, cls = 'large') {
  const layer = P.$('#modalLayer');
  layer.classList.remove('hidden');
  layer.innerHTML = `<div class="modal ${cls} cx-modal pl-modal" role="dialog" aria-modal="true">${inner}</div>`;
  const close = () => {
    layer.classList.add('hidden');
    layer.innerHTML = '';
  };
  P.$$('[data-close]', layer).forEach(b => (b.onclick = close));
  return { layer, close };
}
function openImportDialog() {
  const { layer, close } = modal(
    `<div class="modal-header"><h3>Importar un plugin</h3><div class="spacer"></div><button class="icon-btn" data-close aria-label="Cerrar">${P.icon('close', 15)}</button></div><div class="modal-body"><div class="form-grid"><div class="form-field full"><label>Desde GitHub</label><div class="pl-row"><input id="plGh" placeholder="usuario/repositorio" spellcheck="false" autocomplete="off"><button class="primary-btn" id="plGhGo">Revisar</button></div><div class="form-help">También acepta una dirección como https://github.com/usuario/repo/tree/rama/carpeta. Solo repositorios públicos.</div></div><div class="form-field full"><label>Desde tu PC</label><div class="pl-row wrap"><button class="secondary-btn" id="plZip">Archivo ZIP…</button><button class="secondary-btn" id="plFolder">Carpeta…</button><button class="secondary-btn" id="plFile">Archivo suelto (.json o .md)…</button></div><div class="form-help">Un ZIP o una carpeta con un <code>auric-plugin.json</code>, o con carpetas de skills (<code>SKILL.md</code>). Los paquetes con <code>.claude-plugin</code> también se entienden (se usan sus skills y servidores).</div></div></div><p class="cx-foot">Nada se instala todavía: primero verás una revisión con lo que el plugin contiene y lo que pide.</p></div><div class="modal-actions"><button class="secondary-btn" data-close>Cancelar</button></div>`,
    'medium'
  );
  const go = async source => {
    close();
    await startReview(source);
  };
  P.$('#plGhGo', layer).onclick = () => {
    const v = P.$('#plGh', layer).value.trim();
    if (!v) return P.toast('Falta el repositorio', 'Escribe usuario/repositorio.', 'error');
    go({ type: 'github', input: v });
  };
  P.$('#plGh', layer).onkeydown = e => {
    if (e.key === 'Enter') P.$('#plGhGo', layer).click();
  };
  P.$('#plZip', layer).onclick = async () => {
    const f = await P.D.chooseFiles({ title: 'Elige el ZIP del plugin', filters: [{ name: 'ZIP', extensions: ['zip'] }] });
    if (f?.[0]) go({ type: 'zip', path: f[0] });
  };
  P.$('#plFolder', layer).onclick = async () => {
    const f = await P.D.chooseFolder('Elige la carpeta del plugin');
    if (f) go({ type: 'folder', path: f });
  };
  P.$('#plFile', layer).onclick = async () => {
    const f = await P.D.chooseFiles({ title: 'Elige el manifiesto (.json) o la skill (.md)', filters: [{ name: 'Manifiesto o skill', extensions: ['json', 'md'] }] });
    if (f?.[0]) go({ type: 'file', path: f[0] });
  };
  setTimeout(() => P.$('#plGh', layer)?.focus(), 30);
}

// ── Registro MCP ────────────────────────────────────────────────────────────────────────────────
function openRegistryDialog() {
  const { layer } = modal(
    `<div class="modal-header"><h3>Registro oficial de servidores MCP</h3><div class="spacer"></div><button class="icon-btn" data-close aria-label="Cerrar">${P.icon('close', 15)}</button></div><div class="modal-body"><div class="pl-row"><input id="plRq" class="cx-search" placeholder="Busca un servicio (por ejemplo: github, notion, clima)" spellcheck="false" autocomplete="off"><button class="primary-btn" id="plRgo">Buscar</button></div><p class="cx-foot">Son servidores publicados por terceros. Auric los convierte en un plugin y te muestra la revisión antes de instalar; muchos se descargan con <code>npx</code> o <code>uvx</code> la primera vez que se usan.</p><div id="plRres" class="pl-results"></div></div><div class="modal-actions"><button class="secondary-btn" data-close>Cerrar</button></div>`,
    'large'
  );
  const out = P.$('#plRres', layer);
  let cursor = '';
  let shown = [];
  const draw = (more = false) => {
    out.innerHTML =
      (shown.length
        ? shown
            .map(
              it =>
                `<article class="pl-result"><div class="pl-result-main"><b>${esc(it.title || it.name)}</b> <small>${esc(it.name)} · v${esc(it.version || '?')}</small><p>${esc(it.description || '')}</p><div class="cx-meta">${(it.packageTypes || []).map(t => pill(t)).join('')}${it.remote ? pill('remoto') : ''}${(it.needs || []).length ? `<span class="cx-note">Pide: ${esc(it.needs.join(', '))}</span>` : ''}${it.installable ? '' : '<span class="cx-note">No se puede instalar desde aquí</span>'}</div></div><button class="primary-btn compact-btn" data-pl-reg="${esc(it.name)}" ${it.installable ? '' : 'disabled'}>Revisar</button></article>`
            )
            .join('')
        : '<div class="cx-empty">Sin resultados.</div>') + (cursor && more ? '<div class="pl-more"><button class="secondary-btn" id="plRmore">Cargar más</button></div>' : '');
    P.$$('[data-pl-reg]', out).forEach(b => (b.onclick = () => startReview({ type: 'registry', name: b.dataset.plReg })));
    const mb = P.$('#plRmore', out);
    if (mb) mb.onclick = () => search(true);
  };
  const search = async (append = false) => {
    const q = P.$('#plRq', layer).value.trim();
    const go = P.$('#plRgo', layer);
    go.disabled = true;
    out.innerHTML = '<div class="cx-empty">Buscando…</div>';
    try {
      const r = await call(api().registrySearch, { query: q, cursor: append ? cursor : '' });
      cursor = r.nextCursor || '';
      shown = append ? [...shown, ...(r.items || [])] : r.items || [];
      draw(true);
    } catch (e) {
      out.innerHTML = `<div class="cx-banner warn">${esc(e.message)}</div>`;
    } finally {
      go.disabled = false;
    }
  };
  P.$('#plRgo', layer).onclick = () => search(false);
  P.$('#plRq', layer).onkeydown = e => {
    if (e.key === 'Enter') search(false);
  };
  setTimeout(() => P.$('#plRq', layer)?.focus(), 30);
}

// ── Revisión antes de instalar ──────────────────────────────────────────────────────────────────
async function startReview(source, { updating = null } = {}) {
  const dismissWorking = P.toast('Revisando el plugin…', 'Descargando y analizando lo que contiene.', 'info', 8000);
  let prep;
  try {
    prep = await call(api().prepare, source);
  } catch (e) {
    dismissWorking?.();
    P.toast('No se pudo preparar el plugin', e.message, 'error', 10000);
    return;
  }
  // El aviso «Revisando…» se quita apenas termina: no debe tapar los botones de la ventana de revisión.
  dismissWorking?.();
  if (updating && prep.sameVersion) {
    await call(api().discard, prep.token).catch(() => {});
    P.toast('Sin cambios', `«${updating.name}» ya está en su última versión.`, 'success', 4500);
    return;
  }
  openReviewDialog(prep, { updating });
}

function findingsHtml(review) {
  const list = Array.isArray(review?.findings) ? review.findings : [];
  if (!list.length) return '<div class="cx-empty">No se encontró nada que destacar.</div>';
  const groups = SEV_ORDER.map(sev => [sev, list.filter(f => f.severity === sev)]).filter(([, items]) => items.length);
  return groups
    .map(
      ([sev, items]) =>
        `<div class="pl-sev-group"><div class="pl-sev-title sev-${sev}">${esc(SEV_LABEL[sev])} <small>${items.length}</small></div>${items
          .map(
            f =>
              `<div class="pl-find sev-${sev}"><div class="pl-find-head"><b>${esc(f.title)}</b><span class="pl-area">${esc(AREA_LABEL[f.area] || f.area || '')}</span></div>${f.detail ? `<p>${esc(f.detail)}</p>` : ''}${(f.items || []).length ? `<ul>${f.items.map(i => `<li><code>${esc(i)}</code></li>`).join('')}</ul>` : ''}</div>`
          )
          .join('')}</div>`
    )
    .join('');
}
function contentsHtml(pl) {
  const rows = [];
  if (pl.skills?.length)
    rows.push(
      `<div class="pl-block"><b>${plural(pl.skills.length, 'skill', 'skills')}</b><ul>${pl.skills
        .map(s => `<li>${esc(s.name)}${s.triggers?.length || s.markers?.length ? ` <small>solo cuando: ${esc([...(s.triggers || []), ...(s.markers || [])].slice(0, 6).join(', '))}</small>` : ' <small>se aplica siempre</small>'}</li>`)
        .join('')}</ul></div>`
    );
  if (pl.instructions) rows.push('<div class="pl-block"><b>Instrucciones para la IA</b><p>Un texto que se agrega a la conversación como guía de un tercero (nunca como una orden con autoridad).</p></div>');
  if (pl.mcp?.length)
    rows.push(
      `<div class="pl-block"><b>${plural(pl.mcp.length, 'programa (servidor MCP)', 'programas (servidores MCP)')}</b><p>Se ejecutan en tu PC cuando la IA los usa, siempre con tu permiso y con un entorno limpio (no ven tus variables ni tus claves).</p><ul>${pl.mcp
        .map(m => `<li>${esc(m.name)}<br><code>${esc(m.commandLine)}</code>${m.cwd === 'workspace' ? ' <small>(trabaja dentro de tu proyecto)</small>' : ''}</li>`)
        .join('')}</ul>${placeholderNote(pl.mcp.map(m => m.commandLine))}</div>`
    );
  if (pl.connectors?.length)
    rows.push(`<div class="pl-block"><b>${plural(pl.connectors.length, 'conector', 'conectores')}</b><ul>${pl.connectors.map(c => `<li>${esc(c.name)}${c.url ? ` <code>${esc(c.url)}</code>` : c.ref ? ` <small>(usa el conector ${esc(c.ref)} de Auric)</small>` : ''}</li>`).join('')}</ul></div>`);
  const st = pl.stats || {};
  rows.push(`<div class="pl-block"><b>Archivos</b><p>${plural(st.files || 0, 'archivo', 'archivos')} · ${kb(st.bytes || 0)}</p></div>`);
  return rows.join('');
}
function permissionsHtml(pl) {
  const perm = pl.permissions || {};
  if (!perm.declared) return '<div class="cx-empty">El plugin no declara qué permisos usa. Confía solo en lo que ves en la revisión.</div>';
  const line = (label, items, help = {}) => (items && items.length ? `<li><b>${label}:</b> ${items.map(i => `<code>${esc(i)}</code>${help[i] ? ` <small>(${esc(help[i])})</small>` : ''}`).join(' ')}</li>` : '');
  const html = [
    line('Internet (sitios)', perm.network),
    line('Variables / claves', perm.env),
    line('Programas', perm.runs, { 'auric-node': 'el motor interno de Auric' }),
    perm.files ? `<li><b>Archivos:</b> ${esc(FILES_LABEL[perm.files] || perm.files)}</li>` : '',
    perm.notes ? `<li><b>Notas del autor:</b> ${esc(perm.notes)}</li>` : ''
  ].join('');
  return html ? `<ul class="pl-perm">${html}</ul>` : '<div class="cx-empty">Declara que no necesita permisos especiales.</div>';
}
function diffHtml(diff) {
  if (!diff) return '';
  const rows = [
    ...diff.added.map(x => `<li class="d-add">＋ ${esc(KIND[x.kind] || x.kind)}: ${esc(x.label)}</li>`),
    ...diff.removed.map(x => `<li class="d-del">－ ${esc(KIND[x.kind] || x.kind)}: ${esc(x.label)}</li>`),
    ...diff.changed.map(x => `<li class="d-chg">↻ ${esc(KIND[x.kind] || x.kind)}: ${x.before && x.before !== x.label ? `<code>${esc(x.before)}</code> → <code>${esc(x.label)}</code>` : esc(x.label)}</li>`)
  ];
  return `<div class="pl-diff"><b>Qué cambia respecto a lo instalado (${esc(diff.from || '?')} → ${esc(diff.to || '?')})</b>${rows.length ? `<ul>${rows.join('')}</ul>` : '<p>Solo cambian textos o archivos, sin piezas nuevas ni quitadas.</p>'}</div>`;
}
const KIND = { mcp: 'Servidor', connector: 'Conector', skill: 'Skill', instructions: 'Instrucciones' };

function openReviewDialog(prep, { updating = null } = {}) {
  const pl = prep.plugin;
  const rev = prep.review || {};
  const level = rev.level || 'info';
  const [cls, verdict] = LEVEL_TEXT[level] || LEVEL_TEXT.info;
  const blocked = rev.blocked ? String(rev.blocked.message || rev.blocked) : '';
  const rep = prep.replacing;
  const replaceNote = rep
    ? `<div class="cx-banner ${rep.official && prep.source?.type !== 'official' ? 'warn' : ''}"><b>Ya tienes este plugin (versión ${esc(rep.version || '?')}${rep.official ? ', oficial' : ''}).</b> ${prep.sameVersion ? 'Esta es la misma versión: reinstalar la deja igual.' : 'Instalar reemplaza esa versión; los datos que el plugin guardó se conservan.'}${rep.official && prep.source?.type !== 'official' ? ' <b>Atención:</b> estarías cambiando un plugin oficial por uno de otra procedencia.' : ''}</div>`
    : '';
  const notes = [...(pl.notes || []), ...(pl.ignored || []).map(i => `${i.what}: ${i.why}`)];
  const homepage = /^https:\/\//i.test(pl.homepage || '') ? pl.homepage : '';
  const { layer, close } = modal(
    `<div class="modal-header"><span class="cx-logo ph sm" aria-hidden="true">${esc(initial(pl.name))}</span><h3>${updating ? 'Actualizar' : 'Instalar'} «${esc(pl.name)}» <small>v${esc(pl.version || '?')}</small></h3><div class="spacer"></div><button class="icon-btn" data-close aria-label="Cerrar">${P.icon('close', 15)}</button></div>
<div class="modal-body pl-review">
  <div class="pl-origin">${originHtml(prep.source, pl)}${homepage ? ` <button class="link-btn" data-pl-home="${esc(homepage)}">Sitio web</button>` : ''}</div>
  ${pl.description ? `<p class="desc">${esc(pl.description)}</p>` : ''}
  <div class="pl-verdict v-${blocked ? 'blocked' : cls}" role="status"><b>${blocked ? 'No se puede instalar' : esc(SEV_LABEL[level] || '')}</b> ${esc(blocked || verdict)}</div>
  ${replaceNote}${diffHtml(prep.diff)}
  <div class="pl-section"><div class="pl-section-title">Qué contiene</div>${contentsHtml(pl)}</div>
  <div class="pl-section"><div class="pl-section-title">Permisos que declara</div>${permissionsHtml(pl)}</div>
  <div class="pl-section"><div class="pl-section-title">Revisión de seguridad <small>${esc(plural((rev.findings || []).length, 'punto', 'puntos'))}</small></div>${findingsHtml(rev)}${notes.length ? `<div class="pl-notes"><b>Notas</b><ul>${notes.map(n => `<li>${esc(n)}</li>`).join('')}</ul></div>` : ''}<p class="cx-foot">${esc(rev.disclaimer || 'Esta revisión busca señales conocidas de peligro. No garantiza que un plugin sea seguro: instala solo lo que venga de quien confías.')}</p></div>
</div>
<div class="modal-actions pl-actions">${rev.needsAck && !blocked ? '<label class="pl-ack"><input type="checkbox" id="plAck"> <span>Entiendo el riesgo y quiero instalarlo igualmente</span></label>' : ''}<div class="spacer"></div><button class="secondary-btn" id="plCancel">Cancelar</button><button class="primary-btn" id="plInstall" ${blocked || rev.needsAck ? 'disabled' : ''}>${updating || rep ? (prep.sameVersion ? 'Reinstalar' : 'Actualizar') : 'Instalar'}</button></div>`,
    'large'
  );
  P.$$('[data-pl-home]', layer).forEach(b => (b.onclick = () => P.D.openExternal?.(b.dataset.plHome)));
  const discard = () => call(api().discard, prep.token).catch(() => {});
  const ack = P.$('#plAck', layer);
  const go = P.$('#plInstall', layer);
  if (ack) ack.onchange = () => (go.disabled = !ack.checked);
  P.$('#plCancel', layer).onclick = () => {
    discard();
    close();
  };
  P.$$('[data-close]', layer).forEach(b => {
    const prev = b.onclick;
    b.onclick = () => {
      discard();
      prev?.();
    };
  });
  go.onclick = async () => {
    go.disabled = true;
    go.textContent = 'Instalando…';
    try {
      const done = await call(api().install, prep.token, { acknowledged: !!ack?.checked });
      close();
      P.toast(updating || rep ? 'Plugin actualizado' : 'Plugin instalado', `${pl.name} v${done?.version || pl.version}`, 'success', 5000);
      await afterChange();
      const fresh = installed.find(x => x.id === pl.id);
      if (fresh && ((fresh.secrets || []).some(s => s.state === 'missing') || (fresh.connectors || []).some(c => c.url && !c.connectedAs))) openDetail(pl.id);
    } catch (e) {
      go.disabled = false;
      go.textContent = 'Instalar';
      P.toast('No se pudo instalar', e.message, 'error', 10000);
      if (e.code === 'PLUGIN_STAGE_EXPIRED' || e.code === 'PLUGIN_NOT_STAGED') close();
    }
  };
}

// ── Detalle de un plugin instalado ──────────────────────────────────────────────────────────────
function secretRow(p, s) {
  const state = s.state === 'stored' ? pill('Guardada', 'ok') : s.state === 'env' ? pill('Viene de tu PC', 'accent') : pill('Falta', 'warn');
  return `<div class="pl-secret" data-pl-secret-row="${esc(s.name)}"><div class="pl-secret-name"><code>${esc(s.name)}</code> ${state}</div><div class="pl-row"><input type="password" autocomplete="off" spellcheck="false" placeholder="${s.state === 'stored' ? 'Escribe otra para reemplazarla' : 'Pega aquí la clave'}" data-pl-secret-input="${esc(s.name)}"><button class="secondary-btn compact-btn" data-pl-secret-save="${esc(s.name)}">Guardar</button>${s.state === 'stored' ? `<button class="secondary-btn compact-btn" data-pl-secret-del="${esc(s.name)}">Borrar</button>` : ''}</div></div>`;
}
function connectorRow(c) {
  const linked = c.connectedAs;
  const needsToken = c.auth === 'token';
  return `<div class="pl-conn"><div><b>${esc(c.name)}</b> ${c.url ? `<code>${esc(c.url)}</code>` : `<small>(usa el conector ${esc(c.ref || '')} de Auric; se conecta en la pestaña Conectores)</small>`}${c.description ? `<p class="cx-note">${esc(c.description)}</p>` : ''}</div>${
    c.url
      ? linked
        ? `<div>${pill('Agregado', 'ok')}</div>`
        : `<div class="pl-row">${needsToken ? `<input type="password" autocomplete="off" spellcheck="false" placeholder="Token de acceso" data-pl-conn-token="${esc(c.id)}">` : ''}<button class="primary-btn compact-btn" data-pl-conn="${esc(c.id)}">Conectar</button></div>`
      : ''
  }</div>`;
}
function openDetail(id) {
  const p = installed.find(x => x.id === id);
  if (!p) return;
  const integ = p.integrity || {};
  const integHtml =
    integ.status === 'ok'
      ? `<div class="pl-verdict v-ok"><b>Archivos intactos.</b> Nada cambió desde que lo instalaste.</div>`
      : `<div class="pl-verdict v-danger"><b>Los archivos cambiaron.</b> ${esc(integ.detail || '')} ${[...(integ.changed || []).map(f => ['cambiado', f]), ...(integ.missing || []).map(f => ['falta', f]), ...(integ.extra || []).map(f => ['nuevo', f])].length ? `<ul>${[...(integ.changed || []).map(f => ['cambiado', f]), ...(integ.missing || []).map(f => ['falta', f]), ...(integ.extra || []).map(f => ['nuevo', f])].slice(0, 8).map(([k, f]) => `<li>${k}: <code>${esc(f)}</code></li>`).join('')}</ul>` : ''}El plugin está desactivado y no se ejecuta. Si el cambio fue tuyo, impórtalo otra vez para revisarlo.</div>`;
  const secrets = (p.secrets || []).length
    ? `<div class="pl-section"><div class="pl-section-title">Claves que usa</div>${p.persistentSecrets === false ? '<div class="cx-banner warn">Este equipo no permite guardar claves cifradas: se recordarán solo mientras Auric esté abierto.</div>' : '<p class="cx-foot">Se guardan cifradas en tu PC y solo las recibe este plugin. Nunca se muestran de nuevo ni se envían a la IA.</p>'}${p.secrets.map(s => secretRow(p, s)).join('')}</div>`
    : '';
  const conns = (p.connectors || []).length ? `<div class="pl-section"><div class="pl-section-title">Conectores</div>${p.connectors.map(connectorRow).join('')}</div>` : '';
  const servers = (p.mcp || []).length
    ? `<div class="pl-section"><div class="pl-section-title">Programas (servidores MCP)</div>${p.mcp.map(m => `<div class="pl-conn"><div><b>${esc(m.name)}</b><br><code>${esc(m.commandLine)}</code></div><div><button class="secondary-btn compact-btn" data-pl-test="${esc(m.serverId)}">Probar</button></div></div>`).join('')}${placeholderNote(p.mcp.map(m => m.commandLine))}</div>`
    : '';
  const skills = (p.skills || []).length
    ? `<div class="pl-section"><div class="pl-section-title">Skills</div><ul class="pl-list">${p.skills.map(s => `<li><b>${esc(s.name)}</b>${s.description ? ` — ${esc(s.description)}` : ''}</li>`).join('')}</ul><p class="cx-foot">Las encuentras también en la pestaña Skills, marcadas como «Plugin».</p></div>`
    : '';
  // Al instalar se guarda el nivel y los avisos que no eran solo informativos (con su título).
  const rc = p.review?.counts || {};
  const reviewHead = rc.danger ? `${plural(rc.danger, 'punto de riesgo alto', 'puntos de riesgo alto')}${rc.warn ? ` y ${plural(rc.warn, 'aviso', 'avisos')}` : ''}` : rc.warn ? plural(rc.warn, 'aviso', 'avisos') : 'sin avisos importantes';
  const review = p.review
    ? `<details class="pl-section pl-details"><summary>Revisión que se hizo al instalar (${esc(reviewHead)})</summary>${p.review.acknowledged ? '<p class="cx-note">Lo instalaste aceptando el riesgo.</p>' : ''}${findingsHtml(p.review)}</details>`
    : '';
  const { layer, close } = modal(
    `<div class="modal-header"><span class="cx-logo ph sm" aria-hidden="true">${esc(initial(p.name))}</span><h3>${esc(p.name)} <small>v${esc(p.version || '?')}</small></h3><div class="spacer"></div><button class="icon-btn" data-close aria-label="Cerrar">${P.icon('close', 15)}</button></div><div class="modal-body pl-review"><div class="pl-origin">${statusOf(p)} ${originHtml(p.source, p)}</div>${p.description ? `<p class="desc">${esc(p.description)}</p>` : ''}${integHtml}${secrets}${conns}${servers}${skills}${review}</div><div class="modal-actions"><button class="secondary-btn" id="plReveal">Abrir carpeta</button><button class="secondary-btn" id="plVerify">Comprobar archivos</button><div class="spacer"></div><button class="primary-btn" data-close>Cerrar</button></div>`,
    'large'
  );
  const again = () => {
    close();
    openDetail(id);
  };
  P.$('#plReveal', layer).onclick = () => call(api().reveal, id).catch(e => P.toast('No se pudo abrir', e.message, 'error'));
  P.$('#plVerify', layer).onclick = async () => {
    try {
      const r = await call(api().verify, id);
      const bad = !!(r && r[id] && r[id].status !== 'ok');
      P.toast(bad ? 'Hay archivos cambiados' : 'Todo en orden', bad ? 'Mira el aviso rojo.' : 'Los archivos siguen siendo los que instalaste.', bad ? 'error' : 'success', 4000);
    } catch (e) {
      P.toast('No se pudo comprobar', e.message, 'error');
    }
    await afterChange();
    again();
  };
  P.$$('[data-pl-secret-save]', layer).forEach(
    b =>
      (b.onclick = async () => {
        const name = b.dataset.plSecretSave;
        const input = P.$(`[data-pl-secret-input="${CSS.escape(name)}"]`, layer);
        const value = input.value;
        if (!value.trim()) return P.toast('Falta la clave', name, 'error');
        try {
          await call(api().secretSet, id, name, value);
          input.value = '';
          P.toast('Clave guardada', name, 'success', 3000);
          await afterChange();
          again();
        } catch (e) {
          P.toast('No se pudo guardar', e.message, 'error', 8000);
        }
      })
  );
  P.$$('[data-pl-secret-del]', layer).forEach(
    b =>
      (b.onclick = async () => {
        try {
          await call(api().secretClear, id, b.dataset.plSecretDel);
          await afterChange();
          again();
        } catch (e) {
          P.toast('No se pudo borrar', e.message, 'error');
        }
      })
  );
  P.$$('[data-pl-conn]', layer).forEach(
    b =>
      (b.onclick = async () => {
        const cid = b.dataset.plConn;
        const tokenEl = P.$(`[data-pl-conn-token="${CSS.escape(cid)}"]`, layer);
        b.disabled = true;
        b.textContent = 'Conectando…';
        try {
          const r = await call(api().connect, id, cid, { token: tokenEl ? tokenEl.value.trim() : '' });
          P.toast('Conector agregado', r?.connected ? `${r.toolCount || 0} herramientas disponibles` : 'Termina de conectarlo en la pestaña Conectores.', 'success', 6000);
        } catch (e) {
          P.toast('No se pudo conectar', e.message, 'error', 9000);
        }
        await P.refreshConnectors?.();
        await afterChange();
        again();
      })
  );
  P.$$('[data-pl-test]', layer).forEach(
    b =>
      (b.onclick = async () => {
        const sid = b.dataset.plTest;
        const [plugin, server] = [sid.split('/')[0], sid.split('/').slice(1).join('/')];
        b.disabled = true;
        try {
          const tools = await P.D.mcp.listTools({ id: sid, pluginRef: { plugin, server } });
          P.toast('Funciona', `${plural(tools.length, 'herramienta', 'herramientas')}: ${tools.slice(0, 4).map(t => t.name).join(', ')}${tools.length > 4 ? '…' : ''}`, 'success', 6000);
        } catch (e) {
          P.toast('No arrancó', e.message || String(e), 'error', 9000);
        } finally {
          b.disabled = false;
        }
      })
  );
}
