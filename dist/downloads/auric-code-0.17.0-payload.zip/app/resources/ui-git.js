// Git con permiso: ventanas de confirmación (guardar cambios, subir, acciones destructivas), la herramienta `git` de la IA y el registro.
// Módulo de interfaz. La seguridad real (git.exe por ruta completa, validación de ramas y rutas, programas automáticos, configuración
// peligrosa, copias de seguridad, comprobación de que nada cambió entre confirmar y ejecutar) vive en el proceso principal (git-tools.js).
// Aquí solo se enseña lo que el proceso principal ya comprobó y se pregunta a la persona. Todo texto que viene de fuera (nombres de
// archivos, ramas, mensajes, direcciones) se escapa antes de pintarlo.
import { showDialog, queued, row, note, fmtBytes, fmtDate } from './ui-downloads.js';

let C = null;
const e = s => C.esc(s);

export function initGitUi(ctx) {
  C = ctx;
}

// ── Lo que la persona pidió de forma explícita ────────────────────────────────────────────────────────────────
// Forzar una subida o hacer un reset duro solo se acepta si la persona lo dijo en su mensaje (y no lo prohibió).
const NEGATION = /\b(?:no|nunca|jam[aá]s|sin|evit\w*|ni|ning[uú]n[ao]?s?|tampoco|prohib\w*|don'?t|do not|never|without|avoid)\b/i;
const FORCE_RE =
  /(?:--force(?:-with-lease)?\b|\bforce[- ]?push\b|\bpush\s+(?:-f|--force)\b|\bforz\w*\b[^.\n]{0,40}\b(?:push|subida|subir|rama|servidor|remoto|origin)\b|\b(?:fuerz[ao]s?|fuerc\w*)\s+(?:(?:el|la|los|las|un|una|este|esta|ese|esa|tu|mi)\s+)?(?:push|subida|subir|env[ií]o|rama|servidor|remoto|origin)\b|\b(?:push|subida|subir|sube|subas|suban)\b[^.\n]{0,40}\b(?:forz\w+|fuerc\w+|a la fuerza)\b|\ba la fuerza\b)/i;
const HARD_RE =
  /(?:--hard\b|\bhard[- ]reset\b|\breset\s+(?:duro|hard)\b|\bdescart\w+\s+(?:todos?\s+)?(?:los\s+|mis\s+|esos\s+)?cambios\b|\bdesh(?:ac|az)\w*\s+(?:todos?\s+)?(?:los\s+|mis\s+|esos\s+)?(?:cambios|commits)\b|\b(?:volv|vuelv)\w*\s+(?:atr[aá]s|al\s+commit)\b|\bborr\w+\s+(?:los\s+|mis\s+)?(?:cambios|commits)\b|\bgit\s+clean\b|\btirar\s+(?:los\s+)?cambios\b|\bthrow\s+away\b|\bdiscard\s+(?:all\s+)?(?:my\s+)?changes\b)/i;
function affirmative(text, re) {
  for (const sentence of String(text || '').split(/[.!?\n;]+/)) {
    const m = re.exec(sentence);
    // La negación puede estar antes o dentro de lo que se pidió («sube sin forzar el push»); después ya no cambia el sentido.
    if (m && !NEGATION.test(sentence.slice(0, m.index + m[0].length))) return true;
  }
  return false;
}
export function explicitRequest(text) {
  return { force: affirmative(text, FORCE_RE), hard: affirmative(text, HARD_RE) };
}

// ── Comandos de terminal que invocan git (guarda de mejor esfuerzo) ────────────────────────────────────────────
// La herramienta `git` es el camino con ventanas, copias de seguridad y revisión. Si la IA intenta lo mismo por la terminal, se le
// indica el camino correcto (y lo realmente peligroso pregunta SIEMPRE, también en modo completo). No puede ver dentro de scripts.
const GIT_VIA_TOOL = {
  add: 'add',
  commit: 'commit',
  switch: 'switch',
  checkout: 'switch',
  restore: 'discard / unstage',
  reset: 'reset',
  merge: 'merge',
  pull: 'pull',
  fetch: 'fetch',
  push: 'push',
  init: 'init'
};
const GIT_ALWAYS_ASK = new Set([
  'rebase',
  'cherry-pick',
  'revert',
  'clean',
  'filter-branch',
  'filter-repo',
  'rm',
  'mv',
  'update-ref',
  'am'
]);
function gitSegments(command) {
  const out = [];
  const text = String(command || '');
  for (const seg of text.split(/&&|\|\||;|\||&(?!>)|\r?\n/)) {
    const m = /(?:^|[\s"'`(){}])(?:"|')?(?:[A-Za-z]:)?(?:[^\s"'|&;<>]*[\\/])?git(?:\.exe)?(?:"|')?(?=\s|$)(.*)$/i.exec(seg);
    if (!m) continue;
    const toks = (m[1].match(/"[^"]*"|'[^']*'|\S+/g) || []).map(t => t.replace(/^["']|["']$/g, ''));
    let i = 0;
    while (i < toks.length && /^-/.test(toks[i])) {
      // opciones globales que llevan valor: -C dir, -c clave=valor, --git-dir dir, --work-tree dir, --namespace x
      if (/^(?:-C|-c|--git-dir|--work-tree|--namespace|--exec-path)$/.test(toks[i])) i += 2;
      else i += 1;
    }
    const sub = (toks[i] || '').toLowerCase();
    if (sub) out.push({ sub, args: toks.slice(i + 1), raw: seg.trim() });
  }
  return out;
}
export function gitCommandGuard(command) {
  const result = { useTool: '', askAlways: '', message: '' };
  for (const { sub, args } of gitSegments(command)) {
    const flag = re => args.some(a => re.test(a));
    if (GIT_VIA_TOOL[sub]) {
      // Lecturas inocuas que comparten nombre con acciones: «stash list», «branch --list»… no pasan por aquí (están en GIT_READ).
      result.useTool = GIT_VIA_TOOL[sub];
      result.message = `Para «git ${sub}» usa la herramienta git (action: "${GIT_VIA_TOOL[sub]}"): la persona ve el comando exacto, se hacen copias de seguridad antes de lo destructivo y se revisan los archivos y claves antes de guardar o subir. No lo ejecutes por la terminal.`;
      return result;
    }
    if (
      sub === 'branch' &&
      flag(/^(?:-[dDmMcC]|--delete|--move|--copy|--force|-f|--set-upstream-to|-u|--unset-upstream|--edit-description)/)
    ) {
      result.useTool = 'branch';
      result.message =
        'Para crear, borrar o renombrar ramas usa la herramienta git (action: "branch"): borrar pide permiso aparte y guarda una copia de seguridad.';
      return result;
    }
    if (
      sub === 'branch' &&
      args.some(a => /^[^-]/.test(a)) &&
      !flag(/^(?:--list|-l|-a|-r|-v|-vv|--contains|--merged|--no-merged|--show-current|--points-at|--sort|--format)/)
    ) {
      result.useTool = 'branch';
      result.message = 'Para crear ramas usa la herramienta git (action: "branch", mode: "create").';
      return result;
    }
    if (sub === 'stash' && !(args[0] === 'list' || args[0] === 'show')) {
      result.useTool = 'stash';
      result.message = 'Para guardar o recuperar cambios temporales usa la herramienta git (action: "stash").';
      return result;
    }
    if (
      GIT_ALWAYS_ASK.has(sub) ||
      (sub === 'reflog' && flag(/^(?:expire|delete)$/)) ||
      ((sub === 'gc' || sub === 'prune') && flag(/prune|--aggressive/)) ||
      (sub === 'tag' && flag(/^(?:-d|--delete|-f|--force)$/)) ||
      (sub === 'remote' && flag(/^(?:remove|rm|rename|set-url|add|prune)$/)) ||
      (sub === 'worktree' && flag(/^(?:remove|prune)$/)) ||
      (sub === 'submodule' && flag(/^(?:deinit|update|foreach)$/))
    )
      result.askAlways = `git ${sub}`;
    if (sub === 'config' && flag(/^(?:--global|--system)$/) && !flag(/^(?:--get|--get-all|--list|-l|--get-regexp)$/))
      result.askAlways = 'git config (global)';
    else if (sub === 'config' && flag(/^(?:core\.(?:sshcommand|hookspath|fsmonitor|editor|pager)|credential\.|filter\.|alias\.|include)/i))
      result.askAlways = 'git config (programas)';
  }
  return result;
}

// ── Utilidades ────────────────────────────────────────────────────────────────────────────────────────────────
async function call(fn) {
  let r;
  try {
    r = await fn();
  } catch (err) {
    throw new Error(String(err?.message || err));
  }
  if (!r?.ok) {
    const err = new Error(r?.error || 'No se pudo completar la acción de Git.');
    err.code = r?.code || '';
    throw err;
  }
  return r.value;
}
const stoppedFn = session => () => !!(session && C.isStopped?.(session));
const live = (session, text, detail = '') => {
  if (session) C.setLive?.(session, text, detail);
};
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

const STATUS = {
  M: ['Modificado', 'mod'],
  A: ['Nuevo', 'add'],
  D: ['Borrado', 'del'],
  R: ['Renombrado', 'ren'],
  C: ['Copiado', 'add'],
  T: ['Cambio de tipo', 'mod'],
  U: ['En conflicto', 'del'],
  '?': ['Sin seguimiento', 'new']
};
const chip = s => {
  if (!s) return '';
  const [text, cls] = STATUS[s] || ['Cambiado', 'mod'];
  return `<span class="gt-st is-${cls}">${e(text)}</span>`;
};
function fileRow(f) {
  if (typeof f === 'string') f = { path: f };
  const nums = f.binary
    ? '<span class="gt-num dl-muted">binario</span>'
    : f.added != null
      ? `<span class="gt-num"><b class="gt-plus">+${Number(f.added) || 0}</b> <b class="gt-minus">−${Number(f.deleted) || 0}</b></span>`
      : '<span class="gt-num"></span>';
  const from = f.from ? ` <span class="dl-muted">← ${e(f.from)}</span>` : '';
  return `<li class="gt-file${f.flagged ? ' is-flagged' : ''}" data-gt="file">${chip(f.status)}<span class="gt-path" title="${e(f.path)}"><code>${e(f.path)}</code>${from}</span>${nums}${f.flagged ? '<span class="gt-flag" title="Auric encontró algo delicado en este archivo">delicado</span>' : ''}</li>`;
}
const filesList = (files = [], more = 0, label = 'Archivos') =>
  files.length
    ? `<h4 class="dl-sec">${e(label)}</h4><ul class="gt-files" data-gt="files">${files.map(fileRow).join('')}</ul>${more > 0 ? `<p class="dl-fine gt-more">…y ${more} más.</p>` : ''}`
    : '';
const commitsList = (commits = [], total = 0, label = 'Commits') => {
  if (!commits.length) return '';
  const more = Math.max(0, total - commits.length);
  return `<h4 class="dl-sec">${e(label)}</h4><ul class="gt-commits" data-gt="commits">${commits
    .map(
      c =>
        `<li class="gt-commit"><code>${e(c.short)}</code><span>${e(c.subject)}</span>${c.author ? `<small>${e(c.author)}</small>` : ''}</li>`
    )
    .join('')}</ul>${more > 0 ? `<p class="dl-fine gt-more">…y ${more} más.</p>` : ''}`;
};
const notesBlock = (warnings = [], effects = []) => {
  const list = [...warnings.map(w => note(w.level, w.text)), ...effects.map(t => note('info', t))].join('');
  return list ? `<h4 class="dl-sec">Avisos</h4><ul class="dl-notes" data-gt="warnings">${list}</ul>` : '';
};
function hooksBlock(plan) {
  if (!plan.hooks?.length) return '';
  const items = plan.hooks
    .map(h => {
      const when = h.modified ? fmtDate(h.modified) : '';
      return `<details class="gt-hook" data-gt="hook"><summary><code>${e(h.name)}</code> <small>${e(fmtBytes(h.bytes))}${when ? ` · modificado ${e(when)}` : ''}</small></summary><pre class="dl-cmd">${e(h.preview || '(vacío)')}</pre></details>`;
    })
    .join('');
  return `<h4 class="dl-sec">Programas automáticos de este proyecto (hooks)</h4><p class="dl-fine gt-fine">Git los ejecutará solos durante esta acción: pueden cambiar archivos o rechazarla. Esta ventana se muestra siempre que los hay, también en modo Completo.</p>${items}`;
}
const commandBlock = plan =>
  plan.display?.length
    ? `<h4 class="dl-sec">Comando exacto${plan.display.length > 1 ? 's' : ''}</h4><pre class="dl-cmd" data-gt="command">${e(plan.display.join('\n'))}</pre>`
    : '';
function identityBlock(plan) {
  if (!plan.needsIdentity) return '';
  return `<h4 class="dl-sec">¿Quién firma esta acción?</h4><p class="dl-fine gt-fine">Si prefieres que Git los recuerde siempre, configúralos una vez en tu PC con <code>git config --global user.name</code> y <code>user.email</code>.</p><div class="gt-id"><input data-gt="name" placeholder="Tu nombre" maxlength="100" autocomplete="off" spellcheck="false" aria-label="Tu nombre"><input data-gt="email" type="email" placeholder="tu@correo.com" maxlength="200" autocomplete="off" spellcheck="false" aria-label="Tu correo"></div>`;
}
// La casilla de confirmación va fuera de la zona con scroll: siempre se ve junto a los botones.
const ackBlock = plan =>
  plan.ack
    ? `<div class="gt-ack-wrap"><label class="dl-ack gt-ack"><input type="checkbox" data-gt="ack"> ${e(plan.ack)}</label></div>`
    : '';
const repoRow = plan =>
  row('Proyecto', `<b>${e(plan.repoName)}</b> <span class="dl-muted">· <code class="dl-code">${e(plan.repo)}</code></span>`);
const head = (iconName, eyebrow, title, lead, { danger = false } = {}) =>
  `<div class="dl-head"><span class="dl-head-ico ${danger ? 'is-blocked' : ''}">${C.icon(iconName, 22)}</span><div><span class="eyebrow">${e(eyebrow)}</span><h3 id="gtTitle">${e(title)}</h3><p class="dl-lead">${e(lead)}</p></div></div>`;
const actions = (okLabel, { danger = false, cancel = 'Cancelar' } = {}) =>
  `<div class="dl-actions"><span class="dl-spacer"></span><button class="secondary-btn" data-dl-answer="cancel" data-dl="cancel">${e(cancel)}</button><button class="primary-btn ${danger ? 'is-danger' : ''}" data-dl-answer="ok" data-dl="ok">${e(okLabel)}</button></div>`;

// ── Ventana: guardar cambios (commit) ─────────────────────────────────────────────────────────────────────────
export function commitDialogHtml(plan) {
  const d = plan.data || {};
  const files = d.files || [];
  const more = Math.max(0, (d.totalFiles || 0) - files.length);
  const lead = d.merging
    ? 'Esto termina la fusión de ramas que estaba en curso.'
    : `Se guardará una versión de estos archivos en la rama «${d.branch || 'sin rama'}». Todavía no sale de tu PC: subirla es un paso aparte y también te preguntará.`;
  const danger = (plan.warnings || []).some(w => w.level === 'danger');
  const notStaged = (d.notStaged || []).length
    ? `<h4 class="dl-sec">Sin preparar (no entran en este commit)</h4><ul class="gt-files is-muted" data-gt="not-staged">${d.notStaged.map(f => `<li class="gt-file">${chip(f.status)}<span class="gt-path"><code>${e(f.path)}</code></span></li>`).join('')}</ul>${d.notStagedMore ? `<p class="dl-fine gt-more">…y ${d.notStagedMore} más.</p>` : ''}`
    : '';
  const body = `<div class="dl-body">
  <div class="gt-summary" data-gt="summary"><b>${e(plural(d.totalFiles || files.length, 'archivo', 'archivos'))}</b><span class="gt-plus">+${Number(d.added) || 0}</span><span class="gt-minus">−${Number(d.deleted) || 0}</span><span class="dl-muted">· rama «${e(d.branch || 'sin rama')}»</span></div>
  ${notesBlock(plan.warnings, [])}
  ${filesList(files, more, 'Archivos que se guardan')}
  ${notStaged}
  <h4 class="dl-sec">Mensaje del commit <span class="dl-muted gt-sec-note">· puedes cambiarlo</span></h4>
  <textarea class="gt-message" data-gt="message" rows="5" maxlength="20000" spellcheck="true" aria-label="Mensaje del commit">${e(d.message || '')}</textarea>
  <p class="dl-fine gt-fine">La primera línea es el título (corta y clara); si hace falta, una línea en blanco y los detalles. Auric no deja firmas de IA en el mensaje.</p>
  ${identityBlock(plan)}
  ${hooksBlock(plan)}
  ${commandBlock(plan)}
</div>`;
  return `${head('git', 'GUARDAR CAMBIOS · COMMIT', `Auric quiere guardar cambios en «${plan.repoName}»`, lead, { danger })}${body}${ackBlock(plan)}${actions(danger ? 'Guardar de todos modos' : 'Guardar commit', { danger })}`;
}

// ── Ventana: subir al servidor (push) ─────────────────────────────────────────────────────────────────────────
export function pushDialogHtml(plan) {
  const d = plan.data || {};
  const force = !!d.force;
  const danger = force || (plan.warnings || []).some(w => w.level === 'danger');
  const urls = (d.urls || []).map(u => `<code class="dl-code">${e(u)}</code>`).join(' ');
  const lead = force
    ? 'Esta subida es FORZADA: reemplaza lo que hay en el servidor y puede borrar el trabajo de otras personas. Siempre se pregunta, también en modo Completo.'
    : 'Subir envía tu trabajo fuera de este equipo y otras personas con acceso podrán verlo. Siempre se pregunta, también en modo Completo.';
  const rows = [
    repoRow(plan),
    row('Servidor', `<b>${e(d.remote)}</b> ${urls}`, 'is-host'),
    row(
      'Rama',
      `<b>${e(d.branch)}</b>${d.newBranch ? ' <span class="cx-pill">nueva en el servidor</span>' : ''}${d.setUpstream ? ' <span class="dl-muted">· se asociará con la rama del servidor</span>' : ''}`
    ),
    row(
      'Commits que se envían',
      `<b>${d.totalCommits || 0}</b>${d.behind ? ` <span class="dl-muted">· el servidor tiene ${plural(d.behind, 'commit', 'commits')} que tú no tienes</span>` : ''}`
    )
  ].join('');
  const body = `<div class="dl-body">
  <dl class="dl-rows">${rows}</dl>
  ${notesBlock(plan.warnings, plan.effects)}
  ${commitsList(d.commits, d.totalCommits, 'Lo que se enviará')}
  ${hooksBlock(plan)}
  ${commandBlock(plan)}
</div>`;
  return `${head('upload', force ? 'SUBIDA FORZADA · SIEMPRE SE PREGUNTA' : 'PERMISO PARA SUBIR · SIEMPRE SE PREGUNTA', force ? `Auric quiere subir «${d.branch}» a la FUERZA` : `Auric quiere subir cambios a «${d.remote}»`, lead, { danger })}${body}${ackBlock(plan)}${actions(force ? 'Subir a la fuerza' : 'Subir', { danger })}`;
}

// ── Ventana: acción destructiva ───────────────────────────────────────────────────────────────────────────────
export function destructiveDialogHtml(plan) {
  const d = plan.data || {};
  const files = d.files || [];
  const lost = d.dropped || d.commits || [];
  const backups = plan.backups
    ? note(
        'ok',
        'Antes de hacerlo, Auric guarda una copia de seguridad dentro del propio proyecto. Se recupera pidiendo «restaura la copia de seguridad de Git».'
      )
    : '';
  const body = `<div class="dl-body">
  <dl class="dl-rows">${repoRow(plan)}</dl>
  ${notesBlock(plan.warnings, plan.effects)}
  ${backups ? `<ul class="dl-notes">${backups}</ul>` : ''}
  ${filesList(files, d.more || 0, 'Archivos afectados')}
  ${commitsList(lost, d.droppedTotal || lost.length, d.dropped ? 'Commits que se dejarían de ver' : 'Commits')}
  ${identityBlock(plan)}
  ${hooksBlock(plan)}
  ${commandBlock(plan)}
</div>`;
  return `${head('shield', 'ACCIÓN QUE PUEDE PERDER TRABAJO · SIEMPRE SE PREGUNTA', plan.title, plan.summary, { danger: true })}${body}${ackBlock(plan)}${actions('Sí, hacerlo', { danger: true })}`;
}

// ── Ventana: otras acciones que cambian el proyecto (cambiar de rama, fusionar, traer…) ────────────────────────
export function genericDialogHtml(plan) {
  const d = plan.data || {};
  const danger = (plan.warnings || []).some(w => w.level === 'danger');
  const commits = d.commits || [];
  const body = `<div class="dl-body">
  <dl class="dl-rows">${repoRow(plan)}</dl>
  ${notesBlock(plan.warnings, plan.effects)}
  ${filesList(d.files || [], d.more || 0, 'Archivos')}
  ${commitsList(commits, commits.length, 'Commits que llegan')}
  ${identityBlock(plan)}
  ${hooksBlock(plan)}
  ${commandBlock(plan)}
</div>`;
  return `${head('git', plan.network ? 'PERMISO PARA GIT · USA LA RED' : 'PERMISO PARA GIT', plan.title, plan.summary, { danger })}${body}${ackBlock(plan)}${actions('Permitir', { danger })}`;
}

export function gitDialogHtml(plan) {
  if (plan.dialog === 'commit') return commitDialogHtml(plan);
  if (plan.dialog === 'push') return pushDialogHtml(plan);
  if (plan.dialog === 'destructive') return destructiveDialogHtml(plan);
  return genericDialogHtml(plan);
}

const EMAIL_RE = /^[^\s<>@,;]{1,100}@[^\s<>@,;]{1,100}$/;
function dialogValid(layer, plan) {
  const q = s => layer.querySelector(s);
  if (plan.ack && !q('[data-gt="ack"]')?.checked) return false;
  if (plan.dialog === 'commit' && !String(q('[data-gt="message"]')?.value || '').trim()) return false;
  if (plan.needsIdentity) {
    const name = String(q('[data-gt="name"]')?.value || '').trim(),
      email = String(q('[data-gt="email"]')?.value || '').trim();
    if (!name || name.length > 100 || /[<>\r\n]/.test(name) || !EMAIL_RE.test(email)) return false;
  }
  return true;
}
function collectValues(layer, plan) {
  const q = s => layer.querySelector(s);
  const out = { ack: !!q('[data-gt="ack"]')?.checked };
  if (plan.dialog === 'commit') out.message = String(q('[data-gt="message"]')?.value || '');
  if (plan.needsIdentity)
    out.identity = { name: String(q('[data-gt="name"]')?.value || '').trim(), email: String(q('[data-gt="email"]')?.value || '').trim() };
  return out;
}
function confirmGit(plan, { stopped } = {}) {
  const danger = plan.dialog === 'destructive' || plan.data?.force || (plan.warnings || []).some(w => w.level === 'danger');
  return showDialog({
    html: gitDialogHtml(plan),
    labelId: 'gtTitle',
    cls: `gt-dialog gt-kind-${plan.dialog || 'generic'} ${danger ? 'is-danger' : ''}`,
    stopped,
    focus: plan.dialog === 'commit' ? '[data-gt="message"]' : '[data-dl-answer="cancel"]',
    validate: layer => dialogValid(layer, plan),
    collect: layer => collectValues(layer, plan)
  });
}

// ── La herramienta `git` de la IA ─────────────────────────────────────────────────────────────────────────────
const REJECTED =
  'La persona rechazó esta acción de Git en la ventana de confirmación. No la repitas ni insistas: cuéntale qué querías hacer y pregunta cómo prefiere seguir.';
const STOPPED = 'Tarea detenida por el usuario.';
const ACTION_TEXT = {
  status: 'estado',
  diff: 'cambios',
  log: 'historial',
  show: 'commit',
  branch: 'ramas',
  switch: 'cambio de rama',
  add: 'preparar archivos',
  unstage: 'quitar de preparados',
  discard: 'descartar cambios',
  commit: 'guardar cambios',
  stash: 'guardado temporal',
  fetch: 'traer información',
  pull: 'traer cambios',
  merge: 'fusionar',
  push: 'subir',
  remote: 'servidores',
  reset: 'volver atrás',
  init: 'crear repositorio',
  backups: 'copias de seguridad'
};
export const gitActionLabel = args =>
  ACTION_TEXT[
    String(args?.action || '')
      .toLowerCase()
      .replace(/[\s-]+/g, '_')
      .split('_')[0]
  ] || 'acción';

// env: { root:{path}, roots:[{path}], permission, lastUserText, ruleDecision(cmd), protectDiff(text, source), wrapExternal(source, text) }
export async function gitTool(session, args = {}, env = {}) {
  const base = env.root?.path || env.roots?.[0]?.path || '';
  if (!base) throw new Error('No hay una carpeta de trabajo para usar Git. Abre un proyecto primero.');
  const spec = { ...args, root: base };
  delete spec.cwd;
  const ctx = {
    permission: env.permission || session?.permission || '',
    roots: (env.roots || [env.root]).filter(Boolean).map(r => ({ path: r.path || r })),
    sessionId: session?.id || '',
    explicit: explicitRequest(env.lastUserText || '')
  };
  live(session, `Git: preparando «${gitActionLabel(args)}»…`, '');
  const plan = await call(() => C.D.git.prepare(spec, ctx));
  const cancel = () => C.D.git.cancel(plan.id).catch(() => {});
  // Las reglas «denegar» que la persona puso para comandos también valen para Git.
  if (env.ruleDecision) {
    for (const line of plan.display || []) {
      if (env.ruleDecision(line) === 'deny') {
        await cancel();
        throw new Error('Este comando está bloqueado por una regla de permisos del usuario.');
      }
    }
  }
  let decision = { auto: true };
  let edited = null;
  if (plan.ask) {
    live(session, 'Esperando tu permiso para Git…', plan.title);
    const res = await queued(() => confirmGit(plan, { stopped: stoppedFn(session) }));
    if (res.answer !== 'ok') {
      await cancel();
      throw new Error(res.answer === 'stopped' ? STOPPED : REJECTED);
    }
    const v = res.values || {};
    decision = { user: true, ack: !!v.ack, identity: v.identity, message: v.message };
    if (plan.dialog === 'commit' && v.message != null && v.message.trim() !== String(plan.data?.message || '').trim())
      edited = v.message.trim();
  }
  if (plan.kind !== 'read') await call(() => C.D.git.approve(plan.id, decision));
  live(session, `Git: ${plan.title}…`, plan.repoName);
  const stop = stoppedFn(session);
  const watch = setInterval(() => {
    if (stop()) cancel();
  }, 250);
  let out;
  try {
    out = await call(() => C.D.git.run(plan.id));
  } catch (err) {
    if (err.code === 'GIT_ABORTED') throw new Error(stop() ? STOPPED : 'La acción de Git se detuvo.');
    throw err;
  } finally {
    clearInterval(watch);
  }
  let text = String(out.text || 'Listo.');
  if (edited) text += `\n(La persona cambió el mensaje antes de aceptar. Se guardó con este mensaje: «${edited.slice(0, 300)}»)`;
  const op = String(plan.op || '');
  if (op === 'diff' || op === 'show') text = env.protectDiff ? await env.protectDiff(text, `git:${plan.repo}`) : text;
  if ((op === 'log' || op === 'show') && env.wrapExternal) text = env.wrapExternal(`git:${op}`, text);
  return text;
}

// ── Ajustes: registro de lo que Auric hizo con Git ────────────────────────────────────────────────────────────
const OP_TEXT = {
  add: 'Preparó archivos',
  unstage: 'Quitó archivos de preparados',
  discard: 'Descartó cambios',
  commit: 'Guardó un commit',
  branch_create: 'Creó una rama',
  branch_delete: 'Borró una rama',
  switch: 'Cambió de rama',
  stash_push: 'Guardó cambios temporales',
  stash_apply: 'Aplicó un guardado temporal',
  stash_pop: 'Recuperó un guardado temporal',
  stash_drop: 'Borró un guardado temporal',
  fetch: 'Trajo información del servidor',
  pull: 'Trajo cambios del servidor',
  merge: 'Fusionó ramas',
  merge_abort: 'Canceló una fusión',
  push: 'Subió al servidor',
  reset: 'Movió la rama',
  init: 'Creó un repositorio',
  backups_restore: 'Restauró una copia de seguridad'
};
export async function renderGitSettings(host) {
  host.innerHTML = '<h4>Git</h4><p class="desc">Cargando…</p>';
  let rows = [],
    problem = '';
  try {
    rows = await call(() => C.D.git.log(200));
  } catch (err) {
    problem = err.message;
  }
  const trs = rows
    .map(
      r =>
        `<tr data-op="${e(r.op)}"><td class="dl-when">${e(fmtDate(r.t))}</td><td>${e(OP_TEXT[r.op] || r.op)}${r.ok ? '' : ' <span class="dl-err">(falló)</span>'}</td><td class="dl-what"><b>${e(
          String(r.repo || '')
            .split(/[\\/]/)
            .pop()
        )}</b>${r.by ? ` <span class="dl-muted">· ${r.by === 'persona' ? 'aprobado por ti' : 'sin preguntar (permitido por el modo)'}</span>` : ''}<br>${(r.command || []).map(c => `<code class="dl-code">${e(String(c).slice(0, 240))}</code>`).join(' ')}${r.error ? `<br><span class="dl-err">${e(String(r.error).slice(0, 200))}</span>` : ''}${(r.backups || []).length ? '<br><span class="dl-muted">Con copia de seguridad</span>' : ''}</td></tr>`
    )
    .join('');
  host.innerHTML = `<h4>Git</h4>
<p class="desc">Auric usa tu Git del PC (el que ya tienes instalado) y nunca ejecuta programas que traiga un proyecto ajeno sin avisarte. <b>Subir cambios</b> y las acciones que pueden <b>perder trabajo</b> (descartar, volver atrás, borrar ramas) preguntan SIEMPRE, también en modo Completo. Nunca se fuerza una subida si no lo pides tú de forma explícita. Antes de lo destructivo se guarda una copia de seguridad dentro del propio proyecto. Los commits que crea Auric no llevan ninguna firma de IA.</p>
${problem ? `<div class="cx-banner">No se pudo leer el registro: ${e(problem)}</div>` : ''}
<div class="lm-card"><div class="lm-card-head"><div class="lm-card-title">Registro de acciones de Git</div><button class="secondary-btn compact-btn" id="gtReload">Actualizar</button></div>
${rows.length ? `<div class="dl-log-wrap"><table class="dl-log" data-gt="log"><thead><tr><th>Cuándo</th><th>Qué pasó</th><th>Detalle</th></tr></thead><tbody>${trs}</tbody></table></div>` : '<p class="lm-text" data-gt="log-empty">Todavía no hay acciones de Git. Las consultas (estado, historial, cambios) no se anotan; sí todo lo que modifica algo.</p>'}
</div>`;
  host.querySelector('#gtReload').onclick = () => renderGitSettings(host);
}
