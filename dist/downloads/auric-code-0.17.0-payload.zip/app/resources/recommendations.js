// Recommendations are roles, not ordinal places in a ranking.
const value = n => n != null && Number.isFinite(Number(n)) ? Number(n) : null;
export const modelKey = text => String(text || '').toLowerCase().replace(/^.*::/, '').replace(/^[^/]+\//, '').replace(/:free$/, '').replace(/[^a-z0-9]/g, '');
const keys = model => [...new Set([model.id, model.model, model.slug, model.name, model.displayName].filter(Boolean).map(modelKey))];
// Los catálogos pueden contener miles de rutas. No recorrerlos de nuevo dentro
// de cada comparación del ordenador: abrir el selector debe ser una operación local corta.
const benchmarkIndexes = new WeakMap();
const metadataIndexes = new WeakMap();
function addIndex(index, key, row) {
  if (!key) return;
  let rows = index.get(key);
  if (!rows) index.set(key, rows = new Set());
  rows.add(row);
}
function uniqueMatch(index, candidates) {
  const rows = new Set();
  for (const candidate of candidates) for (const row of index.get(candidate) || []) rows.add(row);
  return rows.size === 1 ? rows.values().next().value : null;
}
function benchmarkIndex(rows) {
  let index = benchmarkIndexes.get(rows);
  if (!index) {
    index = new Map();
    for (const row of rows) for (const key of keys(row)) addIndex(index, key, row);
    benchmarkIndexes.set(rows, index);
  }
  return index;
}
function metadataIndex(rows) {
  let providers = metadataIndexes.get(rows);
  if (!providers) {
    providers = new Map();
    for (const row of rows) {
      let index = providers.get(row.provider);
      if (!index) providers.set(row.provider, index = new Map());
      for (const key of keys(row)) addIndex(index, key, row);
    }
    metadataIndexes.set(rows, providers);
  }
  return providers;
}
export function extractRateLimits(headers = {}) {
  const lower = Object.fromEntries(Object.entries(headers).map(([key, item]) => [key.toLowerCase(), item]));
  const result = {};
  for (const [field, names] of Object.entries({ limitRequests: ['x-ratelimit-limit-requests', 'ratelimit-limit'], remainingRequests: ['x-ratelimit-remaining-requests', 'ratelimit-remaining'], limitTokens: ['x-ratelimit-limit-tokens'], remainingTokens: ['x-ratelimit-remaining-tokens'] })) {
    const found = names.map(name => lower[name]).find(item => item != null && /^\d+(?:\.\d+)?$/.test(String(item)));
    if (found != null) result[field] = Number(found);
  }
  return result;
}
export function benchmarkFor(model, intel = {}) {
  const rows = intel.benchmarks;
  if (!Array.isArray(rows) || !rows.length) return null;
  const row = uniqueMatch(benchmarkIndex(rows), keys(model));
  if (!row) return null;
  return { ...row, tests: {}, source: 'live', fetchedAt: intel.aaUpdatedAt, tag: 'Datos actualizados', index: value(row.index), speed: value(row.speed) };
}
export function metadataFor(model, provider, intel = {}) {
  if (!Array.isArray(intel.catalog) || !intel.catalog.length) return null;
  const aliases = { gemini: ['google', 'google-vertex'], nvidia: ['nvidia'], kimi: ['moonshotai', 'moonshotai-cn'], zai: ['zai', 'zhipuai'], huggingface: ['huggingface'] };
  const indexes = metadataIndex(intel.catalog), ids = keys(model), matches = new Set();
  for (const name of aliases[provider] || [provider]) {
    const index = indexes.get(name);
    if (index) for (const id of ids) for (const row of index.get(id) || []) matches.add(row);
  }
  return matches.size === 1 ? matches.values().next().value : null;
}
export function recommendationRoles(models, { provider = '', intel = {}, benchmark = m => benchmarkFor(m, intel), quota = m => value(m.quotaMultiplier), preferFree = true } = {}) {
  let rows = models.filter(m => m && !m.auto && m.available !== false && !['unavailable', 'retired'].includes(m.tier));
  const free = rows.filter(m => ['free', 'free-tier', 'free-quota'].includes(m.tier));
  if (preferFree && free.length) rows = free;
  if (!rows.length) return [];
  const benchmarks = new Map(rows.map(m => [m, benchmark(m)]));
  const latest = Math.max(0, ...rows.map(m => value(benchmarks.get(m)?.version) || 0));
  const scores = new Map();
  const score = m => {
    if (scores.has(m)) return scores.get(m);
    const b = benchmarks.get(m);
    const observed = intel.observed?.[provider + '::' + m.id] || {};
    const metadata = metadataFor(m, m.provider || provider, intel) || {};
    const comparable = b && (!latest || Number(b.version) === latest) && b.index != null;
    const capabilities = (m.supportedParameters || []).some(p => /tool|function/.test(p)) || m.tools === true || metadata.tools;
    const quality = comparable ? Number(b.index) * 100 + (value(b.coding) || 0) + (value(b.agentic) || 0) : capabilities ? 1 : 0;
    const speed = value(observed.speed) ?? value(b?.speed);
    const limits = observed.rateLimits || {};
    const published = value(m.requestsPerMinute ?? m.rateLimits?.requestsPerMinute ?? limits.limitRequests);
    const multiplier = value(quota(m));
    const generous = published != null ? published : provider === 'auric' && multiplier > 0 ? 1000 / multiplier : null;
    const result = { quality, hasQuality: comparable, speed, generous, capabilities, context: Number(m.contextLength || metadata.context || 0), observed };
    scores.set(m, result);
    return result;
  };
  const chosen = new Map();
  const families = new Set();
  const add = (m, role, reason) => {
    if (!m) return;
    const row = chosen.get(m.id);
    if (row) { if (!row.recommendationRoles.includes(role)) row.recommendationRoles.push(role); return; }
    chosen.set(m.id, { ...m, recommendationRoles: [role], recommendationReason: reason });
    families.add(modelKey(m.model || m.id));
  };
  const smart = [...rows].sort((a, b) => score(b).quality - score(a).quality || score(b).context - score(a).context || String(a.id).localeCompare(String(b.id)));
  const qualityCount = provider === 'auric' ? 3 : 2;
  for (const m of smart) {
    if (families.has(modelKey(m.model || m.id))) continue;
    const s = score(m);
    add(m, s.hasQuality ? 'Calidad' : 'Por capacidades', s.hasQuality ? 'Evaluación publicada por Artificial Analysis.' : 'Sin evaluación comparable: elegido por capacidades declaradas, no por una puntuación inventada.');
    if (chosen.size >= qualityCount) break;
  }
  const fast = [...rows].filter(m => score(m).speed != null).sort((a, b) => score(b).speed - score(a).speed)[0];
  add(fast, 'Rápido', 'Velocidad medida en este equipo o publicada; no se deduce del nombre del modelo.');
  const generous = [...rows].filter(m => score(m).generous != null).sort((a, b) => score(b).generous - score(a).generous)[0];
  add(generous, 'Cupo amplio', provider === 'auric' ? 'Consumo relativo de cuota informado por Auric.' : 'Límite publicado o comunicado por el proveedor.');
  if (!generous) {
    const freeChoice = smart.find(m => ['free', 'free-tier', 'free-quota'].includes(m.tier));
    add(freeChoice, 'Opción gratis', 'El cupo exacto no está publicado. Gratis no significa ilimitado.');
  }
  return [...chosen.values()];
}
