export const READ_SUBAGENT_TOOLS = new Set(['list_files', 'read_file', 'search_text', 'index_search', 'index_project', 'read_document', 'git_status', 'git_diff', 'lsp_diagnostics', 'web_search', 'web_fetch', 'ui_components', 'icon_search', 'icon_get']);
export function subagentTools(role, writePaths = []) {
  const tools = new Set(READ_SUBAGENT_TOOLS);
  if (role === 'tester') tools.add('run_tests');
  if (role === 'implementer' && writePaths.length) for (const tool of ['write_file', 'apply_patch', 'make_dir']) tools.add(tool);
  return tools;
}
export function assertChildTool(session, call) {
  if (!session.parentSessionId) return;
  const allowed = subagentTools(session.subagentRole, session.childWritePaths || []);
  if (!allowed.has(call.tool)) throw new Error('Esta herramienta no está disponible para este subagente. Debe devolver la petición al coordinador.');
  if (['write_file', 'apply_patch', 'make_dir'].includes(call.tool)) {
    const file = String(call.args?.path || '').replace(/\\/g, '/').replace(/^\.\//, '');
    if (!file || /(^|\/)\.\.(\/|$)|^\/|^[a-z]:/i.test(file)) throw new Error('La ruta de edición del subagente no es válida.');
    const lower = file.toLowerCase();
    const match = (session.childWritePaths || []).some(scope => lower === scope.toLowerCase() || scope.endsWith('/') && lower.startsWith(scope.toLowerCase()));
    if (!match) throw new Error('Ese archivo no está entre los asignados al subagente.');
  }
}
export async function boundedTasks(tasks, concurrency, run) {
  const results = new Array(tasks.length); let index = 0;
  const worker = async () => { while (index < tasks.length) { const next = index++; results[next] = await run(tasks[next], next); } };
  await Promise.all(Array.from({ length: Math.min(tasks.length, Math.max(1, concurrency)) }, worker));
  return results;
}
export async function runSubagentLoop({ messages, call, execute, parse, stopped = () => false, onStep = async () => {}, onRound = async () => {}, maxRounds = 8, maxTools = 16 }) {
  let used = 0, last = '', repeated = 0;
  for (let round = 1; round <= maxRounds; round++) {
    if (stopped()) throw new Error('Subagente detenido.');
    const raw = await call(messages);
    if (stopped()) throw new Error('Subagente detenido.');
    const parsed = raw?.toolCalls?.length ? { type: 'tool', calls: raw.toolCalls } : parse(typeof raw === 'string' ? raw : raw?.text || '');
    const calls = parsed.type === 'tool' ? (parsed.calls || []).slice(0, 8) : [];
    if (!calls.length) return { text: parsed.message || raw?.text || String(raw || ''), rounds: round, tools: used, status: 'done' };
    const signature = JSON.stringify(calls.map(c => [c.tool, c.args]));
    repeated = signature === last ? repeated + 1 : 0; last = signature;
    if (repeated >= 3) throw new Error('Subagente pausado: repitió la misma acción sin progresar.');
    messages.push({ role: 'assistant', content: raw?.text || '', toolCalls: calls, reasoningContent: raw?.reasoningContent || '', reasoningDetails: raw?.reasoningDetails || null });
    for (let i = 0; i < calls.length; i++) {
      const invocation = { ...calls[i], id: calls[i].id || `subagent-${round}-${i}` };
      calls[i].id = invocation.id;
      if (stopped()) throw new Error('Subagente detenido.');
      let output;
      try {
        if (used >= maxTools) throw new Error('Se alcanzó el límite de herramientas de esta subtarea. Devuelve los hallazgos disponibles.');
        if (invocation.argsInvalid) throw new Error('Los argumentos llegaron incompletos. No se ejecutó la acción.');
        used++;
        output = await execute(invocation);
        const content = typeof output === 'string' ? output : output?.text || JSON.stringify(output);
        messages.push({ role: 'tool', toolCallId: invocation.id, name: invocation.tool, content: String(content).slice(0, 24000) });
        if (output?.attachment) messages.push({ role: 'user', content: 'Visual evidence from the subtask.', attachments: [output.attachment] });
        await onStep(invocation, content, true);
      } catch (error) {
        const content = String(error.message || error);
        messages.push({ role: 'tool', toolCallId: invocation.id, name: invocation.tool, content: JSON.stringify({ error: content }) });
        await onStep(invocation, content, false);
      }
    }
    await onRound(messages, round);
    if (used >= maxTools) return { text: 'Límite de herramientas alcanzado. El coordinador puede consultar la actividad guardada y continuar.', rounds: round, tools: used, status: 'limited' };
  }
  return { text: 'Límite de rondas alcanzado. La actividad y los hallazgos quedan guardados; no se afirma que la subtarea esté terminada.', rounds: maxRounds, tools: used, status: 'limited' };
}
