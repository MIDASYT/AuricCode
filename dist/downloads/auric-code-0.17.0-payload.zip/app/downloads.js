'use strict';
// Descargas con permiso. Flujo en dos pasos separados (nunca en silencio, nunca en segundo plano):
//   1) prepare(url)  → Auric mira el enlace (sin descargarlo entero), muestra dominio real, redirecciones, nombre, tamaño y tipo.
//   2) approve(id) + start(id) → solo tras el "Descargar" del usuario. Archivo temporal .part, tope de tamaño, huella SHA-256,
//      comprobación de la firma real del archivo y registro de auditoría.
// Instalar/ejecutar es OTRO permiso (prepareRun/approveRun/run) que muestra el comando exacto.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const { spawn, execFile } = require('child_process');
const { Transform } = require('stream');
const { pipeline } = require('stream/promises');
const { domainToUnicode } = require('url');
const netSafe = require('./net-safe');

const SNIFF_BYTES = 4096;
const TICKET_TTL_MS = 10 * 60 * 1000;
const HARD_MAX_BYTES = 20 * 1024 * 1024 * 1024;
const DEFAULT_MAX_BYTES = 4 * 1024 * 1024 * 1024;

// ── Dominios ──────────────────────────────────────────────────────────────────────────────────
// [nombre visible, marca (para detectar imitaciones), dominios oficiales]
const KNOWN_SITES = [
  ['Ollama', 'ollama', ['ollama.com']],
  ['GitHub', 'github', ['github.com', 'githubusercontent.com']],
  ['Microsoft', 'microsoft', ['microsoft.com', 'visualstudio.com', 'aka.ms', 'dot.net', 'nuget.org', 'windows.com']],
  ['Python', 'python', ['python.org']],
  ['Node.js', 'nodejs', ['nodejs.org', 'npmjs.com']],
  ['Git', 'git-scm', ['git-scm.com']],
  ['Google', 'google', ['google.com', 'googleapis.com', 'gstatic.com', 'golang.org', 'go.dev', 'chrome.com', 'android.com']],
  ['Mozilla', 'mozilla', ['mozilla.org', 'mozilla.net']],
  ['NVIDIA', 'nvidia', ['nvidia.com']],
  ['AMD', 'amd', ['amd.com']],
  ['Intel', 'intel', ['intel.com']],
  ['VideoLAN', 'videolan', ['videolan.org']],
  ['7-Zip', '7-zip', ['7-zip.org']],
  ['JetBrains', 'jetbrains', ['jetbrains.com']],
  ['Docker', 'docker', ['docker.com']],
  ['Rust', 'rust-lang', ['rust-lang.org', 'rustup.rs']],
  ['Godot', 'godotengine', ['godotengine.org']],
  ['Blender', 'blender', ['blender.org']],
  ['LibreOffice', 'libreoffice', ['libreoffice.org', 'documentfoundation.org']],
  ['PostgreSQL', 'postgresql', ['postgresql.org']],
  ['SQLite', 'sqlite', ['sqlite.org']],
  ['Hugging Face', 'huggingface', ['huggingface.co', 'hf.co']],
  ['Anthropic', 'anthropic', ['anthropic.com', 'claude.ai']],
  ['OpenAI', 'openai', ['openai.com']],
  ['Apple', 'apple', ['apple.com']],
  ['Adobe', 'adobe', ['adobe.com']]
];
// GitHub aloja archivos de cualquiera: «github.com» es un sitio conocido, pero el repositorio puede no ser el oficial.
// Estos son los repositorios oficiales que Auric reconoce; cualquier otro se muestra con un aviso con el nombre del repositorio.
const GITHUB_OFFICIAL = new Set([
  'ollama/ollama',
  'git-for-windows/git',
  'godotengine/godot',
  'godotengine/godot-builds',
  'microsoft/vscode',
  'nodejs/node',
  'obsproject/obs-studio',
  'ggml-org/llama.cpp'
]);
const GITHUB_HOSTS = new Set(['github.com', 'githubusercontent.com']);
function githubRepoFrom(urls) {
  for (const raw of urls) {
    let u;
    try {
      u = new URL(raw);
    } catch {
      continue;
    }
    if (u.hostname.toLowerCase() !== 'github.com') continue;
    const m = /^\/([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)\/(?:releases|raw|archive|blob|files)(?:\/|$)/.exec(u.pathname);
    if (m) return `${m[1]}/${m[2]}`;
  }
  return '';
}
// Marcas muy imitadas aunque no sean sitios de descarga habituales.
const EXTRA_BRANDS = [
  'paypal',
  'amazon',
  'dropbox',
  'steam',
  'discord',
  'telegram',
  'whatsapp',
  'binance',
  'coinbase',
  'netflix',
  'spotify',
  'zoom',
  'chrome',
  'firefox',
  'windows',
  'office'
];
const MULTI_SUFFIXES = new Set([
  'co.uk',
  'org.uk',
  'ac.uk',
  'gov.uk',
  'com.au',
  'net.au',
  'org.au',
  'com.br',
  'com.ar',
  'com.mx',
  'com.co',
  'com.pe',
  'com.cl',
  'co.jp',
  'ne.jp',
  'or.jp',
  'co.nz',
  'co.za',
  'co.in',
  'com.cn',
  'com.tw',
  'com.hk',
  'com.sg',
  'com.my',
  'com.tr',
  'com.ua',
  'co.kr'
]);
// Alojamiento de contenido de terceros: cada subdominio es de otra persona, no del dueño del dominio.
const HOSTING_SUFFIXES = new Set([
  'github.io',
  'gitlab.io',
  'pages.dev',
  'workers.dev',
  'netlify.app',
  'vercel.app',
  'herokuapp.com',
  'blogspot.com',
  'web.app',
  'firebaseapp.com',
  'azurewebsites.net',
  'cloudfront.net',
  'amazonaws.com',
  'r2.dev',
  'onrender.com',
  'fly.dev',
  'glitch.me',
  'repl.co',
  'ngrok.io',
  'ngrok-free.app',
  'trycloudflare.com',
  'duckdns.org',
  'no-ip.org'
]);

function registrableDomain(host) {
  const h = String(host || '')
    .toLowerCase()
    .replace(/\.$/, '');
  if (!h || require('net').isIP(h.replace(/^\[|\]$/g, ''))) return h;
  const labels = h.split('.').filter(Boolean);
  if (labels.length <= 2) return labels.join('.');
  const last2 = labels.slice(-2).join('.');
  if (MULTI_SUFFIXES.has(last2) || HOSTING_SUFFIXES.has(last2)) return labels.slice(-3).join('.');
  return last2;
}
function skeleton(label) {
  return String(label || '')
    .toLowerCase()
    .replace(/rn/g, 'm')
    .replace(/vv/g, 'w')
    .replace(/[0]/g, 'o')
    .replace(/[1|!]/g, 'l')
    .replace(/3/g, 'e')
    .replace(/5/g, 's')
    .replace(/[-_]/g, '');
}
function editDistance(a, b) {
  if (Math.abs(a.length - b.length) > 2) return 3;
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++)
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return dp[a.length][b.length];
}
// Análisis del dominio real (el que aparece tras https://): nombre conocido, imitaciones, punycode, IP suelta…
function analyzeDomain(host) {
  const h = String(host || '')
    .toLowerCase()
    .replace(/^\[|\]$/g, '')
    .replace(/\.$/, '');
  const registrable = registrableDomain(h);
  const warnings = [];
  let known = '';
  for (const [name, , domains] of KNOWN_SITES) if (domains.includes(registrable)) known = name;
  if (require('net').isIP(h)) {
    warnings.push({ level: 'danger', text: 'La descarga viene de una dirección numérica (IP) y no de un dominio con nombre.' });
    return { host: h, registrable, known, warnings };
  }
  const unicode = domainToUnicode(h);
  if (h.split('.').some(l => l.startsWith('xn--')) || /[^\x00-\x7f]/.test(unicode)) {
    warnings.push({
      level: 'danger',
      text: `El dominio usa caracteres internacionales que pueden imitar a otro sitio (se ve como "${unicode}", técnicamente "${h}").`
    });
  }
  const hostingSuffix = h.split('.').slice(-2).join('.');
  if (HOSTING_SUFFIXES.has(hostingSuffix))
    warnings.push({
      level: 'warn',
      text: `Este contenido lo publica una persona cualquiera en ${hostingSuffix}, no la empresa que da nombre al sitio.`
    });
  if (!known) {
    const labels = h.split('.');
    const sub = labels.slice(0, Math.max(0, labels.length - registrable.split('.').length));
    const regLabel = registrable.split('.')[0];
    const brands = [...KNOWN_SITES.map(([n, b, d]) => [n, b, d]), ...EXTRA_BRANDS.map(b => [b, b, []])];
    for (const [name, brand, domains] of brands) {
      const flat = skeleton(brand);
      const inSub = sub.some(l => skeleton(l) === flat || l === brand);
      const inRegLabelParts = regLabel.split('-').some(part => skeleton(part) === flat) && regLabel !== brand;
      const closeToBrand =
        flat.length >= 5 && regLabel !== brand && editDistance(skeleton(regLabel), flat) <= 1 && !domains.includes(registrable);
      if (inSub) {
        warnings.push({
          level: 'danger',
          text: `El nombre contiene "${brand}" pero el sitio real es ${registrable}, que no es de ${name}.`
        });
        break;
      }
      if (inRegLabelParts || closeToBrand) {
        warnings.push({
          level: 'danger',
          text: `El dominio ${registrable} se parece al de ${name}${domains[0] ? ` (${domains[0]})` : ''} pero no lo es.`
        });
        break;
      }
    }
  }
  return { host: h, registrable, known, warnings };
}

// ── Nombres de archivo ────────────────────────────────────────────────────────────────────────
const RESERVED_WIN = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
function sanitizeFileName(input, fallback = 'descarga') {
  let n = String(input || '');
  try {
    n = decodeURIComponent(n);
  } catch {}
  n = n.split(/[\\/]/).pop();
  n = n
    .replace(/[\u0000-\u001f\u007f‎‏‪-‮⁦-⁩﻿]/g, '') // control y marcas de dirección (nombres engañosos)
    .replace(/[<>:"|?*]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[. ]+$/g, '');
  if (!n || n === '.' || n === '..') n = fallback;
  if (RESERVED_WIN.test(n)) n = '_' + n;
  if (n.length > 120) {
    const ext = path.extname(n).slice(0, 12);
    n = n.slice(0, 120 - ext.length) + ext;
  }
  return n;
}
function parseContentDisposition(value) {
  const v = String(value || '');
  const star = /filename\*\s*=\s*(?:UTF-8|utf-8)''([^;]+)/i.exec(v);
  if (star) {
    try {
      return decodeURIComponent(star[1].trim().replace(/^"|"$/g, ''));
    } catch {}
  }
  const plain = /filename\s*=\s*"((?:[^"\\]|\\.)*)"/i.exec(v) || /filename\s*=\s*([^;]+)/i.exec(v);
  return plain ? plain[1].trim().replace(/\\"/g, '"') : '';
}
function extOf(name) {
  return path
    .extname(String(name || ''))
    .slice(1)
    .toLowerCase();
}

// ── Tipos y firma real ────────────────────────────────────────────────────────────────────────
const BLOCKED_EXT = new Set([
  'lnk',
  'hta',
  'scr',
  'pif',
  'cpl',
  'reg',
  'com',
  'vbs',
  'vbe',
  'jse',
  'wsf',
  'wsh',
  'msc',
  'url',
  'iqy',
  'slk',
  'gadget',
  'application',
  'dll',
  'sys',
  'drv',
  'ocx',
  'chm',
  'appref-ms',
  'settingcontent-ms'
]);
// extensión → { kind, label, sigs: firmas aceptadas }
const TYPE_TABLE = (() => {
  const t = {};
  const add = (exts, kind, label, sigs) => exts.forEach(e => (t[e] = { kind, label, sigs }));
  add(['exe'], 'installer', 'programa o instalador de Windows (.exe)', ['mz']);
  add(['msi'], 'installer', 'instalador de Windows (.msi)', ['ole']);
  add(['msix', 'appx', 'msixbundle', 'appxbundle'], 'installer', 'paquete de aplicación de Windows', ['zip']);
  add(['zip'], 'archive', 'archivo comprimido ZIP', ['zip']);
  add(['7z'], 'archive', 'archivo comprimido 7-Zip', ['7z']);
  add(['rar'], 'archive', 'archivo comprimido RAR', ['rar']);
  add(['gz', 'tgz'], 'archive', 'archivo comprimido gzip', ['gzip']);
  add(['xz'], 'archive', 'archivo comprimido xz', ['xz']);
  add(['bz2'], 'archive', 'archivo comprimido bzip2', ['bzip2']);
  add(['zst'], 'archive', 'archivo comprimido zstd', ['zstd']);
  add(['tar'], 'archive', 'archivo TAR', ['tar', 'binary']);
  add(['pdf'], 'document', 'documento PDF', ['pdf']);
  add(['docx', 'xlsx', 'pptx', 'odt', 'ods', 'odp'], 'document', 'documento de Office', ['zip']);
  add(['doc', 'xls', 'ppt'], 'document', 'documento de Office antiguo', ['ole']);
  add(['png'], 'image', 'imagen PNG', ['png']);
  add(['jpg', 'jpeg'], 'image', 'imagen JPEG', ['jpeg']);
  add(['gif'], 'image', 'imagen GIF', ['gif']);
  add(['webp'], 'image', 'imagen WebP', ['webp']);
  add(['bmp'], 'image', 'imagen BMP', ['bmp']);
  add(['ico'], 'image', 'icono', ['ico']);
  add(['txt', 'md', 'csv', 'tsv', 'json', 'xml', 'yaml', 'yml', 'toml', 'ini', 'log', 'cfg'], 'text', 'archivo de texto', ['text']);
  add(['html', 'htm'], 'text', 'página web (HTML)', ['text', 'html']);
  add(['ps1', 'bat', 'cmd', 'sh', 'py', 'js', 'mjs'], 'script', 'script (se puede ejecutar)', ['text']);
  add(['gguf'], 'model', 'modelo de IA (GGUF)', ['gguf']);
  add(['sqlite', 'db'], 'data', 'base de datos SQLite', ['sqlite']);
  add(['ttf', 'otf', 'woff', 'woff2'], 'font', 'tipografía', ['font']);
  add(['deb'], 'archive', 'paquete .deb', ['ar']);
  add(['iso', 'img', 'bin'], 'archive', 'imagen de disco', ['any']);
  return t;
})();
const EXECUTABLE_SIGS = new Set(['mz', 'elf', 'macho', 'shebang']);

function sniffBuffer(buf) {
  const b = Buffer.isBuffer(buf) ? buf : Buffer.from(buf || []);
  if (!b.length) return 'empty';
  const startsWith = (...bytes) => bytes.every((x, i) => b[i] === x);
  const ascii = (off, s) => b.length >= off + s.length && b.toString('latin1', off, off + s.length) === s;
  if (startsWith(0x4d, 0x5a)) return 'mz';
  if (startsWith(0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1)) return 'ole';
  if (startsWith(0x50, 0x4b, 0x03, 0x04) || startsWith(0x50, 0x4b, 0x05, 0x06) || startsWith(0x50, 0x4b, 0x07, 0x08)) return 'zip';
  if (startsWith(0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c)) return '7z';
  if (ascii(0, 'Rar!\x1a\x07')) return 'rar';
  if (startsWith(0x1f, 0x8b)) return 'gzip';
  if (startsWith(0xfd, 0x37, 0x7a, 0x58, 0x5a, 0x00)) return 'xz';
  if (ascii(0, 'BZh')) return 'bzip2';
  if (startsWith(0x28, 0xb5, 0x2f, 0xfd)) return 'zstd';
  if (ascii(0, '%PDF-')) return 'pdf';
  if (startsWith(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a)) return 'png';
  if (startsWith(0xff, 0xd8, 0xff)) return 'jpeg';
  if (ascii(0, 'GIF87a') || ascii(0, 'GIF89a')) return 'gif';
  if (ascii(0, 'RIFF') && ascii(8, 'WEBP')) return 'webp';
  if (ascii(0, 'BM') && b.length > 14) return 'bmp';
  if (startsWith(0x00, 0x00, 0x01, 0x00)) return 'ico';
  if (ascii(0, 'GGUF')) return 'gguf';
  if (ascii(0, 'SQLite format 3\0')) return 'sqlite';
  if (startsWith(0x7f, 0x45, 0x4c, 0x46)) return 'elf';
  if (startsWith(0xcf, 0xfa, 0xed, 0xfe) || startsWith(0xce, 0xfa, 0xed, 0xfe) || startsWith(0xca, 0xfe, 0xba, 0xbe)) return 'macho';
  if (ascii(0, '!<arch>\n')) return 'ar';
  if (ascii(0, 'wOFF') || ascii(0, 'wOF2') || ascii(0, 'OTTO') || ascii(0, 'true') || startsWith(0x00, 0x01, 0x00, 0x00)) return 'font';
  if (ascii(257, 'ustar')) return 'tar';
  if (ascii(0, '#!')) return 'shebang';
  const head = b.toString('utf8', 0, Math.min(b.length, 512)).replace(/^﻿/, '').trimStart().toLowerCase();
  if (/^(<!doctype html|<html|<head|<body|<script|<\?xml[^>]*\?>\s*<html)/.test(head)) return 'html';
  const sample = b.subarray(0, Math.min(b.length, 2048));
  let nul = 0;
  for (const x of sample) if (x === 0) nul++;
  const hasBom = (sample[0] === 0xff && sample[1] === 0xfe) || (sample[0] === 0xfe && sample[1] === 0xff);
  if (!nul || hasBom) {
    const asText = sample.toString('utf8');
    if (!asText.includes('�') || hasBom) return 'text';
  }
  return 'binary';
}
// ¿El contenido real coincide con lo que dice el nombre? Devuelve { ok, detected, problem?, level? }.
function checkSignature(fileName, buf) {
  const ext = extOf(fileName);
  const detected = sniffBuffer(buf);
  const rule = TYPE_TABLE[ext];
  if (BLOCKED_EXT.has(ext))
    return {
      ok: false,
      detected,
      level: 'blocked',
      problem: `Los archivos .${ext} están bloqueados por seguridad: pueden ejecutar acciones al abrirse.`
    };
  if (detected === 'empty') return { ok: false, detected, level: 'blocked', problem: 'El archivo llegó vacío.' };
  if (!rule) {
    if (EXECUTABLE_SIGS.has(detected) && detected !== 'shebang')
      return {
        ok: false,
        detected,
        level: 'blocked',
        problem: `El archivo se llama .${ext || '(sin extensión)'} pero por dentro es un programa ejecutable (${detected.toUpperCase()}).`
      };
    if (detected === 'html')
      return { ok: false, detected, level: 'blocked', problem: 'El enlace devolvió una página web (HTML), no un archivo.' };
    return { ok: true, detected, unverified: true };
  }
  if (rule.sigs.includes('any')) return { ok: true, detected, unverified: true };
  if (rule.sigs.includes(detected)) return { ok: true, detected };
  if (rule.kind !== 'script' && detected === 'html')
    return {
      ok: false,
      detected,
      level: 'blocked',
      problem: `Se esperaba ${rule.label}, pero el servidor devolvió una página web (HTML). Suele ser un enlace roto o una página de aviso.`
    };
  if (EXECUTABLE_SIGS.has(detected) && rule.kind !== 'installer' && rule.kind !== 'script')
    return {
      ok: false,
      detected,
      level: 'blocked',
      problem: `El archivo dice ser ${rule.label}, pero por dentro es un programa ejecutable. Es un disfraz típico de malware.`
    };
  return {
    ok: false,
    detected,
    level: 'blocked',
    problem: `El contenido no coincide con lo que dice el nombre (.${ext} debería ser ${rule.label}).`
  };
}
function describeSig(sig) {
  return (
    {
      mz: 'programa de Windows',
      ole: 'instalador/documento OLE',
      zip: 'ZIP',
      '7z': '7-Zip',
      pdf: 'PDF',
      png: 'PNG',
      jpeg: 'JPEG',
      gif: 'GIF',
      webp: 'WebP',
      gguf: 'modelo GGUF',
      text: 'texto',
      html: 'página web',
      binary: 'datos binarios',
      elf: 'programa Linux',
      macho: 'programa macOS'
    }[sig] || sig
  );
}
function doubleExtension(name) {
  const m = /\.(pdf|docx?|xlsx?|pptx?|txt|jpe?g|png|gif|zip|mp3|mp4|csv|rtf)\.(exe|msi|scr|bat|cmd|ps1|com|js|vbs|lnk|hta)$/i.exec(
    String(name || '')
  );
  return !!m;
}

// ── Sumas de verificación publicadas ──────────────────────────────────────────────────────────
function parseChecksumText(text, fileName) {
  const base = String(fileName || '').toLowerCase();
  const rows = [];
  for (const raw of String(text || '').split(/\r?\n/)) {
    const line = raw.trim();
    let m;
    if ((m = /^([a-f0-9]{64})\s+\*?(.+)$/i.exec(line))) rows.push([m[1].toLowerCase(), m[2].trim()]);
    else if ((m = /^SHA256\s*\((.+)\)\s*=\s*([a-f0-9]{64})$/i.exec(line))) rows.push([m[2].toLowerCase(), m[1].trim()]);
    else if ((m = /^(.+?)\s*[:=]\s*([a-f0-9]{64})$/i.exec(line))) rows.push([m[2].toLowerCase(), m[1].trim()]);
    else if ((m = /^([a-f0-9]{64})$/i.exec(line))) rows.push([m[1].toLowerCase(), '']);
  }
  const named = rows.find(([, n]) => n && path.basename(n.replace(/\\/g, '/')).toLowerCase() === base);
  if (named) return named[0];
  const anyBare = rows.filter(([, n]) => !n);
  if (anyBare.length === 1 && rows.length === 1) return anyBare[0][0];
  return '';
}

function humanBytes(n) {
  n = Number(n) || 0;
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) {
    n /= 1024;
    i++;
  }
  // coma decimal, como el resto de la interfaz en español
  return `${n >= 100 || i === 0 ? Math.round(n) : n.toFixed(1).replace('.', ',')} ${u[i]}`;
}

// Argumentos de instalador: sin metacaracteres de shell y sin modos silenciosos (el instalador debe verse).
const SILENT_FLAG = /^(\/|--?)(s|silent|verysilent|very-silent|quiet|q|qn|qn\+|norestart-silent|suppressmsgboxes|unattended|sp-)$/i;
function validateInstallerArgs(args) {
  if (!Array.isArray(args)) return [];
  const out = [];
  for (const a of args.slice(0, 12)) {
    const s = String(a);
    if (s.length > 400) throw new Error('Un argumento del instalador es demasiado largo.');
    if (/[\r\n\0&|<>^`$;]|%[A-Za-z_]+%/.test(s))
      throw new Error('Los argumentos del instalador no pueden contener caracteres de shell (& | < > ^ ` $ ; %).');
    if (SILENT_FLAG.test(s.split('=')[0]))
      throw new Error('Auric no instala en silencio: el asistente del instalador tiene que verse para que puedas seguirlo.');
    out.push(s);
  }
  return out;
}
function quoteArg(s) {
  s = String(s);
  return /[\s"]/.test(s) ? `"${s.replace(/"/g, '\\"')}"` : s;
}

class DownloadManager {
  constructor(opts = {}) {
    this.downloadsDir = opts.downloadsDir;
    this.logFile = opts.logFile;
    this.hostMap = opts.hostMap || null;
    this.resolver = opts.resolver;
    this.emit = opts.emit || (() => {});
    this.now = opts.now || (() => Date.now());
    this.userAgent = opts.userAgent || 'Auric-Code';
    this.getFreeBytes =
      opts.getFreeBytes ||
      (async dir => {
        try {
          const st = await fsp.statfs(dir);
          return Number(st.bavail) * Number(st.bsize);
        } catch {
          return Infinity;
        }
      });
    this.authenticode = opts.authenticode || defaultAuthenticode;
    this.spawn = opts.spawn || spawn;
    this.platform = opts.platform || process.platform;
    this.markOfTheWeb = opts.markOfTheWeb || defaultMark;
    this.tickets = new Map();
    this.runs = new Map();
    this.maxActive = opts.maxActive || 2;
    this.runWaitMs = opts.runWaitMs ?? 2500;
  }
  // ── registro de auditoría ───────────────────────────────────────────────────────────────────
  async log(event, data = {}) {
    if (!this.logFile) return;
    try {
      await fsp.mkdir(path.dirname(this.logFile), { recursive: true });
      try {
        const st = await fsp.stat(this.logFile);
        if (st.size > 2 * 1024 * 1024) await fsp.rename(this.logFile, this.logFile + '.1');
      } catch {}
      await fsp.appendFile(this.logFile, JSON.stringify({ ts: new Date(this.now()).toISOString(), event, ...data }) + '\n', 'utf8');
    } catch {}
  }
  async readLog(limit = 100) {
    if (!this.logFile) return [];
    let text = '';
    try {
      text = await fsp.readFile(this.logFile, 'utf8');
    } catch {
      return [];
    }
    const rows = [];
    for (const line of text.split('\n')) {
      if (!line.trim()) continue;
      try {
        rows.push(JSON.parse(line));
      } catch {}
    }
    return rows.slice(-Math.max(1, Math.min(1000, Number(limit) || 100))).reverse();
  }
  purge() {
    const cutoff = this.now() - TICKET_TTL_MS * 2;
    for (const [id, t] of this.tickets) if (t.createdAt < cutoff && !['downloading'].includes(t.status)) this.tickets.delete(id);
    for (const [id, r] of this.runs) if (r.createdAt < cutoff) this.runs.delete(id);
  }

  // ── 1) preparar: mirar el enlace sin descargarlo entero ─────────────────────────────────────
  async prepare(spec = {}) {
    this.purge();
    const rawUrl = String(spec.url || '').trim();
    const maxBytes = Math.max(1024 * 1024, Math.min(HARD_MAX_BYTES, Number(spec.maxBytes) || DEFAULT_MAX_BYTES));
    const requested = netSafe.parseUrlStrict(rawUrl); // https obligatorio, sin usuario:clave
    const hops = [];
    const headers = { 'User-Agent': this.userAgent, 'Accept-Encoding': 'identity', Range: `bytes=0-${SNIFF_BYTES - 1}`, Accept: '*/*' };
    const opened = await netSafe.openSafe(requested.href, {
      headers,
      hostMap: this.hostMap,
      resolver: this.resolver,
      timeoutMs: 25000,
      maxRedirects: 5,
      onHop: h => hops.push({ from: h.from, to: h.to, status: h.status })
    });
    const res = opened.res;
    let head;
    try {
      if (res.statusCode >= 400)
        throw new Error(`El sitio respondió con un error (HTTP ${res.statusCode}). Comprueba que el enlace sea correcto.`);
      if (![200, 206].includes(res.statusCode)) throw new Error(`Respuesta inesperada del sitio (HTTP ${res.statusCode}).`);
      head = (await netSafe.readLimited(res, SNIFF_BYTES)).buffer;
    } finally {
      res.destroy();
    }
    let total = null;
    const cr = /bytes\s+\d+-\d+\/(\d+)/i.exec(String(res.headers['content-range'] || ''));
    if (res.statusCode === 206 && cr) total = Number(cr[1]);
    else if (res.statusCode === 200 && res.headers['content-length'] != null) total = Number(res.headers['content-length']);
    else if (res.statusCode === 206 && res.headers['content-length'] != null && head.length < SNIFF_BYTES)
      total = Number(res.headers['content-length']);
    if (total != null && !Number.isFinite(total)) total = null;

    const final = opened.url;
    const chainHosts = [...new Set([requested.hostname, ...hops.map(h => new URL(h.to).hostname)])];
    const fromServer = sanitizeFileName(parseContentDisposition(res.headers['content-disposition']) || '', '');
    const fromUrl = sanitizeFileName(path.posix.basename(decodeURIComponentSafe(final.pathname)) || '', '');
    const provided = sanitizeFileName(spec.name || '', '');
    const name = sanitizeFileName(fromServer || (extOf(fromUrl) ? fromUrl : '') || provided || fromUrl, 'descarga');
    const ext = extOf(name);
    const contentType = String(res.headers['content-type'] || '')
      .split(';')[0]
      .trim()
      .toLowerCase();

    const warnings = [];
    const add = (level, text) => warnings.push({ level, text });
    const domainInfo = analyzeDomain(final.hostname);
    const requestedInfo = analyzeDomain(requested.hostname);
    for (const w of domainInfo.warnings) add(w.level, w.text);
    if (requestedInfo.registrable !== domainInfo.registrable) for (const w of requestedInfo.warnings) add(w.level, w.text);
    const crossHost = requested.hostname !== final.hostname;
    const crossDomain = requestedInfo.registrable !== domainInfo.registrable;
    if (crossDomain) {
      if (requestedInfo.known && domainInfo.known)
        add('info', `El enlace de ${requested.hostname} (${requestedInfo.known}) pasa por ${final.hostname} (${domainInfo.known}), también un sitio conocido.`);
      else add('warn', `El enlace de ${requested.hostname} redirige a otro sitio: ${final.hostname}. Comprueba que esperabas ese destino.`);
    }
    const chainUrls = [requested.href, ...hops.map(h => h.to)];
    const touchesGithub = [...new Set(chainHosts.map(registrableDomain))].some(d => GITHUB_HOSTS.has(d));
    const githubRepo = githubRepoFrom(chainUrls);
    if (githubRepo) {
      if (GITHUB_OFFICIAL.has(githubRepo.toLowerCase())) add('info', `Repositorio oficial conocido en GitHub: ${githubRepo}.`);
      else
        add(
          'warn',
          `GitHub permite que cualquier persona publique archivos. Este viene del repositorio «${githubRepo}»: comprueba que sea el oficial del programa que quieres.`
        );
    } else if (touchesGithub) {
      add('warn', 'GitHub permite que cualquier persona publique archivos y no se pudo saber de qué repositorio viene este: comprueba que sea el oficial.');
    }
    if (!domainInfo.known && !domainInfo.warnings.length)
      add('info', `${domainInfo.registrable} no está en la lista de sitios conocidos de Auric. Asegúrate de que es el sitio oficial.`);
    if (provided && fromServer && extOf(provided) && extOf(provided) !== extOf(fromServer))
      add('warn', `Te propusieron guardarlo como "${provided}", pero el sitio lo llama "${fromServer}".`);
    if (doubleExtension(name)) add('danger', `El nombre "${name}" tiene doble extensión: parece un documento pero es un programa.`);
    if (contentType === 'text/html' && !['html', 'htm'].includes(ext))
      add('danger', 'El enlace devuelve una página web, no un archivo descargable.');

    const sig = checkSignature(name, head);
    if (!sig.ok) add('block', sig.problem);
    else if (sig.unverified) add('info', `Auric no puede comprobar la firma interna de este tipo de archivo (.${ext || 'sin extensión'}).`);
    const rule = TYPE_TABLE[ext];
    const kind = BLOCKED_EXT.has(ext) ? 'blocked' : rule?.kind || 'unknown';
    if (kind === 'script') add('warn', 'Es un script: descargarlo no lo ejecuta, pero no deberías ejecutarlo sin leerlo.');
    if (total == null) add('warn', `El sitio no informa del tamaño: Auric cortará la descarga si pasa de ${humanBytes(maxBytes)}.`);
    if (total != null && total > maxBytes) add('block', `El archivo pesa ${humanBytes(total)} y el límite es ${humanBytes(maxBytes)}.`);

    await fsp.mkdir(this.downloadsDir, { recursive: true });
    if (total != null && total <= maxBytes) {
      const free = await this.getFreeBytes(this.downloadsDir);
      if (Number.isFinite(free) && total * 1.05 + 50 * 1024 * 1024 > free)
        add('block', `No hay espacio suficiente en el disco (hacen falta ${humanBytes(total)} y quedan ${humanBytes(free)}).`);
    }

    // Suma SHA-256 publicada por el sitio (si la hay)
    let expected = '';
    let hashSource = '';
    let hashKnown = '';
    if (/^[a-f0-9]{64}$/i.test(String(spec.sha256 || ''))) {
      expected = String(spec.sha256).toLowerCase();
      hashSource = String(spec.sha256Source || 'indicada por la IA');
    } else if (spec.checksumUrl) {
      try {
        const got = await this.fetchChecksum(String(spec.checksumUrl), name);
        if (got.hash) {
          expected = got.hash;
          hashSource = got.source;
          hashKnown = analyzeDomain(got.source).known || '';
        } else add('info', 'No se encontró la suma SHA-256 de este archivo en la página indicada.');
      } catch (e) {
        add('info', `No se pudo leer la suma SHA-256 publicada (${e.message}).`);
      }
    }
    if (!expected) add('info', 'No hay una suma SHA-256 publicada con la que comparar. Auric calculará la del archivo y te la mostrará.');

    const blocked = warnings.some(w => w.level === 'block');
    const danger = warnings.some(w => w.level === 'danger');
    const risk = blocked
      ? 'blocked'
      : danger
        ? 'high'
        : kind === 'installer' || crossDomain || !domainInfo.known || total == null || kind === 'script'
          ? 'medium'
          : 'low';
    const id = crypto.randomUUID();
    const ticket = {
      id,
      createdAt: this.now(),
      status: blocked ? 'blocked' : 'prepared',
      requestedUrl: requested.href,
      finalUrl: final.href,
      hosts: chainHosts.includes(final.hostname) ? chainHosts : [...chainHosts, final.hostname],
      name,
      size: total,
      maxBytes,
      contentType,
      detected: sig.detected,
      kind,
      expectedSha256: expected,
      hashSource,
      purpose: String(spec.purpose || '').slice(0, 300)
    };
    this.tickets.set(id, ticket);
    const plan = {
      id,
      status: ticket.status,
      risk,
      requestedUrl: ticket.requestedUrl,
      requestedHost: requested.hostname,
      finalUrl: ticket.finalUrl,
      finalHost: final.hostname,
      registrableDomain: domainInfo.registrable,
      knownSite: domainInfo.known,
      githubRepo,
      redirects: hops,
      crossHost,
      crossDomain,
      name,
      saveDir: this.downloadsDir,
      savePath: path.join(this.downloadsDir, name),
      size: total,
      sizeText: total == null ? 'desconocido' : humanBytes(total),
      maxText: humanBytes(maxBytes),
      contentType,
      kind,
      typeLabel: rule?.label || (ext ? `archivo .${ext}` : 'archivo'),
      detected: sig.detected,
      detectedText: describeSig(sig.detected),
      signatureOk: sig.ok,
      sha256Expected: expected,
      sha256Source: hashSource,
      sha256SourceKnown: hashKnown,
      purpose: ticket.purpose,
      warnings,
      canRunLater: kind === 'installer' && ['exe', 'msi'].includes(ext)
    };
    await this.log('prepared', {
      id,
      url: ticket.requestedUrl,
      finalUrl: ticket.finalUrl,
      host: final.hostname,
      name,
      size: total,
      risk,
      kind
    });
    return plan;
  }
  async fetchChecksum(rawUrl, fileName) {
    const u = netSafe.parseUrlStrict(rawUrl);
    const o = await netSafe.openSafe(u.href, {
      headers: { 'User-Agent': this.userAgent, 'Accept-Encoding': 'identity', Accept: 'text/plain,*/*' },
      hostMap: this.hostMap,
      resolver: this.resolver,
      timeoutMs: 15000
    });
    try {
      if (o.res.statusCode !== 200) throw new Error(`HTTP ${o.res.statusCode}`);
      const { buffer } = await netSafe.readLimited(o.res, 256 * 1024);
      return { hash: parseChecksumText(buffer.toString('utf8'), fileName), source: o.url.hostname };
    } finally {
      o.res.destroy();
    }
  }

  // ── 2) aprobar (clic del usuario) y descargar ───────────────────────────────────────────────
  approve(id) {
    const t = this.tickets.get(String(id));
    if (!t) throw new Error('La descarga ya no está disponible. Vuelve a pedirla.');
    if (t.status === 'blocked') throw new Error('Auric bloqueó esta descarga por seguridad.');
    if (t.status !== 'prepared') throw new Error('Esta descarga ya fue procesada.');
    if (this.now() - t.createdAt > TICKET_TTL_MS) {
      this.tickets.delete(t.id);
      throw new Error('La confirmación caducó (más de 10 minutos). Vuelve a pedir la descarga.');
    }
    t.status = 'approved';
    t.approvedAt = this.now();
    this.log('approved', { id: t.id, host: new URL(t.finalUrl).hostname, name: t.name });
    return true;
  }
  cancel(id) {
    const t = this.tickets.get(String(id));
    if (!t) return false;
    if (t.status === 'downloading') {
      t.cancelRequested = true;
      t.ctl?.abort();
      return true;
    }
    if (['prepared', 'approved'].includes(t.status)) {
      t.status = 'cancelled';
      this.log('cancelled', { id: t.id, name: t.name, stage: 'before-download' });
      return true;
    }
    return false;
  }
  async uniquePath(name) {
    const ext = path.extname(name),
      stem = name.slice(0, name.length - ext.length);
    for (let i = 0; i < 500; i++) {
      const candidate = path.join(this.downloadsDir, i ? `${stem} (${i})${ext}` : name);
      try {
        await fsp.access(candidate);
      } catch {
        return candidate;
      }
    }
    throw new Error('Demasiados archivos con el mismo nombre en la carpeta de descargas.');
  }
  async start(id) {
    const t = this.tickets.get(String(id));
    if (!t) throw new Error('La descarga ya no está disponible. Vuelve a pedirla.');
    if (t.status !== 'approved') throw new Error('Esta descarga no fue confirmada por el usuario.');
    if (this.now() - t.approvedAt > TICKET_TTL_MS) throw new Error('La confirmación caducó. Vuelve a pedir la descarga.');
    const active = [...this.tickets.values()].filter(x => x.status === 'downloading').length;
    if (active >= this.maxActive) throw new Error('Ya hay descargas en curso. Espera a que terminen.');
    t.status = 'downloading';
    t.ctl = new AbortController();
    await fsp.mkdir(this.downloadsDir, { recursive: true });
    const finalPath = await this.uniquePath(t.name);
    const partPath = `${finalPath}.part`;
    t.partPath = partPath;
    const allowedHosts = new Set(t.hosts);
    const hash = crypto.createHash('sha256');
    let received = 0,
      lastEmit = 0,
      head = Buffer.alloc(0),
      startedAt = this.now(),
      fh = null;
    const progress = (force = false) => {
      const nowMs = this.now();
      if (!force && nowMs - lastEmit < 250) return;
      lastEmit = nowMs;
      const secs = Math.max(0.001, (nowMs - startedAt) / 1000);
      this.emit('download-progress', { id: t.id, name: t.name, received, total: t.size, speed: received / secs });
    };
    const fail = async (message, code = 'FAILED') => {
      try {
        await fh?.close();
      } catch {}
      await fsp.rm(partPath, { force: true }).catch(() => {});
      t.status = t.cancelRequested ? 'cancelled' : 'failed';
      await this.log(t.cancelRequested ? 'cancelled' : 'failed', { id: t.id, name: t.name, reason: message, received });
      this.emit('download-done', { id: t.id, ok: false, cancelled: !!t.cancelRequested, error: message });
      const err = new Error(t.cancelRequested ? 'Descarga cancelada.' : message);
      err.code = t.cancelRequested ? 'CANCELLED' : code;
      throw err;
    };
    await this.log('started', { id: t.id, url: t.requestedUrl, host: new URL(t.finalUrl).hostname, name: t.name, size: t.size });
    let opened;
    try {
      opened = await netSafe.openSafe(t.requestedUrl, {
        headers: { 'User-Agent': this.userAgent, 'Accept-Encoding': 'identity', Accept: '*/*' },
        hostMap: this.hostMap,
        resolver: this.resolver,
        signal: t.ctl.signal,
        timeoutMs: 30000,
        onHop: h => {
          const host = new URL(h.to).hostname;
          if (!allowedHosts.has(host))
            throw new Error(`El sitio redirige ahora a ${host}, que no aparecía cuando confirmaste. Auric detuvo la descarga.`);
        }
      });
    } catch (e) {
      return fail(String(e.message || e));
    }
    const res = opened.res;
    try {
      if (!allowedHosts.has(opened.url.hostname))
        throw new Error(`La descarga acabó en ${opened.url.hostname}, que no aparecía cuando confirmaste.`);
      if (res.statusCode !== 200) throw new Error(`El sitio respondió HTTP ${res.statusCode}.`);
      const ctype = String(res.headers['content-type'] || '')
        .split(';')[0]
        .trim()
        .toLowerCase();
      if (ctype === 'text/html' && !['html', 'htm'].includes(extOf(t.name)))
        throw new Error('El sitio devolvió una página web en lugar del archivo.');
      const declared = res.headers['content-length'] != null ? Number(res.headers['content-length']) : null;
      if (t.size != null && declared != null && declared !== t.size)
        throw new Error('El archivo cambió desde que lo confirmaste (otro tamaño). Vuelve a pedir la descarga.');
      if (declared != null && declared > t.maxBytes)
        throw new Error(`El archivo pesa más del límite permitido (${humanBytes(t.maxBytes)}).`);
      fh = await fsp.open(partPath, 'wx');
      const counter = new Transform({
        transform: (chunk, _enc, cb) => {
          received += chunk.length;
          if (received > t.maxBytes) return cb(new Error(`La descarga superó el límite de ${humanBytes(t.maxBytes)} y se cortó.`));
          if (t.size != null && received > t.size)
            return cb(new Error('El sitio envió más datos de los anunciados. Auric cortó la descarga.'));
          if (head.length < SNIFF_BYTES) head = Buffer.concat([head, chunk.subarray(0, SNIFF_BYTES - head.length)]);
          hash.update(chunk);
          progress();
          cb(null, chunk);
        }
      });
      await pipeline(res, counter, fh.createWriteStream({ autoClose: true }), { signal: t.ctl.signal });
      fh = null;
    } catch (e) {
      res.destroy();
      if (t.cancelRequested || e?.name === 'AbortError' || e?.code === 'ABORT_ERR') t.cancelRequested = true;
      return fail(String(e?.message || e));
    }
    if (t.size != null && received !== t.size)
      return fail(`La descarga llegó incompleta (${humanBytes(received)} de ${humanBytes(t.size)}).`);
    const sig = checkSignature(t.name, head);
    if (!sig.ok) return fail(`Auric descartó el archivo: ${sig.problem}`, 'BAD_SIGNATURE');
    const sha256 = hash.digest('hex');
    let hashStatus = 'none';
    if (t.expectedSha256) {
      if (sha256 !== t.expectedSha256)
        return fail(`El SHA-256 no coincide con el publicado (${t.hashSource}). El archivo se eliminó por seguridad.`, 'HASH_MISMATCH');
      hashStatus = 'match';
    }
    try {
      await fsp.rename(partPath, finalPath);
    } catch (e) {
      return fail(`No se pudo guardar el archivo: ${e.message}`);
    }
    try {
      await this.markOfTheWeb(finalPath, t.finalUrl);
    } catch {}
    t.status = 'done';
    t.path = finalPath;
    t.sha256 = sha256;
    const result = {
      id: t.id,
      path: finalPath,
      name: path.basename(finalPath),
      size: received,
      sizeText: humanBytes(received),
      sha256,
      hashStatus,
      hashSource: t.hashSource,
      host: new URL(t.finalUrl).hostname,
      kind: t.kind,
      canRunLater: t.kind === 'installer' && ['exe', 'msi'].includes(extOf(finalPath))
    };
    progress(true);
    await this.log('done', {
      id: t.id,
      path: finalPath,
      name: result.name,
      size: received,
      sha256,
      hashStatus,
      host: result.host,
      url: t.requestedUrl
    });
    this.emit('download-done', { id: t.id, ok: true, ...result });
    return result;
  }

  // ── Ejecutar / instalar: permiso aparte con el comando exacto ───────────────────────────────
  async findDownloaded(spec) {
    const rows = await this.readLog(1000);
    const done = rows.filter(r => r.event === 'done');
    let row = null;
    if (spec.downloadId) row = done.find(r => r.id === String(spec.downloadId));
    if (!row && spec.path) {
      const want = canonical(spec.path);
      row = done.find(r => canonical(r.path) === want);
    }
    if (!row)
      throw new Error('Solo se pueden ejecutar archivos que Auric descargó con download_file. No encontré ese archivo en el registro.');
    return row;
  }
  async hashFile(file) {
    const h = crypto.createHash('sha256');
    await pipeline(fs.createReadStream(file), h);
    return h.digest('hex');
  }
  async prepareRun(spec = {}) {
    this.purge();
    const row = await this.findDownloaded(spec);
    const file = canonical(row.path);
    const dir = canonical(this.downloadsDir);
    if (!(file === dir || file.startsWith(dir + path.sep))) throw new Error('El archivo no está en la carpeta de descargas de Auric.');
    let st;
    try {
      st = await fsp.stat(file);
    } catch {
      throw new Error('El archivo ya no existe en la carpeta de descargas.');
    }
    if (!st.isFile()) throw new Error('No es un archivo.');
    const ext = extOf(file);
    if (!['exe', 'msi'].includes(ext)) throw new Error(`Auric solo inicia instaladores .exe y .msi (este es .${ext || 'sin extensión'}).`);
    const now = await this.hashFile(file);
    if (now !== row.sha256) throw new Error('El archivo cambió después de descargarse (el SHA-256 ya no coincide). Auric no lo ejecutará.');
    const fh = await fsp.open(file, 'r');
    const headBuf = Buffer.alloc(SNIFF_BYTES);
    const { bytesRead } = await fh.read(headBuf, 0, SNIFF_BYTES, 0);
    await fh.close();
    const sig = sniffBuffer(headBuf.subarray(0, bytesRead));
    if ((ext === 'exe' && sig !== 'mz') || (ext === 'msi' && sig !== 'ole'))
      throw new Error('El contenido del archivo no coincide con un instalador válido.');
    const args = validateInstallerArgs(spec.args);
    const exe = ext === 'msi' ? 'msiexec.exe' : file;
    const argv = ext === 'msi' ? ['/i', file, ...args] : args;
    const command = [quoteArg(exe), ...argv.map(quoteArg)].join(' ');
    const signature = await this.authenticode(file);
    const warnings = [];
    if (signature.status !== 'Valid' && signature.status !== 'unavailable')
      warnings.push({
        level: 'danger',
        text: `El instalador ${signature.status === 'NotSigned' ? 'no tiene firma digital' : `tiene una firma no válida (${signature.status})`}.`
      });
    if (signature.status === 'unavailable')
      warnings.push({ level: 'info', text: 'Auric no pudo comprobar la firma digital en este sistema.' });
    const id = crypto.randomUUID();
    const run = { id, createdAt: this.now(), status: 'prepared', downloadId: row.id, file, sha256: row.sha256, exe, argv, command };
    this.runs.set(id, run);
    await this.log('run-prepared', { id, downloadId: row.id, file, command, signer: signature.subject || '', signature: signature.status });
    return {
      id,
      name: path.basename(file),
      path: file,
      size: st.size,
      sizeText: humanBytes(st.size),
      sha256: row.sha256,
      sourceHost: row.host,
      downloadedAt: row.ts,
      command,
      signature,
      warnings,
      visible: true
    };
  }
  approveRun(id) {
    const r = this.runs.get(String(id));
    if (!r) throw new Error('La confirmación de instalación ya no está disponible.');
    if (r.status !== 'prepared') throw new Error('Esta instalación ya fue procesada.');
    if (this.now() - r.createdAt > TICKET_TTL_MS) {
      this.runs.delete(r.id);
      throw new Error('La confirmación caducó. Vuelve a pedirla.');
    }
    r.status = 'approved';
    r.approvedAt = this.now();
    this.log('run-approved', { id: r.id, command: r.command });
    return true;
  }
  async run(id) {
    const r = this.runs.get(String(id));
    if (!r || r.status !== 'approved') throw new Error('Esta instalación no fue confirmada por el usuario.');
    if (this.now() - r.approvedAt > TICKET_TTL_MS) throw new Error('La confirmación caducó. Vuelve a pedirla.');
    const again = await this.hashFile(r.file).catch(() => '');
    if (again !== r.sha256) {
      r.status = 'failed';
      await this.log('run-failed', { id: r.id, reason: 'hash-changed' });
      throw new Error('El archivo cambió justo antes de ejecutarse. Auric no lo ejecutará.');
    }
    r.status = 'running';
    const child = this.spawn(r.exe, r.argv, { cwd: path.dirname(r.file), detached: true, stdio: 'ignore', windowsHide: false });
    const outcome = await new Promise(resolve => {
      let settled = false;
      const done = v => {
        if (settled) return;
        settled = true;
        resolve(v);
      };
      child.once('error', e => done({ error: e }));
      child.once('exit', code => done({ exited: true, code }));
      setTimeout(() => done({ running: true }), this.runWaitMs);
    });
    if (outcome.error) {
      r.status = 'failed';
      const elevation = /EACCES|UNKNOWN|740|elevation/i.test(String(outcome.error.code || '') + String(outcome.error.message || ''));
      await this.log('run-failed', { id: r.id, reason: String(outcome.error.message), elevation });
      const err = new Error(
        elevation
          ? 'Este instalador pide permisos de administrador y Auric no puede iniciarlo así. Ábrelo tú desde la carpeta de descargas.'
          : `No se pudo iniciar el instalador: ${outcome.error.message}`
      );
      err.code = elevation ? 'ELEVATION' : 'SPAWN';
      err.path = r.file;
      throw err;
    }
    try {
      child.unref?.();
    } catch {}
    await this.log('run-started', {
      id: r.id,
      pid: child.pid || 0,
      command: r.command,
      quickExit: !!outcome.exited,
      exitCode: outcome.code ?? null
    });
    r.status = 'started';
    return { pid: child.pid || 0, started: true, exited: !!outcome.exited, exitCode: outcome.code ?? null, command: r.command };
  }

  // Restos de descargas que se quedaron a medias (por ejemplo, la app se cerró): solo los «.part» que Auric creó en su
  // propia carpeta y con más de un día. Nunca toca ningún otro archivo.
  async cleanStale(maxAgeMs = 24 * 3600 * 1000) {
    let names = [];
    try {
      names = await fsp.readdir(this.downloadsDir);
    } catch {
      return 0;
    }
    let removed = 0;
    for (const name of names) {
      if (!name.endsWith('.part')) continue;
      const file = path.join(this.downloadsDir, name);
      try {
        const st = await fsp.lstat(file);
        if (!st.isFile() || this.now() - st.mtimeMs < maxAgeMs) continue;
        await fsp.rm(file, { force: true });
        removed++;
      } catch {}
    }
    if (removed) await this.log('cleaned', { count: removed });
    return removed;
  }

  async deleteDownloaded(id, trash) {
    const row = await this.findDownloaded({ downloadId: id });
    const file = canonical(row.path);
    const dir = canonical(this.downloadsDir);
    if (!file.startsWith(dir + path.sep)) throw new Error('Solo se pueden eliminar archivos de la carpeta de descargas de Auric.');
    if (trash) await trash(file);
    else await fsp.rm(file, { force: true });
    await this.log('deleted', { id: row.id, path: file });
    return true;
  }
}
function canonical(p) {
  try {
    return fs.realpathSync.native(path.resolve(String(p || '')));
  } catch {
    return path.resolve(String(p || ''));
  }
}
function decodeURIComponentSafe(s) {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}
// Marca de origen de Windows ("Mark of the Web"): activa SmartScreen / Vista protegida de Office al abrir el archivo.
async function defaultMark(file, url) {
  if (process.platform !== 'win32') return;
  await fsp.writeFile(`${file}:Zone.Identifier`, `[ZoneTransfer]\r\nZoneId=3\r\nHostUrl=${String(url).slice(0, 500)}\r\n`);
}
// Firma digital (Authenticode) en Windows. La ruta se pasa por variable de entorno para evitar inyección en el comando.
function defaultAuthenticode(file) {
  if (process.platform !== 'win32') return Promise.resolve({ status: 'unavailable' });
  return new Promise(resolve => {
    execFile(
      'powershell.exe',
      [
        '-NoProfile',
        '-NonInteractive',
        '-Command',
        "$s=Get-AuthenticodeSignature -LiteralPath $env:AURIC_CHECK_FILE; [pscustomobject]@{status=[string]$s.Status;subject=if($s.SignerCertificate){$s.SignerCertificate.Subject}else{''}} | ConvertTo-Json -Compress"
      ],
      { env: { ...process.env, AURIC_CHECK_FILE: file }, windowsHide: true, timeout: 20000 },
      (err, stdout) => {
        if (err) return resolve({ status: 'unavailable' });
        try {
          const o = JSON.parse(String(stdout || '{}'));
          resolve({ status: o.status || 'unavailable', subject: o.subject || '' });
        } catch {
          resolve({ status: 'unavailable' });
        }
      }
    );
  });
}

// Solo pruebas E2E (AURIC_E2E=1 + AURIC_E2E_SPAWN_LOG): en vez de abrir un programa de verdad, anota el comando exacto
// que habría ejecutado. En uso normal esta función no se usa nunca.
function e2eSpawnStub(logFile) {
  const { EventEmitter } = require('events');
  return (exe, argv) => {
    fs.appendFileSync(logFile, JSON.stringify({ exe, argv }) + '\n');
    const child = new EventEmitter();
    child.pid = 4242;
    child.unref = () => {};
    return child;
  };
}

// ── Registro de los IPC (main.js) ─────────────────────────────────────────────────────────────
function register({ app, ipcMain, shell, getWindow, hostMap }) {
  const downloadsDir = process.env.AURIC_DOWNLOADS_DIR || path.join(app.getPath('downloads'), 'Auric');
  const e2e = process.env.AURIC_E2E === '1';
  const mgr = new DownloadManager({
    downloadsDir,
    spawn: e2e && process.env.AURIC_E2E_SPAWN_LOG ? e2eSpawnStub(process.env.AURIC_E2E_SPAWN_LOG) : undefined,
    logFile: path.join(app.getPath('userData'), 'downloads-log.jsonl'),
    hostMap,
    userAgent: `Auric-Code/${app.getVersion ? app.getVersion() : '0'}`,
    emit: (name, detail) => {
      try {
        const win = getWindow?.();
        if (win && !win.isDestroyed()) win.webContents.send('auric:event', { name, detail });
      } catch {}
    }
  });
  mgr.cleanStale().catch(() => {});
  const guard = ctx => {
    if (String(ctx?.permission || '') === 'chat') throw new Error('El modo Chat no permite descargar archivos.');
  };
  const wrap =
    fn =>
    async (_e, ...args) => {
      try {
        return { ok: true, value: await fn(...args) };
      } catch (err) {
        return { ok: false, error: String(err?.message || err), code: err?.code || '', path: err?.path || '' };
      }
    };
  ipcMain.handle(
    'auric:dl-prepare',
    wrap((spec, ctx) => (guard(ctx), mgr.prepare(spec)))
  );
  ipcMain.handle(
    'auric:dl-approve',
    wrap(id => mgr.approve(id))
  );
  ipcMain.handle(
    'auric:dl-start',
    wrap(id => mgr.start(id))
  );
  ipcMain.handle(
    'auric:dl-cancel',
    wrap(id => mgr.cancel(id))
  );
  ipcMain.handle(
    'auric:dl-log',
    wrap(limit => mgr.readLog(limit))
  );
  ipcMain.handle(
    'auric:dl-dir',
    wrap(() => mgr.downloadsDir)
  );
  ipcMain.handle(
    'auric:dl-delete',
    wrap(id => mgr.deleteDownloaded(id, file => shell.trashItem(file)))
  );
  ipcMain.handle(
    'auric:dl-show',
    wrap(async id => {
      const row = await mgr.findDownloaded({ downloadId: id });
      shell.showItemInFolder(row.path);
      return true;
    })
  );
  ipcMain.handle(
    'auric:run-prepare',
    wrap((spec, ctx) => (guard(ctx), mgr.prepareRun(spec)))
  );
  ipcMain.handle(
    'auric:run-approve',
    wrap(id => mgr.approveRun(id))
  );
  ipcMain.handle(
    'auric:run-start',
    wrap(id => mgr.run(id))
  );
  return mgr;
}

module.exports = {
  register,
  DownloadManager,
  analyzeDomain,
  registrableDomain,
  sanitizeFileName,
  parseContentDisposition,
  sniffBuffer,
  checkSignature,
  parseChecksumText,
  validateInstallerArgs,
  doubleExtension,
  humanBytes,
  TYPE_TABLE,
  BLOCKED_EXT
};
